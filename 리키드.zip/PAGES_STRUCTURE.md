# 📄 페이지 구조 매핑 문서

디자인 파일과 개발 구조를 명확히 매핑한 문서입니다.

## 🗂️ 페이지 구조

### `/` - 홈 페이지 (`pages/index.vue`)

| 섹션 | 컴포넌트 | 디자인 설명 |
|------|----------|------------|
| Hero Section | `HeroSection` | 메인 히어로 영역<br>- 한국어 타이틀: "당신의 아이덴티티를 펼치는 공간"<br>- 영어 설명: "LIKID IS A CREATOR-DRIVEN LIFE SIMULATION GAME."<br>- LIKID 워터마크 배경 |

---

### `/about` - 소개 페이지 (`pages/about.vue`)

| 섹션 | 컴포넌트 | 디자인 설명 |
|------|----------|------------|
| What is LIKID? | `WhatIsLikidSection` | LIKID 소개 텍스트 영역<br>- "• WHAT IS LIKID?" 제목<br>- 여러 문단의 설명 텍스트 |
| Features | `FeaturesSection` | 4가지 특징 카드 그리드<br>- 검은 배경<br>- 01~04 번호<br>- 각 특징의 제목과 설명 |

---

### `/roadmap` - 로드맵 페이지 (`pages/roadmap.vue`)

| 섹션 | 컴포넌트 | 디자인 설명 |
|------|----------|------------|
| Roadmap | `RoadmapSection` | 로드맵 카드 그리드<br>- "• ROADMAP" 제목<br>- 기간별 마일스톤 카드 (2025 Q4 - 2026 Q2 등)<br>- 각 카드에 기능 리스트 |
| Coming Soon | `ComingSoonSection` | COMING SOON 배너<br>- 검은 배경<br>- 큰 "COMING SOON" 텍스트<br>- 설명 텍스트<br>- LIKID 워터마크 배경 |

---

### `/nft` - NFT 페이지 (`pages/nft.vue`)

| 섹션 | 컴포넌트 | 디자인 설명 |
|------|----------|------------|
| NFT Features | `NFTFeaturesSection` | NFT 특징 카드 그리드<br>- "• NFT 특징" 제목<br>- 4개 카드 (01~04)<br>- 각 카드에 특징 설명 |
| CTA | `CTASection` | 행동 유도 섹션<br>- "지금 바로 LIKID NFT로 여정을 떠나보세요." 텍스트<br>- "시작하기" 버튼 |

---

## 📁 파일 구조

```
pages/
  ├── index.vue      → / (홈)
  ├── about.vue      → /about (소개)
  ├── roadmap.vue    → /roadmap (로드맵)
  └── nft.vue        → /nft (NFT)

features/
  ├── HeroSection/              → 홈 페이지 히어로
  ├── WhatIsLikidSection/       → 소개 섹션
  ├── FeaturesSection/          → 특징 섹션
  ├── RoadmapSection/           → 로드맵 섹션
  ├── ComingSoonSection/        → Coming Soon 배너
  ├── NFTFeaturesSection/        → NFT 특징 섹션
  └── CTASection/               → CTA 섹션
```

---

## 🎨 디자인 파일에서 요청할 때

### ✅ 올바른 예시

```
페이지: /about
섹션 1: What is LIKID? (텍스트 영역)
섹션 2: Features (4개 카드 그리드)
```

### ❌ 피해야 할 예시

```
페이지: about 페이지 전체
→ 어떤 섹션인지 명확하지 않음
```

---

## 💡 커서 디자인 파일 주석 예시

디자인 파일 내부에 다음과 같이 주석을 추가하면 좋습니다:

```
[페이지: /]
- 섹션 1: Hero Section

[페이지: /about]  
- 섹션 1: What is LIKID?
- 섹션 2: Features

[페이지: /roadmap]
- 섹션 1: Roadmap
- 섹션 2: Coming Soon

[페이지: /nft]
- 섹션 1: NFT Features
- 섹션 2: CTA
```

---

## 🔄 공통 레이아웃

모든 페이지는 `layouts/default.vue`를 사용합니다:

- **Header** (`widgets/Header`) - 네비게이션
- **Footer** (`widgets/Footer`) - 푸터
- **Sidebar** (`widgets/Sidebar`) - 데스크톱 전용 사이드바 (1400px+)

