# 🏗️ LIKID 프로젝트 아키텍처 가이드

이 문서는 LIKID Nuxt.js 프로젝트의 아키텍처 구조와 유지보수 가이드를 설명합니다.

## 📋 목차

1. [아키텍처 개요](#1-아키텍처-개요)
2. [프로젝트 구조](#2-프로젝트-구조)
3. [레이어별 설명](#3-레이어별-설명)
4. [주요 기능 플로우](#4-주요-기능-플로우)
5. [코딩 컨벤션](#5-코딩-컨벤션)
6. [유지보수 가이드](#6-유지보수-가이드)
7. [주요 기술 스택](#7-주요-기술-스택)

---

## 1. 아키텍처 개요

### 1.1. 아키텍처 패턴

이 프로젝트는 **Feature-Sliced Design (FSD)** 아키텍처 패턴을 기반으로 구성되어 있습니다.

```
┌─────────────────────────────────────────┐
│           Pages (라우팅)                 │
├─────────────────────────────────────────┤
│         Widgets (복합 컴포넌트)           │
├─────────────────────────────────────────┤
│         Features (비즈니스 로직)          │
├─────────────────────────────────────────┤
│         Entities (도메인 모델)            │
├─────────────────────────────────────────┤
│         Shared (공통 유틸리티)            │
└─────────────────────────────────────────┘
```

### 1.2. 주요 원칙

- **단방향 데이터 흐름**: 상위 레이어에서 하위 레이어로만 의존
- **레이어 분리**: 각 레이어는 명확한 책임을 가짐
- **재사용성**: 하위 레이어의 컴포넌트는 상위 레이어에서 재사용 가능
- **선언형 프로그래밍**: 명령형 코드 대신 선언형 패턴 사용 (ES7+)

---

## 2. 프로젝트 구조

```
my-nuxt-app/
├── app.vue                    # 루트 컴포넌트
├── nuxt.config.ts             # Nuxt 설정
├── tsconfig.json              # TypeScript 설정
│
├── pages/                     # 페이지 레이어 (라우팅)
│   ├── index.vue              # 메인 페이지 (/)
│   ├── login.vue              # 로그인 페이지 (/login)
│   ├── signup.vue             # 회원가입 페이지 (/signup)
│   ├── find-account.vue       # 아이디/비밀번호 찾기 (/find-account)
│   ├── checkout.vue           # 결제 페이지 (/checkout)
│   ├── order-complete.vue     # 주문 완료 페이지 (/order-complete)
│   └── nft/
│       ├── index.vue          # NFT 목록 (/nft)
│       └── [id].vue           # NFT 상세 (/nft/:id)
│
├── layouts/                   # 레이아웃
│   ├── default.vue            # 기본 레이아웃 (Header + Footer)
│   └── signup.vue             # 회원가입/로그인 전용 레이아웃
│
├── widgets/                   # 위젯 레이어 (복합 컴포넌트)
│   ├── Header/                # 전역 헤더
│   ├── Footer/                # 전역 푸터
│   └── SignupHeader/          # 회원가입/로그인 페이지 헤더
│
├── features/                  # 기능 레이어 (비즈니스 로직)
│   ├── auth/                  # 인증 관련
│   │   ├── useLogin.ts        # 로그인 composable
│   │   ├── useSignUp.ts       # 회원가입 composable
│   │   ├── useLogout.ts       # 로그아웃 composable
│   │   ├── useTokenRefresh.ts # 토큰 갱신 composable
│   │   └── usePortoneCertification.ts # Portone 인증 composable
│   ├── HeroSection/           # 히어로 섹션
│   ├── FeaturesSection/       # 특징 섹션
│   ├── RoadmapSection/        # 로드맵 섹션
│   ├── ComingSoonSection/     # Coming Soon 섹션
│   ├── NFTFeaturesSection/    # NFT 특징 섹션
│   ├── CTASection/            # CTA 섹션
│   ├── SignupForm/            # 회원가입 폼
│   ├── LoginForm/             # 로그인 폼
│   ├── FindAccountForm/       # 아이디/비밀번호 찾기 폼
│   ├── NFTArtworkGrid/        # NFT 작품 그리드
│   └── NFTDetailDescription/  # NFT 상세 설명
│
├── entities/                  # 엔티티 레이어 (도메인 모델)
│   ├── user/                  # 사용자 도메인
│   │   ├── types.ts           # 사용자 타입 정의
│   │   └── index.ts           # 엔티티 export
│   └── nft/                   # NFT 도메인
│       └── types.ts           # NFT 타입 정의
│
├── shared/                    # 공유 레이어 (공통 유틸리티)
│   └── api/                   # API 클라이언트
│       ├── instance.ts        # Axios 인스턴스 (인터셉터 포함)
│       ├── auth.ts            # 인증 API
│       ├── nft.ts             # NFT API
│       ├── order.ts           # 주문 API
│       ├── portone.ts         # Portone API
│       ├── errors.ts          # 에러 타입
│       └── index.ts           # API export
│
├── components/                # 공통 UI 컴포넌트
│   └── ui/                    # 기본 UI 컴포넌트
│       ├── Button.vue         # 버튼
│       ├── Card.vue           # 카드
│       ├── Container.vue      # 컨테이너
│       ├── EyeIcon.vue        # 눈 아이콘
│       ├── Spinner.vue        # 로딩 스피너
│       ├── Toast.vue          # 토스트 메시지
│       └── index.ts           # 컴포넌트 export
│
├── stores/                    # Pinia 스토어
│   ├── auth.ts                # 인증 상태 관리
│   ├── toast.ts               # 토스트 메시지 상태 관리
│   └── ui.ts                  # UI 상태 관리
│
├── styles/                    # 스타일 파일
│   ├── global.css             # 전역 스타일
│   ├── pages/                 # 페이지별 스타일
│   ├── features/              # 기능별 스타일
│   ├── widgets/               # 위젯별 스타일
│   └── components/            # 컴포넌트별 스타일
│
├── plugins/                   # Nuxt 플러그인
│   ├── auth.client.ts         # 인증 초기화 플러그인
│   └── error-handler.client.ts # 에러 핸들러 플러그인
│
└── public/                    # 정적 파일
    ├── favicon.ico            # 파비콘
    ├── logo.png               # 로고
    └── robots.txt             # robots.txt
```

---

## 3. 레이어별 설명

### 3.1. Pages 레이어

**책임**: 라우팅 및 페이지 구성

- Nuxt.js의 파일 기반 라우팅 사용
- 각 페이지는 `definePageMeta`로 레이아웃 지정
- 페이지는 주로 Features 레이어의 컴포넌트를 조합

**예시**:
```vue
<!-- pages/index.vue -->
<template>
  <div>
    <HeroSection />
    <FeaturesSection />
    <RoadmapSection />
  </div>
</template>

<script setup lang="ts">
definePageMeta({
  layout: 'default'
})
</script>
```

### 3.2. Widgets 레이어

**책임**: 복합 컴포넌트 (여러 Features를 조합)

- 전역적으로 사용되는 복합 컴포넌트
- 예: Header, Footer, SignupHeader

**특징**:
- 여러 Features나 Entities를 조합
- 페이지 레벨의 복잡한 UI 구성

### 3.3. Features 레이어

**책임**: 비즈니스 로직 및 기능 단위

- 독립적인 기능 단위
- Composable 패턴 사용 (Vue 3 Composition API)
- 각 Feature는 자체 상태 관리 및 비즈니스 로직 포함

**구조**:
```
features/
  └── FeatureName/
      ├── FeatureName.vue      # 메인 컴포넌트
      └── (선택적) useFeature.ts # Composable
```

**예시 - Composable**:
```typescript
// features/auth/useLogin.ts
export const useLogin = () => {
  const isLoading = ref(false)
  const execute = async (data: LoginRequest) => {
    // 로그인 로직
  }
  return { execute, isLoading }
}
```

### 3.4. Entities 레이어

**책임**: 도메인 모델 및 타입 정의

- 비즈니스 도메인의 타입 정의
- API 응답/요청 타입
- 도메인별로 폴더 분리

**예시**:
```typescript
// entities/user/types.ts
export interface User {
  id: string
  name: string
  email: string
}

export interface LoginRequest {
  loginId: string
  password: string
}
```

### 3.5. Shared 레이어

**책임**: 공통 유틸리티 및 인프라 코드

- API 클라이언트
- 공통 유틸리티 함수
- 설정 파일

**API 클라이언트 구조**:
```typescript
// shared/api/instance.ts
export const apiClient = axios.create({
  baseURL: import.meta.env.NUXT_PUBLIC_API_BASE_URL
})

// Request/Response 인터셉터
apiClient.interceptors.request.use(...)
apiClient.interceptors.response.use(...)
```

---

## 4. 주요 기능 플로우

### 4.1. 회원가입 플로우

```mermaid
flowchart TD
    A[회원가입 페이지 접속] --> B[폼 입력]
    B --> C[본인인증 요청]
    C --> D[Portone SDK 팝업]
    D --> E{인증 성공?}
    E -->|실패| F[에러 토스트 표시]
    E -->|성공| G[폼 자동 채우기]
    G --> H[필수 정보 입력]
    H --> I[아이디 중복 확인]
    I --> J{중복?}
    J -->|중복| K[에러 표시]
    J -->|사용 가능| L[회원가입 API 호출]
    L --> M{성공?}
    M -->|실패| N[에러 토스트 표시]
    M -->|성공| O[토큰 저장]
    O --> P[로그인 페이지로 이동]
    F --> B
    K --> B
    N --> B
```

### 4.2. 로그인 플로우

```mermaid
flowchart TD
    A[로그인 페이지 접속] --> B[아이디/비밀번호 입력]
    B --> C[로그인 유지 체크박스 선택]
    C --> D[로그인 API 호출]
    D --> E{인증 성공?}
    E -->|실패| F[에러 토스트 표시]
    E -->|성공| G{로그인 유지?}
    G -->|예| H[localStorage에 토큰 저장]
    G -->|아니오| I[sessionStorage에 토큰 저장]
    H --> J[메인 페이지로 이동]
    I --> J
    F --> B
```

### 4.3. 본인인증 플로우 (Portone)

```mermaid
sequenceDiagram
    participant U as 사용자
    participant F as Frontend
    participant B as Backend API
    participant P as Portone SDK
    participant PR as Portone REST API

    U->>F: 본인인증 요청 버튼 클릭
    F->>B: POST /api/v1/auth/kyc/session
    B-->>F: verificationId, authUrl 반환
    F->>P: SDK 로드 (CDN)
    P-->>F: SDK 준비 완료
    F->>P: requestIdentityVerification()
    P->>U: 본인인증 팝업 표시
    U->>P: 본인인증 정보 입력
    P-->>F: identityVerificationTxId 반환
    F->>B: POST /api/v1/auth/kyc/verify
    Note over B,PR: Backend에서 Portone REST API 호출
    B->>PR: GET /v2/certifications/:imp_uid
    PR-->>B: 인증 결과 반환
    B-->>F: identityToken, verification 반환
    F->>F: 폼 자동 채우기
    F-->>U: 인증 완료 토스트 표시
```

### 4.4. NFT 구매 플로우

```mermaid
flowchart TD
    A[NFT 목록 페이지] --> B[NFT 클릭]
    B --> C[NFT 상세 페이지]
    C --> D{로그인 상태?}
    D -->|미로그인| E[로그인 페이지로 이동]
    D -->|로그인| F[수량 선택]
    F --> G[구매하기 버튼 클릭]
    G --> H[결제 페이지]
    H --> I[입금은행 선택]
    I --> J[입금자명 입력]
    J --> K[주문 API 호출]
    K --> L{주문 성공?}
    L -->|실패| M[에러 토스트 표시]
    L -->|성공| N[주문 완료 페이지]
    M --> H
    E --> O[로그인 완료]
    O --> C
```

### 4.5. 토큰 갱신 플로우

```mermaid
sequenceDiagram
    participant C as Client
    participant I as Axios Interceptor
    participant A as Auth Store
    participant B as Backend API

    C->>I: API 요청
    I->>I: 토큰 만료 확인
    alt 토큰 만료 임박 또는 만료
        I->>A: refreshToken 가져오기
        A-->>I: refreshToken 반환
        I->>B: POST /api/v1/auth/token/refresh
        alt 갱신 성공
            B-->>I: 새 accessToken, refreshToken
            I->>A: 새 토큰 저장
            I->>I: 원래 요청 재시도
            I-->>C: 응답 반환
        else 갱신 실패
            I->>A: 로그아웃 처리
            I-->>C: 401 에러
        end
    else 토큰 유효
        I->>B: 원래 요청 전송
        B-->>I: 응답 반환
        I-->>C: 응답 반환
    end
```

### 4.6. API 호출 플로우

```mermaid
flowchart TD
    A[컴포넌트/Composable] --> B[API 함수 호출]
    B --> C[Axios Instance]
    C --> D{인증 필요?}
    D -->|예| E[Request Interceptor]
    D -->|아니오| F[API 요청]
    E --> G{토큰 유효?}
    G -->|만료| H[토큰 갱신]
    G -->|유효| I[Authorization 헤더 추가]
    H --> J{갱신 성공?}
    J -->|실패| K[로그아웃 처리]
    J -->|성공| I
    I --> F
    F --> L[Backend API]
    L --> M[Response Interceptor]
    M --> N{응답 성공?}
    N -->|401| O[토큰 갱신 시도]
    N -->|성공| P[데이터 반환]
    N -->|에러| Q[에러 처리]
    O --> R{갱신 성공?}
    R -->|성공| F
    R -->|실패| K
    P --> S[컴포넌트 업데이트]
    Q --> T[에러 토스트 표시]
```

### 4.7. 전체 인증 플로우

```mermaid
stateDiagram-v2
    [*] --> 비로그인
    비로그인 --> 로그인중: 로그인 요청
    로그인중 --> 로그인완료: 인증 성공
    로그인중 --> 비로그인: 인증 실패
    로그인완료 --> 토큰갱신중: 토큰 만료 임박
    토큰갱신중 --> 로그인완료: 갱신 성공
    토큰갱신중 --> 비로그인: 갱신 실패
    로그인완료 --> 비로그인: 로그아웃
    비로그인 --> 회원가입중: 회원가입 요청
    회원가입중 --> 비로그인: 가입 실패
    회원가입중 --> 로그인완료: 가입 성공
```

### 4.8. 페이지 라우팅 플로우

```mermaid
flowchart LR
    A[/ 메인] --> B[/nft 목록]
    A --> C[/login]
    A --> D[/signup]
    C --> E[로그인 성공]
    E --> A
    D --> F[회원가입 성공]
    F --> C
    B --> G[/nft/:id 상세]
    G --> H{로그인?}
    H -->|예| I[/checkout]
    H -->|아니오| C
    I --> J[/order-complete]
    A --> K[/find-account]
```

---

## 5. 코딩 컨벤션

### 4.1. 파일 명명 규칙

- **컴포넌트**: PascalCase (예: `SignupForm.vue`)
- **Composable**: camelCase with `use` prefix (예: `useLogin.ts`)
- **타입 파일**: `types.ts` 또는 `index.ts`
- **스타일 파일**: `ComponentName.module.css`

### 4.2. 코드 스타일

#### 선언형 프로그래밍 우선

**❌ 명령형 (피해야 할 패턴)**:
```typescript
let result = []
for (let i = 0; i < items.length; i++) {
  if (items[i].active) {
    result.push(items[i])
  }
}
```

**✅ 선언형 (권장 패턴)**:
```typescript
const result = items.filter(item => item.active)
```

#### const 사용 우선

**❌ 피해야 할 패턴**:
```typescript
let errorMessage = '기본 메시지'
if (condition) {
  errorMessage = '변경된 메시지'
}
```

**✅ 권장 패턴**:
```typescript
const errorMessage = condition 
  ? '변경된 메시지' 
  : '기본 메시지'
```

### 4.3. TypeScript 사용

- 모든 파일에서 TypeScript 사용
- `any` 타입 최소화
- 인터페이스로 타입 명시

**예시**:
```typescript
interface User {
  id: string
  name: string
}

const user: User = {
  id: '1',
  name: 'John'
}
```

### 4.4. CSS 모듈 사용

- 모든 컴포넌트 스타일은 CSS Modules 사용
- 클래스명은 kebab-case (예: `signupForm__input`)
- 전역 스타일은 `styles/global.css`에만 정의

**예시**:
```vue
<template>
  <div :class="styles.signupForm">
    <input :class="styles.signupForm__input" />
  </div>
</template>

<script setup lang="ts">
import styles from '~/styles/features/SignupForm.module.css'
</script>
```

---

## 6. 유지보수 가이드

### 5.1. 새 기능 추가하기

#### 1단계: Entity 타입 정의
```typescript
// entities/newFeature/types.ts
export interface NewFeatureData {
  id: string
  name: string
}
```

#### 2단계: API 클라이언트 추가
```typescript
// shared/api/newFeature.ts
import { apiClient } from './instance'

export async function getNewFeature(id: string) {
  const response = await apiClient.get(`/api/v1/new-feature/${id}`)
  return response.data
}
```

#### 3단계: Composable 생성 (필요시)
```typescript
// features/newFeature/useNewFeature.ts
export const useNewFeature = () => {
  const data = ref<NewFeatureData | null>(null)
  const isLoading = ref(false)
  
  const fetchData = async (id: string) => {
    isLoading.value = true
    try {
      data.value = await getNewFeature(id)
    } finally {
      isLoading.value = false
    }
  }
  
  return { data, isLoading, fetchData }
}
```

#### 4단계: Feature 컴포넌트 생성
```vue
<!-- features/NewFeature/NewFeature.vue -->
<template>
  <div :class="styles.newFeature">
    <!-- 컴포넌트 내용 -->
  </div>
</template>

<script setup lang="ts">
import styles from '~/styles/features/NewFeature.module.css'
</script>
```

#### 5단계: 페이지에 통합
```vue
<!-- pages/new-feature.vue -->
<template>
  <NewFeature />
</template>

<script setup lang="ts">
import NewFeature from '~/features/NewFeature/NewFeature.vue'
</script>
```

### 5.2. API 수정하기

#### API 엔드포인트 변경

1. **API 클라이언트 수정** (`shared/api/`)
2. **타입 정의 업데이트** (`entities/*/types.ts`)
3. **Composable 업데이트** (`features/*/use*.ts`)
4. **컴포넌트 업데이트** (API를 사용하는 컴포넌트)

#### 환경 변수 추가

1. `.env` 파일에 추가
2. `nuxt.config.ts`에서 필요시 설정
3. `import.meta.env`로 접근

### 5.3. 스타일 수정하기

#### 컴포넌트 스타일 수정

1. 해당 컴포넌트의 CSS Module 파일 수정
   - 위치: `styles/features/`, `styles/widgets/`, `styles/pages/`
2. 클래스명은 kebab-case 유지
3. 반응형 디자인 고려 (mobile, tablet, desktop)

#### 전역 스타일 수정

- `styles/global.css` 파일 수정
- 전역 스타일은 최소화 권장

### 5.4. 상태 관리 수정하기

#### Pinia Store 추가/수정

1. `stores/` 폴더에 새 store 파일 생성
2. `defineStore` 사용
3. 필요한 곳에서 `useStore()` 호출

**예시**:
```typescript
// stores/newStore.ts
export const useNewStore = defineStore('newStore', {
  state: () => ({
    data: null
  }),
  actions: {
    setData(data: any) {
      this.data = data
    }
  }
})
```

### 5.5. 에러 처리

#### API 에러 처리

- 모든 API 호출은 try-catch로 감싸기
- Toast 메시지로 사용자에게 알림
- 에러 로깅 (개발 환경)

**예시**:
```typescript
try {
  const response = await apiCall()
  toastStore.success('성공 메시지')
} catch (error: any) {
  const errorMessage = error.response?.data?.message || '에러 메시지'
  toastStore.error(errorMessage)
}
```

### 5.6. 테스트 및 디버깅

#### 개발 서버 실행
```bash
npm run dev
```

#### 프로덕션 빌드
```bash
npm run build
npm run generate  # 정적 사이트 생성
```

#### 디버깅 팁

1. **브라우저 콘솔**: 클라이언트 사이드 에러 확인
2. **Network 탭**: API 요청/응답 확인
3. **Vue DevTools**: 컴포넌트 상태 확인
4. **TypeScript**: 타입 에러 확인

---

## 7. 주요 기술 스택

### 6.1. 프레임워크 및 라이브러리

- **Nuxt.js 4**: Vue.js 기반 프레임워크
- **Vue 3**: Composition API 사용
- **TypeScript**: 타입 안정성
- **Pinia**: 상태 관리
- **Axios**: HTTP 클라이언트

### 6.2. 스타일링

- **CSS Modules**: 컴포넌트 스타일 격리
- **PostCSS/Autoprefixer**: 크로스 브라우저 호환성

### 6.3. 외부 서비스

- **Portone**: 본인인증 및 결제
- **Kakao 주소 검색 API**: 우편번호 검색

### 6.4. 배포

- **CloudFront + S3**: 정적 사이트 호스팅
- **SPA 모드**: `ssr: false` 설정

---

## 8. 주의사항

### 7.1. 레이어 의존성 규칙

- **상위 레이어는 하위 레이어에만 의존**
- Pages → Widgets → Features → Entities → Shared
- 하위 레이어는 상위 레이어를 import 하지 않음

### 7.2. 환경 변수

- `.env` 파일은 Git에 커밋하지 않음
- 환경 변수는 `import.meta.env`로 접근
- 클라이언트 접근 가능한 변수는 `NUXT_PUBLIC_` prefix 사용

### 7.3. SSR 고려사항

- 현재 프로젝트는 `ssr: false` (SPA 모드)
- 클라이언트 전용 코드는 `import.meta.client` 체크
- 서버 전용 코드는 `import.meta.server` 체크

### 7.4. 성능 최적화

- 이미지 최적화 (WebP, lazy loading)
- 코드 스플리팅 (자동)
- 불필요한 리렌더링 방지 (computed, watch 적절히 사용)

---

## 9. 참고 문서

- [Nuxt.js 공식 문서](https://nuxt.com/docs)
- [Vue 3 공식 문서](https://vuejs.org/)
- [Pinia 공식 문서](https://pinia.vuejs.org/)
- [Feature-Sliced Design](https://feature-sliced.design/)
- [PORTONE_SETUP.md](./PORTONE_SETUP.md) - Portone 설정 가이드
- [CLOUDFRONT_SETUP.md](./CLOUDFRONT_SETUP.md) - CloudFront 배포 가이드

---

**마지막 업데이트**: 2024년

