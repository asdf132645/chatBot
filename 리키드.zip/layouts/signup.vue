<template>
  <div class="likid-layout">
    <SignupHeader />
    <main class="likid-layout__main">
      <slot />
    </main>
    <Footer />
  </div>
</template>

<script setup lang="ts">
import SignupHeader from '~/widgets/SignupHeader/SignupHeader.vue'
import Footer from '~/widgets/Footer/Footer.vue'
</script>

<style scoped>
.likid-layout {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.likid-layout__main {
  flex: 1;
  position: relative;
}
</style>

