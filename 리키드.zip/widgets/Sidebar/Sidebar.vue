<template>
  <aside class="likid-sidebar">
    <div class="likid-sidebar__content">
      <div class="likid-sidebar__header">
        <div class="likid-sidebar__logo">LIKID</div>
      </div>
      
      <div class="likid-sidebar__section">
        <h2 class="likid-sidebar__title">당신의 아이덴티티를 펼치는 공간</h2>
      </div>

      <div class="likid-sidebar__section">
        <h3 class="likid-sidebar__subtitle">• WHAT IS LIKID?</h3>
        <p class="likid-sidebar__text">
          LIKID는 크리에이터 중심의 라이프 시뮬레이션 게임입니다.
        </p>
      </div>

      <div class="likid-sidebar__section">
        <div class="likid-sidebar__features">
          <div class="likid-sidebar__feature">
            <span class="likid-sidebar__feature-number">01</span>
            <span class="likid-sidebar__feature-title">현실의 제약에서 벗어난 도전</span>
          </div>
          <div class="likid-sidebar__feature">
            <span class="likid-sidebar__feature-number">02</span>
            <span class="likid-sidebar__feature-title">자아실현의 무대</span>
          </div>
          <div class="likid-sidebar__feature">
            <span class="likid-sidebar__feature-number">03</span>
            <span class="likid-sidebar__feature-title">창작과 생활의 결합</span>
          </div>
          <div class="likid-sidebar__feature">
            <span class="likid-sidebar__feature-number">04</span>
            <span class="likid-sidebar__feature-title">확장 가능한 가능성</span>
          </div>
        </div>
      </div>

      <div class="likid-sidebar__section">
        <h3 class="likid-sidebar__subtitle">• ROADMAP</h3>
        <div class="likid-sidebar__roadmap">
          <div class="likid-sidebar__roadmap-item">
            <div class="likid-sidebar__roadmap-period">2025 Q4 - 2026 Q2</div>
            <ul class="likid-sidebar__roadmap-list">
              <li>UGC 시스템 출시</li>
              <li>NFT 통합</li>
            </ul>
          </div>
          <div class="likid-sidebar__roadmap-item">
            <div class="likid-sidebar__roadmap-period">2026 Q3 - 2026 Q4</div>
            <ul class="likid-sidebar__roadmap-list">
              <li>커뮤니티 기능 강화</li>
            </ul>
          </div>
          <div class="likid-sidebar__roadmap-item">
            <div class="likid-sidebar__roadmap-period">2027 Q1 - 2027 Q2</div>
            <ul class="likid-sidebar__roadmap-list">
              <li>모바일 버전 출시</li>
            </ul>
          </div>
          <div class="likid-sidebar__roadmap-item">
            <div class="likid-sidebar__roadmap-period">2027 Q3 - 2027 Q4</div>
            <ul class="likid-sidebar__roadmap-list">
              <li>글로벌 확장</li>
            </ul>
          </div>
        </div>
      </div>

      <div class="likid-sidebar__section">
        <div class="likid-sidebar__coming-soon">COMING SOON</div>
      </div>

      <div class="likid-sidebar__section">
        <h3 class="likid-sidebar__subtitle">• NFT 특징</h3>
        <div class="likid-sidebar__nft-features">
          <div class="likid-sidebar__nft-feature">
            <span class="likid-sidebar__feature-number">01</span>
            <span class="likid-sidebar__feature-title">브랜드 IP 기반의 한정 디지털 아트워크 소유</span>
          </div>
          <div class="likid-sidebar__nft-feature">
            <span class="likid-sidebar__feature-number">02</span>
            <span class="likid-sidebar__feature-title">게임 아이템 스킨으로 NFT 디지털 아트워크 활용 가능</span>
          </div>
          <div class="likid-sidebar__nft-feature">
            <span class="likid-sidebar__feature-number">03</span>
            <span class="likid-sidebar__feature-title">도시 내 특정 공간 & 이벤트 입장권 활용</span>
          </div>
          <div class="likid-sidebar__nft-feature">
            <span class="likid-sidebar__feature-number">04</span>
            <span class="likid-sidebar__feature-title">NFT 컬렉터 전용 커뮤니티 & 사전 이벤트 참여</span>
          </div>
        </div>
      </div>

      <div class="likid-sidebar__section">
        <div class="likid-sidebar__cta">
          지금 바로 LIKID NFT로 여정을 떠나보세요.
        </div>
      </div>

      <div class="likid-sidebar__footer-logo">LIKID</div>
    </div>
  </aside>
</template>

<script setup lang="ts">
</script>

<style scoped>
.likid-sidebar {
  display: none;
  width: 320px;
  position: fixed;
  right: 0;
  top: 0;
  height: 100vh;
  overflow-y: auto;
  background-color: #fff;
  border-left: 1px solid #e5e5e5;
  padding: 24px;
}

.likid-sidebar__content {
  display: flex;
  flex-direction: column;
  gap: 32px;
}

.likid-sidebar__logo {
  font-size: 20px;
  font-weight: 700;
  letter-spacing: 2px;
}

.likid-sidebar__title {
  font-size: 18px;
  font-weight: 600;
  line-height: 1.5;
  margin: 0;
}

.likid-sidebar__subtitle {
  font-size: 14px;
  font-weight: 600;
  margin: 0 0 12px 0;
}

.likid-sidebar__text {
  font-size: 12px;
  line-height: 1.6;
  margin: 0;
  color: #666;
}

.likid-sidebar__features,
.likid-sidebar__nft-features {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.likid-sidebar__feature,
.likid-sidebar__nft-feature {
  display: flex;
  gap: 12px;
  align-items: flex-start;
}

.likid-sidebar__feature-number {
  font-size: 12px;
  font-weight: 700;
  min-width: 24px;
}

.likid-sidebar__feature-title {
  font-size: 12px;
  line-height: 1.5;
}

.likid-sidebar__roadmap {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.likid-sidebar__roadmap-item {
  padding-bottom: 20px;
  border-bottom: 1px solid #e5e5e5;
}

.likid-sidebar__roadmap-item:last-child {
  border-bottom: none;
}

.likid-sidebar__roadmap-period {
  font-size: 12px;
  font-weight: 600;
  margin-bottom: 8px;
}

.likid-sidebar__roadmap-list {
  font-size: 11px;
  line-height: 1.6;
  margin: 0;
  padding-left: 16px;
  color: #666;
}

.likid-sidebar__coming-soon {
  font-size: 24px;
  font-weight: 700;
  letter-spacing: 2px;
  text-align: center;
  padding: 24px;
  background-color: #000;
  color: #fff;
}

.likid-sidebar__cta {
  font-size: 14px;
  font-weight: 600;
  line-height: 1.6;
  text-align: center;
}

.likid-sidebar__footer-logo {
  text-align: center;
  font-size: 32px;
  font-weight: 700;
  letter-spacing: 2px;
  opacity: 0.1;
  margin-top: auto;
  padding-top: 32px;
}

@media (min-width: 1400px) {
  .likid-sidebar {
    display: block;
  }
}
</style>
