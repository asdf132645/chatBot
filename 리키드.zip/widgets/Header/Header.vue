<template>
  <header :class="styles.likidHeader">
    <Container>
      <nav :class="styles.likidHeader__nav">
        <NuxtLink to="/" :class="styles.likidHeader__logo">
          <img src="/logo.png" alt="LIKID" :class="styles.likidHeader__logoImage" />
        </NuxtLink>
        <ul :class="styles.likidHeader__menu">
          <li><a href="#home" @click.prevent="scrollToSection('home')">홈</a></li>
          <li><a href="#home" @click.prevent="scrollToSection('home')">소개</a></li>
          <li><a href="#features" @click.prevent="scrollToSection('features')">핵심경험</a></li>
          <li><a href="#roadmap" @click.prevent="scrollToSection('roadmap')">로드맵</a></li>
          <li><a href="#nft" @click.prevent="scrollToSection('nft')">NFT 특징</a></li>
        </ul>
        <div :class="styles.likidHeader__actions">
          <NuxtLink
            v-if="!isNFTPage"
            to="/nft"
            :class="[styles.likidHeader__btn, styles['likidHeader__btn--primary']]"
          >
            NFT 구매하기
            <span :class="styles.likidHeader__arrow">↗</span>
          </NuxtLink>
          <NuxtLink
            v-else
            to="/"
            :class="[styles.likidHeader__btn, styles['likidHeader__btn--primary']]"
          >
            메인 페이지
            <span :class="styles.likidHeader__arrow">↗</span>
          </NuxtLink>
          <template v-if="!isLoggedIn">
            <button 
              type="button"
              :class="[styles.likidHeader__btn, styles['likidHeader__btn--secondary']]"
              @click="handleSignupClick"
            >
              회원가입
            </button>
            <button 
              type="button"
              :class="[styles.likidHeader__btn, styles['likidHeader__btn--secondary']]"
              @click="handleLoginClick"
            >
              로그인
            </button>
          </template>
          <button 
            v-else
            type="button"
            :class="[styles.likidHeader__btn, styles['likidHeader__btn--secondary']]"
            @click="handleLogoutClick"
            :disabled="isLoggingOut"
          >
            {{ isLoggingOut ? '로그아웃 중...' : '로그아웃' }}
          </button>
        </div>
        <button
          :class="styles.likidHeader__mobileMenu"
          @click="toggleMobileMenu"
          aria-label="메뉴"
        >
          <span></span>
          <span></span>
          <span></span>
        </button>
      </nav>
      <ul
        v-if="uiStore.isMobileMenuOpen"
        :class="styles.likidHeader__mobileMenuList"
      >
        <li><a href="#home" @click.prevent="handleMobileLink('home')">홈</a></li>
        <li><a href="#home" @click.prevent="handleMobileLink('home')">소개</a></li>
        <li><a href="#features" @click.prevent="handleMobileLink('features')">핵심경험</a></li>
        <li><a href="#roadmap" @click.prevent="handleMobileLink('roadmap')">로드맵</a></li>
        <li><a href="#nft" @click.prevent="handleMobileLink('nft')">NFT 특징</a></li>
        <li v-if="!isLoggedIn"><NuxtLink to="/signup" @click="closeMobileMenu">회원가입</NuxtLink></li>
        <li v-if="!isLoggedIn"><NuxtLink to="/login" @click="closeMobileMenu">로그인</NuxtLink></li>
        <li v-else><button type="button" @click="handleLogoutClick" :disabled="isLoggingOut" style="background: none; border: none; color: inherit; font-size: inherit; cursor: pointer; width: 100%; text-align: left; padding: 0;">{{ isLoggingOut ? '로그아웃 중...' : '로그아웃' }}</button></li>
      </ul>
    </Container>
  </header>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { navigateTo } from '#app'
import { Container } from '@/components/ui'
import { useUIStore } from '~/stores/ui'
import { useAuthStore } from '~/stores/auth'
import { useLogout } from '~/features/auth'
import styles from '~/styles/widgets/Header.module.css'

const route = useRoute()
const uiStore = useUIStore()
const authStore = useAuthStore()
const { execute: logout, isLoading: isLoggingOut } = useLogout()

const isNFTPage = computed(() => route.path === '/nft')
const isLoggedIn = computed(() => authStore.isLoggedIn)

const toggleMobileMenu = () => {
  uiStore.toggleMobileMenu()
}

const closeMobileMenu = () => {
  uiStore.closeMobileMenu()
}

const scrollToSection = (sectionId: string) => {
  if (import.meta.server) return
  
  if (route.path !== '/') {
    navigateTo('/')
    setTimeout(() => {
      const element = document.getElementById(sectionId)
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' })
      }
    }, 100)
  } else {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }
}

const handleMobileLink = (sectionId: string) => {
  closeMobileMenu()
  scrollToSection(sectionId)
}

const handleSignupClick = async (e: Event) => {
  e.preventDefault()
  e.stopPropagation()
  closeMobileMenu()
  try {
    await navigateTo('/signup')
  } catch (error) {
    console.error('Navigation error:', error)
    if (import.meta.client) {
      window.location.href = '/signup'
    }
  }
}

const handleLoginClick = async (e: Event) => {
  e.preventDefault()
  e.stopPropagation()
  closeMobileMenu()
  try {
    await navigateTo('/login')
  } catch (error) {
    console.error('Navigation error:', error)
    if (import.meta.client) {
      window.location.href = '/login'
    }
  }
}

const handleLogoutClick = async (e: Event) => {
  e.preventDefault()
  e.stopPropagation()
  closeMobileMenu()
  await logout()
}
</script>
