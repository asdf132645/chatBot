<template>
  <header :class="styles.signupHeader">
    <Container>
      <nav :class="styles.signupHeader__nav">
        <NuxtLink to="/" :class="styles.signupHeader__logo">
          <img src="/logo.png" alt="LIKID" :class="styles.signupHeader__logoImage" />
        </NuxtLink>
        <div :class="styles.signupHeader__actions">
          <NuxtLink to="/" :class="[styles.signupHeader__btn, styles['signupHeader__btn--primary']]">
            메인 페이지
            <span :class="styles.signupHeader__arrow">↗</span>
          </NuxtLink>
          <button 
            type="button"
            :class="[styles.signupHeader__btn, styles['signupHeader__btn--secondary']]"
            @click="handleSignupClick"
          >
            회원가입
          </button>
          <button 
            type="button"
            :class="[styles.signupHeader__btn, styles['signupHeader__btn--secondary']]"
            @click="handleLoginClick"
          >
            로그인
          </button>
        </div>
        <button
          :class="styles.signupHeader__mobileMenu"
          @click="toggleMobileMenu"
          aria-label="메뉴"
        >
          <span></span>
          <span></span>
          <span></span>
        </button>
      </nav>
      <ul
        v-if="uiStore.isMobileMenuOpen"
        :class="styles.signupHeader__mobileMenuList"
      >
        <li><NuxtLink to="/" @click="closeMobileMenu">메인 페이지</NuxtLink></li>
        <li><NuxtLink to="/signup" @click="closeMobileMenu">회원가입</NuxtLink></li>
        <li><NuxtLink to="/login" @click="closeMobileMenu">로그인</NuxtLink></li>
      </ul>
    </Container>
  </header>
</template>

<script setup lang="ts">
import { navigateTo } from '#app'
import { Container } from '@/components/ui'
import { useUIStore } from '~/stores/ui'
import styles from '~/styles/widgets/SignupHeader.module.css'

const uiStore = useUIStore()

const toggleMobileMenu = () => {
  uiStore.toggleMobileMenu()
}

const closeMobileMenu = () => {
  uiStore.closeMobileMenu()
}

const handleSignupClick = async (e: Event) => {
  e.preventDefault()
  e.stopPropagation()
  closeMobileMenu()
  try {
    await navigateTo('/signup')
  } catch (error) {
    console.error('Navigation error:', error)
    if (import.meta.client) {
      window.location.href = '/signup'
    }
  }
}

const handleLoginClick = async (e: Event) => {
  e.preventDefault()
  e.stopPropagation()
  closeMobileMenu()
  try {
    await navigateTo('/login')
  } catch (error) {
    console.error('Navigation error:', error)
    if (import.meta.client) {
      window.location.href = '/login'
    }
  }
}
</script>

