<template>
  <footer :class="styles.likidFooter">
    <Container>
      <div :class="styles.likidFooter__top">
        <nav :class="styles.likidFooter__nav">
          <a href="#home" @click.prevent="scrollToSection('home')">HOME</a>
          <a href="#about" @click.prevent="scrollToSection('about')">ABOUT</a>
          <a href="#features" @click.prevent="scrollToSection('features')">CORE EXPERIENCES</a>
          <a href="#roadmap" @click.prevent="scrollToSection('roadmap')">ROADMAP</a>
          <a href="#nft" @click.prevent="scrollToSection('nft')">NFT</a>
        </nav>
      </div>
      <div :class="styles.likidFooter__bottom">
        <div :class="styles.likidFooter__info">
          <p>주식회사 벨로이드 | 대표자 김창우 | 사업자등록번호 123-88-02861</p>
          <p>주소 서울특별시 영등포구 여의대로 108, 4층(여의도동, 파크원 타워1) | 메일 biz@velloid.com</p>
          <p :class="styles.likidFooter__copyright">Copyright © 2025 LIKID All rights reserved.</p>
        </div>
        <div :class="styles.likidFooter__logo">
          <img src="/logo.png" alt="LIKID" :class="styles.likidFooter__logoImage" />
        </div>
      </div>
    </Container>
  </footer>
</template>

<script setup lang="ts">
import { useRoute } from 'vue-router'
import { navigateTo } from '#app'
import { Container } from '@/components/ui'
import styles from '~/styles/widgets/Footer.module.css'

const route = useRoute()

const scrollToSection = (sectionId: string) => {
  if (import.meta.server) return
  
  if (route.path !== '/') {
    navigateTo('/')
    setTimeout(() => {
      const element = document.getElementById(sectionId)
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' })
      }
    }, 100)
  } else {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }
}
</script>
