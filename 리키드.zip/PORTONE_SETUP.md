# Portone 설정 및 수정 가이드

포트원 결제 및 본인인증 연동 시 수정해야 할 파일과 설정 항목을 정리한 문서입니다.

## 📋 목차

1. [환경 변수 설정](#1-환경-변수-설정)
2. [코드 수정 위치](#2-코드-수정-위치)
3. [Portone 관리자 콘솔 설정](#3-portone-관리자-콘솔-설정)

---

## 1. 환경 변수 설정

### `.env` 파일 수정

프로젝트 루트의 `.env` 파일에 다음 값들을 설정합니다:

```bash
# PortOne V2 API 설정
PORTONE_API_KEY=your-store-id-here
PORTONE_API_SECRET=your-api-secret-here

# 본인인증 채널 설정 (channelKey 또는 pgProvider 중 하나 필수)
PORTONE_CHANNEL_KEY=your-channel-key-here
# 또는
# PORTONE_PG_PROVIDER=INICIS

# 백엔드 API URL
NUXT_PUBLIC_API_BASE_URL=https://your-api-url.com
```

**수정해야 할 값:**
- `PORTONE_API_KEY`: Portone 관리자 콘솔에서 확인한 Store ID
- `PORTONE_API_SECRET`: Portone 관리자 콘솔에서 확인한 API Secret
- `PORTONE_CHANNEL_KEY`: 본인인증 채널의 Channel Key (또는 `PORTONE_PG_PROVIDER` 사용)
- `NUXT_PUBLIC_API_BASE_URL`: 백엔드 API 기본 URL

---

## 2. 코드 수정 위치

### 2.1. Store ID 수정

**파일:** `features/auth/usePortoneCertification.ts`

**위치:** 8번째 줄

```typescript
// 현재 값
const PORTONE_STORE_ID = 'store-f96143b6-7f41-4a9f-ab82-9a6cebf7babd'

// 수정할 값 (Portone 관리자 콘솔에서 확인한 Store ID로 변경)
const PORTONE_STORE_ID = 'your-store-id-here'
```

---

### 2.2. Portone SDK CDN URL (필요시)

**파일:** `features/auth/usePortoneCertification.ts`

**위치:** 63번째 줄

```typescript
// 현재 값
script.src = 'https://cdn.portone.io/v2/browser-sdk.js'

// Portone SDK 버전이 변경되거나 다른 CDN을 사용하는 경우 수정
script.src = 'https://cdn.portone.io/v2/browser-sdk.js'
```

**참고:** 일반적으로 수정할 필요 없습니다. Portone 공식 CDN을 사용합니다.

---

### 2.3. Portone API Base URL (필요시)

**파일:** `shared/api/portone.ts`

**위치:** 5번째 줄

```typescript
// 현재 값
const PORTONE_API_BASE_URL = 'https://api.portone.io'

// Portone API 엔드포인트가 변경되는 경우에만 수정
const PORTONE_API_BASE_URL = 'https://api.portone.io'
```

**참고:** 일반적으로 수정할 필요 없습니다. Portone 공식 API 엔드포인트를 사용합니다.

---

### 2.4. 백엔드 API 엔드포인트 (필요시)

**파일:** `shared/api/instance.ts`

**위치:** API_BASE_URL 설정 부분

```typescript
// 환경 변수에서 가져오므로 .env 파일 수정으로 충분
const API_BASE_URL = import.meta.env.NUXT_PUBLIC_API_BASE_URL || 
  'http://likid-api-dev.ap-northeast-2.elasticbeanstalk.com/likid'
```

**참고:** `.env` 파일의 `NUXT_PUBLIC_API_BASE_URL` 값을 수정하면 됩니다.

---

## 3. Portone 관리자 콘솔 설정

### 3.1. Store ID 및 API Secret 확인

1. Portone 관리자 콘솔 로그인: https://admin.portone.io
2. **설정** > **API 키 관리** 메뉴로 이동
3. **Store ID**와 **API Secret** 확인
4. `.env` 파일과 `features/auth/usePortoneCertification.ts` 파일에 반영

---

### 3.2. Channel Key 또는 PG Provider 확인

본인인증을 사용하려면 **Channel Key** 또는 **PG Provider** 중 하나는 필수입니다.

#### Channel Key 확인 방법

1. Portone 관리자 콘솔 로그인: https://admin.portone.io
2. **결제 연동** > **채널 관리** 메뉴로 이동
3. 본인인증 채널을 생성하거나 기존 채널 선택
4. 채널 상세 정보에서 **Channel Key** 확인
5. `.env` 파일의 `PORTONE_CHANNEL_KEY`에 설정

#### PG Provider 확인 방법

1. Portone 관리자 콘솔 로그인: https://admin.portone.io
2. **결제 연동** > **채널 관리** 메뉴로 이동
3. 본인인증 채널의 PG Provider 코드 확인 (예: `INICIS`, `KCP`, `KGINICIS` 등)
4. `.env` 파일의 `PORTONE_PG_PROVIDER`에 설정

**참고:** `PORTONE_CHANNEL_KEY`와 `PORTONE_PG_PROVIDER` 중 하나만 설정하면 됩니다.

---

## 4. 수정 체크리스트

새로운 Portone 계정으로 변경할 때 다음 항목을 확인하세요:

- [ ] `.env` 파일의 `PORTONE_API_KEY` 수정
- [ ] `.env` 파일의 `PORTONE_API_SECRET` 수정
- [ ] `.env` 파일의 `PORTONE_CHANNEL_KEY` 또는 `PORTONE_PG_PROVIDER` 설정
- [ ] `features/auth/usePortoneCertification.ts`의 `PORTONE_STORE_ID` 수정
- [ ] 백엔드 API URL이 올바른지 확인 (`NUXT_PUBLIC_API_BASE_URL`)

---

## 5. 사용 중인 파일 목록

포트원 관련 코드가 사용되는 파일들:

### 본인인증 관련

1. **`features/auth/usePortoneCertification.ts`**
   - Portone SDK 로드 및 본인인증 처리
   - Store ID, Channel Key, PG Provider 사용
   - 수정 필요: Store ID (8번째 줄)

2. **`shared/api/portone.ts`**
   - Portone REST API V2 클라이언트
   - Access Token 발급 및 본인인증 결과 조회
   - 수정 필요: 없음 (환경 변수 사용)

3. **`features/SignupForm/SignupForm.vue`**
   - 회원가입 시 본인인증 사용
   - 수정 필요: 없음

4. **`features/FindAccountForm/FindAccountForm.vue`**
   - 아이디 찾기/비밀번호 찾기 시 본인인증 사용
   - 수정 필요: 없음

### 환경 변수

- `.env` 파일: 모든 Portone 설정 값 저장
- `nuxt.config.ts`: 환경 변수는 자동으로 로드됨

---

## 6. 테스트 방법

### 본인인증 테스트

1. 개발 서버 실행: `npm run dev`
2. 회원가입 페이지(`/signup`) 접속
3. "인증요청" 버튼 클릭
4. Portone 본인인증 팝업이 정상적으로 열리는지 확인
5. 본인인증 완료 후 결과가 정상적으로 반환되는지 확인

### 에러 발생 시 확인 사항

- Store ID가 올바른지 확인
- API Secret이 올바른지 확인
- Channel Key 또는 PG Provider가 설정되어 있는지 확인
- 환경 변수가 올바르게 로드되었는지 확인 (브라우저 콘솔에서 확인)
- 백엔드 API가 정상적으로 동작하는지 확인

---

## 7. 주의사항

1. **환경 변수 보안**
   - `.env` 파일은 절대 Git에 커밋하지 마세요
   - `.gitignore`에 `.env`가 포함되어 있는지 확인하세요
   - 프로덕션 환경에서는 환경 변수를 안전하게 관리하세요

2. **Store ID와 API Secret**
   - Store ID는 클라이언트에서도 사용되므로 노출되어도 상대적으로 안전합니다
   - API Secret은 서버 사이드에서만 사용해야 하며, 절대 클라이언트에 노출되면 안 됩니다

3. **Channel Key vs PG Provider**
   - Channel Key와 PG Provider 중 하나만 설정하면 됩니다
   - Channel Key를 우선적으로 사용하며, 없으면 PG Provider를 사용합니다

4. **SDK 버전**
   - Portone SDK는 CDN을 통해 로드됩니다
   - 버전이 변경되면 CDN URL을 확인하세요

---

## 8. 참고 자료

- [Portone 공식 문서](https://developers.portone.io/)
- [Portone 관리자 콘솔](https://admin.portone.io)
- [Portone SDK 문서](https://developers.portone.io/docs/ko/tip/identity-verification)

---

**마지막 업데이트:** 2025년 11월 26일

