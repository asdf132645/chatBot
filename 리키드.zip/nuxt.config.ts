// nuxt.config.ts
export default defineNuxtConfig({
  ssr: false,

  // Global CSS 등록
  css: ['~/styles/global.css'],

  app: {
    baseURL: "/",
    buildAssetsDir: "/_nuxt/",
    head: {
      link: [
        { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' },
        { rel: 'icon', type: 'image/png', sizes: '16x16', href: '/fa.ico/favicon-16x16.png' },
        { rel: 'icon', type: 'image/png', sizes: '32x32', href: '/fa.ico/favicon-32x32.png' },
        { rel: 'icon', type: 'image/png', sizes: '96x96', href: '/fa.ico/favicon-96x96.png' },
        { rel: 'apple-touch-icon', sizes: '57x57', href: '/fa.ico/apple-icon-57x57.png' },
        { rel: 'apple-touch-icon', sizes: '60x60', href: '/fa.ico/apple-icon-60x60.png' },
        { rel: 'apple-touch-icon', sizes: '72x72', href: '/fa.ico/apple-icon-72x72.png' },
        { rel: 'apple-touch-icon', sizes: '76x76', href: '/fa.ico/apple-icon-76x76.png' },
        { rel: 'apple-touch-icon', sizes: '114x114', href: '/fa.ico/apple-icon-114x114.png' },
        { rel: 'apple-touch-icon', sizes: '120x120', href: '/fa.ico/apple-icon-120x120.png' },
        { rel: 'apple-touch-icon', sizes: '144x144', href: '/fa.ico/apple-icon-144x144.png' },
        { rel: 'apple-touch-icon', sizes: '152x152', href: '/fa.ico/apple-icon-152x152.png' },
        { rel: 'apple-touch-icon', sizes: '180x180', href: '/fa.ico/apple-icon-180x180.png' },
        { rel: 'manifest', href: '/fa.ico/manifest.json' }
      ],
      meta: [
        { name: 'msapplication-TileColor', content: '#ffffff' },
        { name: 'msapplication-TileImage', content: '/fa.ico/ms-icon-144x144.png' }
      ]
    }
  },

  nitro: {
    preset: "static"
  },

  modules: ['@pinia/nuxt'],

  components: true,

  compatibilityDate: '2025-07-15',
})
