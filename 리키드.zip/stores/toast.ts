import { defineStore } from 'pinia'

export type ToastType = 'success' | 'error' | 'info' | 'warning'

export interface Toast {
  id: string
  message: string
  type: ToastType
  duration?: number
}

interface ToastState {
  toasts: Toast[]
}

export const useToastStore = defineStore('toast', {
  state: (): ToastState => ({
    toasts: []
  }),

  actions: {
    /**
     * 토스트 메시지 추가
     */
    showToast(message: string, type: ToastType = 'info', duration: number = 5000) {
      const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
      
      const toast: Toast = {
        id,
        message,
        type,
        duration
      }

      this.toasts.push(toast)

      // 자동 제거
      if (duration > 0) {
        setTimeout(() => {
          this.removeToast(id)
        }, duration)
      }

      return id
    },

    /**
     * 성공 토스트
     */
    success(message: string, duration?: number) {
      return this.showToast(message, 'success', duration)
    },

    /**
     * 에러 토스트
     */
    error(message: string, duration?: number) {
      return this.showToast(message, 'error', duration)
    },

    /**
     * 정보 토스트
     */
    info(message: string, duration?: number) {
      return this.showToast(message, 'info', duration)
    },

    /**
     * 경고 토스트
     */
    warning(message: string, duration?: number) {
      return this.showToast(message, 'warning', duration)
    },

    /**
     * 토스트 제거
     */
    removeToast(id: string) {
      const index = this.toasts.findIndex(toast => toast.id === id)
      if (index > -1) {
        this.toasts.splice(index, 1)
      }
    },

    /**
     * 모든 토스트 제거
     */
    clearAll() {
      this.toasts = []
    }
  }
})

