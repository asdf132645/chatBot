import { defineStore } from 'pinia'

interface UIState {
  // 모바일 메뉴 토글
  isMobileMenuOpen: boolean
  
  // 로딩 상태
  isLoading: boolean
  
  // 필터/정렬 상태
  filters: Record<string, any>
  sortBy: string | null
  
  // 모달 상태
  activeModal: string | null
}

export const useUIStore = defineStore('ui', {
  state: (): UIState => ({
    isMobileMenuOpen: false,
    isLoading: false,
    filters: {},
    sortBy: null,
    activeModal: null
  }),

  getters: {
    hasActiveFilters: (state) => Object.keys(state.filters).length > 0,
    isModalOpen: (state) => state.activeModal !== null
  },

  actions: {
    toggleMobileMenu() {
      this.isMobileMenuOpen = !this.isMobileMenuOpen
    },

    closeMobileMenu() {
      this.isMobileMenuOpen = false
    },

    setLoading(loading: boolean) {
      this.isLoading = loading
    },

    setFilter(key: string, value: any) {
      this.filters[key] = value
    },

    removeFilter(key: string) {
      delete this.filters[key]
    },

    clearFilters() {
      this.filters = {}
    },

    setSortBy(sortBy: string | null) {
      this.sortBy = sortBy
    },

    openModal(modalName: string) {
      this.activeModal = modalName
    },

    closeModal() {
      this.activeModal = null
    }
  }
})
