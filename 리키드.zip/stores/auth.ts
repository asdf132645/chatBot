import { defineStore } from 'pinia'
import type { User } from '~/entities/user/types'

interface AuthState {
  user: User | null
  isAuthenticated: boolean
  accessToken: string | null
  refreshToken: string | null
}

export const useAuthStore = defineStore('auth', {
  state: (): AuthState => ({
    user: null,
    isAuthenticated: false,
    accessToken: null,
    refreshToken: null
  }),

  getters: {
    isLoggedIn: (state) => state.isAuthenticated && state.accessToken !== null,
    userName: (state) => state.user?.name || state.user?.loginId || 'Guest',
    token: (state) => state.accessToken // 기존 코드 호환성을 위한 getter
  },

  actions: {
    /**
     * 인증 정보 설정 (로그인 시 사용)
     */
    setAuth(data: { user: User; accessToken: string; refreshToken: string }) {
      this.user = data.user
      this.accessToken = data.accessToken
      this.refreshToken = data.refreshToken
      this.isAuthenticated = true
      
      // localStorage에 저장
      if (import.meta.client) {
        localStorage.setItem('access_token', data.accessToken)
        localStorage.setItem('refresh_token', data.refreshToken)
        localStorage.setItem('user', JSON.stringify(data.user))
      }
    },

    /**
     * 토큰만 업데이트 (토큰 재발급 시 사용)
     */
    setTokens(data: { accessToken: string; refreshToken: string }) {
      this.accessToken = data.accessToken
      this.refreshToken = data.refreshToken
      this.isAuthenticated = true
      
      // localStorage 업데이트
      if (import.meta.client) {
        localStorage.setItem('access_token', data.accessToken)
        localStorage.setItem('refresh_token', data.refreshToken)
      }
    },

    /**
     * 로그아웃
     */
    logout() {
      this.user = null
      this.accessToken = null
      this.refreshToken = null
      this.isAuthenticated = false
      
      // localStorage 정리
      if (import.meta.client) {
        localStorage.removeItem('access_token')
        localStorage.removeItem('refresh_token')
        localStorage.removeItem('user')
        // 기존 호환성을 위한 토큰도 제거
        localStorage.removeItem('auth_token')
      }
    },

    /**
     * 앱 시작 시 localStorage에서 인증 정보 복원
     */
    initializeAuth() {
      if (import.meta.client) {
        const accessToken = localStorage.getItem('access_token')
        const refreshToken = localStorage.getItem('refresh_token')
        const userStr = localStorage.getItem('user')
        
        // 기존 호환성을 위한 auth_token도 확인
        const legacyToken = localStorage.getItem('auth_token')
        const token = accessToken || legacyToken
        
        if (token) {
          try {
            // user 정보가 있으면 파싱
            if (userStr) {
              const user = JSON.parse(userStr)
              this.user = user
            }
            
            this.accessToken = token
            this.refreshToken = refreshToken
            this.isAuthenticated = true
            
            // 기존 auth_token이 있으면 마이그레이션
            if (legacyToken && !accessToken) {
              localStorage.setItem('access_token', legacyToken)
              localStorage.removeItem('auth_token')
            }
          } catch (error) {
            console.error('Failed to restore auth state:', error)
            this.logout()
          }
        }
      }
    }
  }
})
