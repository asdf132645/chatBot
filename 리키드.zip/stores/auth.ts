import { defineStore } from 'pinia'
import type { User } from '~/entities/user/types'

/**
 * JWT 토큰 디코딩 (페이로드만 추출)
 */
const decodeJWT = (token: string): any => {
  try {
    const parts = token.split('.')
    if (parts.length !== 3) return null
    
    const base64Url = parts[1]
    if (!base64Url) return null
    
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/')
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split('')
        .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    )
    return JSON.parse(jsonPayload)
  } catch (error) {
    return null
  }
}

interface AuthState {
  user: User | null
  isAuthenticated: boolean
  accessToken: string | null
  refreshToken: string | null
  name: string | null // JWT 토큰에서 파싱한 이름
}

export const useAuthStore = defineStore('auth', {
  state: (): AuthState => ({
    user: null,
    isAuthenticated: false,
    accessToken: null,
    refreshToken: null,
    name: null
  }),

  getters: {
    isLoggedIn: (state) => state.isAuthenticated && state.accessToken !== null,
    userName: (state) => state.user?.name || state.user?.loginId || 'Guest',
    token: (state) => state.accessToken // 기존 코드 호환성을 위한 getter
  },

  actions: {
    /**
     * 인증 정보 설정 (로그인 시 사용)
     */
    setAuth(data: { user: User; accessToken: string; refreshToken: string }) {
      this.user = data.user
      this.accessToken = data.accessToken
      this.refreshToken = data.refreshToken
      this.isAuthenticated = true
      
      // JWT 토큰에서 name 파싱
      const decoded = decodeJWT(data.accessToken)
      if (decoded && decoded.name) {
        this.name = decoded.name
      }
      
      // localStorage에 저장
      if (import.meta.client) {
        localStorage.setItem('access_token', data.accessToken)
        localStorage.setItem('refresh_token', data.refreshToken)
        localStorage.setItem('user', JSON.stringify(data.user))
        if (this.name) {
          localStorage.setItem('user_name', this.name)
        }
      }
    },

    /**
     * 토큰만 업데이트 (토큰 재발급 시 사용)
     */
    setTokens(data: { accessToken: string; refreshToken: string; keepLoggedIn?: boolean }) {
      this.accessToken = data.accessToken
      this.refreshToken = data.refreshToken
      this.isAuthenticated = true
      
      // JWT 토큰에서 name 파싱
      const decoded = decodeJWT(data.accessToken)
      if (decoded && decoded.name) {
        this.name = decoded.name
      }
      
      // 로그인 유지 옵션에 따라 저장 위치 결정
      if (import.meta.client) {
        const keepLoggedIn = data.keepLoggedIn ?? true // 기본값은 true (기존 동작 유지)
        
        if (keepLoggedIn) {
          // 로그인 유지: localStorage에 저장 (영구 저장)
          localStorage.setItem('access_token', data.accessToken)
          localStorage.setItem('refresh_token', data.refreshToken)
          if (this.name) {
            localStorage.setItem('user_name', this.name)
          }
          // sessionStorage에서 제거 (혹시 있을 수 있음)
          sessionStorage.removeItem('access_token')
          sessionStorage.removeItem('refresh_token')
          sessionStorage.removeItem('user_name')
        } else {
          // 로그인 유지 안 함: sessionStorage에 저장 (탭 닫으면 삭제)
          sessionStorage.setItem('access_token', data.accessToken)
          sessionStorage.setItem('refresh_token', data.refreshToken)
          if (this.name) {
            sessionStorage.setItem('user_name', this.name)
          }
          // localStorage에서 제거
          localStorage.removeItem('access_token')
          localStorage.removeItem('refresh_token')
          localStorage.removeItem('user_name')
        }
      }
    },

    /**
     * 로그아웃
     */
    logout() {
      this.user = null
      this.accessToken = null
      this.refreshToken = null
      this.name = null
      this.isAuthenticated = false
      
      // localStorage 및 sessionStorage 정리
      if (import.meta.client) {
        localStorage.removeItem('access_token')
        localStorage.removeItem('refresh_token')
        localStorage.removeItem('user')
        localStorage.removeItem('user_name')
        sessionStorage.removeItem('access_token')
        sessionStorage.removeItem('refresh_token')
        sessionStorage.removeItem('user_name')
        // 기존 호환성을 위한 토큰도 제거
        localStorage.removeItem('auth_token')
      }
    },

    /**
     * 앱 시작 시 localStorage 또는 sessionStorage에서 인증 정보 복원
     */
    initializeAuth() {
      if (import.meta.client) {
        // localStorage 우선 확인 (로그인 유지) - 선언형 방식
        const accessToken = localStorage.getItem('access_token') ?? sessionStorage.getItem('access_token')
        const refreshToken = localStorage.getItem('refresh_token') ?? sessionStorage.getItem('refresh_token')
        
        const userStr = localStorage.getItem('user')
        
        // 기존 호환성을 위한 auth_token도 확인
        const legacyToken = localStorage.getItem('auth_token')
        const token = accessToken || legacyToken
        
        if (token) {
          try {
            // user 정보가 있으면 파싱
            if (userStr) {
              const user = JSON.parse(userStr)
              this.user = user
            }
            
            this.accessToken = token
            this.refreshToken = refreshToken
            this.isAuthenticated = true
            
            // JWT 토큰에서 name 파싱
            const decoded = decodeJWT(token)
            if (decoded && decoded.name) {
              this.name = decoded.name
            } else {
              // localStorage에서 name 복원 시도
              const storedName = localStorage.getItem('user_name') ?? sessionStorage.getItem('user_name')
              if (storedName) {
                this.name = storedName
              }
            }
            
            // 기존 auth_token이 있으면 마이그레이션
            if (legacyToken && !accessToken) {
              localStorage.setItem('access_token', legacyToken)
              localStorage.removeItem('auth_token')
            }
          } catch (error) {
            console.error('Failed to restore auth state:', error)
            this.logout()
          }
        }
      }
    }
  }
})
