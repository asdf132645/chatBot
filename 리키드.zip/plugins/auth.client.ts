import { useAuthStore } from '~/stores/auth'

export default defineNuxtPlugin(() => {
  const authStore = useAuthStore()
  
  // 앱 시작 시 localStorage에서 인증 정보 복원
  authStore.initializeAuth()
})
