export default defineNuxtPlugin(() => {
  if (process.client) {
    // 브라우저 확장 프로그램 관련 에러 무시
    window.addEventListener('error', (e) => {
      if (e.message && e.message.includes('message channel closed')) {
        e.preventDefault()
        return false
      }
    })

    window.addEventListener('unhandledrejection', (e) => {
      if (e.reason && e.reason.message && e.reason.message.includes('message channel closed')) {
        e.preventDefault()
        return false
      }
    })
  }
})

