# LIKID Nuxt App

Look at the [Nuxt documentation](https://nuxt.com/docs/getting-started/introduction) to learn more.

## Portone PASS 인증 설정

### Portone V2 API 정보
- **Store ID**: `store-f96143b6-7f41-4a9f-ab82-9a6cebf7babd`
- **API Secret**: `portone-v2-secret`

### Channel Key 또는 PG Provider 확인 방법

본인인증을 사용하려면 **`channelKey` 또는 `pgProvider` 중 하나는 필수**입니다.

**Portone 관리자 콘솔에서 확인:**
1. Portone 관리자 콘솔 로그인: https://admin.portone.io
2. **결제 연동** > **채널 관리** 메뉴로 이동
3. 본인인증 채널을 생성하거나 기존 채널 선택
4. 채널 상세 정보에서 **Channel Key** 확인
   - 또는 **PG Provider** 코드 확인 (예: `INICIS`, `KCP`, `KGINICIS` 등)

### 환경 변수 설정

프로젝트 루트에 `.env` 파일을 생성하고 다음 내용을 추가하세요:

```bash
# PortOne V2 API 설정
PORTONE_API_KEY=store-f96143b6-7f41-4a9f-ab82-9a6cebf7babd
PORTONE_API_SECRET=portone-v2-secret

# 본인인증 채널 설정 (channelKey 또는 pgProvider 중 하나 필수)
PORTONE_CHANNEL_KEY=your-channel-key-here
# 또는
# PORTONE_PG_PROVIDER=INICIS

# 백엔드 API URL
NUXT_PUBLIC_API_BASE_URL=https://api.likid.com
```

**참고**: 
- `PORTONE_API_KEY`와 `PORTONE_API_SECRET`은 서버 사이드에서만 사용됩니다.
- `PORTONE_CHANNEL_KEY` 또는 `PORTONE_PG_PROVIDER` 중 하나는 반드시 설정해야 합니다.
- 클라이언트에서는 Store ID와 Channel Key/PG Provider를 사용하여 SDK로 본인인증 팝업을 띄웁니다.
- 인증 완료 후 서버에서 REST API로 결과를 조회합니다.

## Setup

Make sure to install dependencies:

```bash
# npm
npm install

# pnpm
pnpm install

# yarn
yarn install

# bun
bun install
```

## Development Server

Start the development server on `http://localhost:3000`:

```bash
# npm
npm run dev

# pnpm
pnpm dev

# yarn
yarn dev

# bun
bun run dev
```

## Production

Build the application for production:

```bash
# npm
npm run build

# pnpm
pnpm build

# yarn
yarn build

# bun
bun run build
```

Locally preview production build:

```bash
# npm
npm run preview

# pnpm
pnpm preview

# yarn
yarn preview

# bun
bun run preview
```

Check out the [deployment documentation](https://nuxt.com/docs/getting-started/deployment) for more information.
