<template>
  <div :class="['likid-card', { 'likid-card--dark': dark }]">
    <slot />
  </div>
</template>

<script setup lang="ts">
interface Props {
  dark?: boolean
}

withDefaults(defineProps<Props>(), {
  dark: false
})
</script>

<style scoped>
.likid-card {
  background-color: #fff;
  padding: 24px;
  border-radius: 8px;
}

.likid-card--dark {
  background-color: #000;
  color: #fff;
}

@media (min-width: 768px) {
  .likid-card {
    padding: 32px;
  }
}
</style>
