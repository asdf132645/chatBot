<template>
  <Teleport to="body">
    <TransitionGroup
      name="toast"
      tag="div"
      :class="styles.toastContainer"
    >
      <div
        v-for="toast in toasts"
        :key="toast.id"
        :class="[
          styles.toast,
          styles[`toast--${toast.type}`]
        ]"
      >
        <div :class="styles.toast__content">
          <span :class="styles.toast__message">{{ toast.message }}</span>
        </div>
        <button
          :class="styles.toast__close"
          @click="removeToast(toast.id)"
          aria-label="닫기"
        >
          ×
        </button>
      </div>
    </TransitionGroup>
  </Teleport>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useToastStore } from '~/stores/toast'
import styles from '~/styles/components/ui/Toast.module.css'

const toastStore = useToastStore()

const toasts = computed(() => toastStore.toasts)

const removeToast = (id: string) => {
  toastStore.removeToast(id)
}
</script>

