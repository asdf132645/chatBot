<template>
  <button
    :class="[
      'likid-button',
      `likid-button--${variant}`,
      `likid-button--${size}`,
      { 'likid-button--full-width': fullWidth }
    ]"
    @click="$emit('click', $event)"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
interface Props {
  variant?: 'primary' | 'secondary' | 'outline'
  size?: 'sm' | 'md' | 'lg'
  fullWidth?: boolean
}

withDefaults(defineProps<Props>(), {
  variant: 'primary',
  size: 'md',
  fullWidth: false
})

defineEmits<{
  click: [event: MouseEvent]
}>()
</script>

<style scoped>
.likid-button {
  font-family: inherit;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  border: none;
  outline: none;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.likid-button--primary {
  background-color: #000;
  color: #fff;
}

.likid-button--primary:hover {
  background-color: #333;
}

.likid-button--secondary {
  background-color: #fff;
  color: #000;
}

.likid-button--secondary:hover {
  background-color: #f5f5f5;
}

.likid-button--outline {
  background-color: transparent;
  color: #000;
  border: 1px solid #000;
}

.likid-button--outline:hover {
  background-color: #000;
  color: #fff;
}

.likid-button--sm {
  padding: 8px 16px;
  font-size: 14px;
}

.likid-button--md {
  padding: 12px 24px;
  font-size: 16px;
}

.likid-button--lg {
  padding: 16px 32px;
  font-size: 18px;
}

.likid-button--full-width {
  width: 100%;
}
</style>
