<template>
  <div class="likid-container">
    <slot />
  </div>
</template>

<script setup lang="ts">
</script>

<style scoped>
.likid-container {
  width: 100%;
  max-width: 1440px;
  margin: 0 auto;
  padding: 0 16px;
}

@media (min-width: 768px) {
  .likid-container {
    padding: 0 24px;
  }
}

@media (min-width: 1024px) {
  .likid-container {
    padding: 0 48px;
  }
}

@media (min-width: 1280px) {
  .likid-container {
    padding: 0 80px;
  }
}
</style>
