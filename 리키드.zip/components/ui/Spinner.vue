<template>
  <div :class="[styles.spinner, size && styles[`spinner--${size}`]]">
    <div :class="styles.spinner__circle"></div>
  </div>
</template>

<script setup lang="ts">
import styles from '~/styles/components/ui/Spinner.module.css'

interface Props {
  size?: 'sm' | 'md' | 'lg'
}

withDefaults(defineProps<Props>(), {
  size: 'md'
})
</script>

