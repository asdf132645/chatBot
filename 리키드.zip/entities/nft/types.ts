// NFT 관련 타입 정의

export interface NFTArtwork {
  id: number
  image: string
  brand: string
  title: string
  price: number
}

export interface NFTListResponse {
  artworks: NFTArtwork[]
  total: number
}

export interface NFTDetail {
  id: number
  title: string
  imageUrl: string
  price: number
  stockQuantity: number
  minQuantity: number
  maxQuantity: number
  artworkDescription: string
  brandDescription: string
  notes?: string | string[] // 서버에서 문자열 또는 배열로 받을 수 있음
  isActive: boolean
  createEpoch: number
  updateEpoch: number
}

