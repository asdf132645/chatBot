// NFT 관련 타입 정의

export interface NFTArtwork {
  id: number
  image: string
  brand: string
  title: string
  price: number
}

export interface NFTListRequest {
  type?: 'PAGINATION' | 'INFINITE'
  limit?: number
  offset?: number
  page?: number
  size?: number
  sortType?: string
  sortDirection?: 'desc' | 'asc'
}

export interface PaginateInfo {
  last: boolean
  totalPage: number
  totalCount: number
  currentPage: number
}

export interface NFTListResponse {
  content: NFTDetail[]
  paginate: PaginateInfo
}

// 하위 호환성을 위한 레거시 타입
export interface NFTListResponseLegacy {
  artworks: NFTArtwork[]
  total: number
}

export interface NFTDetail {
  id: number
  title: string
  imageUrl: string
  price: number
  stockQuantity: number
  minQuantity: number | null
  maxQuantity: number | null
  artworkDescription: string
  brandDescription: string | null
  notes?: string | string[] // 서버에서 문자열 또는 배열로 받을 수 있음
  isActive: boolean
  createEpoch: number
  updateEpoch: number
}

