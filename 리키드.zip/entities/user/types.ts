// 사용자 엔티티 타입 정의

export interface User {
  userId: string
  loginId: string
  name?: string
  email?: string
}

export interface Address {
  zipcode: string
  address1: string
  address2?: string
}

export interface Agreements {
  termsOfUse: boolean
  privacyPolicy: boolean
  thirdPartySharing?: boolean
  emailMarketing?: boolean
}

export interface SignUpRequest {
  loginId: string
  password: string
  name: string
  email: string
  nickname: string
  region: string
  birth: string // yyyy-MM-dd 형식
  address: Address
  telephoneNumber?: string
  mobileNumber: string
  gender: '남성' | '여성'
  identityToken?: string // 임시로 optional로 변경
  agreements: Agreements
}

export interface SignUpResponse {
  accessToken: string
  refreshToken: string
}

export interface LoginRequest {
  loginId: string
  password: string
}

export interface LoginResponse {
  accessToken: string
  refreshToken: string
}

export interface TokenRefreshRequest {
  refreshToken: string
}

export interface TokenRefreshResponse {
  accessToken: string
  refreshToken: string
}

export interface LogoutRequest {
  refreshToken: string
}

// KYC 관련 타입
export type KycPurpose = 'SIGN_UP' | 'FIND_ID' | 'RESET_PASSWORD'
export type KycUsage = 'SIGN_UP' | 'FIND_ID' | 'RESET_PASSWORD'

export interface KycSessionRequest {
  usage: KycUsage
  redirectUrl: string
}

export interface KycSessionResponse {
  verificationId: string
  authUrl: string
}

export interface KycVerifyRequest {
  verificationId: string
  transactionId: string
}

export interface KycVerification {
  id: string
  provider: string
  purpose: KycPurpose
  status: string
  name: string
  birthDate: string
  gender: 'MALE' | 'FEMALE'
  phoneNumber: string
  carrier: 'SKT' | 'KT' | 'LGU'
  ci: string
  di: string
  verifiedAt: string
  alreadyRegistered: boolean
}

export interface KycVerifyResponse {
  identityToken?: string // 임시로 optional로 변경
  verification: KycVerification
}

// API 공통 응답 타입
export interface ApiMessage {
  httpStatus?: string
  reasonPhrase: string
  message: string
  success?: boolean // 하위 호환성을 위해 유지
}

export interface ApiResponse<T> {
  message: ApiMessage
  data: T
}

