<template>
  <div :class="styles.signupPage">
    <Container>
      <h1 :class="styles.signupPage__title">회원가입</h1>
      <SignupForm />
    </Container>
  </div>
</template>

<script setup lang="ts">
import { Container } from '@/components/ui'
import SignupForm from '~/features/SignupForm/SignupForm.vue'
import styles from '~/styles/pages/signup.module.css'

definePageMeta({
  layout: 'signup'
})
</script>

