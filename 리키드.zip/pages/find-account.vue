<template>
  <div :class="styles.findAccountPage">
    <Container>
      <h1 :class="styles.findAccountPage__title">아이디·비밀번호 찾기</h1>
      <FindAccountForm />
    </Container>
  </div>
</template>

<script setup lang="ts">
import { Container } from '@/components/ui'
import FindAccountForm from '~/features/FindAccountForm/FindAccountForm.vue'
import styles from '~/styles/pages/find-account.module.css'

definePageMeta({
  layout: 'signup'
})
</script>

