<template>
  <div class="main-page">
    <!-- 섹션 1: Hero Section (WHAT IS LIKID 포함) -->
    <HeroSection />
    
    <!-- 섹션 3: Features -->
    <FeaturesSection />
    
    <!-- 섹션 4: Roadmap -->
    <RoadmapSection />
    
    <!-- 섹션 5: Coming Soon -->
    <ComingSoonSection />
    
    <!-- 섹션 6: NFT Features -->
    <NFTFeaturesSection />
    
    <!-- 섹션 7: CTA (Call to Action) -->
    <CTASection />
  </div>
</template>

<script setup lang="ts">
import HeroSection from '~/features/HeroSection/HeroSection.vue'
import FeaturesSection from '~/features/FeaturesSection/FeaturesSection.vue'
import RoadmapSection from '~/features/RoadmapSection/RoadmapSection.vue'
import ComingSoonSection from '~/features/ComingSoonSection/ComingSoonSection.vue'
import NFTFeaturesSection from '~/features/NFTFeaturesSection/NFTFeaturesSection.vue'
import CTASection from '~/features/CTASection/CTASection.vue'

definePageMeta({
  layout: 'default'
})
</script>

<style scoped>
.main-page {
  width: 100%;
}
</style>