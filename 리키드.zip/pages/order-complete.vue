<template>
  <div :class="styles.orderCompletePage">
    <Container>
      <!-- 주문 완료 메시지 -->
      <div :class="styles.orderCompletePage__header">
        <h1 :class="styles.orderCompletePage__title">주문이 완료되었어요</h1>
        <p :class="styles.orderCompletePage__orderNumber">주문번호 {{ orderNumber }}</p>
      </div>

      <!-- 입금 계좌 정보 -->
      <div :class="styles.orderCompletePage__account">
        <h2 :class="styles.orderCompletePage__accountTitle">입금 계좌</h2>
        <div :class="styles.orderCompletePage__accountInfo">
          <div :class="styles.orderCompletePage__accountRow">
            <span :class="styles.orderCompletePage__accountLabel">계좌번호</span>
            <span :class="styles.orderCompletePage__accountValue">140-015-611884</span>
          </div>
          <div :class="styles.orderCompletePage__accountRow">
            <span :class="styles.orderCompletePage__accountLabel">은행명</span>
            <span :class="styles.orderCompletePage__accountValue">신한은행</span>
          </div>
          <div :class="styles.orderCompletePage__accountRow">
            <span :class="styles.orderCompletePage__accountLabel">예금주</span>
            <span :class="styles.orderCompletePage__accountValue">(주)벨로이드</span>
          </div>
        </div>
        <p :class="styles.orderCompletePage__accountNote">
          10일 이내(주문일 포함) 입금이 되지 않을 경우, 주문이 자동 취소됩니다
        </p>
      </div>

      <!-- 액션 버튼 -->
      <div :class="styles.orderCompletePage__actions">
        <NuxtLink to="/nft" :class="styles.orderCompletePage__buttonSecondary">
          쇼핑 계속하기
        </NuxtLink>
        <button :class="styles.orderCompletePage__buttonPrimary" @click="handleCheckHistory">
          구매 내역 확인하기
        </button>
      </div>

      <!-- 주문상품 -->
      <section :class="styles.orderCompletePage__section">
        <h2 :class="styles.orderCompletePage__sectionTitle">주문상품</h2>
        <div :class="styles.orderCompletePage__product">
          <div :class="styles.orderCompletePage__productImage">
            <img :src="artwork.image" :alt="artwork.title" />
          </div>
          <div :class="styles.orderCompletePage__productInfo">
            <div :class="styles.orderCompletePage__brand">{{ artwork.brand }}</div>
            <div :class="styles.orderCompletePage__productTitle">{{ artwork.title }}</div>
            <div :class="styles.orderCompletePage__divider"></div>
            <div :class="styles.orderCompletePage__productDetails">
              <span>수량: {{ quantity }}</span>
              <span :class="styles.orderCompletePage__price">₩{{ (artwork.price * quantity).toLocaleString() }}</span>
            </div>
          </div>
        </div>
      </section>

      <!-- 결제정보 -->
      <section :class="styles.orderCompletePage__section">
        <h2 :class="styles.orderCompletePage__sectionTitle">결제정보</h2>
        <div :class="styles.orderCompletePage__paymentInfo">
          <div :class="styles.orderCompletePage__paymentRow">
            <span :class="styles.orderCompletePage__paymentLabel">최종 결제 금액</span>
            <span :class="styles.orderCompletePage__paymentValue">
              ₩{{ (artwork.price * quantity).toLocaleString() }} <span :class="styles.orderCompletePage__paymentStatus">(입금대기)</span>
            </span>
          </div>
        </div>
      </section>

      <!-- 입금정보 -->
      <section :class="styles.orderCompletePage__section">
        <h2 :class="styles.orderCompletePage__sectionTitle">입금정보</h2>
        <div :class="styles.orderCompletePage__depositInfo">
          <div :class="styles.orderCompletePage__depositRow">
            <span :class="styles.orderCompletePage__depositLabel">입금은행</span>
            <span :class="styles.orderCompletePage__depositValue">{{ depositInfo.bank }}</span>
          </div>
          <div :class="styles.orderCompletePage__depositRow">
            <span :class="styles.orderCompletePage__depositLabel">입금자명</span>
            <span :class="styles.orderCompletePage__depositValue">{{ depositInfo.depositorName }}</span>
          </div>
        </div>
      </section>
    </Container>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { Container } from '@/components/ui'
import styles from '~/styles/pages/order-complete.module.css'

definePageMeta({
  layout: 'signup'
})

const route = useRoute()

const orderNumber = ref('1234567891012')
const quantity = ref(1)

// Placeholder 이미지 (SVG data URL)
const placeholderImage = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjVmNWY1Ii8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5GVCBJbWFnZTwvdGV4dD48L3N2Zz4='

const artwork = ref({
  id: '',
  image: placeholderImage,
  brand: '브랜드명',
  title: '작품명 Neon Skull #102',
  price: 21000
})

const depositInfo = ref({
  bank: '국민은행',
  depositorName: '권정인'
})

onMounted(() => {
  // URL 파라미터에서 주문 정보 가져오기
  const orderId = route.query.orderId as string
  const artworkId = route.query.artworkId as string
  const qty = route.query.quantity as string
  
  if (orderId) {
    orderNumber.value = orderId
  }
  
  if (artworkId) {
    artwork.value.id = artworkId
    // 실제로는 API에서 작품 정보를 가져와야 함
  }
  
  if (qty) {
    quantity.value = parseInt(qty) || 1
  }

  // 실제로는 API에서 주문 정보를 가져와야 함
  // depositInfo도 API에서 가져와야 함
})

const handleCheckHistory = () => {
  // 구매 내역 페이지로 이동
  // navigateTo('/orders')
  console.log('구매 내역 확인')
}
</script>

