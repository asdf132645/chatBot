<template>
  <div :class="styles.orderCompletePage">
    <Container>
      <div v-if="isLoading" :class="styles.orderCompletePage__loading">
        <Spinner size="lg" />
      </div>
      <template v-else>
        <!-- 주문 완료 메시지 -->
        <div :class="styles.orderCompletePage__header">
          <h1 :class="styles.orderCompletePage__title">주문이 완료되었어요</h1>
          <p v-if="orderNumber" :class="styles.orderCompletePage__orderNumber">주문번호 {{ orderNumber }}</p>
        </div>

      <!-- 입금 계좌 정보 -->
      <div :class="styles.orderCompletePage__account">
        <h2 :class="styles.orderCompletePage__accountTitle">입금 계좌</h2>
        <div :class="styles.orderCompletePage__accountInfo">
          <div :class="styles.orderCompletePage__accountRow">
            <span :class="styles.orderCompletePage__accountLabel">계좌번호</span>
            <span :class="styles.orderCompletePage__accountValue">140-015-611884</span>
          </div>
          <div :class="styles.orderCompletePage__accountRow">
            <span :class="styles.orderCompletePage__accountLabel">은행명</span>
            <span :class="styles.orderCompletePage__accountValue">신한은행</span>
          </div>
          <div :class="styles.orderCompletePage__accountRow">
            <span :class="styles.orderCompletePage__accountLabel">예금주</span>
            <span :class="styles.orderCompletePage__accountValue">(주)벨로이드</span>
          </div>
        </div>
        <p :class="styles.orderCompletePage__accountNote">
          10일 이내(주문일 포함) 입금이 되지 않을 경우, 주문이 자동 취소됩니다
        </p>
      </div>

      <!-- 액션 버튼 -->
      <div :class="styles.orderCompletePage__actions">
        <NuxtLink to="/nft" :class="styles.orderCompletePage__buttonSecondary">
          쇼핑 계속하기
        </NuxtLink>
      </div>

      <!-- 주문상품 -->
      <section :class="styles.orderCompletePage__section">
        <h2 :class="styles.orderCompletePage__sectionTitle">주문상품</h2>
        <div :class="styles.orderCompletePage__product">
          <div :class="styles.orderCompletePage__productImage">
            <img :src="artwork.image" :alt="artwork.title" />
          </div>
          <div :class="styles.orderCompletePage__productInfo">
            <div :class="styles.orderCompletePage__brand">{{ artwork.brand }}</div>
            <div :class="styles.orderCompletePage__productTitle">{{ artwork.title }}</div>
            <div :class="styles.orderCompletePage__divider"></div>
            <div :class="styles.orderCompletePage__productDetails">
              <span>수량: {{ quantity }}</span>
              <span :class="styles.orderCompletePage__price">₩{{ (artwork.price * quantity).toLocaleString() }}</span>
            </div>
          </div>
        </div>
      </section>

      <!-- 결제정보 -->
      <section :class="styles.orderCompletePage__section">
        <h2 :class="styles.orderCompletePage__sectionTitle">결제정보</h2>
        <div :class="styles.orderCompletePage__paymentInfo">
          <div :class="styles.orderCompletePage__paymentRow">
            <span :class="styles.orderCompletePage__paymentLabel">최종 결제 금액</span>
            <span :class="styles.orderCompletePage__paymentValue">
              ₩{{ (artwork.price * quantity).toLocaleString() }} <span :class="styles.orderCompletePage__paymentStatus">(입금대기)</span>
            </span>
          </div>
        </div>
      </section>

      <!-- 입금정보 -->
      <section :class="styles.orderCompletePage__section">
        <h2 :class="styles.orderCompletePage__sectionTitle">입금정보</h2>
        <div :class="styles.orderCompletePage__depositInfo">
          <div :class="styles.orderCompletePage__depositRow">
            <span :class="styles.orderCompletePage__depositLabel">입금은행</span>
            <span :class="styles.orderCompletePage__depositValue">{{ getBankName(depositInfo.bank) }}</span>
          </div>
          <div :class="styles.orderCompletePage__depositRow">
            <span :class="styles.orderCompletePage__depositLabel">입금자명</span>
            <span :class="styles.orderCompletePage__depositValue">{{ depositInfo.depositorName }}</span>
          </div>
        </div>
      </section>
      </template>
    </Container>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { Container } from '@/components/ui'
import { getNFTDetail } from '~/shared/api/nft'
import { getBankList } from '~/shared/api/order'
import { useToastStore } from '~/stores/toast'
import { Spinner } from '@/components/ui'
import styles from '~/styles/pages/order-complete.module.css'
import type { NFTDetail } from '~/entities/nft/types'
import type { Bank } from '~/shared/api/order'

definePageMeta({
  layout: 'signup'
})

const route = useRoute()
const toastStore = useToastStore()

const isLoading = ref(true)
const orderNumber = ref('')
const quantity = ref(1)

// Placeholder 이미지 (SVG data URL)
const placeholderImage = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjVmNWY1Ii8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5GVCBJbWFnZTwvdGV4dD48L3N2Zz4='

const artwork = ref<NFTDetail>({
  id: 0,
  image: placeholderImage,
  brand: '',
  title: '',
  price: 0,
  stockQuantity: 0,
  minQuantity: null,
  maxQuantity: null,
  brandDescription: null,
  notes: undefined,
  isActive: true,
  createEpoch: 0,
  updateEpoch: 0
})

const depositInfo = ref({
  bank: '',
  depositorName: ''
})

const banks = ref<Bank[]>([])

// 은행 코드로 한글 이름 찾기
const getBankName = (bankCode: string): string => {
  const bank = banks.value.find(b => b.code === bankCode)
  return bank?.name || bankCode
}

// NFT 상세 정보 가져오기
const fetchNFTDetail = async (nftId: number) => {
  if (import.meta.server) return
  
  try {
    const response = await getNFTDetail(nftId)
    
    if ((response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') && response.data) {
      artwork.value = response.data
    } else {
      toastStore.error('작품 정보를 불러오는데 실패했습니다.')
    }
  } catch (error: any) {
    const errorMessage = error.response?.data?.message?.message || 
                        error.message || 
                        '작품 정보를 불러오는데 실패했습니다.'
    toastStore.error(errorMessage)
  }
}

// 은행 목록 조회
const fetchBanks = async () => {
  if (import.meta.server) return
  
  try {
    const response = await getBankList()
    if ((response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') && response.data) {
      banks.value = response.data
    }
  } catch (error) {
    // 은행 목록 조회 실패는 무시 (은행명 표시만 안 됨)
  }
}

onMounted(async () => {
  // URL 파라미터에서 주문 정보 가져오기
  const orderId = route.query.orderId as string
  const artworkId = route.query.artworkId as string
  const qty = route.query.quantity as string
  const bank = route.query.bank as string
  const depositor = route.query.depositor as string
  
  // 은행 목록 조회 (은행명 표시를 위해)
  await fetchBanks()
  
  if (orderId) {
    orderNumber.value = orderId
  }
  
  if (artworkId) {
    const nftId = parseInt(artworkId)
    if (!isNaN(nftId)) {
      await fetchNFTDetail(nftId)
    }
  }
  
  if (qty) {
    quantity.value = parseInt(qty) || 1
  }

  if (bank) {
    depositInfo.value.bank = bank
  }

  if (depositor) {
    depositInfo.value.depositorName = depositor
  }

  isLoading.value = false
})
</script>

