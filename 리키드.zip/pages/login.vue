<template>
  <div :class="styles.loginPage">
    <Container>
      <h1 :class="styles.loginPage__title">로그인</h1>
      <LoginForm />
    </Container>
  </div>
</template>

<script setup lang="ts">
import { Container } from '@/components/ui'
import LoginForm from '~/features/LoginForm/LoginForm.vue'
import styles from '~/styles/pages/login.module.css'

definePageMeta({
  layout: 'signup'
})
</script>

