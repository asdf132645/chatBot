<template>
  <div :class="styles.nftDetailPage">
    <Container>
      <div v-if="isLoading" :class="styles.nftDetailPage__loading">
        <Spinner size="lg" />
      </div>
      <!-- TODO: 나중에 제거 가능 - artwork가 없을 때도 더미 데이터 표시 -->
      <template v-else-if="artwork || DUMMY_NFT_DETAIL">
        <div :class="styles.nftDetailPage__content">
          <div :class="styles.nftDetailPage__left">
            <div :class="styles.nftDetailPage__imageWrapper">
              <img :src="(artwork || DUMMY_NFT_DETAIL).imageUrl" :alt="(artwork || DUMMY_NFT_DETAIL).title" :class="styles.nftDetailPage__image" />
              <div :class="styles.nftDetailPage__imageActions">
                <button 
                  :class="styles.nftDetailPage__actionButton"
                  @click="handleCopyLink"
                  title="링크 복사"
                >
                  <span>🔗</span>
                </button>
              </div>
            </div>
          </div>
          <div :class="styles.nftDetailPage__right">
            <div :class="styles.nftDetailPage__brand"></div>
            <h1 :class="styles.nftDetailPage__title">{{ (artwork || DUMMY_NFT_DETAIL).title }}</h1>
            <div :class="styles.nftDetailPage__divider"></div>
            <div :class="styles.nftDetailPage__purchase">
              <div :class="styles.nftDetailPage__quantity">
                <button
                  :class="styles.nftDetailPage__quantityButton"
                  @click="decreaseQuantity"
                  :disabled="quantity <= getMinQuantity(artwork || DUMMY_NFT_DETAIL)"
                >
                  -
                </button>
                <span :class="styles.nftDetailPage__quantityValue">{{ quantity }}</span>
                <button
                  :class="styles.nftDetailPage__quantityButton"
                  @click="increaseQuantity"
                  :disabled="quantity >= getMaxQuantity(artwork || DUMMY_NFT_DETAIL)"
                >
                  +
                </button>
              </div>
              <div :class="styles.nftDetailPage__price">₩{{ ((artwork || DUMMY_NFT_DETAIL).price * quantity).toLocaleString() }}</div>
            </div>
            <button :class="styles.nftDetailPage__buyButton" @click="handlePurchase" :disabled="!(artwork || DUMMY_NFT_DETAIL).isActive">
              바로 구매하기
              <span :class="styles.nftDetailPage__arrow">↗</span>
            </button>
          </div>
        </div>
        <NFTDetailDescription :artwork="artworkForComponent" />
      </template>
    </Container>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { navigateTo } from '#app'
import { Container, Spinner } from '@/components/ui'
import { useAuthStore } from '~/stores/auth'
import { useToastStore } from '~/stores/toast'
import { getNFTDetail } from '~/shared/api/nft'
import type { NFTDetail } from '~/entities/nft/types'
import NFTDetailDescription from '~/features/NFTDetailDescription/NFTDetailDescription.vue'
import styles from '~/styles/pages/nft-detail.module.css'
import descriptionStyles from '~/styles/features/NFTDetailDescription.module.css'

definePageMeta({
  layout: 'default'
})

const route = useRoute()
const authStore = useAuthStore()
const toastStore = useToastStore()

const quantity = ref(1)
const artwork = ref<NFTDetail | null>(null)
const isLoading = ref(false)

// TODO: 나중에 제거 가능 - 서버 데이터가 없을 때 표시할 더미 데이터
const DUMMY_NFT_DETAIL: NFTDetail = {
  id: 999,
  title: '샘플 NFT 작품',
  imageUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjVmNWY1Ii8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5GVCBJbWFnZTwvdGV4dD48L3N2Zz4=',
  price: 100000,
  stockQuantity: 100,
  minQuantity: 1,
  maxQuantity: 10,
  artworkDescription: '이것은 샘플 NFT 작품입니다. 실제 작품 정보가 로드되지 않았을 때 표시되는 더미 데이터입니다.',
  brandDescription: 'LIKID는 크리에이터 중심의 라이프 시뮬레이션 게임으로, 사용자들이 자신만의 독특한 가상 세계를 만들고 경험할 수 있는 플랫폼입니다.',
  notes: '01\n구매자는 해당 NFT 아트워크의 고유한 소유권을 블록체인 상에서 영구적으로 보장받습니다.\n02\n아트워크의 저작권은 원작 아티스트에게 귀속되며, 상업적 이용은 별도의 허가 없이는 제한됩니다.\n03\nNFT는 개인 소장, 온라인 전시, 커뮤니티 내 활동 등 비상업적 사용 범위에서 자유롭게 활용 가능합니다.\n04\n모든 거래는 블록체인 네트워크를 기반으로 처리되며, 환불 및 교환은 불가합니다.\n05\n구매자는 브랜드 커뮤니티 및 이벤트 참여 권한을 제공받으며, 이와 관련된 혜택은 변동될 수 있습니다.',
  isActive: true,
  createEpoch: Date.now(),
  updateEpoch: Date.now()
}

// NFT 상세 조회
const fetchNFTDetail = async () => {
  if (import.meta.server) return
  
  const id = parseInt(route.params.id as string)
  if (isNaN(id)) {
    // 유효하지 않은 ID인 경우 더미 데이터 표시 (토스트 메시지 없이)
    artwork.value = { ...DUMMY_NFT_DETAIL, id: 999 }
    return
  }
  
  isLoading.value = true
  
  try {
    const response = await getNFTDetail(id)
    
    if ((response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') && response.data) {
      artwork.value = response.data
    } else {
      // 에러 발생 시 더미 데이터 표시 (토스트 메시지 없이)
      // TODO: 나중에 제거 가능 - 에러 발생 시 더미 데이터 표시
      artwork.value = { ...DUMMY_NFT_DETAIL, id }
    }
  } catch (err: any) {
    // 에러 발생 시 더미 데이터 표시 (토스트 메시지 없이)
    // TODO: 나중에 제거 가능 - 에러 발생 시 더미 데이터 표시
    const id = parseInt(route.params.id as string)
    artwork.value = { ...DUMMY_NFT_DETAIL, id: isNaN(id) ? 999 : id }
  } finally {
    isLoading.value = false
  }
}

// 선언형 방식으로 notes 파싱 (재귀 함수)
const parseNotes = (lines: string[], index = 0, acc: string[] = []): string[] => {
  if (index >= lines.length) return acc
  
  const line = lines[index]?.trim()
  if (!line) return parseNotes(lines, index + 1, acc)
  
  // "01", "02" 같은 번호만 있는 줄인지 확인
  if (/^0[1-9]$/.test(line)) {
    const number = line
    const content = lines[index + 1]?.trim() || ''
    if (content) {
      acc.push(`<span class="idnfttitle">${number}</span> ${content}`)
      return parseNotes(lines, index + 2, acc) // 다음 줄 건너뛰기
    } else {
      acc.push(`<span class="idnfttitle">${number}</span>`)
      return parseNotes(lines, index + 1, acc)
    }
  } else if (/^0[1-9]\s+(.+)$/.test(line)) {
    // "01 내용" 형식
    const match = line.match(/^(0[1-9])\s+(.+)$/)
    if (match?.[1] && match?.[2]) {
      const [, number, content] = match
      acc.push(`<span class="idnfttitle">${number}</span> ${content}`)
    }
    return parseNotes(lines, index + 1, acc)
  } else {
    // 번호가 없는 줄은 이전 항목에 추가
    const lastIndex = acc.length - 1
    if (lastIndex >= 0) {
      acc[lastIndex] += ` ${line}`
    } else {
      acc.push(line)
    }
    return parseNotes(lines, index + 1, acc)
  }
}

// 컴포넌트용 artwork 객체 (기존 구조 유지)
// TODO: 나중에 제거 가능 - artwork가 없을 때 더미 데이터 사용
const artworkForComponent = computed(() => {
  const currentArtwork = artwork.value || DUMMY_NFT_DETAIL
  
  if (!currentArtwork) {
    return {
      id: route.params.id as string,
      image: '',
      brand: '',
      title: '',
      price: 0,
      description: {
        artwork: '',
        brand: '',
        notes: []
      }
    }
  }
  
  // 서버에서 문자열로 받을 경우를 대비한 기본 유의사항
  const defaultNotesString = `01
구매자는 해당 NFT 아트워크의 고유한 소유권을 블록체인 상에서 영구적으로 보장받습니다.
02
아트워크의 저작권은 원작 아티스트에게 귀속되며, 상업적 이용은 별도의 허가 없이는 제한됩니다.
03
NFT는 개인 소장, 온라인 전시, 커뮤니티 내 활동 등 비상업적 사용 범위에서 자유롭게 활용 가능합니다.
04
모든 거래는 블록체인 네트워크를 기반으로 처리되며, 환불 및 교환은 불가합니다.
05
구매자는 브랜드 커뮤니티 및 이벤트 참여 권한을 제공받으며, 이와 관련된 혜택은 변동될 수 있습니다.`
  
  const defaultLines = defaultNotesString.split('\n').map(item => item.trim()).filter(item => item)
  const defaultNotes = parseNotes(defaultLines)

  // 서버에서 notes를 받은 경우 처리 (문자열 또는 배열)
  const notes: string[] = currentArtwork.notes 
    ? (typeof currentArtwork.notes === 'string'
        ? (() => {
            // 문자열인 경우 \n 기준으로 분리하고, "01", "02" 같은 번호를 볼드 처리
            const lines = currentArtwork.notes.split('\n').map(item => item.trim()).filter(item => item)
            
            // 선언형 방식으로 처리 (재귀 함수 재사용)
            return parseNotes(lines)
          })()
        : Array.isArray(currentArtwork.notes)
          ? currentArtwork.notes.map(note => 
              typeof note === 'string'
                ? note.replace(/^(0[1-9])\s+(.+)$/, `<span class="idnfttitle">$1</span> $2`).replace(/\n/g, '<br>')
                : note
            )
          : defaultNotes)
    : defaultNotes

  return {
    id: String(currentArtwork.id),
    image: currentArtwork.imageUrl,
    brand: '', // API 응답에 brand가 없으므로 빈 문자열
    title: currentArtwork.title,
    price: currentArtwork.price,
    description: {
      artwork: currentArtwork.artworkDescription,
      brand: currentArtwork.brandDescription || '',
      notes: notes
    }
  }
})

// 최소 수량 가져오기 (null이면 기본값 1)
const getMinQuantity = (artwork: NFTDetail) => {
  return artwork.minQuantity ?? 1
}

// 최대 수량 가져오기 (maxQuantity와 stockQuantity 중 작은 값 사용)
const getMaxQuantity = (artwork: NFTDetail) => {
  const maxQty = artwork.maxQuantity ?? Infinity
  const stockQty = artwork.stockQuantity ?? 0
  // maxQuantity와 stockQuantity 중 작은 값을 반환
  return Math.min(maxQty, stockQty)
}

// 수량 증가
const increaseQuantity = () => {
  const currentArtwork = artwork.value || DUMMY_NFT_DETAIL
  if (!currentArtwork) return
  const maxQty = getMaxQuantity(currentArtwork)
  if (quantity.value < maxQty) {
    quantity.value += 1
  }
}

// 수량 감소
const decreaseQuantity = () => {
  const currentArtwork = artwork.value || DUMMY_NFT_DETAIL
  if (!currentArtwork) return
  const minQty = getMinQuantity(currentArtwork)
  if (quantity.value > minQty) {
    quantity.value -= 1
  }
}

const handlePurchase = () => {
  // 로그인 상태 확인
  if (!authStore.isLoggedIn) {
    navigateTo('/login')
    return
  }
  
  const currentArtwork = artwork.value || DUMMY_NFT_DETAIL
  if (!currentArtwork) return
  // 결제 페이지로 이동
  navigateTo(`/checkout?artworkId=${currentArtwork.id}&quantity=${quantity.value}`)
}

// 링크 복사 기능
const handleCopyLink = async () => {
  if (import.meta.server) return
  
  try {
    const currentUrl = window.location.href
    await navigator.clipboard.writeText(currentUrl)
    toastStore.success('링크가 복사되었습니다.')
  } catch (error) {
    // 클립보드 API가 지원되지 않는 경우 대체 방법 사용
    try {
      const textArea = document.createElement('textarea')
      textArea.value = window.location.href
      textArea.style.position = 'fixed'
      textArea.style.opacity = '0'
      document.body.appendChild(textArea)
      textArea.select()
      document.execCommand('copy')
      document.body.removeChild(textArea)
      toastStore.success('링크가 복사되었습니다.')
    } catch (fallbackError) {
      toastStore.error('링크 복사에 실패했습니다.')
    }
  }
}

onMounted(() => {
  fetchNFTDetail()
})
</script>

