<template>
  <div :class="styles.nftDetailPage">
    <Container>
      <div v-if="isLoading" :class="styles.nftDetailPage__loading">
        <Spinner size="lg" />
      </div>
      <!-- TODO: 나중에 제거 가능 - artwork가 없을 때도 더미 데이터 표시 -->
      <template v-else-if="artwork || DUMMY_NFT_DETAIL">
        <div :class="styles.nftDetailPage__content">
          <div :class="styles.nftDetailPage__left">
            <div :class="styles.nftDetailPage__imageWrapper">
              <img :src="(artwork || DUMMY_NFT_DETAIL).imageUrl" :alt="(artwork || DUMMY_NFT_DETAIL).title" :class="styles.nftDetailPage__image" />
              <div :class="styles.nftDetailPage__imageActions">
                <button :class="styles.nftDetailPage__actionButton">
                  <span>🔗</span>
                </button>
                <button :class="styles.nftDetailPage__actionButton">
                  <span>♡</span>
                </button>
              </div>
            </div>
          </div>
          <div :class="styles.nftDetailPage__right">
            <div :class="styles.nftDetailPage__brand"></div>
            <h1 :class="styles.nftDetailPage__title">{{ (artwork || DUMMY_NFT_DETAIL).title }}</h1>
            <div :class="styles.nftDetailPage__divider"></div>
            <div :class="styles.nftDetailPage__purchase">
              <div :class="styles.nftDetailPage__quantity">
                <button
                  :class="styles.nftDetailPage__quantityButton"
                  @click="decreaseQuantity"
                  :disabled="quantity <= (artwork || DUMMY_NFT_DETAIL).minQuantity"
                >
                  -
                </button>
                <span :class="styles.nftDetailPage__quantityValue">{{ quantity }}</span>
                <button
                  :class="styles.nftDetailPage__quantityButton"
                  @click="increaseQuantity"
                  :disabled="quantity >= (artwork || DUMMY_NFT_DETAIL).maxQuantity"
                >
                  +
                </button>
              </div>
              <div :class="styles.nftDetailPage__price">₩{{ ((artwork || DUMMY_NFT_DETAIL).price * quantity).toLocaleString() }}</div>
            </div>
            <button :class="styles.nftDetailPage__buyButton" @click="handlePurchase" :disabled="!(artwork || DUMMY_NFT_DETAIL).isActive">
              바로 구매하기
              <span :class="styles.nftDetailPage__arrow">↗</span>
            </button>
          </div>
        </div>
        <NFTDetailDescription :artwork="artworkForComponent" />
      </template>
    </Container>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { navigateTo } from '#app'
import { Container, Spinner } from '@/components/ui'
import { useToastStore } from '~/stores/toast'
import { getNFTDetail } from '~/shared/api/nft'
import type { NFTDetail } from '~/entities/nft/types'
import NFTDetailDescription from '~/features/NFTDetailDescription/NFTDetailDescription.vue'
import styles from '~/styles/pages/nft-detail.module.css'
import descriptionStyles from '~/styles/features/NFTDetailDescription.module.css'

definePageMeta({
  layout: 'default'
})

const route = useRoute()
const toastStore = useToastStore()

const quantity = ref(1)
const artwork = ref<NFTDetail | null>(null)
const isLoading = ref(false)

// TODO: 나중에 제거 가능 - 서버 데이터가 없을 때 표시할 더미 데이터
const DUMMY_NFT_DETAIL: NFTDetail = {
  id: 999,
  title: '샘플 NFT 작품',
  imageUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjVmNWY1Ii8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5GVCBJbWFnZTwvdGV4dD48L3N2Zz4=',
  price: 100000,
  stockQuantity: 100,
  minQuantity: 1,
  maxQuantity: 10,
  artworkDescription: '이것은 샘플 NFT 작품입니다. 실제 작품 정보가 로드되지 않았을 때 표시되는 더미 데이터입니다.',
  brandDescription: 'LIKID는 크리에이터 중심의 라이프 시뮬레이션 게임으로, 사용자들이 자신만의 독특한 가상 세계를 만들고 경험할 수 있는 플랫폼입니다.',
  notes: '01\n구매자는 해당 NFT 아트워크의 고유한 소유권을 블록체인 상에서 영구적으로 보장받습니다.\n02\n아트워크의 저작권은 원작 아티스트에게 귀속되며, 상업적 이용은 별도의 허가 없이는 제한됩니다.\n03\nNFT는 개인 소장, 온라인 전시, 커뮤니티 내 활동 등 비상업적 사용 범위에서 자유롭게 활용 가능합니다.\n04\n모든 거래는 블록체인 네트워크를 기반으로 처리되며, 환불 및 교환은 불가합니다.\n05\n구매자는 브랜드 커뮤니티 및 이벤트 참여 권한을 제공받으며, 이와 관련된 혜택은 변동될 수 있습니다.',
  isActive: true,
  createEpoch: Date.now(),
  updateEpoch: Date.now()
}

// NFT 상세 조회
const fetchNFTDetail = async () => {
  if (import.meta.server) return
  
  const id = parseInt(route.params.id as string)
  if (isNaN(id)) {
    toastStore.error('유효하지 않은 NFT ID입니다.')
    return
  }
  
  isLoading.value = true
  
  try {
    const response = await getNFTDetail(id)
    
    if (response.message.httpStatus === '200 OK' && response.data) {
      artwork.value = response.data
    } else {
      const errorMessage = response.message.message || 'NFT 상세 정보를 불러오는데 실패했습니다.'
      toastStore.error(errorMessage)
      // TODO: 나중에 제거 가능 - 에러 발생 시 더미 데이터 표시
      artwork.value = { ...DUMMY_NFT_DETAIL, id }
    }
  } catch (err: any) {
    console.error('NFT 상세 조회 오류:', err)
    const errorMessage = err.response?.data?.message?.message || 
                        err.response?.data?.message || 
                        err.message || 
                        'NFT 상세 정보를 불러오는데 실패했습니다.'
    toastStore.error(errorMessage)
    // TODO: 나중에 제거 가능 - 에러 발생 시 더미 데이터 표시
    const id = parseInt(route.params.id as string)
    artwork.value = { ...DUMMY_NFT_DETAIL, id: isNaN(id) ? 999 : id }
  } finally {
    isLoading.value = false
  }
}

// 컴포넌트용 artwork 객체 (기존 구조 유지)
// TODO: 나중에 제거 가능 - artwork가 없을 때 더미 데이터 사용
const artworkForComponent = computed(() => {
  const currentArtwork = artwork.value || DUMMY_NFT_DETAIL
  
  if (!currentArtwork) {
    return {
      id: route.params.id as string,
      image: '',
      brand: '',
      title: '',
      price: 0,
      description: {
        artwork: '',
        brand: '',
        notes: []
      }
    }
  }
  
  // 서버에서 문자열로 받을 경우를 대비한 기본 유의사항
  const defaultNotesString = `01
구매자는 해당 NFT 아트워크의 고유한 소유권을 블록체인 상에서 영구적으로 보장받습니다.
02
아트워크의 저작권은 원작 아티스트에게 귀속되며, 상업적 이용은 별도의 허가 없이는 제한됩니다.
03
NFT는 개인 소장, 온라인 전시, 커뮤니티 내 활동 등 비상업적 사용 범위에서 자유롭게 활용 가능합니다.
04
모든 거래는 블록체인 네트워크를 기반으로 처리되며, 환불 및 교환은 불가합니다.
05
구매자는 브랜드 커뮤니티 및 이벤트 참여 권한을 제공받으며, 이와 관련된 혜택은 변동될 수 있습니다.`
  
  const defaultNotes: string[] = []
  const defaultLines = defaultNotesString.split('\n').map(item => item.trim()).filter(item => item)
  
  for (let i = 0; i < defaultLines.length; i++) {
    const line = defaultLines[i]
    if (!line) continue
    
    // "01", "02" 같은 번호만 있는 줄인지 확인
    if (/^0[1-9]$/.test(line)) {
      const number = line
      // 다음 줄이 내용
      const content = defaultLines[i + 1] || ''
      if (content) {
        defaultNotes.push(`<span class="idnfttitle">${number}</span> ${content}`)
        i++ // 다음 줄을 건너뛰기
      } else {
        defaultNotes.push(`<span class="idnfttitle">${number}</span>`)
      }
    } else if (/^0[1-9]\s+(.+)$/.test(line)) {
      // "01 내용" 형식
      const match = line.match(/^(0[1-9])\s+(.+)$/)
      if (match && match[1] && match[2]) {
        const number = match[1]
        const content = match[2]
        defaultNotes.push(`<span class="idnfttitle">${number}</span> ${content}`)
      }
    } else {
      // 번호가 없는 줄은 이전 항목에 추가
      if (defaultNotes.length > 0) {
        defaultNotes[defaultNotes.length - 1] += ' ' + line
      } else {
        defaultNotes.push(line)
      }
    }
  }

  // 서버에서 notes를 받은 경우 처리 (문자열 또는 배열)
  let notes: string[] = defaultNotes
  if (currentArtwork.notes) {
    if (typeof currentArtwork.notes === 'string') {
      // 문자열인 경우 \n 기준으로 분리하고, "01", "02" 같은 번호를 볼드 처리
      const lines = currentArtwork.notes.split('\n').map(item => item.trim()).filter(item => item)
      const noteItems: string[] = []
      
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i]
        if (!line) continue
        
        // "01", "02" 같은 번호만 있는 줄인지 확인
        if (/^0[1-9]$/.test(line)) {
          const number = line
          // 다음 줄이 내용
          const content = lines[i + 1] || ''
          if (content) {
            noteItems.push(`<span class="idnfttitle">${number}</span> ${content}`)
            i++ // 다음 줄을 건너뛰기
          } else {
            noteItems.push(`<span class="idnfttitle">${number}</span>`)
          }
        } else if (/^0[1-9]\s+(.+)$/.test(line)) {
          // "01 내용" 형식
          const match = line.match(/^(0[1-9])\s+(.+)$/)
          if (match && match[1] && match[2]) {
            const number = match[1]
            const content = match[2]
            noteItems.push(`<span class="idnfttitle">${number}</span> ${content}`)
          }
        } else {
          // 번호가 없는 줄은 이전 항목에 추가
          if (noteItems.length > 0) {
            noteItems[noteItems.length - 1] += ' ' + line
          } else {
            noteItems.push(line)
          }
        }
      }
      notes = noteItems
    } else if (Array.isArray(currentArtwork.notes)) {
      // 배열인 경우 각 항목의 "01", "02" 번호를 볼드 처리하고 \n을 <br>로 변환
      notes = currentArtwork.notes.map(note => {
        if (typeof note === 'string') {
          return note.replace(/^(0[1-9])\s+(.+)$/, `<span class="idnfttitle">$1</span> $2`)
            .replace(/\n/g, '<br>')
        }
        return note
      })
    }
  } else {
    // 기본값 사용
    notes = defaultNotes
  }

  return {
    id: String(currentArtwork.id),
    image: currentArtwork.imageUrl,
    brand: '', // API 응답에 brand가 없으므로 빈 문자열
    title: currentArtwork.title,
    price: currentArtwork.price,
    description: {
      artwork: currentArtwork.artworkDescription,
      brand: currentArtwork.brandDescription,
      notes: notes
    }
  }
})

// TODO: 나중에 제거 가능 - 더미 데이터도 처리하도록 수정
const increaseQuantity = () => {
  const currentArtwork = artwork.value || DUMMY_NFT_DETAIL
  if (!currentArtwork) return
  const maxQty = currentArtwork.maxQuantity
  if (quantity.value < maxQty) {
    quantity.value += 1
  }
}

const decreaseQuantity = () => {
  const currentArtwork = artwork.value || DUMMY_NFT_DETAIL
  if (!currentArtwork) return
  const minQty = currentArtwork.minQuantity
  if (quantity.value > minQty) {
    quantity.value -= 1
  }
}

const handlePurchase = () => {
  const currentArtwork = artwork.value || DUMMY_NFT_DETAIL
  if (!currentArtwork) return
  // 결제 페이지로 이동
  navigateTo(`/checkout?artworkId=${currentArtwork.id}&quantity=${quantity.value}`)
}

onMounted(() => {
  fetchNFTDetail()
})
</script>

