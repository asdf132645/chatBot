<template>
  <div :class="styles.nftPage">
    <Container>
      <h1 :class="styles.nftPage__title">NFT ARTWORK</h1>
      <NFTArtworkGrid />
    </Container>
  </div>
</template>

<script setup lang="ts">
import { Container } from '@/components/ui'
import NFTArtworkGrid from '~/features/NFTArtworkGrid/NFTArtworkGrid.vue'
import styles from '~/styles/pages/nft.module.css'

definePageMeta({
  layout: 'default'
})
</script>

