<template>
  <div :class="styles.checkoutPage">
    <Container>
      <h1 :class="styles.checkoutPage__title">주문 및 결제</h1>
      
      <section :class="styles.checkoutPage__section">
        <h2 :class="styles.checkoutPage__sectionTitle">주문상품</h2>
        <div :class="styles.checkoutPage__product">
          <div :class="styles.checkoutPage__productImage">
            <img :src="artwork.image" :alt="artwork.title" />
          </div>
          <div :class="styles.checkoutPage__productInfo">
            <div :class="styles.checkoutPage__brand">{{ artwork.brand }}</div>
            <div :class="styles.checkoutPage__productTitle">{{ artwork.title }}</div>
            <div :class="styles.checkoutPage__divider"></div>
            <div :class="styles.checkoutPage__productDetails">
              <span>수량 : {{ quantity }}</span>
              <span :class="styles.checkoutPage__price">₩{{ (artwork.price * quantity).toLocaleString() }}</span>
            </div>
          </div>
        </div>
      </section>

      <section :class="styles.checkoutPage__section">
        <h2 :class="styles.checkoutPage__sectionTitle">입금정보</h2>
        <div :class="styles.checkoutPage__formRow">
          <label :class="styles.checkoutPage__label">입금은행</label>
          <select v-model="form.bank" :class="styles.checkoutPage__select">
            <option value="">은행을 선택하세요</option>
            <option value="kb">KB국민은행</option>
            <option value="shinhan">신한은행</option>
            <option value="woori">우리은행</option>
            <option value="hana">하나은행</option>
            <option value="nh">NH농협은행</option>
            <option value="ibk">IBK기업은행</option>
            <option value="keb">KEB하나은행</option>
            <option value="kakao">카카오뱅크</option>
            <option value="toss">토스뱅크</option>
          </select>
        </div>
        <div :class="styles.checkoutPage__formRow">
          <label :class="styles.checkoutPage__label">입금자명</label>
          <input
            v-model="form.depositorName"
            type="text"
            :class="styles.checkoutPage__input"
            placeholder="입금자명을 입력하세요"
          />
        </div>
      </section>

      <section :class="styles.checkoutPage__section">
        <h2 :class="styles.checkoutPage__sectionTitle">① 입금 안내</h2>
        <ul :class="styles.checkoutPage__guideList">
          <li>입금 확인은 평일 기준 1-2시간 이내 처리됩니다</li>
          <li>주말 및 공휴일 입금은 익일 확인됩니다</li>
          <li>주문 후 3일 이내 미입금 시 자동 주문 취소됩니다</li>
        </ul>
      </section>

      <button :class="styles.checkoutPage__submitButton" @click="handleSubmit">
        결제하기
      </button>
    </Container>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { navigateTo } from '#app'
import { Container } from '@/components/ui'
import styles from '~/styles/pages/checkout.module.css'

definePageMeta({
  layout: 'default'
})

const route = useRoute()

const quantity = ref(1)
const form = ref({
  bank: '',
  depositorName: ''
})

// Placeholder 이미지 (SVG data URL)
const placeholderImage = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjVmNWY1Ii8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5GVCBJbWFnZTwvdGV4dD48L3N2Zz4='

const artwork = ref({
  id: '',
  image: placeholderImage,
  brand: '브랜드명',
  title: '작품명 Neon Skull #102',
  price: 21000
})

onMounted(() => {
  // URL 파라미터에서 작품 정보 가져오기
  const artworkId = route.query.artworkId as string
  const qty = route.query.quantity as string
  
  if (artworkId) {
    artwork.value.id = artworkId
    // 실제로는 API에서 작품 정보를 가져와야 함
  }
  
  if (qty) {
    quantity.value = parseInt(qty) || 1
  }
})

const handleSubmit = () => {
  // 결제 처리 로직
  // 실제로는 API 호출 후 주문 완료 페이지로 이동
  const orderId = '1234567891012' // 실제로는 API 응답에서 받아옴
  
  navigateTo({
    path: '/order-complete',
    query: {
      orderId,
      artworkId: artwork.value.id,
      quantity: quantity.value.toString()
    }
  })
}
</script>

