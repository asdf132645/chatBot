<template>
  <div :class="styles.checkoutPage">
    <Container>
      <h1 :class="styles.checkoutPage__title">주문 및 결제</h1>
      
      <section :class="styles.checkoutPage__section">
        <h2 :class="styles.checkoutPage__sectionTitle">주문상품</h2>
        <div v-if="isLoadingArtwork" :class="styles.checkoutPage__loading">
          <Spinner size="lg" />
        </div>
        <div v-else :class="styles.checkoutPage__product">
          <div :class="styles.checkoutPage__productImage">
            <img :src="artwork.image" :alt="artwork.title" />
          </div>
          <div :class="styles.checkoutPage__productInfo">
            <div :class="styles.checkoutPage__brand">{{ artwork.brand }}</div>
            <div :class="styles.checkoutPage__productTitle">{{ artwork.title }}</div>
            <div :class="styles.checkoutPage__divider"></div>
            <div :class="styles.checkoutPage__productDetails">
              <span>수량 : {{ quantity }}</span>
              <span :class="styles.checkoutPage__price">₩{{ (artwork.price * quantity).toLocaleString() }}</span>
            </div>
          </div>
        </div>
      </section>

      <section :class="styles.checkoutPage__section">
        <h2 :class="styles.checkoutPage__sectionTitle">입금정보</h2>
        <div :class="styles.checkoutPage__formRow">
          <label :class="styles.checkoutPage__label">입금은행</label>
          <select v-model="form.bank" :class="styles.checkoutPage__select" :disabled="isLoadingBanks">
            <option value="">은행을 선택하세요</option>
            <option v-for="bank in banks" :key="bank.code" :value="bank.code">
              {{ bank.name }}
            </option>
          </select>
        </div>
        <div :class="styles.checkoutPage__formRow">
          <label :class="styles.checkoutPage__label">입금자명</label>
          <input
            v-model="form.depositorName"
            type="text"
            :class="styles.checkoutPage__input"
            placeholder="입금자명을 입력하세요"
          />
        </div>
      </section>

      <section :class="styles.checkoutPage__section">
        <h2 :class="styles.checkoutPage__sectionTitle">① 입금 안내</h2>
        <ul :class="styles.checkoutPage__guideList">
          <li>입금 확인은 평일 기준 1-2시간 이내 처리됩니다</li>
          <li>주말 및 공휴일 입금은 익일 확인됩니다</li>
          <li>주문 후 3일 이내 미입금 시 자동 주문 취소됩니다</li>
        </ul>
      </section>

      <button 
        :class="styles.checkoutPage__submitButton" 
        @click="handleSubmit"
        :disabled="isSubmitting || !form.bank || !form.depositorName"
      >
        {{ isSubmitting ? '처리 중...' : '결제하기' }}
      </button>
    </Container>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { navigateTo } from '#app'
import { Container, Spinner } from '@/components/ui'
import { useToastStore } from '~/stores/toast'
import { getBankList, createOrder } from '~/shared/api/order'
import { getNFTDetail } from '~/shared/api/nft'
import type { Bank } from '~/shared/api/order'
import type { NFTDetail } from '~/entities/nft/types'
import styles from '~/styles/pages/checkout.module.css'

definePageMeta({
  layout: 'default'
})

const route = useRoute()
const toastStore = useToastStore()

const quantity = ref(1)
const form = ref({
  bank: '',
  depositorName: ''
})

const banks = ref<Bank[]>([])
const isLoadingBanks = ref(false)
const isSubmitting = ref(false)
const isLoadingArtwork = ref(false)

// Placeholder 이미지 (SVG data URL)
const placeholderImage = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjVmNWY1Ii8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5GVCBJbWFnZTwvdGV4dD48L3N2Zz4='

const artwork = ref({
  id: '',
  image: placeholderImage,
  brand: '',
  title: '',
  price: 0
})

// 은행 목록 조회
const fetchBanks = async () => {
  if (import.meta.server) return

  isLoadingBanks.value = true
  try {
    const response = await getBankList()
    
    // httpStatus가 "OK" 또는 "200 OK"인 경우 성공
    if ((response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') && response.data) {
      banks.value = response.data
    } else {
      const errorMessage = response.message.message || '은행 목록을 불러오는데 실패했습니다.'
      toastStore.error(errorMessage)
    }
  } catch (err: any) {
    console.error('은행 목록 조회 오류:', err)
    const errorMessage = err.response?.data?.message?.message || 
                        err.response?.data?.message || 
                        err.message || 
                        '은행 목록을 불러오는데 실패했습니다.'
    toastStore.error(errorMessage)
  } finally {
    isLoadingBanks.value = false
  }
}

// NFT 상세 정보 조회
const fetchNFTDetail = async () => {
  if (import.meta.server) return
  
  const artworkId = route.query.artworkId as string
  if (!artworkId) {
    toastStore.error('작품 정보가 없습니다.')
    return
  }
  
  const id = parseInt(artworkId)
  if (isNaN(id)) {
    toastStore.error('유효하지 않은 작품 ID입니다.')
    return
  }
  
  isLoadingArtwork.value = true
  
  try {
    const response = await getNFTDetail(id)
    
    if ((response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') && response.data) {
      const nftDetail: NFTDetail = response.data
      artwork.value = {
        id: String(nftDetail.id),
        image: nftDetail.imageUrl,
        brand: '', // API 응답에 brand 필드가 없음
        title: nftDetail.title,
        price: nftDetail.price
      }
    } else {
      toastStore.error('작품 정보를 불러오는데 실패했습니다.')
    }
  } catch (err: any) {
    const errorMessage = err.response?.data?.message?.message || 
                        err.response?.data?.message || 
                        err.message || 
                        '작품 정보를 불러오는데 실패했습니다.'
    toastStore.error(errorMessage)
  } finally {
    isLoadingArtwork.value = false
  }
}

onMounted(() => {
  // URL 파라미터에서 수량 가져오기
  const qty = route.query.quantity as string
  if (qty) {
    quantity.value = parseInt(qty) || 1
  }
  
  // NFT 상세 정보 조회
  fetchNFTDetail()
  
  // 은행 목록 조회
  fetchBanks()
})

const handleSubmit = async () => {
  // 유효성 검사
  if (!form.value.bank) {
    toastStore.error('입금은행을 선택해주세요.')
    return
  }
  
  if (!form.value.depositorName) {
    toastStore.error('입금자명을 입력해주세요.')
    return
  }
  
  if (!artwork.value.id) {
    toastStore.error('작품 정보가 없습니다.')
    return
  }
  
  isSubmitting.value = true
  
  try {
    const nftId = parseInt(artwork.value.id)
    if (isNaN(nftId)) {
      toastStore.error('유효하지 않은 작품 ID입니다.')
      return
    }
    
    const totalPrice = artwork.value.price * quantity.value
    
    const response = await createOrder({
      nftId,
      quantity: quantity.value,
      totalPrice,
      bank: form.value.bank,
      depositor: form.value.depositorName
    })
    
    // httpStatus가 "OK", "200 OK", 또는 "CREATED"인 경우 성공
    if (response.message.httpStatus === 'OK' || 
        response.message.httpStatus === '200 OK' || 
        response.message.httpStatus === 'CREATED') {
      toastStore.success('주문이 완료되었습니다.')
      
      // 주문 완료 페이지로 이동
      navigateTo({
        path: '/order-complete',
        query: {
          artworkId: artwork.value.id,
          quantity: quantity.value.toString(),
          bank: form.value.bank,
          depositor: form.value.depositorName
        }
      })
    } else {
      const errorMessage = response.message.message || '주문 처리에 실패했습니다.'
      toastStore.error(errorMessage)
    }
  } catch (err: any) {
    const errorMessage = err.response?.data?.message?.message || 
                        err.response?.data?.message || 
                        err.message || 
                        '주문 처리에 실패했습니다.'
    toastStore.error(errorMessage)
  } finally {
    isSubmitting.value = false
  }
}
</script>

