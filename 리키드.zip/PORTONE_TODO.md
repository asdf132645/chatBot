# Portone 관련 남은 작업 정리

이 문서는 Portone 관련해서 아직 구현되지 않았거나 완료해야 할 작업들을 정리한 것입니다.

## 📋 목차

1. [비밀번호 찾기/재설정 API 연동](#1-비밀번호-찾기재설정-api-연동)
2. [Portone 결제 연동 (선택사항)](#2-portone-결제-연동-선택사항)
3. [주문 상세 조회 API 연동](#3-주문-상세-조회-api-연동)

---

## 1. 비밀번호 찾기/재설정 API 연동

### 현재 상태
- ✅ 비밀번호 찾기 폼 UI 완료
- ✅ Portone PASS 본인인증 연동 완료
- ❌ 비밀번호 재설정 API 미연동

### 작업 위치

**파일:** `features/FindAccountForm/FindAccountForm.vue`

**함수:** `handleFindPassword` (약 419번째 줄)

**현재 코드:**
```typescript
const handleFindPassword = async () => {
  // ... 검증 로직 ...
  
  // PASS 인증 확인
  if (!isKycVerified.value || !identityToken.value) {
    toastStore.error('본인인증을 완료해주세요.')
    return
  }

  // TODO: 비밀번호 재설정 API 호출
  // 실제로는 API 호출
  // 임시로 결과 표시
  result.value = {
    title: '비밀번호 재설정',
    message: '입력하신 정보가 확인되었습니다. 비밀번호 재설정 페이지로 이동합니다.',
    data: undefined
  }
}
```

### 필요한 작업

1. **백엔드 API 스펙 확인**
   - 비밀번호 재설정 API 엔드포인트 확인
   - Request body 구조 확인 (아이디, 이름, 생년월일, 휴대폰 번호, identityToken 등)
   - Response 구조 확인

2. **API 함수 추가**
   - **파일:** `shared/api/auth.ts`
   - 비밀번호 재설정 API 함수 추가
   - 예시:
   ```typescript
   export interface ResetPasswordRequest {
     loginId: string
     name: string
     birthDate: string
     mobilePhoneNumber: string
     identityToken: string
   }
   
   export const resetPassword = async (data: ResetPasswordRequest): Promise<ApiResponse<{}>> => {
     const response = await apiClient.post<ApiResponse<{}>>('/api/v1/auth/reset-password', data)
     return response.data
   }
   ```

3. **`handleFindPassword` 함수 수정**
   - **파일:** `features/FindAccountForm/FindAccountForm.vue`
   - 실제 API 호출로 변경
   - 성공 시 비밀번호 재설정 페이지로 이동하거나 결과 표시
   - 에러 처리 추가

### 참고사항
- `identityToken`은 Portone PASS 인증 완료 후 받은 값 사용
- 휴대폰 번호는 하이픈 제거 후 전송
- 생년월일은 YYYY-MM-DD 형식으로 전송

---

## 2. Portone 결제 연동 (선택사항)

### 현재 상태
- ✅ 무통장 입금 방식만 구현됨
- ❌ Portone 결제 연동 미구현

### 작업 위치

**파일:** `pages/checkout.vue`

**함수:** `handleSubmit` (약 195번째 줄)

**현재 코드:**
```typescript
const handleSubmit = async () => {
  // ... 유효성 검사 ...
  
  const response = await createOrder({
    nftId,
    quantity: quantity.value,
    totalPrice,
    bank: form.value.bank,
    depositor: form.value.depositorName
  })
  
  // 주문 완료 페이지로 이동
  navigateTo({
    path: '/order-complete',
    query: {
      artworkId: artwork.value.id,
      quantity: quantity.value.toString(),
      bank: form.value.bank,
      depositor: form.value.depositorName
    }
  })
}
```

### 필요한 작업

1. **결제 방식 선택 UI 추가**
   - 무통장 입금 / 신용카드 결제 선택 옵션 추가
   - **파일:** `pages/checkout.vue`
   - **위치:** 입금정보 섹션 위에 결제 방식 선택 추가

2. **Portone 결제 SDK 연동**
   - **파일:** `features/payment/usePortonePayment.ts` (새로 생성)
   - Portone 결제 SDK 로드
   - 결제 요청 함수 구현
   - 결제 완료 콜백 처리

3. **결제 API 연동**
   - **파일:** `shared/api/payment.ts` (새로 생성)
   - 결제 승인 API 함수 추가
   - 결제 취소 API 함수 추가 (필요시)

4. **`handleSubmit` 함수 수정**
   - **파일:** `pages/checkout.vue`
   - 결제 방식에 따라 분기 처리
   - 무통장 입금: 기존 로직 유지
   - 신용카드 결제: Portone 결제 SDK 호출 → 결제 완료 후 주문 생성

### 참고사항
- Portone 결제는 별도의 Store ID와 Channel Key가 필요할 수 있음
- 결제 완료 후 주문 생성 API 호출
- 결제 실패 시 에러 처리

---

## 3. 주문 상세 조회 API 연동

### 현재 상태
- ✅ 주문 생성 API 연동 완료
- ✅ 주문 완료 페이지 UI 완료
- ❌ 주문 상세 조회 API 미연동 (URL 파라미터로만 정보 전달)

### 작업 위치

**파일:** `pages/order-complete.vue`

**함수:** `onMounted` (약 123번째 줄)

**현재 코드:**
```typescript
onMounted(async () => {
  // URL 파라미터에서 주문 정보 가져오기
  const orderId = route.query.orderId as string
  const artworkId = route.query.artworkId as string
  // ...
  
  // 실제로는 API에서 주문 정보를 가져와야 함
  // depositInfo도 API에서 가져와야 함
})
```

### 필요한 작업

1. **백엔드 API 스펙 확인**
   - 주문 상세 조회 API 엔드포인트 확인 (예: `GET /api/v1/order/{orderId}`)
   - Response 구조 확인 (주문 정보, 작품 정보, 입금 정보 등)

2. **API 함수 추가**
   - **파일:** `shared/api/order.ts`
   - 주문 상세 조회 API 함수 추가
   - 예시:
   ```typescript
   export interface OrderDetail {
     orderId: string
     orderNumber: string
     nftId: number
     quantity: number
     totalPrice: number
     bank: string
     depositor: string
     status: string
     createdAt: string
     // ... 기타 필드
   }
   
   export async function getOrderDetail(orderId: string): Promise<ApiResponse<OrderDetail>> {
     const response = await apiClient.get<ApiResponse<OrderDetail>>(`/api/v1/order/${orderId}`)
     return response.data
   }
   ```

3. **`onMounted` 함수 수정**
   - **파일:** `pages/order-complete.vue`
   - `orderId`가 있으면 주문 상세 조회 API 호출
   - 응답에서 주문 정보, 작품 정보, 입금 정보 추출
   - NFT 상세 정보는 `getNFTDetail` API로 별도 조회 (또는 주문 상세 응답에 포함되어 있을 수 있음)

4. **`checkout.vue` 수정**
   - **파일:** `pages/checkout.vue`
   - 주문 생성 API 응답에서 `orderId` 받아서 전달
   - **위치:** `handleSubmit` 함수 (약 238번째 줄)
   - 예시:
   ```typescript
   if (response.message.httpStatus === 'CREATED') {
     const orderId = response.data?.orderId || response.data?.id
     navigateTo({
       path: '/order-complete',
       query: {
         orderId: orderId // orderId 추가
       }
     })
   }
   ```

### 참고사항
- 주문 생성 API 응답에 `orderId`가 포함되어 있는지 확인 필요
- 주문 상세 조회 API가 없으면 URL 파라미터 방식 유지
- NFT 작품 정보는 주문 상세 응답에 포함되어 있을 수도 있고, 별도 조회가 필요할 수도 있음

---

## 4. 체크리스트

### 비밀번호 찾기/재설정
- [ ] 백엔드 API 스펙 확인
- [ ] `shared/api/auth.ts`에 `resetPassword` 함수 추가
- [ ] `features/FindAccountForm/FindAccountForm.vue`의 `handleFindPassword` 함수 수정
- [ ] 성공 시 처리 (페이지 이동 또는 결과 표시)
- [ ] 에러 처리 추가

### Portone 결제 연동 (선택사항)
- [ ] 결제 방식 선택 UI 추가
- [ ] `features/payment/usePortonePayment.ts` 생성 및 구현
- [ ] `shared/api/payment.ts` 생성 및 결제 API 함수 추가
- [ ] `pages/checkout.vue`의 `handleSubmit` 함수 수정
- [ ] 결제 완료 후 주문 생성 로직 구현
- [ ] 결제 실패 시 에러 처리

### 주문 상세 조회
- [ ] 백엔드 API 스펙 확인
- [ ] `shared/api/order.ts`에 `getOrderDetail` 함수 추가
- [ ] `pages/order-complete.vue`의 `onMounted` 함수 수정
- [ ] `pages/checkout.vue`에서 `orderId` 전달하도록 수정
- [ ] 주문 상세 정보 표시 로직 구현

---

## 5. 관련 파일 목록

### 수정이 필요한 파일

1. **`features/FindAccountForm/FindAccountForm.vue`**
   - `handleFindPassword` 함수 수정 필요

2. **`pages/checkout.vue`**
   - `handleSubmit` 함수 수정 필요 (결제 연동 시)
   - 주문 생성 후 `orderId` 전달하도록 수정

3. **`pages/order-complete.vue`**
   - `onMounted` 함수 수정 필요 (주문 상세 조회 API 연동)

### 새로 생성해야 할 파일

1. **`shared/api/payment.ts`** (결제 연동 시)
   - Portone 결제 관련 API 함수

2. **`features/payment/usePortonePayment.ts`** (결제 연동 시)
   - Portone 결제 SDK 연동 composable

### 수정이 필요한 기존 파일

1. **`shared/api/auth.ts`**
   - `resetPassword` 함수 추가

2. **`shared/api/order.ts`**
   - `getOrderDetail` 함수 추가
   - `OrderDetail` 인터페이스 추가

---

## 6. API 스펙 확인 필요 항목

다음 API들의 정확한 스펙을 확인해야 합니다:

1. **비밀번호 재설정 API**
   - 엔드포인트: `POST /api/v1/auth/reset-password` (예상)
   - Request body 구조
   - Response 구조

2. **주문 상세 조회 API**
   - 엔드포인트: `GET /api/v1/order/{orderId}` (예상)
   - Response 구조
   - 주문 생성 API 응답에 `orderId` 포함 여부

3. **Portone 결제 API** (결제 연동 시)
   - 결제 승인 API
   - 결제 취소 API
   - 결제 조회 API

---

## 7. 참고 자료

- [Portone 결제 연동 가이드](https://developers.portone.io/docs/ko/tip/payment)
- [Portone 본인인증 가이드](https://developers.portone.io/docs/ko/tip/identity-verification)
- [Portone 관리자 콘솔](https://admin.portone.io)

---

**마지막 업데이트:** 2025년 1월 27일

