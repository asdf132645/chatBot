# CloudFront SPA 배포 설정 가이드

## 문제: `/login` 페이지가 작동하지 않는 경우

**중요**: SPA 모드에서는 `/login` 경로로 직접 접근할 때 `/login/index.html`을 반환해야 합니다.

### 1. CloudFront Custom Error Response 설정 확인 (필수!)

CloudFront 콘솔에서 다음 설정을 확인하세요:

1. **Distribution 선택** → **Error Pages** 탭
2. **Create Custom Error Response** 클릭
3. 다음 설정 추가:
   - **HTTP Error Code**: `404: Not Found`
   - **Customize Error Response**: `Yes`
   - **Response Page Path**: `/index.html`
   - **HTTP Response Code**: `200: OK`
   - **Error Caching Minimum TTL**: `10` (초)

4. **403: Forbidden** 에러도 동일하게 설정:
   - **HTTP Error Code**: `403: Forbidden`
   - **Customize Error Response**: `Yes`
   - **Response Page Path**: `/index.html`
   - **HTTP Response Code**: `200: OK`

### 2. CloudFront Origin 설정 확인

**중요**: CloudFront의 Origin을 S3 버킷의 **정적 웹사이트 호스팅 엔드포인트**로 설정해야 합니다!

1. CloudFront 콘솔 → **Origins and Origin Groups** 탭
2. Origin 선택 → **Edit**
3. **Origin Domain**을 다음 중 하나로 설정:
   - ✅ **S3 정적 웹사이트 호스팅 엔드포인트** (예: `your-bucket.s3-website.ap-northeast-2.amazonaws.com`)
   - ❌ **S3 버킷 도메인** (예: `your-bucket.s3.ap-northeast-2.amazonaws.com`) ← 이건 안 됨!

**왜?** S3 버킷 도메인은 `/login` 같은 경로를 인식하지 못하지만, 정적 웹사이트 호스팅 엔드포인트는 `/login/index.html`을 자동으로 반환합니다.

### 3. S3 버킷 정적 웹사이트 호스팅 설정

S3 버킷 설정에서:
1. **Properties** → **Static website hosting** 활성화
2. **Index document**: `index.html`
3. **Error document**: `index.html` (SPA 라우팅용)
4. **정적 웹사이트 호스팅 엔드포인트 URL**을 복사하여 CloudFront Origin에 사용

### 4. CloudFront 캐시 무효화

1. CloudFront 콘솔 → **Invalidations** 탭
2. **Create invalidation** 클릭
3. **Object paths**에 다음 입력:
   ```
   /login/*
   /login
   /*
   ```
4. **Create invalidation** 실행

### 5. S3 파일 업로드 확인

`.output/public` 폴더의 모든 파일이 S3에 업로드되었는지 확인:

```bash
# 로컬에서 확인
ls -la .output/public/login/
ls -la .output/public/signup/

# S3에서 확인 (AWS CLI 사용)
aws s3 ls s3://your-bucket-name/login/
aws s3 ls s3://your-bucket-name/signup/
```

### 6. 빌드 재생성 및 재배포

```bash
# 빌드 재생성
rm -rf .output .nuxt
npm run build

# S3에 업로드 (예시)
aws s3 sync .output/public s3://your-bucket-name --delete

# CloudFront 캐시 무효화
aws cloudfront create-invalidation \
  --distribution-id YOUR_DISTRIBUTION_ID \
  --paths "/*"
```

## 참고사항

- `/signup`은 작동하지만 `/login`이 작동하지 않는다면, S3에 파일이 제대로 업로드되지 않았을 가능성이 높습니다.
- CloudFront 캐시가 오래된 버전을 보여줄 수도 있으므로, 캐시 무효화를 시도해보세요.


