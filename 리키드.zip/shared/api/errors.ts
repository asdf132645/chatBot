// API 에러 코드 및 타입 정의

export enum ApiErrorCode {
  // 400
  InvalidRequest = 'InvalidRequest',
  ValidationFailed = 'ValidationFailed',
  InvalidIdentityToken = 'InvalidIdentityToken',
  InvalidParameter = 'InvalidParameter',
  PhoneVerificationRequired = 'PhoneVerificationRequired',
  
  // 401
  Unauthorized = 'Unauthorized',
  TokenExpired = 'TokenExpired',
  InvalidCredentials = 'InvalidCredentials',
  
  // 403
  Forbidden = 'Forbidden',
  KycNotVerified = 'KycNotVerified',
  PermissionDenied = 'PermissionDenied',
  
  // 404
  ResourceNotFound = 'ResourceNotFound',
  UserNotFound = 'UserNotFound',
  ArtworkNotFound = 'ArtworkNotFound',
  OrderNotFound = 'OrderNotFound',
  
  // 409
  Conflict = 'Conflict',
  DuplicatedLoginId = 'DuplicatedLoginId',
  AlreadyRegisteredUser = 'AlreadyRegisteredUser',
  DuplicateFavorite = 'DuplicateFavorite',
  OrderStateConflict = 'OrderStateConflict',
  
  // 500
  InternalServerError = 'InternalServerError',
  UpstreamServiceError = 'UpstreamServiceError',
  DatabaseError = 'DatabaseError',
  UnexpectedError = 'UnexpectedError'
}

export interface ApiError {
  message: {
    success: false
    reasonPhrase: ApiErrorCode | string
    message: string
  }
}

/**
 * API 에러인지 확인
 */
export const isApiError = (error: any): error is ApiError => {
  return error?.response?.data?.message?.success === false
}

/**
 * 특정 에러 코드인지 확인
 */
export const isErrorCode = (error: any, code: ApiErrorCode): boolean => {
  return isApiError(error) && error.message.reasonPhrase === code
}

