// 인증 관련 API 클라이언트
import { apiClient } from './instance'
import type {
  SignUpRequest,
  SignUpResponse,
  LoginRequest,
  LoginResponse,
  TokenRefreshRequest,
  TokenRefreshResponse,
  LogoutRequest,
  KycSessionRequest,
  KycSessionResponse,
  KycVerifyRequest,
  KycVerifyResponse,
  ApiResponse
} from '~/entities/user/types'

/**
 * 회원가입 API
 */
export const signUp = async (data: SignUpRequest): Promise<ApiResponse<SignUpResponse>> => {
  const response = await apiClient.post<ApiResponse<SignUpResponse>>('/api/v1/auth/sign-up', data)
  return response.data
}

/**
 * PASS 인증 세션 시작
 */
export const startKycSession = async (data: KycSessionRequest): Promise<ApiResponse<KycSessionResponse>> => {
  const response = await apiClient.post<ApiResponse<KycSessionResponse>>('/api/v1/auth/kyc/session', data)
  return response.data
}

/**
 * PASS 결과 검증
 */
export const verifyKyc = async (data: KycVerifyRequest): Promise<ApiResponse<KycVerifyResponse>> => {
  const response = await apiClient.post<ApiResponse<KycVerifyResponse>>('/api/v1/auth/kyc/verify', data)
  return response.data
}

/**
 * 로그인 API
 */
export const login = async (data: LoginRequest): Promise<ApiResponse<LoginResponse>> => {
  const response = await apiClient.post<ApiResponse<LoginResponse>>('/api/v1/auth/log-in', data)
  return response.data
}

/**
 * 토큰 재발급 API
 */
export const refreshToken = async (data: TokenRefreshRequest): Promise<ApiResponse<TokenRefreshResponse>> => {
  const response = await apiClient.post<ApiResponse<TokenRefreshResponse>>('/api/v1/auth/token/refresh', data)
  return response.data
}

/**
 * 로그아웃 API
 */
export const logout = async (): Promise<ApiResponse<void>> => {
  const response = await apiClient.post<ApiResponse<void>>('/api/v1/auth/log-out')
  return response.data
}

/**
 * 아이디 중복 체크 API
 * @param loginId - 확인할 아이디
 * @returns true면 중복, false면 사용 가능
 */
export const checkId = async (loginId: string): Promise<ApiResponse<boolean>> => {
  const response = await apiClient.get<ApiResponse<boolean>>('/api/v1/auth/check/id', {
    params: { loginId }
  })
  return response.data
}

/**
 * 이메일 중복 체크 API
 * @param email - 확인할 이메일
 * @returns true면 중복, false면 사용 가능
 */
export const checkEmail = async (email: string): Promise<ApiResponse<boolean>> => {
  const response = await apiClient.get<ApiResponse<boolean>>('/api/v1/auth/check/email', {
    params: { email }
  })
  return response.data
}

/**
 * 아이디 찾기 API
 */
export interface FindLoginIdRequest {
  name: string
  email: string
  mobilePhoneNumber: string
}

export const findLoginId = async (data: FindLoginIdRequest): Promise<ApiResponse<string>> => {
  const response = await apiClient.post<ApiResponse<string>>('/api/v1/auth/find/login-id', data)
  return response.data
}

/**
 * 모바일 인증번호 발송 API
 * POST /api/v1/auth/verification/mobile
 * 휴대폰 번호로 인증번호를 발송하고 recoveryToken을 받아옵니다.
 */
export interface MobileVerificationRequest {
  mobilePhoneNumber: string
}

export const verifyMobile = async (data: MobileVerificationRequest): Promise<ApiResponse<string>> => {
  const response = await apiClient.post<ApiResponse<string>>('/api/v1/auth/verification/mobile', data)
  return response.data
}

/**
 * 인증번호 확인 API
 * POST /api/v1/auth/verify/code
 * 사용자가 입력한 인증번호를 확인합니다.
 */
export interface VerifyCodeRequest {
  recoveryToken: string
  code: string
}

export const verifyCode = async (data: VerifyCodeRequest): Promise<ApiResponse<{}>> => {
  const response = await apiClient.post<ApiResponse<{}>>('/api/v1/auth/verify/code', data)
  return response.data
}

/**
 * 비밀번호 찾기 요청 API
 * POST /api/v1/auth/password/request
 * 아이디와 휴대폰 번호로 비밀번호 재설정 요청을 보냅니다.
 */
export interface RequestPasswordResetRequest {
  loginId: string
  mobilePhoneNumber: string
}

export const requestPasswordReset = async (data: RequestPasswordResetRequest): Promise<ApiResponse<string>> => {
  const response = await apiClient.post<ApiResponse<string>>('/api/v1/auth/password/request', data)
  return response.data
}

/**
 * 비밀번호 재설정 API
 * POST /api/v1/auth/reset/password
 * recoveryToken과 새로운 비밀번호로 비밀번호를 재설정합니다.
 */
export interface ResetPasswordRequest {
  recoveryToken: string
  newPassword: string
}

export const resetPassword = async (data: ResetPasswordRequest): Promise<ApiResponse<{}>> => {
  const response = await apiClient.post<ApiResponse<{}>>('/api/v1/auth/reset/password', data)
  return response.data
}

