// 인증 관련 API 클라이언트
import { apiClient } from './instance'
import type {
  SignUpRequest,
  SignUpResponse,
  LoginRequest,
  LoginResponse,
  TokenRefreshRequest,
  TokenRefreshResponse,
  LogoutRequest,
  KycSessionRequest,
  KycSessionResponse,
  KycVerifyRequest,
  KycVerifyResponse,
  ApiResponse
} from '~/entities/user/types'

/**
 * 회원가입 API
 */
export const signUp = async (data: SignUpRequest): Promise<ApiResponse<SignUpResponse>> => {
  const response = await apiClient.post<ApiResponse<SignUpResponse>>('/api/v1/auth/sign-up', data)
  return response.data
}

/**
 * PASS 인증 세션 시작
 */
export const startKycSession = async (data: KycSessionRequest): Promise<ApiResponse<KycSessionResponse>> => {
  const response = await apiClient.post<ApiResponse<KycSessionResponse>>('/api/v1/auth/kyc/session', data)
  return response.data
}

/**
 * PASS 결과 검증
 */
export const verifyKyc = async (data: KycVerifyRequest): Promise<ApiResponse<KycVerifyResponse>> => {
  const response = await apiClient.post<ApiResponse<KycVerifyResponse>>('/api/v1/auth/kyc/verify', data)
  return response.data
}

/**
 * 로그인 API
 */
export const login = async (data: LoginRequest): Promise<ApiResponse<LoginResponse>> => {
  const response = await apiClient.post<ApiResponse<LoginResponse>>('/api/v1/auth/log-in', data)
  return response.data
}

/**
 * 토큰 재발급 API
 */
export const refreshToken = async (data: TokenRefreshRequest): Promise<ApiResponse<TokenRefreshResponse>> => {
  const response = await apiClient.post<ApiResponse<TokenRefreshResponse>>('/api/v1/auth/token/refresh', data)
  return response.data
}

/**
 * 로그아웃 API
 */
export const logout = async (): Promise<ApiResponse<void>> => {
  const response = await apiClient.post<ApiResponse<void>>('/api/v1/auth/log-out')
  return response.data
}

