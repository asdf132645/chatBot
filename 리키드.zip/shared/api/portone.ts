// PortOne REST API V2 클라이언트
import axios, { type AxiosInstance } from 'axios'

// PortOne API 기본 URL
const PORTONE_API_BASE_URL = 'https://api.portone.io'

// PortOne API 인스턴스 생성
const portoneApiClient: AxiosInstance = axios.create({
  baseURL: PORTONE_API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 타입 정의
export interface PortOneTokenRequest {
  apiKey: string
  apiSecret: string
}

export interface PortOneTokenResponse {
  accessToken: string
  tokenType: string
  expiresIn: number
}

export interface PortOneCertificationResponse {
  imp_uid: string
  merchant_uid: string
  success: boolean
  name?: string
  gender?: string
  birth?: string
  foreigner?: boolean
  phone?: string
  carrier?: string
  certified?: boolean
  certified_at?: number
  unique_key?: string
  unique_in_site?: string
  pg_provider?: string
  pg_id?: string
  error_code?: string
  error_msg?: string
}

/**
 * PortOne Access Token 발급
 * POST /v2/token
 */
export async function getPortOneAccessToken(): Promise<string> {
  // 서버 사이드에서만 실행 (환경변수는 서버에서만 접근 가능)
  if (import.meta.server) {
    const apiKey = process.env.PORTONE_API_KEY
    const apiSecret = process.env.PORTONE_API_SECRET

    if (!apiKey || !apiSecret) {
      throw new Error('PORTONE_API_KEY와 PORTONE_API_SECRET 환경변수가 설정되어 있지 않습니다.')
    }

    try {
      const response = await portoneApiClient.post<PortOneTokenResponse>('/v2/token', {
        apiKey,
        apiSecret
      })

      if (response.data && response.data.accessToken) {
        return response.data.accessToken
      } else {
        throw new Error('PortOne Access Token 발급 실패: 응답 데이터가 올바르지 않습니다.')
      }
    } catch (error: any) {
      const errorMessage = error.response?.data?.message || error.message || 'PortOne Access Token 발급 중 오류가 발생했습니다.'
      throw new Error(`PortOne Access Token 발급 실패: ${errorMessage}`)
    }
  } else {
    // 클라이언트 사이드에서는 서버 API를 통해 호출
    const { apiClient } = await import('./instance')
    try {
      const response = await apiClient.post<{ accessToken: string }>('/api/v1/portone/token')
      if (response.data && response.data.accessToken) {
        return response.data.accessToken
      } else {
        throw new Error('PortOne Access Token 발급 실패: 응답 데이터가 올바르지 않습니다.')
      }
    } catch (error: any) {
      const errorMessage = error.response?.data?.message || error.message || 'PortOne Access Token 발급 중 오류가 발생했습니다.'
      throw new Error(`PortOne Access Token 발급 실패: ${errorMessage}`)
    }
  }
}

/**
 * PortOne 본인인증 결과 조회
 * GET /v2/certifications/:imp_uid
 */
export async function getCertification(imp_uid: string): Promise<PortOneCertificationResponse> {
  if (!imp_uid) {
    throw new Error('imp_uid가 필요합니다.')
  }

  try {
    // 서버 사이드에서 직접 호출
    if (import.meta.server) {
      // Access Token 발급
      const accessToken = await getPortOneAccessToken()

      // 인증 결과 조회
      const response = await portoneApiClient.get<PortOneCertificationResponse>(
        `/v2/certifications/${imp_uid}`,
        {
          headers: {
            Authorization: `PortOne ${accessToken}`
          }
        }
      )

      if (response.data) {
        return response.data
      } else {
        throw new Error('PortOne 본인인증 결과 조회 실패: 응답 데이터가 올바르지 않습니다.')
      }
    } else {
      // 클라이언트 사이드에서는 서버 API를 통해 호출
      const { apiClient } = await import('./instance')
      const response = await apiClient.get<PortOneCertificationResponse>(
        `/api/v1/portone/certifications/${imp_uid}`
      )
      
      if (response.data) {
        return response.data
      } else {
        throw new Error('PortOne 본인인증 결과 조회 실패: 응답 데이터가 올바르지 않습니다.')
      }
    }
  } catch (error: any) {
    const errorMessage = error.response?.data?.message || error.message || 'PortOne 본인인증 결과 조회 중 오류가 발생했습니다.'
    throw new Error(`PortOne 본인인증 결과 조회 실패: ${errorMessage}`)
  }
}

