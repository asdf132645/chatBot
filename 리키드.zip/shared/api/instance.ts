import axios from 'axios'
import type { AxiosInstance, AxiosRequestConfig, AxiosResponse, AxiosError } from 'axios'
import { useAuthStore } from '~/stores/auth'

// API 기본 URL 설정 (환경 변수에서 가져오거나 기본값 사용)
const API_BASE_URL = import.meta.env.NUXT_PUBLIC_API_BASE_URL || 'http://likid-api-dev.ap-northeast-2.elasticbeanstalk.com/likid'

// Axios 인스턴스 생성
export const apiClient: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 요청 인터셉터: 토큰 자동 추가
apiClient.interceptors.request.use(
  (config) => {
    // 클라이언트 사이드에서만 실행
    if (import.meta.client) {
      try {
        const authStore = useAuthStore()
        
        // 토큰이 있으면 Authorization 헤더에 추가
        if (authStore.token && config.headers) {
          config.headers.Authorization = `Bearer ${authStore.token}`
        }
      } catch (error) {
        // Store 초기화 실패 시 무시
        console.warn('Auth store not available:', error)
      }
    }
    
    return config
  },
  (error: AxiosError) => {
    return Promise.reject(error)
  }
)

// 응답 인터셉터: 에러 처리 및 토큰 재발급
apiClient.interceptors.response.use(
  (response: AxiosResponse) => {
    return response
  },
  async (error: AxiosError) => {
    const originalRequest = error.config as AxiosRequestConfig & { _retry?: boolean }
    
    // 401 Unauthorized 에러 처리
    if (error.response?.status === 401 && originalRequest && !originalRequest._retry) {
      originalRequest._retry = true
      
      if (import.meta.client) {
        try {
          const authStore = useAuthStore()
          
          // refreshToken이 있으면 토큰 재발급 시도
          if (authStore.refreshToken) {
            try {
              const { refreshToken: refreshTokenApi } = await import('./auth')
              const response = await refreshTokenApi({ refreshToken: authStore.refreshToken })
              
              // HTTP 상태 코드 또는 success 필드로 성공 여부 확인
              const isSuccess = response.message.httpStatus === '200 OK' || 
                               response.message.httpStatus === '200' ||
                               response.message.success === true ||
                               (response.data && response.data.accessToken && response.data.refreshToken)
              
              if (isSuccess && response.data) {
                // 새 토큰 저장
                authStore.setTokens({
                  accessToken: response.data.accessToken,
                  refreshToken: response.data.refreshToken
                })
                
                // 원래 요청 재시도
                if (originalRequest.headers) {
                  originalRequest.headers.Authorization = `Bearer ${response.data.accessToken}`
                }
                
                return apiClient(originalRequest)
              }
            } catch (refreshError) {
              // 토큰 재발급 실패 시 로그아웃
              authStore.logout()
              if (typeof window !== 'undefined') {
                window.location.href = '/login'
              }
              return Promise.reject(refreshError)
            }
          } else {
            // refreshToken이 없으면 로그아웃
            authStore.logout()
            if (typeof window !== 'undefined') {
              window.location.href = '/login'
            }
          }
        } catch (storeError) {
          // Store 초기화 실패 시 무시
          console.warn('Auth store not available:', storeError)
        }
      }
    }
    
    return Promise.reject(error)
  }
)

export default apiClient

