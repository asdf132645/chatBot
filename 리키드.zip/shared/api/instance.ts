import axios from 'axios'
import type { AxiosInstance, AxiosRequestConfig, AxiosResponse, AxiosError } from 'axios'
import { useAuthStore } from '~/stores/auth'

// API 기본 URL 설정 (환경 변수에서 가져오거나 기본값 사용)
const API_BASE_URL = import.meta.env.NUXT_PUBLIC_API_BASE_URL || 'http://likid-api-dev.ap-northeast-2.elasticbeanstalk.com/likid'

/**
 * JWT 토큰 디코딩 (페이로드만 추출)
 */
const decodeJWT = (token: string): any => {
  try {
    const parts = token.split('.')
    if (parts.length !== 3) return null
    
    const base64Url = parts[1]
    if (!base64Url) return null
    
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/')
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split('')
        .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    )
    return JSON.parse(jsonPayload)
  } catch (error) {
    return null
  }
}

/**
 * 토큰 만료 시간 체크 (만료 5분 전이면 true)
 */
const isTokenExpiringSoon = (token: string | null): boolean => {
  if (!token) return false
  
  const decoded = decodeJWT(token)
  if (!decoded || !decoded.exp) return false
  
  // exp는 초 단위이므로 밀리초로 변환
  const expTime = decoded.exp * 1000
  const now = Date.now()
  const fiveMinutes = 5 * 60 * 1000 // 5분
  
  // 만료 시간이 5분 이내면 true
  return expTime - now < fiveMinutes
}

/**
 * 토큰이 만료되었는지 체크
 */
const isTokenExpired = (token: string | null): boolean => {
  if (!token) return true
  
  const decoded = decodeJWT(token)
  if (!decoded || !decoded.exp) return true
  
  // exp는 초 단위이므로 밀리초로 변환
  const expTime = decoded.exp * 1000
  const now = Date.now()
  
  return now >= expTime
}

// Axios 인스턴스 생성
export const apiClient: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 요청 인터셉터: 토큰 자동 추가 및 만료 체크
apiClient.interceptors.request.use(
  async (config) => {
    // 클라이언트 사이드에서만 실행
    if (import.meta.client) {
      try {
        const authStore = useAuthStore()
        
        // 인증 관련 API는 토큰 갱신 시도하지 않음
        const isAuthEndpoint = config.url?.includes('/auth/log-in') || 
                              config.url?.includes('/auth/sign-up') ||
                              config.url?.includes('/auth/log-out') ||
                              config.url?.includes('/auth/token/refresh')
        
        // Access token이 만료되기 전이면 자동으로 리프레시
        if (!isAuthEndpoint && authStore.accessToken && authStore.refreshToken) {
          // Access token이 만료되었거나 곧 만료될 예정이면 리프레시
          if (isTokenExpired(authStore.accessToken) || isTokenExpiringSoon(authStore.accessToken)) {
            // 리프레시 토큰도 만료되었는지 체크
            if (!isTokenExpired(authStore.refreshToken)) {
              try {
                const { refreshToken: refreshTokenApi } = await import('./auth')
                const response = await refreshTokenApi({ refreshToken: authStore.refreshToken })
                
                // httpStatus가 "OK" 또는 "200 OK"인 경우 성공
                if ((response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') && response.data) {
                  // 새 토큰 저장 (로그인 유지 옵션 유지)
                  const keepLoggedIn = localStorage.getItem('access_token') !== null
                  authStore.setTokens({
                    accessToken: response.data.accessToken,
                    refreshToken: response.data.refreshToken,
                    keepLoggedIn
                  })
                }
              } catch (refreshError) {
                // 리프레시 실패 시 로그아웃하지 않고 계속 진행 (401 에러에서 처리)
                console.warn('Token refresh failed in interceptor:', refreshError)
              }
            }
          }
        }
        
        // 토큰이 있으면 Authorization 헤더에 추가
        if (authStore.token && config.headers) {
          config.headers.Authorization = `Bearer ${authStore.token}`
        }
      } catch (error) {
        // Store 초기화 실패 시 무시
        console.warn('Auth store not available:', error)
      }
    }
    
    return config
  },
  (error: AxiosError) => {
    return Promise.reject(error)
  }
)

// 응답 인터셉터: 에러 처리 및 토큰 재발급
apiClient.interceptors.response.use(
  (response: AxiosResponse) => {
    return response
  },
  async (error: AxiosError) => {
    const originalRequest = error.config as AxiosRequestConfig & { _retry?: boolean }
    
    // 401 Unauthorized 에러 처리
    // 로그인/회원가입 API는 토큰 재발급을 시도하지 않음
    const isAuthEndpoint = originalRequest?.url?.includes('/auth/log-in') || 
                          originalRequest?.url?.includes('/auth/sign-up') ||
                          originalRequest?.url?.includes('/auth/log-out')
    
    if (error.response?.status === 401 && originalRequest && !originalRequest._retry && !isAuthEndpoint) {
      originalRequest._retry = true
      
      if (import.meta.client) {
        try {
          const authStore = useAuthStore()
          
          // refreshToken이 있으면 토큰 재발급 시도
          if (authStore.refreshToken) {
            try {
              const { refreshToken: refreshTokenApi } = await import('./auth')
              const response = await refreshTokenApi({ refreshToken: authStore.refreshToken })
              
              // httpStatus가 "OK" 또는 "200 OK"인 경우 성공
              if ((response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') && response.data) {
                // 새 토큰 저장 (로그인 유지 옵션 유지)
                const keepLoggedIn = localStorage.getItem('access_token') !== null
                authStore.setTokens({
                  accessToken: response.data.accessToken,
                  refreshToken: response.data.refreshToken,
                  keepLoggedIn
                })
                
                // 원래 요청 재시도
                if (originalRequest.headers) {
                  originalRequest.headers.Authorization = `Bearer ${response.data.accessToken}`
                }
                
                return apiClient(originalRequest)
              }
            } catch (refreshError) {
              // 토큰 재발급 실패 시 로그아웃
              authStore.logout()
              if (typeof window !== 'undefined') {
                window.location.href = '/login'
              }
              return Promise.reject(refreshError)
            }
          } else {
            // refreshToken이 없으면 로그아웃
            authStore.logout()
            if (typeof window !== 'undefined') {
              window.location.href = '/login'
            }
          }
        } catch (storeError) {
          // Store 초기화 실패 시 무시
          console.warn('Auth store not available:', storeError)
        }
      }
    }
    
    return Promise.reject(error)
  }
)

export default apiClient

