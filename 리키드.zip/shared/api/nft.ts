// NFT 관련 API 클라이언트
import { apiClient } from './instance'
import type { ApiResponse } from '~/entities/user/types'
import type { NFTArtwork, NFTDetail, NFTListResponse } from '~/entities/nft/types'

/**
 * NFT 상품 리스트 조회 API
 */
export const getNFTList = async (): Promise<ApiResponse<NFTListResponse>> => {
  const response = await apiClient.get<ApiResponse<NFTListResponse>>('/api/v1/nft/list')
  return response.data
}

/**
 * NFT 상품 상세 조회 API
 */
export const getNFTDetail = async (id: number): Promise<ApiResponse<NFTDetail>> => {
  const response = await apiClient.get<ApiResponse<NFTDetail>>(`/api/v1/nft/${id}`)
  return response.data
}

