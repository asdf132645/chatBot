// 주문 관련 API

import { apiClient } from './instance'
import type { ApiResponse } from '~/entities/user/types'

export interface Bank {
  code: string
  name: string
}

export interface CreateOrderRequest {
  nftId: number
  quantity: number
  totalPrice: number
  bank: string
  depositor: string
}

/**
 * 입금은행 목록 조회
 */
export async function getBankList(): Promise<ApiResponse<Bank[]>> {
  const response = await apiClient.get<ApiResponse<Bank[]>>('/api/v1/order/bank')
  return response.data
}

/**
 * 주문 생성
 */
export async function createOrder(request: CreateOrderRequest): Promise<ApiResponse<{}>> {
  const response = await apiClient.post<ApiResponse<{}>>('/api/v1/order', request)
  return response.data
}

