<template>
  <section id="nft" :class="styles.nftFeatures">
    <Container>
      <div :class="styles.nftFeatures__grid">
        <div :class="styles.nftFeatures__titleCard">
          <h2 :class="styles.nftFeatures__title">NFT 특징</h2>
        </div>
        <div
          v-for="(feature, index) in nftFeatures"
          :key="index"
          :class="[
            styles.nftFeatures__card,
            expandedIndex === index ? styles['nftFeatures__card--expanded'] : ''
          ]"
          @click="handleCardClick(index)"
        >
          <div :class="styles.nftFeatures__header">
            <div :class="styles.nftFeatures__number">{{ String(index + 1).padStart(2, '0') }}</div>
            <div :class="styles.nftFeatures__dot"></div>
          </div>
          <div :class="styles.nftFeatures__divider"></div>
          <div :class="styles.nftFeatures__content">
            <p :class="styles.nftFeatures__text" v-html="feature.text"></p>
          </div>
        </div>
      </div>
    </Container>
  </section>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'
import { Container } from '@/components/ui'
import styles from '~/styles/features/NFTFeaturesSection.module.css'

// 모바일에서 첫 번째 카드가 열려있는 상태로 시작
const expandedIndex = ref<number | null>(null)

const handleCardClick = (index: number) => {
  // 모바일에서만 작동
  if (import.meta.client && window.innerWidth <= 767) {
    if (expandedIndex.value === index) {
      // 같은 카드를 클릭하면 닫기
      expandedIndex.value = null
    } else {
      // 다른 카드를 클릭하면 열기
      expandedIndex.value = index
    }
  }
}

// 모바일에서만 첫 번째 카드 열기
const checkMobile = () => {
  if (import.meta.client) {
    if (window.innerWidth <= 767) {
      if (expandedIndex.value === null) {
        expandedIndex.value = 0
      }
    } else {
      expandedIndex.value = null
    }
  }
}

onMounted(() => {
  checkMobile()
  if (import.meta.client) {
    window.addEventListener('resize', checkMobile)
  }
})

onUnmounted(() => {
  if (import.meta.client) {
    window.removeEventListener('resize', checkMobile)
  }
})

const nftFeatures = [
  {
    text: '브랜드 IP 기반의<br> 한정 디지털 아트워크 소유'
  },
  {
    text: '게임 아이템 스킨으로<br> NFT 디지털 아트워크 활용 가능'
  },
  {
    text: '도시 내 특정 공간 &<br> 이벤트 입장권 활용'
  },
  {
    text: 'NFT 컬렉터 전용 커뮤니티 &<br> 사전 이벤트 참여'
  }
]
</script>
