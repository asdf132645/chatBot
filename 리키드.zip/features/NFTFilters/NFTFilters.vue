<template>
  <div :class="styles.nftFilters">
    <div :class="styles.nftFilters__left">
      <div :class="styles.nftFilters__dropdowns">
        <select v-model="filters.status" :class="styles.nftFilters__dropdown">
          <option value="">판매상태</option>
          <option value="on-sale">판매중</option>
          <option value="sold-out">품절</option>
          <option value="upcoming">출시 예정</option>
        </select>
        <select v-model="filters.brand" :class="styles.nftFilters__dropdown">
          <option value="">브랜드</option>
          <option value="brand1">브랜드 1</option>
          <option value="brand2">브랜드 2</option>
          <option value="brand3">브랜드 3</option>
        </select>
        <select v-model="filters.price" :class="styles.nftFilters__dropdown">
          <option value="">가격</option>
          <option value="0-50000">50,000원 이하</option>
          <option value="50000-100000">50,000원 ~ 100,000원</option>
          <option value="100000-200000">100,000원 ~ 200,000원</option>
          <option value="200000+">200,000원 이상</option>
        </select>
      </div>
      <div :class="styles.nftFilters__tags">
        <button :class="styles.nftFilters__tag" @click="handleReset">
          <span>초기화</span>
          <!-- RefreshIcon 임시 제거 -->
          <svg :class="styles.nftFilters__tagIcon" width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M1 4V10H7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M23 20V14H17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10M23 14L18.36 18.36A9 9 0 0 1 3.51 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </button>
        <button
          v-for="tag in activeTags"
          :key="tag.key"
          :class="styles.nftFilters__tag"
          @click="removeFilter(tag.key)"
        >
          <span>{{ tag.label }}</span>
          <span :class="styles.nftFilters__tagClose">×</span>
        </button>
      </div>
    </div>
    <div :class="styles.nftFilters__right">
      <div :class="styles.nftFilters__search">
        <span :class="styles.nftFilters__searchIcon">🔍</span>
        <input
          v-model="searchQuery"
          type="text"
          :class="styles.nftFilters__searchInput"
          placeholder="Q 브랜드, 작품명 등으로 검색"
        />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
// RefreshIcon 임시 제거 - 인라인 SVG 사용
// import RefreshIcon from '@/components/ui/RefreshIcon.vue'
import styles from '~/styles/features/NFTFilters.module.css'

const searchQuery = ref('')
const filters = ref({
  status: '',
  brand: '',
  price: ''
})

// 필터 옵션 라벨 매핑
const filterLabels: Record<string, Record<string, string>> = {
  status: {
    'on-sale': '판매중',
    'sold-out': '품절',
    'upcoming': '출시 예정'
  },
  brand: {
    'brand1': '브랜드 1',
    'brand2': '브랜드 2',
    'brand3': '브랜드 3'
  },
  price: {
    '0-50000': '50,000원 이하',
    '50000-100000': '50,000원 ~ 100,000원',
    '100000-200000': '100,000원 ~ 200,000원',
    '200000+': '200,000원 이상'
  }
}

// 활성화된 필터 태그들
const activeTags = computed(() => {
  const tags: Array<{ key: string; label: string }> = []
  
  if (filters.value.status) {
    const label = filterLabels.status?.[filters.value.status]
    if (label) {
      tags.push({
        key: 'status',
        label: label
      })
    }
  }
  
  if (filters.value.brand) {
    const label = filterLabels.brand?.[filters.value.brand]
    if (label) {
      tags.push({
        key: 'brand',
        label: label
      })
    }
  }
  
  if (filters.value.price) {
    const label = filterLabels.price?.[filters.value.price]
    if (label) {
      tags.push({
        key: 'price',
        label: label
      })
    }
  }
  
  return tags
})

const removeFilter = (key: string) => {
  if (key === 'status') {
    filters.value.status = ''
  } else if (key === 'brand') {
    filters.value.brand = ''
  } else if (key === 'price') {
    filters.value.price = ''
  }
}

const handleReset = () => {
  filters.value = {
    status: '',
    brand: '',
    price: ''
  }
  searchQuery.value = ''
}
</script>

