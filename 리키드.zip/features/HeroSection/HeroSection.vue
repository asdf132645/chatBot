<template>
  <section id="home" :class="styles.hero">
    <Container>
      <div :class="styles.hero__content">
        <h1 :class="styles.hero__title">
          <span :class="styles.hero__titleLine1">당신의 아이덴티티를</span><br :class="styles.hero__titleBreak"><span :class="styles.hero__titleLine2">펼치는 공간</span>
        </h1>
        <NuxtLink to="/nft" :class="styles.hero__buttonLink">
          <Button 
            :class="styles.hero__button"
            size="lg" 
            variant="primary"
          >
            NFT 구매하기
          </Button>
        </NuxtLink>
        <div :class="styles.hero__divider"></div>
        <div :class="styles.hero__top">
          <p :class="styles.hero__description">
            리키드(LIKID)는 ‘LIKE’와 ‘IDENTITY’에서 영감을 얻어 만들어졌습니다.<br>
            이 안에는 개인과 브랜드가 고유한 아이덴티티를 발견하고,<br>
            표현하며 나아가야 한다는 철학이 담겨 있습니다.
          </p>
          <div :class="styles.hero__watermark">LIKID</div>
        </div>
        <div :class="styles.hero__divider"></div>
        <h2 :class="styles.hero__heading">LIKID IS A CREATOR-DRIVEN LIFE SIMULATION GAME.</h2>
        <div :class="styles.hero__divider"></div>
        <div :class="styles['hero__what-is']">
          <h3 :class="styles['hero__what-is-title']">• WHAT IS LIKID?</h3>
        </div>
        <div :class="styles.hero__divider"></div>
        <div :class="styles['hero__what-is-text']">
          <p>
            LIKID는 크리에이터 중심의 라이프 시뮬레이션 게임으로, 사용자들이 자신만의 독특한 가상 세계를 만들고 경험할 수 있는 플랫폼입니다.
          </p>
          <p>
            플레이어는 크리에이터이자 새로운 가상 도시의 주민으로, 현실과 독립된 공간에서 자신만의 삶을 설계하고 경험합니다.
          </p>
          <p>
            개인은 작품, 아이템, 경험을 통해 자신의 개성을 표현하고, 브랜드는 고유한 스토리와 비전을 담아 새로운 연결을 만들어갑니다.
          </p>
          <p>
            LIKID는 단순한 공간이 아닌, 자아 표현과 성장의 무대이며, 또 다른 삶을 살아갈 새로운 집입니다.
          </p>
        </div>
      </div>
    </Container>
  </section>
</template>

<script setup lang="ts">
import { Container, Button } from '@/components/ui'
import styles from '~/styles/features/HeroSection.module.css'
</script>
