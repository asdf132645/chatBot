<template>
  <section id="roadmap" :class="styles.roadmap">
    <Container>
      <div :class="styles.roadmap__titleSection">
        <h3 :class="styles.roadmap__title">• 로드맵</h3>
      </div>
      <div :class="styles.roadmap__wrapper">
        <div
          ref="sliderRef"
          :class="styles.roadmap__slider"
          @touchstart="handleTouchStart"
          @touchmove="handleTouchMove"
          @touchend="handleTouchEnd"
        >
          <div
            v-for="(item, index) in roadmapItems"
            :key="index"
            :class="[
              styles.roadmap__card,
              index === 0 ? styles['roadmap__card--dark'] : '',
              index === 3 ? styles['roadmap__card--behind'] : ''
            ]"
          >
            <div :class="styles.roadmap__period" v-html="item.period"></div>
            <ul :class="styles.roadmap__list">
              <li
                v-for="(feature, featureIndex) in item.features"
                :key="featureIndex"
              >
                <template v-if="typeof feature === 'string'">
                  {{ feature }}
                </template>
                <template v-else>
                  <div :class="styles.roadmap__featureMain">{{ feature.main }}</div>
                  <div :class="styles.roadmap__featureSub">{{ feature.sub }}</div>
                </template>
              </li>
            </ul>
          </div>
        </div>
        <p :class="styles.roadmap__disclaimer">
          본 내용은 향후 서비스 기획 및 업데이트에 따라 변동될 수 있습니다.
        </p>
      </div>
    </Container>
  </section>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'
import { Container } from '@/components/ui'
import styles from '~/styles/features/RoadmapSection.module.css'

const sliderRef = ref<HTMLElement | null>(null)
const touchStartX = ref(0)
const touchStartY = ref(0)
const isDragging = ref(false)
const scrollLeft = ref(0)

const roadmapItems = [
  {
    period: '2025 Q4 -<br> 2026 Q2',
    features: [
      {
        main: '콘셉트 검증',
        sub: '핵심 게임 플레이 루프와 아트 스타일 확정'
      },
      {
        main: '브랜드 파트너사 확보',
        sub: '패션, 아트, 라이프스타일 등 파트너사 확보'
      },
      {
        main: 'NFT 디지털 아트워크 론칭',
        sub: '파트너 브랜드 IP 기반'
      },
      {
        main: '커뮤니티 빌드업',
        sub: '디스코드/트위터/유튜브 중심 커뮤니티 운영'
      }
    ]
  },
  {
    period: '2026 Q3 -<br> 2026 Q4',
    features: [
      {
        main: '크리에이터 툴킷 알파 공개',
        sub: '플레이어가 직접 아이템, 공간 제작 가능'
      },
      {
        main: 'UGC 테스트',
        sub: '초기 크리에이터 그룹을 초청해, 도시 내 오브젝트 아이템 제작 테스트'
      },
      {
        main: '포인트 시스템 베타',
        sub: '충전/적립 테스트 시작'
      }
    ]
  },
  {
    period: '2027 Q1 -<br> 2027 Q2',
    features: [
      {
        main: '월드도시 오픈 베타',
        sub: '일부 구역 공개, 유저가 직접 탐험/생활할 수 있는 공간 확장'
      },
      {
        main: '파트너 브랜드 아이템 스킨 적용',
        sub: 'NFT 보유 디지털 아트워크 활용 아이템 스킨 적용'
      }
    ]
  },
  {
    period: '2027 Q3 -<br> 2027 Q4',
    features: [
      {
        main: '글로벌 런칭 PC/Mobile 크로스 플레이',
        sub: '아바타, 공간 커스터마이징 기능 일부 제공'
      },
      {
        main: 'UGC 마켓플레이스 오픈',
        sub: '크리에이터가 제작한 아이템•공간을 거래할 수 있는 구조'
      },
      {
        main: '포인트 연계 시스템 정식 도입',
        sub: '유저가 충전한 포인트 게임 내 경제 활동에 활용, NFT 구매로 확보한 아트워크 아이템 스킨화 가능'
      }
    ]
  }
]

const handleTouchStart = (e: TouchEvent) => {
  if (!sliderRef.value || !e.touches[0]) return
  touchStartX.value = e.touches[0].clientX
  touchStartY.value = e.touches[0].clientY
  scrollLeft.value = sliderRef.value.scrollLeft
  isDragging.value = true
}

const handleTouchMove = (e: TouchEvent) => {
  // 모바일에서는 세로 배치이므로 터치 드래그 비활성화
  if (window.innerWidth <= 767) {
    return
  }
  
  if (!isDragging.value || !sliderRef.value || !e.touches[0]) return
  
  const x = e.touches[0].clientX
  const y = e.touches[0].clientY
  const walkX = touchStartX.value - x
  const walkY = touchStartY.value - y
  
  // 수평 스크롤이 수직 스크롤보다 클 때만 슬라이드
  if (Math.abs(walkX) > Math.abs(walkY)) {
    e.preventDefault()
    sliderRef.value.scrollLeft = scrollLeft.value + walkX
  } else {
    // 수직 스크롤이 더 크면 드래그 취소
    isDragging.value = false
  }
}

const handleTouchEnd = () => {
  isDragging.value = false
}

// 마우스 드래그 지원
let mouseDown = false
let mouseStartX = 0
let mouseScrollLeft = 0

const handleMouseDown = (e: MouseEvent) => {
  if (!sliderRef.value) return
  mouseDown = true
  mouseStartX = e.pageX - (sliderRef.value.offsetLeft || 0)
  mouseScrollLeft = sliderRef.value.scrollLeft
  sliderRef.value.style.cursor = 'grabbing'
}

const handleMouseMove = (e: MouseEvent) => {
  if (!mouseDown || !sliderRef.value) return
  e.preventDefault()
  const x = e.pageX - (sliderRef.value.offsetLeft || 0)
  const walk = (x - mouseStartX) * 2
  sliderRef.value.scrollLeft = mouseScrollLeft - walk
}

const handleMouseUp = () => {
  mouseDown = false
  if (sliderRef.value) {
    sliderRef.value.style.cursor = 'grab'
  }
}

onMounted(() => {
  const slider = sliderRef.value
  if (slider) {
    slider.addEventListener('mousedown', handleMouseDown)
    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)
  }
})

onUnmounted(() => {
  const slider = sliderRef.value
  if (slider) {
    slider.removeEventListener('mousedown', handleMouseDown)
    window.removeEventListener('mousemove', handleMouseMove)
    window.removeEventListener('mouseup', handleMouseUp)
  }
})
</script>
