<template>
  <div :class="styles.findAccountForm">
    <!-- 탭 -->
    <div :class="styles.findAccountForm__tabs">
      <button
        :class="[
          styles.findAccountForm__tab,
          activeTab === 'id' ? styles['findAccountForm__tab--active'] : ''
        ]"
        @click="activeTab = 'id'"
      >
        아이디 찾기
      </button>
      <button
        :class="[
          styles.findAccountForm__tab,
          activeTab === 'password' ? styles['findAccountForm__tab--active'] : ''
        ]"
        @click="activeTab = 'password'"
      >
        비밀번호 찾기
      </button>
    </div>

    <!-- 아이디 찾기 폼 -->
    <form
      v-if="activeTab === 'id'"
      :class="styles.findAccountForm__form"
      @submit.prevent="handleFindId"
    >
      <div :class="styles.findAccountForm__row">
        <label :class="styles.findAccountForm__label">휴대폰 번호</label>
        <div :class="styles.findAccountForm__inputGroup">
          <input
            v-model="idForm.phone"
            type="tel"
            :class="[
              styles.findAccountForm__input,
              errors.idPhone ? styles['findAccountForm__input--error'] : ''
            ]"
            placeholder="010-0000-0000"
            @input="validateIdPhone"
          />
          <button 
            type="button" 
            :class="styles.findAccountForm__buttonSecondary"
            :disabled="kycLoading || isKycVerified"
            @click="handleKycRequest('id')"
          >
            {{ isKycVerified ? '인증완료' : '인증요청' }}
          </button>
        </div>
        <p v-if="errors.idPhone" :class="styles.findAccountForm__error">
          {{ errors.idPhone }}
        </p>
      </div>
      <button type="submit" :class="styles.findAccountForm__submitButton">
        아이디 찾기
      </button>
    </form>

    <!-- 비밀번호 찾기 폼 -->
    <form
      v-if="activeTab === 'password'"
      :class="styles.findAccountForm__form"
      @submit.prevent="handleFindPassword"
    >
      <div :class="styles.findAccountForm__row">
        <label :class="styles.findAccountForm__label">아이디</label>
        <input
          v-model="passwordForm.username"
          type="text"
          :class="[
            styles.findAccountForm__input,
            errors.passwordUsername ? styles['findAccountForm__input--error'] : ''
          ]"
          placeholder="아이디를 입력하세요"
          @input="validatePasswordUsername"
        />
        <p v-if="errors.passwordUsername" :class="styles.findAccountForm__error">
          {{ errors.passwordUsername }}
        </p>
      </div>
      <div :class="styles.findAccountForm__row">
        <label :class="styles.findAccountForm__label">이름</label>
        <input
          v-model="passwordForm.name"
          type="text"
          :class="[
            styles.findAccountForm__input,
            errors.passwordName ? styles['findAccountForm__input--error'] : ''
          ]"
          placeholder="이름을 입력하세요"
          @input="validatePasswordName"
        />
        <p v-if="errors.passwordName" :class="styles.findAccountForm__error">
          {{ errors.passwordName }}
        </p>
      </div>
      <div :class="styles.findAccountForm__row">
        <label :class="styles.findAccountForm__label">생년월일</label>
        <input
          v-model="passwordForm.birthDate"
          type="date"
          :class="[
            styles.findAccountForm__input,
            errors.passwordBirthDate ? styles['findAccountForm__input--error'] : ''
          ]"
          :max="maxDate"
          @change="validatePasswordBirthDate"
          @click="handleDateInputClick"
        />
        <p v-if="errors.passwordBirthDate" :class="styles.findAccountForm__error">
          {{ errors.passwordBirthDate }}
        </p>
      </div>
      <div :class="styles.findAccountForm__row">
        <label :class="styles.findAccountForm__label">휴대폰 번호</label>
        <div :class="styles.findAccountForm__inputGroup">
          <input
            v-model="passwordForm.phone"
            type="tel"
            :class="[
              styles.findAccountForm__input,
              errors.passwordPhone ? styles['findAccountForm__input--error'] : ''
            ]"
            placeholder="010-0000-0000"
            @input="validatePasswordPhone"
          />
          <button 
            type="button" 
            :class="styles.findAccountForm__buttonSecondary"
            :disabled="kycLoading || isKycVerified"
            @click="handleKycRequest('password')"
          >
            {{ isKycVerified ? '인증완료' : '인증요청' }}
          </button>
        </div>
        <p v-if="errors.passwordPhone" :class="styles.findAccountForm__error">
          {{ errors.passwordPhone }}
        </p>
      </div>
      <button type="submit" :class="styles.findAccountForm__submitButton">
        비밀번호 찾기
      </button>
    </form>

    <!-- 결과 표시 -->
    <div v-if="result" :class="styles.findAccountForm__result">
      <div :class="styles.findAccountForm__resultContent">
        <h3 :class="styles.findAccountForm__resultTitle">{{ result.title }}</h3>
        <p :class="styles.findAccountForm__resultText">{{ result.message }}</p>
        <div v-if="result.data" :class="styles.findAccountForm__resultData">
          <p v-if="activeTab === 'id'">
            아이디: <strong>{{ result.data }}</strong>
          </p>
        </div>
      </div>
      <div :class="styles.findAccountForm__resultActions">
        <NuxtLink to="/login" :class="styles.findAccountForm__buttonPrimary">
          로그인하기
        </NuxtLink>
        <button
          type="button"
          :class="styles.findAccountForm__buttonSecondary"
          @click="handleReset"
        >
          다시 찾기
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { usePortoneCertification } from '~/features/auth/usePortoneCertification'
import styles from '~/styles/features/FindAccountForm.module.css'

const route = useRoute()
const router = useRouter()

// Portone PASS 인증
const {
  requestCertification,
  isLoading: kycLoading,
  error: kycError,
  impUid,
  paymentId,
  identityToken: portoneIdentityToken,
  verification: portoneVerification,
  reset: resetPortone
} = usePortoneCertification()

// PASS 인증 상태
const isKycVerified = ref(false)
const identityToken = ref<string | null>(null)
const kycVerification = ref<any>(null)

const activeTab = ref<'id' | 'password'>('id')
const result = ref<{ title: string; message: string; data?: string } | null>(null)

const maxDate = computed(() => {
  if (import.meta.server) return undefined
  const today = new Date()
  return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`
})

const idForm = ref({
  phone: ''
})

const passwordForm = ref({
  username: '',
  name: '',
  birthDate: '',
  phone: ''
})

const errors = ref<Record<string, string>>({})

const handleDateInputClick = (event: Event) => {
  const input = event.target as HTMLInputElement
  if (input?.type === 'date' && 'showPicker' in input) {
    (input as any).showPicker()
  }
}

// 아이디 찾기 검증
const validateIdPhone = () => {
  if (!idForm.value.phone) {
    errors.value.idPhone = ''
    return
  }
  const pattern = /^01[0-9]-[0-9]{3,4}-[0-9]{4}$/
  errors.value.idPhone = !pattern.test(idForm.value.phone)
    ? '올바른 휴대폰 번호 형식을 입력해주세요.'
    : ''
}

// 비밀번호 찾기 검증
const validatePasswordUsername = () => {
  errors.value.passwordUsername = !passwordForm.value.username ? '아이디를 입력해주세요.' : ''
}

const validatePasswordName = () => {
  if (!passwordForm.value.name) {
    errors.value.passwordName = ''
    return
  }
  errors.value.passwordName = passwordForm.value.name.trim().length < 2 ? '이름을 정확히 입력해주세요.' : ''
}

const validatePasswordBirthDate = () => {
  errors.value.passwordBirthDate = !passwordForm.value.birthDate ? '생년월일을 선택해주세요.' : ''
}

const validatePasswordPhone = () => {
  if (!passwordForm.value.phone) {
    errors.value.passwordPhone = ''
    return
  }
  const pattern = /^01[0-9]-[0-9]{3,4}-[0-9]{4}$/
  errors.value.passwordPhone = !pattern.test(passwordForm.value.phone)
    ? '올바른 휴대폰 번호 형식을 입력해주세요.'
    : ''
}

// PASS 인증 요청 (Portone SDK 사용)
const handleKycRequest = async (type: 'id' | 'password') => {
  if (import.meta.server) return
  
  // 검증
  if (type === 'id') {
    validateIdPhone()
    if (errors.value.idPhone) return
  } else {
    validatePasswordPhone()
    if (errors.value.passwordPhone) return
  }
  
  try {
    // Portone PASS 인증 요청 - 아이디 찾기 또는 비밀번호 찾기용
    const usage = type === 'id' ? 'FIND_ID' : 'RESET_PASSWORD'
    const result = await requestCertification(usage)
    
    if (result && result.identityToken) {
      // 인증 성공 - 백엔드에서 identityToken 받음
      isKycVerified.value = true
      identityToken.value = result.identityToken
      kycVerification.value = result.verification
      
      console.log('✅ PASS 인증 완료 - identityToken:', result.identityToken)
      console.log('인증 정보:', result.verification)
      
      alert('본인인증이 완료되었습니다.')
    } else {
      alert(kycError.value || '본인인증에 실패했습니다.')
    }
  } catch (error) {
    console.error('PASS 인증 요청 오류:', error)
    alert('인증 요청 중 오류가 발생했습니다.')
  }
}

// Portone SDK는 직접 팝업을 띄우므로 콜백 처리가 필요 없음
// handleKycCallback 함수는 더 이상 사용하지 않음

const handleFindId = async () => {
  validateIdPhone()

  if (errors.value.idPhone) {
    return
  }

  // PASS 인증 확인
  if (!isKycVerified.value || !identityToken.value) {
    alert('본인인증을 완료해주세요.')
    return
  }

  // TODO: 아이디 찾기 API 호출
  // 실제로는 API 호출
  // 임시로 결과 표시
  result.value = {
    title: '아이디 찾기 완료',
    message: '입력하신 정보로 등록된 아이디를 찾았습니다.',
    data: 'user123' // 실제로는 API에서 받아온 값
  }
}

const handleFindPassword = async () => {
  validatePasswordUsername()
  validatePasswordName()
  validatePasswordBirthDate()
  validatePasswordPhone()

  if (
    errors.value.passwordUsername ||
    errors.value.passwordName ||
    errors.value.passwordBirthDate ||
    errors.value.passwordPhone
  ) {
    return
  }

  // PASS 인증 확인
  if (!isKycVerified.value || !identityToken.value) {
    alert('본인인증을 완료해주세요.')
    return
  }

  // TODO: 비밀번호 재설정 API 호출
  // 실제로는 API 호출
  // 임시로 결과 표시
  result.value = {
    title: '비밀번호 재설정',
    message: '입력하신 정보가 확인되었습니다. 비밀번호 재설정 페이지로 이동합니다.',
    data: undefined
  }
}

// Portone SDK는 직접 팝업을 띄우므로 onMounted에서 콜백 처리가 필요 없음

const handleReset = () => {
  result.value = null
  idForm.value = { phone: '' }
  passwordForm.value = { username: '', name: '', birthDate: '', phone: '' }
  errors.value = {}
  isKycVerified.value = false
  identityToken.value = null
  kycVerification.value = null
  resetPortone() // Portone 상태 초기화
}
</script>

