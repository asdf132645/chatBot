<template>
  <div :class="styles.findAccountForm">
    <!-- 탭 -->
    <div :class="styles.findAccountForm__tabs">
      <button
        :class="[
          styles.findAccountForm__tab,
          activeTab === 'id' ? styles['findAccountForm__tab--active'] : ''
        ]"
        @click="activeTab = 'id'"
      >
        아이디 찾기
      </button>
      <button
        :class="[
          styles.findAccountForm__tab,
          activeTab === 'password' ? styles['findAccountForm__tab--active'] : ''
        ]"
        @click="activeTab = 'password'"
      >
        비밀번호 찾기
      </button>
    </div>

    <!-- 아이디 찾기 폼 -->
    <form
      v-if="activeTab === 'id'"
      :class="styles.findAccountForm__form"
      @submit.prevent="handleFindId"
    >
      <div :class="styles.findAccountForm__row">
        <label :class="styles.findAccountForm__label">이름</label>
        <input
          v-model="idForm.name"
          type="text"
          :class="[
            styles.findAccountForm__input,
            errors.idName ? styles['findAccountForm__input--error'] : ''
          ]"
          placeholder="이름을 입력하세요"
          @input="validateIdName"
        />
        <p v-if="errors.idName" :class="styles.findAccountForm__error">
          {{ errors.idName }}
        </p>
      </div>
      <div :class="styles.findAccountForm__row">
        <label :class="styles.findAccountForm__label">이메일</label>
        <input
          v-model="idForm.email"
          type="email"
          :class="[
            styles.findAccountForm__input,
            errors.idEmail ? styles['findAccountForm__input--error'] : ''
          ]"
          placeholder="이메일을 입력하세요"
          @input="validateIdEmail"
        />
        <p v-if="errors.idEmail" :class="styles.findAccountForm__error">
          {{ errors.idEmail }}
        </p>
      </div>
      <div :class="styles.findAccountForm__row">
        <label :class="styles.findAccountForm__label">휴대폰 번호</label>
        <input
          v-model="idForm.phone"
          type="tel"
          :class="[
            styles.findAccountForm__input,
            errors.idPhone ? styles['findAccountForm__input--error'] : ''
          ]"
          placeholder="01000000000"
          @input="validateIdPhone"
        />
        <p v-if="errors.idPhone" :class="styles.findAccountForm__error">
          {{ errors.idPhone }}
        </p>
      </div>
      <button type="submit" :class="styles.findAccountForm__submitButton" :disabled="isFindingId">
        {{ isFindingId ? '찾는 중...' : '아이디 찾기' }}
      </button>
    </form>

    <!-- 비밀번호 찾기 폼 -->
    <form
      v-if="activeTab === 'password'"
      :class="styles.findAccountForm__form"
      @submit.prevent="handleFindPassword"
    >
      <div :class="styles.findAccountForm__row">
        <label :class="styles.findAccountForm__label">아이디</label>
        <input
          v-model="passwordForm.username"
          type="text"
          :class="[
            styles.findAccountForm__input,
            errors.passwordUsername ? styles['findAccountForm__input--error'] : ''
          ]"
          placeholder="아이디를 입력하세요"
          @input="validatePasswordUsername"
        />
        <p v-if="errors.passwordUsername" :class="styles.findAccountForm__error">
          {{ errors.passwordUsername }}
        </p>
      </div>
      <div :class="styles.findAccountForm__row">
        <label :class="styles.findAccountForm__label">휴대폰 번호</label>
        <input
          v-model="passwordForm.phone"
          type="tel"
          :class="[
            styles.findAccountForm__input,
            errors.passwordPhone ? styles['findAccountForm__input--error'] : ''
          ]"
          placeholder="01000000000"
          @input="validatePasswordPhone"
        />
        <p v-if="errors.passwordPhone" :class="styles.findAccountForm__error">
          {{ errors.passwordPhone }}
        </p>
      </div>
      <button type="submit" :class="styles.findAccountForm__submitButton" :disabled="isRequestingPassword">
        {{ isRequestingPassword ? '요청 중...' : '비밀번호 찾기' }}
      </button>
    </form>

    <!-- 아이디 찾기 완료 모달 -->
    <div v-if="result && activeTab === 'id'" :class="styles.findAccountForm__modalOverlay" @click="handleCloseModal">
      <div :class="styles.findAccountForm__modal" @click.stop>
        <div :class="styles.findAccountForm__modalContent">
          <h3 :class="styles.findAccountForm__modalTitle">{{ result.title }}</h3>
          <p :class="styles.findAccountForm__modalText">{{ result.message }}</p>
          <div v-if="result.data" :class="styles.findAccountForm__modalData">
            <p>아이디: <strong>{{ result.data }}</strong></p>
          </div>
        </div>
        <div :class="styles.findAccountForm__modalActions">
          <NuxtLink to="/login" :class="styles.findAccountForm__buttonPrimary">
            로그인하기
          </NuxtLink>
          <button
            type="button"
            :class="styles.findAccountForm__buttonSecondary"
            @click="handleCloseModal"
          >
            닫기
          </button>
        </div>
      </div>
    </div>

    <!-- 비밀번호 재설정 모달 -->
    <div v-if="showPasswordResetModal" :class="styles.findAccountForm__modalOverlay" @click="handleClosePasswordResetModal">
      <div :class="styles.findAccountForm__modal" @click.stop>
        <div :class="styles.findAccountForm__modalContent">
          <h3 :class="styles.findAccountForm__modalTitle">비밀번호 재설정</h3>
          <p :class="styles.findAccountForm__modalText">새로운 비밀번호를 입력해주세요.</p>
          
          <!-- 새 비밀번호 입력 -->
          <div :class="styles.findAccountForm__row">
            <label :class="styles.findAccountForm__label">새 비밀번호</label>
            <input
              v-model="newPassword"
              type="password"
              :class="[
                styles.findAccountForm__input,
                errors.newPassword ? styles['findAccountForm__input--error'] : ''
              ]"
              placeholder="새 비밀번호를 입력하세요"
              @input="validateNewPassword"
            />
            <p v-if="errors.newPassword" :class="styles.findAccountForm__error">
              {{ errors.newPassword }}
            </p>
          </div>

          <!-- 비밀번호 확인 -->
          <div :class="styles.findAccountForm__row">
            <label :class="styles.findAccountForm__label">비밀번호 확인</label>
            <input
              v-model="newPasswordConfirm"
              type="password"
              :class="[
                styles.findAccountForm__input,
                errors.newPasswordConfirm ? styles['findAccountForm__input--error'] : ''
              ]"
              placeholder="비밀번호를 다시 입력하세요"
              @input="validateNewPasswordConfirm"
            />
            <p v-if="errors.newPasswordConfirm" :class="styles.findAccountForm__error">
              {{ errors.newPasswordConfirm }}
            </p>
          </div>
        </div>
        <div :class="styles.findAccountForm__modalActions">
          <button
            type="button"
            :class="styles.findAccountForm__buttonPrimary"
            :disabled="isResettingPassword || !isPasswordResetFormValid"
            @click="handleResetPassword"
          >
            {{ isResettingPassword ? '처리 중...' : '비밀번호 재설정' }}
          </button>
          <button
            type="button"
            :class="styles.findAccountForm__buttonSecondary"
            @click="handleClosePasswordResetModal"
          >
            취소
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useToastStore } from '~/stores/toast'
import styles from '~/styles/features/FindAccountForm.module.css'

const route = useRoute()
const router = useRouter()
const toastStore = useToastStore()

const activeTab = ref<'id' | 'password'>('id')
const result = ref<{ title: string; message: string; data?: string } | null>(null)

const idForm = ref({
  name: '',
  email: '',
  phone: ''
})

const isFindingId = ref(false)

const passwordForm = ref({
  username: '',
  phone: ''
})

const errors = ref<Record<string, string>>({})

// 비밀번호 재설정 관련 상태
const isRequestingPassword = ref(false)
const recoveryTokenInput = ref('')
const showPasswordResetModal = ref(false)
const newPassword = ref('')
const newPasswordConfirm = ref('')
const isResettingPassword = ref(false)

// 아이디 찾기 검증
const validateIdName = () => {
  if (!idForm.value.name) {
    errors.value.idName = ''
    return
  }
  errors.value.idName = idForm.value.name.trim().length < 2 ? '이름을 정확히 입력해주세요.' : ''
}

const validateIdEmail = () => {
  if (!idForm.value.email) {
    errors.value.idEmail = ''
    return
  }
  const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  errors.value.idEmail = !pattern.test(idForm.value.email)
    ? '올바른 이메일 형식을 입력해주세요.'
    : ''
}

const validateIdPhone = () => {
  if (!idForm.value.phone) {
    errors.value.idPhone = ''
    return
  }
  // 하이픈 제거 후 검증
  const phoneWithoutHyphen = idForm.value.phone.replace(/-/g, '')
  const pattern = /^01[0-9][0-9]{3,4}[0-9]{4}$/
  errors.value.idPhone = !pattern.test(phoneWithoutHyphen)
    ? '올바른 휴대폰 번호 형식을 입력해주세요.'
    : ''
}

// 비밀번호 찾기 검증
const validatePasswordUsername = () => {
  errors.value.passwordUsername = !passwordForm.value.username ? '아이디를 입력해주세요.' : ''
}

const validatePasswordPhone = () => {
  if (!passwordForm.value.phone) {
    errors.value.passwordPhone = ''
    return
  }
  // 하이픈 제거 후 검증
  const phoneWithoutHyphen = passwordForm.value.phone.replace(/-/g, '')
  const pattern = /^01[0-9][0-9]{3,4}[0-9]{4}$/
  errors.value.passwordPhone = !pattern.test(phoneWithoutHyphen)
    ? '올바른 휴대폰 번호 형식을 입력해주세요.'
    : ''
}

// 비밀번호 재설정 검증
const validateNewPassword = () => {
  if (!newPassword.value) {
    errors.value.newPassword = ''
    return
  }
  if (newPassword.value.length < 8) {
    errors.value.newPassword = '비밀번호는 8자 이상이어야 합니다.'
    return
  }
  errors.value.newPassword = ''
  // 비밀번호 확인도 재검증
  if (newPasswordConfirm.value) {
    validateNewPasswordConfirm()
  }
}

const validateNewPasswordConfirm = () => {
  if (!newPasswordConfirm.value) {
    errors.value.newPasswordConfirm = ''
    return
  }
  if (newPassword.value !== newPasswordConfirm.value) {
    errors.value.newPasswordConfirm = '비밀번호가 일치하지 않습니다.'
    return
  }
  errors.value.newPasswordConfirm = ''
}

const isPasswordResetFormValid = computed(() => {
  return recoveryTokenInput.value.length > 0 &&
         newPassword.value.length >= 8 && 
         newPassword.value === newPasswordConfirm.value &&
         !errors.value.newPassword &&
         !errors.value.newPasswordConfirm
})


const handleFindId = async () => {
  validateIdName()
  validateIdEmail()
  validateIdPhone()

  if (errors.value.idName || errors.value.idEmail || errors.value.idPhone) {
    return
  }

  if (!idForm.value.name || !idForm.value.email || !idForm.value.phone) {
    toastStore.error('모든 필드를 입력해주세요.')
    return
  }

  isFindingId.value = true

  try {
    const { findLoginId } = await import('~/shared/api/auth')
    
    // 하이픈 제거
    const phoneWithoutHyphen = idForm.value.phone.replace(/-/g, '')
    
    const response = await findLoginId({
      name: idForm.value.name,
      email: idForm.value.email,
      mobilePhoneNumber: phoneWithoutHyphen
    })

    if (response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') {
      if (response.data) {
        result.value = {
          title: '아이디 찾기 완료',
          message: '입력하신 정보로 등록된 아이디를 찾았습니다.',
          data: response.data
        }
      } else {
        toastStore.error('아이디를 찾을 수 없습니다.')
      }
    } else {
      const errorMessage = response.message.message || '아이디 찾기에 실패했습니다.'
      toastStore.error(errorMessage)
    }
  } catch (error: any) {
    const errorMessage = error.response?.data?.message?.message || 
                        error.message || 
                        '아이디 찾기에 실패했습니다.'
    toastStore.error(errorMessage)
  } finally {
    isFindingId.value = false
  }
}

const handleFindPassword = async () => {
  validatePasswordUsername()
  validatePasswordPhone()

  if (errors.value.passwordUsername || errors.value.passwordPhone) {
    return
  }

  if (!passwordForm.value.username || !passwordForm.value.phone) {
    toastStore.error('아이디와 휴대폰 번호를 입력해주세요.')
    return
  }

  isRequestingPassword.value = true

  try {
    const { requestPasswordReset } = await import('~/shared/api/auth')
    
    // 하이픈 제거
    const phoneWithoutHyphen = passwordForm.value.phone.replace(/-/g, '')
    
    const response = await requestPasswordReset({
      loginId: passwordForm.value.username,
      mobilePhoneNumber: phoneWithoutHyphen
    })

    if (response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') {
      // API 응답의 data가 recoveryToken
      if (response.data) {
        recoveryTokenInput.value = response.data
      } else {
        toastStore.error('비밀번호 재설정 요청에 실패했습니다.')
        return
      }
      newPassword.value = ''
      newPasswordConfirm.value = ''
      errors.value.newPassword = ''
      errors.value.newPasswordConfirm = ''
      showPasswordResetModal.value = true
      toastStore.success('새 비밀번호를 입력해주세요.')
    } else {
      const errorMessage = response.message.message || '비밀번호 찾기 요청에 실패했습니다.'
      toastStore.error(errorMessage)
    }
  } catch (error: any) {
    const errorMessage = error.response?.data?.message?.message || 
                        error.message || 
                        '비밀번호 찾기 요청에 실패했습니다.'
    toastStore.error(errorMessage)
  } finally {
    isRequestingPassword.value = false
  }
}

// 비밀번호 재설정
const handleResetPassword = async () => {
  // recoveryToken 검증 (API 응답에서 받은 값이 있어야 함)
  if (!recoveryTokenInput.value) {
    toastStore.error('비밀번호 재설정 요청이 유효하지 않습니다. 다시 시도해주세요.')
    return
  }

  // 비밀번호 검증
  validateNewPassword()
  validateNewPasswordConfirm()

  if (!isPasswordResetFormValid.value) {
    return
  }

  isResettingPassword.value = true

  try {
    const { resetPassword } = await import('~/shared/api/auth')
    
    const response = await resetPassword({
      recoveryToken: recoveryTokenInput.value,
      newPassword: newPassword.value
    })

    if (response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') {
      toastStore.success('비밀번호가 재설정되었습니다.')
      // 모달 닫기 및 폼 초기화
      handleClosePasswordResetModal()
      handleReset()
      // 로그인 페이지로 이동
      router.push('/login')
    } else {
      const errorMessage = response.message.message || '비밀번호 재설정에 실패했습니다.'
      toastStore.error(errorMessage)
    }
  } catch (error: any) {
    const errorMessage = error.response?.data?.message?.message || 
                        error.message || 
                        '비밀번호 재설정에 실패했습니다.'
    toastStore.error(errorMessage)
  } finally {
    isResettingPassword.value = false
  }
}

// 비밀번호 재설정 모달 닫기
const handleClosePasswordResetModal = () => {
  showPasswordResetModal.value = false
  recoveryTokenInput.value = ''
  newPassword.value = ''
  newPasswordConfirm.value = ''
  errors.value.newPassword = ''
  errors.value.newPasswordConfirm = ''
}

// Portone SDK는 직접 팝업을 띄우므로 onMounted에서 콜백 처리가 필요 없음

const handleCloseModal = () => {
  result.value = null
  idForm.value = { name: '', email: '', phone: '' }
  errors.value = {}
  isFindingId.value = false
}

const handleReset = () => {
  result.value = null
  idForm.value = { name: '', email: '', phone: '' }
  passwordForm.value = { username: '', phone: '' }
  errors.value = {}
  isFindingId.value = false
  recoveryTokenInput.value = ''
  showPasswordResetModal.value = false
  newPassword.value = ''
  newPasswordConfirm.value = ''
}
</script>

