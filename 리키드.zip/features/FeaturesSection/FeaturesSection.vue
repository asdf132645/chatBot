<template>
  <section id="features" :class="styles.features">
    <Container>
      <div :class="styles.features__titleSection">
        <h3 :class="styles.features__heading">• 핵심 경험</h3>
      </div>
      <div :class="styles.features__grid">
        <div
          v-for="(feature, index) in features"
          :key="index"
          :class="styles.features__item"
        >
          <div :class="styles.features__number">{{ String(index + 1).padStart(2, '0') }}</div>
          <div :class="styles.features__content">
            <h3 :class="styles.features__title">{{ feature.title }}</h3>
            <p :class="styles.features__description">{{ feature.description }}</p>
          </div>
        </div>
      </div>
    </Container>
  </section>
</template>

<script setup lang="ts">
import { Container } from '@/components/ui'
import styles from '~/styles/features/FeaturesSection.module.css'

const features = [
  {
    title: '현실의 제약에서 벗어난 도전',
    description: '일상에서는 위험과 부담으로 망설였던 도전을, 리키드의 세계에서는 자유롭게 실현할 수 있습니다.'
  },
  {
    title: '자아실현의 무대',
    description: '플레이어는 캐릭터와 공간, 활동을 통해 자신을 표현하며, 크리에이터로서의 가능성을 확장할 수 있습니다.'
  },
  {
    title: '창작과 생활의 결합',
    description: '단순한 플레이가 아니라, 나만의 생활 방식을 설계하고, 도시 속 다른 플레이어와 상호작용하며 이야기를 만들어갑니다.'
  },
  {
    title: '확장 가능한 가능성',
    description: '리키드는 단순한 게임을 넘어, 크리에이터가 새로운 형태의 가치를 만들어낼 수 있는 기회의 장을 지향합니다.'
  }
]
</script>
