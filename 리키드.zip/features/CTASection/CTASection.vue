<template>
  <section :class="styles.cta">
    <Container>
      <div :class="styles.cta__content">
        <div :class="styles.cta__text">
          <h2 :class="styles.cta__title">지금 바로 LIKID NFT로 여정을 떠나보세요.</h2>
          <p :class="styles.cta__subtitle">LEARN ABOUT CREATOR-DRIVEN LIFE NFT</p>
        </div>
        <NuxtLink to="/nft">
          <Button size="lg" variant="secondary" :class="styles.cta__button">
            시작하기
          </Button>
        </NuxtLink>
      </div>
      <div :class="styles.cta__divider"></div>
    </Container>
  </section>
</template>

<script setup lang="ts">
import { Container, Button } from '@/components/ui'
import styles from '~/styles/features/CTASection.module.css'
</script>
