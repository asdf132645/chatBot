<template>
  <div :class="styles.nftArtworkGrid">
    <div :class="styles.nftArtworkGrid__header">
      <div :class="styles.nftArtworkGrid__count">{{ paginate.totalCount }}개</div>
      <select v-model="sortBy" :class="styles.nftArtworkGrid__sort" @change="handleSortChange">
        <option value="id-desc">최신순</option>
        <option value="id-asc">오래된순</option>
        <option value="price-asc">낮은 가격순</option>
        <option value="price-desc">높은 가격순</option>
      </select>
    </div>
    <div v-if="isLoading" :class="styles.nftArtworkGrid__loading">
      <Spinner size="lg" />
    </div>
    <div v-else-if="artworks.length === 0" :class="styles.nftArtworkGrid__empty">
      표시할 아이템이 없습니다.
    </div>
    <div v-else :class="styles.nftArtworkGrid__grid">
      <NuxtLink
        v-for="(artwork, index) in artworks"
        :key="artwork.id || index"
        :to="`/nft/${artwork.id}`"
        :class="styles.nftArtworkGrid__card"
      >
        <div :class="styles.nftArtworkGrid__image">
          <img :src="artwork.imageUrl" :alt="artwork.title" />
        </div>
        <div :class="styles.nftArtworkGrid__info">
          <div :class="styles.nftArtworkGrid__brand">브랜드</div>
          <div :class="styles.nftArtworkGrid__titleRow">
            <div :class="styles.nftArtworkGrid__title">{{ artwork.title }}</div>
          </div>
          <div :class="styles.nftArtworkGrid__price">₩{{ artwork.price.toLocaleString() }}</div>
        </div>
        <div :class="styles.nftArtworkGrid__buyButton">
          바로 구매하기
          <span :class="styles.nftArtworkGrid__arrow">↗</span>
        </div>
      </NuxtLink>
    </div>
    <!-- 페이징 -->
    <div v-if="!isLoading && paginate.totalPage > 1" :class="styles.nftArtworkGrid__pagination">
      <button
        :class="styles.nftArtworkGrid__pageButton"
        :disabled="currentPage === 1"
        @click="goToPage(currentPage - 1)"
      >
        이전
      </button>
      <div :class="styles.nftArtworkGrid__pageNumbers">
        <button
          v-for="page in visiblePages"
          :key="page"
          :class="[
            styles.nftArtworkGrid__pageNumber,
            page === currentPage ? styles['nftArtworkGrid__pageNumber--active'] : ''
          ]"
          @click="goToPage(page)"
        >
          {{ page }}
        </button>
      </div>
      <button
        :class="styles.nftArtworkGrid__pageButton"
        :disabled="currentPage === paginate.totalPage || paginate.last"
        @click="goToPage(currentPage + 1)"
      >
        다음
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { Spinner } from '@/components/ui'
import { getNFTList } from '~/shared/api/nft'
import { useToastStore } from '~/stores/toast'
import type { NFTDetail, NFTListResponse, PaginateInfo } from '~/entities/nft/types'
import styles from '~/styles/features/NFTArtworkGrid.module.css'

const toastStore = useToastStore()

const sortBy = ref('id-desc')
const artworks = ref<NFTDetail[]>([])
const isLoading = ref(false)
const currentPage = ref(1)
const pageSize = ref(15)
const paginate = ref<PaginateInfo>({
  last: false,
  totalPage: 1,
  totalCount: 0,
  currentPage: 1
})

// 정렬 옵션 파싱
const getSortParams = (sortValue: string) => {
  const [sortType, sortDirection] = sortValue.split('-')
  return {
    sortType: sortType === 'price' ? 'price' : 'id',
    sortDirection: sortDirection as 'desc' | 'asc'
  }
}

// NFT 리스트 조회
const fetchNFTList = async () => {
  if (import.meta.server) return
  
  isLoading.value = true
  
  try {
    const sortParams = getSortParams(sortBy.value)
    
    const response = await getNFTList({
      type: 'PAGINATION',
      page: currentPage.value - 1, // API는 0부터 시작
      size: pageSize.value,
      sortType: sortParams.sortType,
      sortDirection: sortParams.sortDirection
    })
    
    // httpStatus가 "OK" 또는 "200 OK"인 경우 성공
    if ((response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') && response.data) {
      artworks.value = response.data.content || []
      paginate.value = response.data.paginate || {
        last: false,
        totalPage: 1,
        totalCount: 0,
        currentPage: 0
      }
      // API는 0부터 시작하는 페이지를 반환하므로 UI 표시를 위해 +1
      currentPage.value = (paginate.value.currentPage ?? 0) + 1
    } else {
      const errorMessage = response.message.message || 'NFT 리스트를 불러오는데 실패했습니다.'
      toastStore.error(errorMessage)
      artworks.value = []
      paginate.value = {
        last: false,
        totalPage: 1,
        totalCount: 0,
        currentPage: 1
      }
    }
  } catch (err: any) {
    const errorMessage = err.response?.data?.message?.message || 
                        err.response?.data?.message || 
                        err.message || 
                        'NFT 리스트를 불러오는데 실패했습니다.'
    toastStore.error(errorMessage)
    artworks.value = []
    paginate.value = {
      last: false,
      totalPage: 1,
      totalCount: 0,
      currentPage: 1
    }
  } finally {
    isLoading.value = false
  }
}

// 정렬 변경 핸들러
const handleSortChange = () => {
  currentPage.value = 1
  fetchNFTList()
}

// 페이지 이동
const goToPage = (page: number) => {
  if (page < 1 || page > paginate.value.totalPage) return
  currentPage.value = page
  fetchNFTList()
  // 페이지 상단으로 스크롤
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

// 보이는 페이지 번호 계산
const visiblePages = computed(() => {
  const total = paginate.value.totalPage
  const current = paginate.value.currentPage
  
  if (total <= 7) {
    // 전체 페이지가 7개 이하면 모두 표시
    return Array.from({ length: total }, (_, i) => i + 1)
  }
  
  // 현재 페이지 기준으로 앞뒤 3개씩 표시
  const start = (() => {
    const baseStart = Math.max(1, current - 3)
    const baseEnd = Math.min(total, current + 3)
    
    if (baseStart === 1) {
      return 1
    } else if (baseEnd === total) {
      return Math.max(1, total - 6)
    }
    return baseStart
  })()
  
  const end = (() => {
    const baseEnd = Math.min(total, current + 3)
    if (start === 1) {
      return Math.min(7, total)
    } else if (baseEnd === total) {
      return total
    }
    return baseEnd
  })()
  
  return Array.from({ length: end - start + 1 }, (_, i) => start + i)
})

onMounted(() => {
  fetchNFTList()
})
</script>

