<template>
  <div :class="styles.nftArtworkGrid">
    <div :class="styles.nftArtworkGrid__header">
      <div :class="styles.nftArtworkGrid__count">{{ totalCount }}개</div>
      <select v-model="sortBy" :class="styles.nftArtworkGrid__sort">
        <option value="price-asc">낮은 가격순</option>
        <option value="price-desc">높은 가격순</option>
      </select>
    </div>
    <div v-if="isLoading" :class="styles.nftArtworkGrid__loading">
      <Spinner size="lg" />
    </div>
    <div v-else :class="styles.nftArtworkGrid__grid">
      <NuxtLink
        v-for="(artwork, index) in sortedArtworks"
        :key="artwork.id || index"
        :to="`/nft/${artwork.id}`"
        :class="styles.nftArtworkGrid__card"
      >
        <div :class="styles.nftArtworkGrid__image">
          <img :src="artwork.image" :alt="artwork.title" />
        </div>
        <div :class="styles.nftArtworkGrid__info">
          <div :class="styles.nftArtworkGrid__brand">{{ artwork.brand }}</div>
          <div :class="styles.nftArtworkGrid__titleRow">
            <div :class="styles.nftArtworkGrid__title">{{ artwork.title }}</div>
          </div>
          <div :class="styles.nftArtworkGrid__price">₩{{ artwork.price.toLocaleString() }}</div>
        </div>
        <div :class="styles.nftArtworkGrid__buyButton">
          바로 구매하기
          <span :class="styles.nftArtworkGrid__arrow">↗</span>
        </div>
      </NuxtLink>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { Spinner } from '@/components/ui'
import { getNFTList } from '~/shared/api/nft'
import { useToastStore } from '~/stores/toast'
import type { NFTArtwork, NFTListResponse } from '~/entities/nft/types'
import styles from '~/styles/features/NFTArtworkGrid.module.css'

const toastStore = useToastStore()

const sortBy = ref('price-asc')
const artworks = ref<NFTArtwork[]>([])
const isLoading = ref(false)
const totalCount = ref(0)

// TODO: 나중에 제거 가능 - 서버 데이터가 없을 때 표시할 더미 데이터
const DUMMY_ARTWORK: NFTArtwork = {
  id: 999,
  image: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjVmNWY1Ii8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5GVCBJbWFnZTwvdGV4dD48L3N2Zz4=',
  brand: '브랜드명',
  title: '작품명 샘플 NFT 작품',
  price: 100000
}

// NFT 리스트 조회
const fetchNFTList = async () => {
  if (import.meta.server) return
  
  isLoading.value = true
  
  try {
    const response = await getNFTList()
    
    if (response.message.httpStatus === '200 OK' && response.data) {
      const data = response.data
      // 응답이 NFTListResponse인 경우
      if ('artworks' in data && 'total' in data) {
        artworks.value = data.artworks || []
        totalCount.value = data.total || 0
      } else if (Array.isArray(data)) {
        // 응답이 배열인 경우 (하위 호환성)
        const arrayData = data as NFTArtwork[]
        artworks.value = arrayData
        totalCount.value = arrayData.length
      } else {
        artworks.value = []
        totalCount.value = 0
      }
    } else {
      const errorMessage = response.message.message || 'NFT 리스트를 불러오는데 실패했습니다.'
      toastStore.error(errorMessage)
      artworks.value = []
      totalCount.value = 0
    }
  } catch (err: any) {
    console.error('NFT 리스트 조회 오류:', err)
    const errorMessage = err.response?.data?.message?.message || 
                        err.response?.data?.message || 
                        err.message || 
                        'NFT 리스트를 불러오는데 실패했습니다.'
    toastStore.error(errorMessage)
    artworks.value = []
    totalCount.value = 0
  } finally {
    isLoading.value = false
  }
}

// 정렬된 작품 목록
// TODO: 나중에 제거 가능 - 서버 데이터가 없을 때 더미 데이터 표시
const sortedArtworks = computed<NFTArtwork[]>(() => {
  // 실제 데이터가 없으면 더미 데이터 하나 반환
  if (artworks.value.length === 0) {
    return [DUMMY_ARTWORK]
  }
  
  const sorted = [...artworks.value]
  if (sortBy.value === 'price-asc') {
    return sorted.sort((a, b) => a.price - b.price)
  } else if (sortBy.value === 'price-desc') {
    return sorted.sort((a, b) => b.price - a.price)
  }
  return sorted
})

onMounted(() => {
  fetchNFTList()
})
</script>

