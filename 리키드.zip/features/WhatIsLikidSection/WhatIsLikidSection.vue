<template>
  <section id="about" :class="styles.whatIs">
    <Container>
      <div :class="styles.whatIs__content">
        <h2 :class="styles.whatIs__subtitle">• WHAT IS LIKID?</h2>
        <div :class="styles.whatIs__text">
          <p>
            LIKID는 크리에이터 중심의 라이프 시뮬레이션 게임으로, 사용자들이 자신만의 독특한 가상 세계를 만들고 경험할 수 있는 플랫폼입니다.
          </p>
          <p>
            플레이어는 크리에이터이자 새로운 가상 도시의 주민으로, 현실과 독립된 공간에서 자신만의 삶을 설계하고 경험합니다.
          </p>
          <p>
            개인은 작품, 아이템, 경험을 통해 자신의 개성을 표현하고, 브랜드는 고유한 스토리와 비전을 담아 새로운 연결을 만들어갑니다.
          </p>
          <p>
            LIKID는 단순한 공간이 아닌, 자아 표현과 성장의 무대이며, 또 다른 삶을 살아갈 새로운 집입니다.
          </p>
        </div>
      </div>
    </Container>
  </section>
</template>

<script setup lang="ts">
import { Container } from '@/components/ui'
import styles from '~/styles/features/WhatIsLikidSection.module.css'
</script>
