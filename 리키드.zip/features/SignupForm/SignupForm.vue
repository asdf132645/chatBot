<template>
  <form :class="styles.signupForm" @submit.prevent="handleSubmit">
    <!-- 본인인증 -->
    <section :class="styles.signupForm__section">
      <h2 :class="styles.signupForm__sectionTitle">본인인증</h2>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.phone = el as HTMLElement">
        <label :class="styles.signupForm__label">휴대폰 번호</label>
        <div :class="styles.signupForm__inputGroup">
          <input
            v-model="form.phone"
            type="tel"
            :class="[
              styles.signupForm__input,
              errors.phone ? styles['signupForm__input--error'] : ''
            ]"
            placeholder="010-0000-0000"
            @input="createValidator('phone')"
          />
          <button 
            type="button" 
            :class="styles.signupForm__buttonSecondary"
            :disabled="kycLoading || isKycVerified"
            @click="handleKycRequest"
          >
            {{ isKycVerified ? '인증완료' : '인증요청' }}
          </button>
        </div>
        <p v-if="errors.phone" :class="styles.signupForm__error">
          {{ errors.phone }}
        </p>
      </div>
    </section>

    <!-- 기본정보 -->
    <section :class="styles.signupForm__section">
      <h2 :class="styles.signupForm__sectionTitle">기본정보</h2>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.name = el as HTMLElement">
        <label :class="styles.signupForm__label">이름</label>
        <input
          v-model="form.name"
          type="text"
          :class="[
            styles.signupForm__input,
            errors.name ? styles['signupForm__input--error'] : ''
          ]"
          placeholder="이름을 입력하세요"
          @input="createValidator('name')"
        />
        <p v-if="errors.name" :class="styles.signupForm__error">
          {{ errors.name }}
        </p>
      </div>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.birthDate = el as HTMLElement">
        <label :class="styles.signupForm__label">생년월일</label>
        <input
          v-model="form.birthDate"
          type="date"
          :class="[
            styles.signupForm__input,
            errors.birthDate ? styles['signupForm__input--error'] : ''
          ]"
          :max="maxDate"
          @change="handleBirthDateChange"
          @click="handleDateInputClick"
        />
        <p v-if="errors.birthDate" :class="styles.signupForm__error">
          {{ errors.birthDate }}
        </p>
      </div>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.username = el as HTMLElement">
        <label :class="styles.signupForm__label">아이디</label>
        <input
          v-model="form.username"
          type="text"
          :class="[
            styles.signupForm__input,
            errors.username ? styles['signupForm__input--error'] : ''
          ]"
          placeholder="아이디를 입력하세요"
          @input="handleUsernameInput"
          @keypress="preventKoreanInput"
        />
        <p v-if="errors.username" :class="styles.signupForm__error">
          {{ errors.username }}
        </p>
      </div>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.password = el as HTMLElement">
        <label :class="styles.signupForm__label">비밀번호</label>
        <div :class="styles.signupForm__inputGroup">
          <input
            v-model="form.password"
            :type="showPassword ? 'text' : 'password'"
            :class="[
              styles.signupForm__input,
              errors.password ? styles['signupForm__input--error'] : ''
            ]"
            placeholder="비밀번호를 입력하세요"
            @input="handlePasswordInput"
          />
          <button
            type="button"
            :class="styles.signupForm__eyeButton"
            @click="showPassword = !showPassword"
            aria-label="비밀번호 표시/숨김"
          >
            <EyeIcon :visible="showPassword" :size="20" />
          </button>
        </div>
        <p v-if="errors.password" :class="styles.signupForm__error">
          {{ errors.password }}
        </p>
      </div>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.passwordConfirm = el as HTMLElement">
        <label :class="styles.signupForm__label">비밀번호 확인</label>
        <div :class="styles.signupForm__inputGroup">
          <input
            v-model="form.passwordConfirm"
            :type="showPasswordConfirm ? 'text' : 'password'"
            :class="[
              styles.signupForm__input,
              errors.passwordConfirm ? styles['signupForm__input--error'] : ''
            ]"
            placeholder="비밀번호를 다시 입력하세요"
            @input="createValidator('passwordConfirm')"
          />
          <button
            type="button"
            :class="styles.signupForm__eyeButton"
            @click="showPasswordConfirm = !showPasswordConfirm"
            aria-label="비밀번호 확인 표시/숨김"
          >
            <EyeIcon :visible="showPasswordConfirm" :size="20" />
          </button>
        </div>
        <p v-if="errors.passwordConfirm" :class="styles.signupForm__error">
          {{ errors.passwordConfirm }}
        </p>
      </div>
    </section>

    <!-- 주소 -->
    <section :class="styles.signupForm__section">
      <h2 :class="styles.signupForm__sectionTitle">주소</h2>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.zipCode = el as HTMLElement">
        <label :class="styles.signupForm__label">우편번호</label>
        <div :class="styles.signupForm__inputGroup">
          <input
            v-model="form.zipCode"
            type="text"
            :class="[
              styles.signupForm__input,
              errors.zipCode ? styles['signupForm__input--error'] : ''
            ]"
            placeholder="우편번호"
            @input="createValidator('zipCode')"
          />
          <button type="button" :class="styles.signupForm__buttonPrimary" @click="openAddressSearch">
            검색
          </button>
        </div>
        <p v-if="errors.zipCode" :class="styles.signupForm__error">
          {{ errors.zipCode }}
        </p>
      </div>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.address = el as HTMLElement">
        <label :class="styles.signupForm__label">기본주소</label>
        <input
          v-model="form.address"
          type="text"
          :class="[
            styles.signupForm__input,
            errors.address ? styles['signupForm__input--error'] : ''
          ]"
          placeholder="기본주소"
          @input="createValidator('address')"
        />
        <p v-if="errors.address" :class="styles.signupForm__error">
          {{ errors.address }}
        </p>
      </div>
      <div :class="styles.signupForm__row">
        <label :class="styles.signupForm__label">상세주소 (선택)</label>
        <input
          v-model="form.detailAddress"
          type="text"
          :class="styles.signupForm__input"
          placeholder="상세주소"
        />
      </div>
    </section>

    <!-- 연락처 -->
    <section :class="styles.signupForm__section">
      <h2 :class="styles.signupForm__sectionTitle">연락처</h2>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.landline = el as HTMLElement">
        <label :class="styles.signupForm__label">일반전화</label>
        <input
          v-model="form.landline"
          type="tel"
          :class="[
            styles.signupForm__input,
            errors.landline ? styles['signupForm__input--error'] : ''
          ]"
          placeholder="02-0000-0000"
          @input="createValidator('landline')"
        />
        <p v-if="errors.landline" :class="styles.signupForm__error">
          {{ errors.landline }}
        </p>
      </div>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.mobile = el as HTMLElement">
        <label :class="styles.signupForm__label">휴대전화</label>
        <input
          v-model="form.mobile"
          type="tel"
          :class="[
            styles.signupForm__input,
            errors.mobile ? styles['signupForm__input--error'] : ''
          ]"
          placeholder="010-0000-0000"
          @input="createValidator('mobile')"
        />
        <p v-if="errors.mobile" :class="styles.signupForm__error">
          {{ errors.mobile }}
        </p>
      </div>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.email = el as HTMLElement">
        <label :class="styles.signupForm__label">이메일</label>
        <input
          v-model="form.email"
          type="email"
          :class="[
            styles.signupForm__input,
            errors.email ? styles['signupForm__input--error'] : ''
          ]"
          placeholder="example@email.com"
          @input="createValidator('email')"
        />
        <p v-if="errors.email" :class="styles.signupForm__error">
          {{ errors.email }}
        </p>
      </div>
    </section>

    <!-- 지역 및 성별 -->
    <section :class="styles.signupForm__section">
      <div :class="styles.signupForm__row">
        <label :class="styles.signupForm__label">지역</label>
        <select v-model="form.region" :class="styles.signupForm__select">
          <option value="">지역 선택</option>
          <option value="seoul">서울</option>
          <option value="busan">부산</option>
          <option value="daegu">대구</option>
          <option value="incheon">인천</option>
          <option value="gwangju">광주</option>
          <option value="daejeon">대전</option>
          <option value="ulsan">울산</option>
          <option value="gyeonggi">경기</option>
          <option value="gangwon">강원</option>
          <option value="chungbuk">충북</option>
          <option value="chungnam">충남</option>
          <option value="jeonbuk">전북</option>
          <option value="jeonnam">전남</option>
          <option value="gyeongbuk">경북</option>
          <option value="gyeongnam">경남</option>
          <option value="jeju">제주</option>
        </select>
      </div>
      <div :class="styles.signupForm__row">
        <label :class="styles.signupForm__label">성별</label>
        <div :class="styles.signupForm__radioGroup">
          <label :class="styles.signupForm__radioLabel">
            <input
              v-model="form.gender"
              type="radio"
              value="남성"
              :class="styles.signupForm__radio"
            />
            <span>남성</span>
          </label>
          <label :class="styles.signupForm__radioLabel">
            <input
              v-model="form.gender"
              type="radio"
              value="여성"
              :class="styles.signupForm__radio"
            />
            <span>여성</span>
          </label>
        </div>
      </div>
    </section>

    <!-- 약관 동의 -->
    <section :class="styles.signupForm__section" :ref="el => fieldRefs.terms = el as HTMLElement">
      <h2 :class="styles.signupForm__sectionTitle">약관 동의</h2>
      <div :class="styles.signupForm__row">
        <label :class="styles.signupForm__checkboxLabel">
          <input
            v-model="agreeAll"
            type="checkbox"
            :class="styles.signupForm__checkbox"
            @change="handleAgreeAll"
          />
          <span>전체 동의</span>
        </label>
      </div>
      <div :class="styles.signupForm__row">
        <label :class="styles.signupForm__checkboxLabel">
          <input
            v-model="form.agreeTerms"
            type="checkbox"
            :class="styles.signupForm__checkbox"
            required
          />
          <span>이용약관 동의 <span :class="styles.signupForm__required">(필수)</span></span>
        </label>
        <p v-if="errors.terms" :class="styles.signupForm__error">
          {{ errors.terms }}
        </p>
      </div>
      <div :class="styles.signupForm__row">
        <label :class="styles.signupForm__checkboxLabel">
          <input
            v-model="form.agreePrivacy"
            type="checkbox"
            :class="styles.signupForm__checkbox"
            required
          />
          <span>개인정보 수집 및 이용동의 <span :class="styles.signupForm__required">(필수)</span></span>
        </label>
      </div>
      <div :class="styles.signupForm__row">
        <label :class="styles.signupForm__checkboxLabel">
          <input
            v-model="form.agreeConsignment"
            type="checkbox"
            :class="styles.signupForm__checkbox"
          />
          <span>개인정보 처리 위탁 동의 (선택)</span>
        </label>
      </div>
      <div :class="styles.signupForm__row">
        <label :class="styles.signupForm__checkboxLabel">
          <input
            v-model="form.agreeEmail"
            type="checkbox"
            :class="styles.signupForm__checkbox"
          />
          <span>이메일 수신 동의 (선택)</span>
        </label>
      </div>
    </section>

    <button 
      type="submit" 
      :class="styles.signupForm__submitButton"
      :disabled="signUpLoading"
    >
      {{ signUpLoading ? '처리 중...' : '회원가입' }}
    </button>
  </form>
</template>

<script setup lang="ts">
import { ref, watch, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { EyeIcon } from '@/components/ui'
import { useSignUp } from '~/features/auth'
import { usePortoneCertification } from '~/features/auth/usePortoneCertification'
import { useAuthStore } from '~/stores/auth'
import type { SignUpRequest } from '~/entities/user/types'
import styles from '~/styles/features/SignupForm.module.css'

const route = useRoute()
const router = useRouter()
const { execute: signUp, isLoading: signUpLoading, error: signUpError } = useSignUp()

// Portone PASS 인증
const {
  requestCertification,
  isLoading: kycLoading,
  error: kycError,
  impUid,
  paymentId,
  identityToken: portoneIdentityToken,
  verification: portoneVerification,
  reset: resetPortone
} = usePortoneCertification()

// PASS 인증 상태
const isKycVerified = ref(false)
const identityToken = ref<string | null>(null)
const kycVerification = ref<any>(null)

// 검증 규칙 선언
type ValidationRule = {
  required?: boolean
  pattern?: RegExp
  message: string
  custom?: (value: any, form: any) => string | null
}

const validationRules: Record<string, ValidationRule> = {
  phone: {
    required: true,
    pattern: /^01[0-9]-[0-9]{3,4}-[0-9]{4}$/,
    message: '올바른 휴대폰 번호 형식을 입력해주세요. (예: 010-0000-0000)'
  },
  name: {
    required: true,
    custom: (value) => value?.trim().length < 2 ? '이름은 2자 이상 입력해주세요.' : null,
    message: '이름을 입력해주세요.'
  },
  birthDate: {
    required: true,
    message: '생년월일을 선택해주세요.'
  },
  username: {
    required: true,
    pattern: /^[a-zA-Z0-9]+$/,
    message: '아이디는 영문과 숫자만 사용할 수 있습니다.'
  },
  password: {
    required: true,
    custom: (value) => {
      if (!value) return null
      const hasEnglish = /[a-zA-Z]/.test(value)
      const hasNumber = /[0-9]/.test(value)
      const hasSpecial = /[^a-zA-Z0-9\s]/.test(value)
      return (!hasEnglish || !hasNumber || !hasSpecial) 
        ? '비밀번호는 영문, 숫자, 특수문자를 모두 포함해야 합니다.' 
        : null
    },
    message: '비밀번호를 입력해주세요.'
  },
  passwordConfirm: {
    required: true,
    custom: (value, form) => value !== form.password ? '비밀번호가 일치하지 않습니다.' : null,
    message: '비밀번호 확인을 입력해주세요.'
  },
  zipCode: {
    required: true,
    pattern: /^\d{5}$/,
    message: '올바른 우편번호 형식을 입력해주세요. (5자리 숫자)'
  },
  address: {
    required: true,
    custom: (value) => value?.trim().length < 5 ? '주소를 정확히 입력해주세요.' : null,
    message: '기본주소를 입력해주세요.'
  },
  mobile: {
    required: true,
    pattern: /^01[0-9]-[0-9]{3,4}-[0-9]{4}$/,
    message: '올바른 휴대전화 번호 형식을 입력해주세요. (예: 010-0000-0000)'
  },
  email: {
    required: true,
    pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    message: '올바른 이메일 형식을 입력해주세요. (예: example@email.com)'
  },
  landline: {
    pattern: /^0[2-9]{1,2}-[0-9]{3,4}-[0-9]{4}$/,
    message: '올바른 전화번호 형식을 입력해주세요. (예: 02-0000-0000)'
  }
}

// 에러 상태 관리
const errors = ref<Record<string, string>>({})
const fieldRefs = ref<Record<string, HTMLElement | null>>({})

// 비밀번호 표시/숨김 상태
const showPassword = ref(false)
const showPasswordConfirm = ref(false)

// 공통 검증 함수
const validateField = (field: string, value: any) => {
  const rule = validationRules[field]
  if (!rule) return null

  if (rule.required && !value) {
    return rule.message
  }

  if (value && rule.pattern && !rule.pattern.test(value)) {
    return rule.message
  }

  if (value && rule.custom) {
    return rule.custom(value, form.value)
  }

  return null
}

// 필드별 검증 함수 생성
const createValidator = (field: string) => () => {
  errors.value[field] = validateField(field, form.value[field as keyof typeof form.value]) || ''
}

// 오늘 날짜를 최대값으로 설정
const maxDate = computed(() => {
  if (import.meta.server) return undefined
  const today = new Date()
  return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`
})

const handleDateInputClick = (event: Event) => {
  const input = event.target as HTMLInputElement
  if (input?.type === 'date' && 'showPicker' in input) {
    (input as any).showPicker()
  }
}

// 카카오 주소 검색 API
const loadKakaoAddressScript = () => {
  return new Promise<void>((resolve, reject) => {
    if (import.meta.server) {
      resolve()
      return
    }

    // 이미 로드되어 있는지 확인
    if (window.daum && window.daum.Postcode) {
      resolve()
      return
    }

    const script = document.createElement('script')
    script.src = '//t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js'
    script.async = true
    script.onload = () => resolve()
    script.onerror = () => reject(new Error('카카오 주소 검색 스크립트 로드 실패'))
    document.head.appendChild(script)
  })
}

const openAddressSearch = async () => {
  if (import.meta.server) return

  try {
    await loadKakaoAddressScript()

    if (!window.daum || !window.daum.Postcode) {
      alert('주소 검색 서비스를 불러올 수 없습니다.')
      return
    }

    new window.daum.Postcode({
      oncomplete: (data: any) => {
        // 주소 검색 결과 처리
        let addr = '' // 주소 변수
        let extraAddr = '' // 참고항목 변수

        // 사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
        if (data.userSelectedType === 'R') {
          // 사용자가 도로명 주소를 선택했을 경우
          addr = data.roadAddress
        } else {
          // 사용자가 지번 주소를 선택했을 경우(J)
          addr = data.jibunAddress
        }

        // 사용자가 선택한 주소가 도로명 타입일때 참고항목을 조합한다.
        if (data.userSelectedType === 'R') {
          // 법정동명이 있을 경우 추가한다. (법정리는 제외)
          // 법정동의 경우 마지막 문자가 "동/로/가"로 끝난다.
          if (data.bname !== '' && /[동|로|가]$/g.test(data.bname)) {
            extraAddr += data.bname
          }
          // 건물명이 있고, 공동주택일 경우 추가한다.
          if (data.buildingName !== '' && data.apartment === 'Y') {
            extraAddr += extraAddr !== '' ? ', ' + data.buildingName : data.buildingName
          }
          // 표시할 참고항목이 있을 경우, 괄호까지 추가한 최종 문자열을 만든다.
          if (extraAddr !== '') {
            extraAddr = ' (' + extraAddr + ')'
          }
        }

        // 우편번호와 주소 정보를 해당 필드에 넣는다.
        form.value.zipCode = data.zonecode
        form.value.address = addr + extraAddr
        // 커서를 상세주소 필드로 이동한다.
        // 상세주소 입력 필드가 있다면 포커스
        const detailInput = document.querySelector('input[placeholder="상세주소"]') as HTMLInputElement
        if (detailInput) {
          detailInput.focus()
        }
      },
      onresize: (size: any) => {
        // 팝업 크기 조정
      },
      width: '100%',
      height: '100%'
    }).open()
  } catch (error) {
    console.error('주소 검색 오류:', error)
    alert('주소 검색 중 오류가 발생했습니다.')
  }
}

// 전역 타입 선언
declare global {
  interface Window {
    daum?: {
      Postcode: new (options: any) => {
        open: () => void
      }
    }
  }
}


const form = ref({
  phone: '010-0000-0000',
  name: '',
  birthDate: '',
  birthDateDisplay: '',
  username: '',
  password: '',
  passwordConfirm: '',
  zipCode: '',
  address: '',
  detailAddress: '',
  landline: '02-0000-0000',
  mobile: '010-0000-0000',
  email: '',
  region: '',
  gender: '여성',
  agreeTerms: true,
  agreePrivacy: false,
  agreeConsignment: false,
  agreeEmail: false
})

// 아이디 한글 입력 방지
const preventKoreanInput = (event: KeyboardEvent) => {
  if (event.keyCode === 229) event.preventDefault()
}

const handleUsernameInput = () => {
  const username = form.value.username
  const koreanPattern = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/
  if (koreanPattern.test(username)) {
    form.value.username = username.replace(/[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/g, '')
  }
  createValidator('username')()
}

const handlePasswordInput = () => {
  createValidator('password')()
  if (form.value.passwordConfirm) {
    createValidator('passwordConfirm')()
  }
}

const handleBirthDateChange = () => {
  createValidator('birthDate')()
  formatBirthDate()
}

const formatBirthDate = () => {
  if (form.value.birthDate) {
    // YYYY-MM-DD 형식을 YYYY.MM.DD 형식으로 변환
    const date = form.value.birthDate.split('-')
    form.value.birthDateDisplay = `${date[0]}.${date[1]}.${date[2]}`
  }
}

const agreeAll = ref(false)

const handleAgreeAll = () => {
  if (agreeAll.value) {
    form.value.agreeTerms = true
    form.value.agreePrivacy = true
    form.value.agreeConsignment = true
    form.value.agreeEmail = true
  } else {
    form.value.agreeTerms = false
    form.value.agreePrivacy = false
    form.value.agreeConsignment = false
    form.value.agreeEmail = false
  }
}

watch(
  () => [
    form.value.agreeTerms,
    form.value.agreePrivacy,
    form.value.agreeConsignment,
    form.value.agreeEmail
  ],
  () => {
    agreeAll.value =
      form.value.agreeTerms &&
      form.value.agreePrivacy &&
      form.value.agreeConsignment &&
      form.value.agreeEmail
  }
)

// 모든 필드 검증
const validateAll = (): { field: string; message: string } | null => {
  Object.keys(validationRules).forEach(field => {
    errors.value[field] = validateField(field, form.value[field as keyof typeof form.value]) || ''
  })
  
  // 약관 동의 검증
  if (!form.value.agreeTerms || !form.value.agreePrivacy) {
    errors.value.terms = '필수 약관에 동의해주세요.'
  } else {
    errors.value.terms = ''
  }
  
  // 첫 번째 에러 필드 찾기
  const errorFields = Object.keys(errors.value).filter(field => errors.value[field])
  if (errorFields.length === 0) return null
  
  const firstErrorField = errorFields[0]
  if (!firstErrorField) return null
  
  return { field: firstErrorField, message: errors.value[firstErrorField] || '' }
}

// PASS 인증 요청 (Portone SDK 사용)
const handleKycRequest = async () => {
  if (import.meta.server) return
  
  // 휴대폰 번호 검증
  createValidator('phone')()
  if (errors.value.phone) {
    return
  }
  
  try {
    // Portone PASS 인증 요청 - 회원가입용
    const result = await requestCertification('SIGN_UP')
    
    if (result && result.identityToken) {
      // 인증 성공 - 백엔드에서 identityToken 받음
      isKycVerified.value = true
      identityToken.value = result.identityToken
      kycVerification.value = result.verification
      
      // 인증 정보로 폼 자동 채우기
      if (result.verification) {
        const verification = result.verification
        if (verification.name) {
          form.value.name = verification.name
        }
        if (verification.birthDate) {
          // yyyy-MM-dd 형식으로 변환
          const birthDate = verification.birthDate
          if (birthDate.includes('-')) {
            form.value.birthDate = birthDate
          } else if (birthDate.length === 8) {
            // yyyyMMdd 형식인 경우
            form.value.birthDate = `${birthDate.substring(0, 4)}-${birthDate.substring(4, 6)}-${birthDate.substring(6, 8)}`
          }
        }
        if (verification.phoneNumber) {
          // 전화번호 형식 변환 (01012345678 -> 010-1234-5678)
          const phone = verification.phoneNumber.replace(/-/g, '')
          if (phone.length === 11) {
            form.value.phone = `${phone.substring(0, 3)}-${phone.substring(3, 7)}-${phone.substring(7)}`
            form.value.mobile = `${phone.substring(0, 3)}-${phone.substring(3, 7)}-${phone.substring(7)}`
          }
        }
        if (verification.gender) {
          // MALE/FEMALE -> 남성/여성 변환
          form.value.gender = verification.gender === 'MALE' ? '남성' : '여성'
        }
      }
      
      console.log('✅ PASS 인증 완료 - identityToken:', result.identityToken)
      console.log('인증 정보:', result.verification)
      
      alert('본인인증이 완료되었습니다.')
    } else {
      alert(kycError.value || '본인인증에 실패했습니다.')
    }
  } catch (error) {
    console.error('PASS 인증 요청 오류:', error)
    alert('인증 요청 중 오류가 발생했습니다.')
  }
}

// Portone SDK는 직접 팝업을 띄우므로 콜백 처리가 필요 없음
// handleKycCallback 함수는 더 이상 사용하지 않음

const handleSubmit = async () => {
  if (import.meta.server) return
  
  // PASS 인증 확인
  if (!isKycVerified.value || !identityToken.value) {
    alert('본인인증을 완료해주세요.')
    const phoneRef = fieldRefs.value.phone
    if (phoneRef) {
      phoneRef.scrollIntoView({ behavior: 'smooth', block: 'center' })
    }
    return
  }
  
  const error = validateAll()
  if (error && error.field) {
    // 에러 메시지가 없으면 기본 메시지 설정
    if (!errors.value[error.field]) {
      errors.value[error.field] = validationRules[error.field]?.message || error.message
    }
    
    // 첫 번째 에러 필드로 스크롤
    const errorRef = fieldRefs.value[error.field]
    if (errorRef) {
      errorRef.scrollIntoView({ behavior: 'smooth', block: 'center' })
    }
    return
  }
  
  // 회원가입 요청 데이터 구성
  const signUpData: SignUpRequest = {
    loginId: form.value.username,
    password: form.value.password,
    name: form.value.name,
    email: form.value.email,
    region: form.value.region,
    birth: form.value.birthDate, // yyyy-MM-dd 형식
    address: {
      zipcode: form.value.zipCode,
      address1: form.value.address,
      address2: form.value.detailAddress || undefined
    },
    telephoneNumber: form.value.landline || undefined,
    mobileNumber: form.value.mobile.replace(/-/g, ''),
    gender: form.value.gender as '남성' | '여성',
    identityToken: identityToken.value,
    agreements: {
      termsOfUse: form.value.agreeTerms,
      privacyPolicy: form.value.agreePrivacy,
      thirdPartySharing: form.value.agreeConsignment,
      emailMarketing: form.value.agreeEmail
    }
  }
  
  try {
    const response = await signUp(signUpData)
    
    if (response && response.message.httpStatus === '200 OK' && response.data) {
      // 회원가입 성공 - 토큰 저장 및 로그인 처리
      const authStore = useAuthStore()
      
      authStore.setTokens({
        accessToken: response.data.accessToken,
        refreshToken: response.data.refreshToken
      })
      
      alert('회원가입이 완료되었습니다.')
      router.push('/')
    } else {
      // 에러 메시지 표시
      alert(signUpError.value || response?.message?.message || '회원가입에 실패했습니다.')
    }
  } catch (error) {
    console.error('회원가입 오류:', error)
    alert('회원가입 중 오류가 발생했습니다.')
  }
}

// Portone SDK는 직접 팝업을 띄우므로 onMounted에서 콜백 처리가 필요 없음
</script>

