<template>
  <form :class="styles.signupForm" @submit.prevent="handleSubmit">
    <!-- 본인인증 -->
    <section :class="styles.signupForm__section">
      <h2 :class="styles.signupForm__sectionTitle">본인인증</h2>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.phone = el as HTMLElement">
        <label :class="styles.signupForm__label"><span :class="styles.signupForm__required">*</span> 휴대폰 번호</label>
        <div :class="styles.signupForm__inputGroup">
          <input
            v-model="form.phone"
            type="tel"
            :class="[
              styles.signupForm__input,
              errors.phone ? styles['signupForm__input--error'] : ''
            ]"
            placeholder="01000000000"
            @input="createValidator('phone')"
            :disabled="isMobileCodeVerified"
          />
          <button 
            type="button" 
            :class="styles.signupForm__buttonPrimary"
            :disabled="(isVerifyingMobile || isMobileCodeVerified || !form.phone) && !canResendMobile"
            @click="handleMobileVerification"
          >
            <template v-if="isMobileCodeVerified">
              인증완료
            </template>
            <template v-else-if="isVerifyingMobile">
              발송중...
            </template>
            <template v-else-if="canResendMobile">
              재전송
            </template>
            
            <template v-else>
              인증요청
            </template>
          </button>
        </div>
        <p v-if="errors.phone" :class="styles.signupForm__error">
          {{ errors.phone }}
        </p>
      </div>
    </section>

    <!-- 인증번호 입력 모달 -->
    <div v-if="showMobileVerificationModal" :class="styles.signupForm__modalOverlay" @click="handleCloseMobileVerificationModal">
      <div :class="styles.signupForm__modal" @click.stop>
        <div :class="styles.signupForm__modalContent">
          <h3 :class="styles.signupForm__modalTitle">인증번호 입력</h3>
          <p :class="styles.signupForm__modalText">SMS로 받은 인증번호를 입력해주세요.</p>
          
          <div v-if="!isMobileCodeVerified" :class="styles.signupForm__row" style="margin-top: 1.5rem;">
            <label :class="styles.signupForm__label">인증번호</label>
            <div :class="styles.signupForm__inputGroup">
              <input
                v-model="mobileVerificationCode"
                type="text"
                :class="[
                  styles.signupForm__input,
                  errors.mobileVerificationCode ? styles['signupForm__input--error'] : ''
                ]"
                placeholder="인증번호 6자리"
                maxlength="6"
                inputmode="numeric"
                pattern="[0-9]*"
                @input="handleVerificationCodeInput"
                autofocus
              />
              <button 
                type="button" 
                :class="styles.signupForm__buttonSecondary"
                :disabled="!canResendVerificationCode"
                @click="handleResendVerificationCode()"
              >
                <template v-if="canResendVerificationCode">
                  재요청
                </template>
                <template v-else-if="mobileVerificationTimer > 0">
                  {{ formatTimer(mobileVerificationTimer) }}
                </template>
                <template v-else>
                  재요청
                </template>
              </button>
            </div>
            <p v-if="errors.mobileVerificationCode" :class="styles.signupForm__error">
              {{ errors.mobileVerificationCode }}
            </p>
          </div>
          
          <!-- 인증 완료 메시지 -->
          <div v-if="isMobileCodeVerified" :class="styles.signupForm__row" style="margin-top: 1.5rem; text-align: center;">
            <p :class="styles.signupForm__successMessage">인증이 완료되었습니다.</p>
          </div>
        </div>
        <div :class="styles.signupForm__modalActions">
          <button
            type="button"
            :class="styles.signupForm__buttonSecondary"
            @click="handleCloseMobileVerificationModal"
          >
            닫기
          </button>
          <button
            v-if="!isMobileCodeVerified"
            type="button"
            :class="styles.signupForm__buttonPrimary"
            :disabled="isVerifyingCode || !mobileVerificationCode || mobileVerificationCode.length !== 6"
            @click="handleVerifyCode"
          >
            {{ isVerifyingCode ? '확인중...' : '인증완료' }}
          </button>
          <button
            v-else
            type="button"
            :class="styles.signupForm__buttonPrimary"
            @click="handleCloseMobileVerificationModal"
          >
            확인
          </button>
        </div>
      </div>
    </div>

    <!-- 기본정보 -->
    <section :class="styles.signupForm__section">
      <h2 :class="styles.signupForm__sectionTitle">기본정보</h2>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.name = el as HTMLElement">
        <label :class="styles.signupForm__label"><span :class="styles.signupForm__required">*</span> 이름</label>
        <input
          v-model="form.name"
          type="text"
          :class="[
            styles.signupForm__input,
            errors.name ? styles['signupForm__input--error'] : ''
          ]"
          placeholder="이름을 입력하세요"
          @input="createValidator('name')"
        />
        <p v-if="errors.name" :class="styles.signupForm__error">
          {{ errors.name }}
        </p>
      </div>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.birthDate = el as HTMLElement">
        <label :class="styles.signupForm__label"><span :class="styles.signupForm__required">*</span> 생년월일</label>
        <input
          :value="form.birthDate"
          type="text"
          :class="[
            styles.signupForm__input,
            errors.birthDate ? styles['signupForm__input--error'] : ''
          ]"
          placeholder="YYYY-MM-DD (예: 1990-01-01)"
          readonly
          @click="handleOpenBirthDateModal"
        />
        <p v-if="errors.birthDate" :class="styles.signupForm__error">
          {{ errors.birthDate }}
        </p>
      </div>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.username = el as HTMLElement">
        <label :class="styles.signupForm__label"><span :class="styles.signupForm__required">*</span> 아이디</label>
        <div :class="styles.signupForm__inputGroup">
          <input
            v-model="form.username"
            type="text"
            :class="[
              styles.signupForm__input,
              errors.username ? styles['signupForm__input--error'] : ''
            ]"
            placeholder="아이디를 입력하세요"
            @input="handleUsernameInput"
            @keypress="preventKoreanInput"
          />
          <button 
            type="button" 
            :class="styles.signupForm__buttonPrimary"
            :disabled="!form.username || isCheckingUsername"
            @click="handleCheckUsername"
          >
            {{ isCheckingUsername ? '확인중...' : '중복확인' }}
          </button>
        </div>
        <p v-if="errors.username" :class="styles.signupForm__error">
          {{ errors.username }}
        </p>
      </div>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.nickname = el as HTMLElement">
        <label :class="styles.signupForm__label"><span :class="styles.signupForm__required">*</span> 닉네임</label>
        <input
          v-model="form.nickname"
          type="text"
          :class="[
            styles.signupForm__input,
            errors.nickname ? styles['signupForm__input--error'] : ''
          ]"
          placeholder="닉네임을 입력하세요"
          @input="createValidator('nickname')"
        />
        <p v-if="errors.nickname" :class="styles.signupForm__error">
          {{ errors.nickname }}
        </p>
      </div>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.password = el as HTMLElement">
        <label :class="styles.signupForm__label"><span :class="styles.signupForm__required">*</span> 비밀번호</label>
        <div :class="styles.signupForm__inputGroup">
          <input
            v-model="form.password"
            :type="showPassword ? 'text' : 'password'"
            :class="[
              styles.signupForm__input,
              errors.password ? styles['signupForm__input--error'] : ''
            ]"
            placeholder="비밀번호를 입력하세요"
            @input="handlePasswordInput"
          />
          <button
            type="button"
            :class="styles.signupForm__eyeButton"
            @click="showPassword = !showPassword"
            aria-label="비밀번호 표시/숨김"
          >
            <EyeIcon :visible="showPassword" :size="20" />
          </button>
        </div>
        <p v-if="errors.password" :class="styles.signupForm__error">
          {{ errors.password }}
        </p>
      </div>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.passwordConfirm = el as HTMLElement">
        <label :class="styles.signupForm__label"><span :class="styles.signupForm__required">*</span> 비밀번호 확인</label>
        <div :class="styles.signupForm__inputGroup">
          <input
            v-model="form.passwordConfirm"
            :type="showPasswordConfirm ? 'text' : 'password'"
            :class="[
              styles.signupForm__input,
              errors.passwordConfirm ? styles['signupForm__input--error'] : ''
            ]"
            placeholder="비밀번호를 다시 입력하세요"
            @input="handlePasswordConfirmInput"
          />
          <button
            type="button"
            :class="styles.signupForm__eyeButton"
            @click="showPasswordConfirm = !showPasswordConfirm"
            aria-label="비밀번호 확인 표시/숨김"
          >
            <EyeIcon :visible="showPasswordConfirm" :size="20" />
          </button>
        </div>
        <p v-if="errors.passwordConfirm" :class="styles.signupForm__error">
          {{ errors.passwordConfirm }}
        </p>
      </div>
    </section>

    <!-- 주소 -->
    <section :class="styles.signupForm__section">
      <h2 :class="styles.signupForm__sectionTitle">주소</h2>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.zipCode = el as HTMLElement">
        <label :class="styles.signupForm__label"><span :class="styles.signupForm__required">*</span> 우편번호</label>
        <div :class="styles.signupForm__inputGroup">
          <input
            v-model="form.zipCode"
            type="text"
            :class="[
              styles.signupForm__input,
              errors.zipCode ? styles['signupForm__input--error'] : ''
            ]"
            placeholder="우편번호"
            readonly
            @click="openAddressSearch"
            @input="createValidator('zipCode')"
          />
          <button type="button" :class="styles.signupForm__buttonPrimary" @click="openAddressSearch">
            검색
          </button>
        </div>
        <p v-if="errors.zipCode" :class="styles.signupForm__error">
          {{ errors.zipCode }}
        </p>
      </div>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.address = el as HTMLElement">
        <label :class="styles.signupForm__label"><span :class="styles.signupForm__required">*</span> 기본주소</label>
        <input
          v-model="form.address"
          type="text"
          :class="[
            styles.signupForm__input,
            errors.address ? styles['signupForm__input--error'] : ''
          ]"
          placeholder="기본주소"
          @input="createValidator('address')"
        />
        <p v-if="errors.address" :class="styles.signupForm__error">
          {{ errors.address }}
        </p>
      </div>
      <div :class="styles.signupForm__row">
        <label :class="styles.signupForm__label">상세주소 (선택)</label>
        <input
          v-model="form.detailAddress"
          type="text"
          :class="styles.signupForm__input"
          placeholder="상세주소"
        />
      </div>
    </section>

    <!-- 연락처 -->
    <section :class="styles.signupForm__section">
      <h2 :class="styles.signupForm__sectionTitle">연락처</h2>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.landline = el as HTMLElement">
        <label :class="styles.signupForm__label">일반전화</label>
        <input
          v-model="form.landline"
          type="tel"
          :class="[
            styles.signupForm__input,
            errors.landline ? styles['signupForm__input--error'] : ''
          ]"
          placeholder="020000000"
          @input="createValidator('landline')"
        />
        <p v-if="errors.landline" :class="styles.signupForm__error">
          {{ errors.landline }}
        </p>
      </div>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.mobile = el as HTMLElement">
        <label :class="styles.signupForm__label"><span :class="styles.signupForm__required">*</span> 휴대전화</label>
        <input
          v-model="form.mobile"
          type="tel"
          :class="[
            styles.signupForm__input,
            errors.mobile ? styles['signupForm__input--error'] : ''
          ]"
          placeholder="01000000000"
          readonly
          @input="createValidator('mobile')"
          @click="handleMobileInputClick"
        />
        <p v-if="errors.mobile" :class="styles.signupForm__error">
          {{ errors.mobile }}
        </p>
      </div>
      <div :class="styles.signupForm__row" :ref="el => fieldRefs.email = el as HTMLElement">
        <label :class="styles.signupForm__label"><span :class="styles.signupForm__required">*</span> 이메일</label>
        <div :class="styles.signupForm__inputGroup">
          <input
            v-model="form.email"
            type="email"
            :class="[
              styles.signupForm__input,
              errors.email ? styles['signupForm__input--error'] : ''
            ]"
          placeholder="example@email.com"
          @input="handleEmailInput"
          />
          <button
            type="button"
            :class="styles.signupForm__buttonPrimary"
            :disabled="isCheckingEmail || !form.email"
            @click="handleCheckEmail"
          >
            {{ isCheckingEmail ? '확인 중...' : '중복확인' }}
          </button>
        </div>
        <p v-if="errors.email" :class="styles.signupForm__error">
          {{ errors.email }}
        </p>
      </div>
    </section>

    <!-- 지역 및 성별 -->
    <section :class="styles.signupForm__section">
      <div :class="styles.signupForm__row">
        <label :class="styles.signupForm__label"><span :class="styles.signupForm__required">*</span> 지역</label>
        <select v-model="form.region" :class="styles.signupForm__select">
          <option value="">지역 선택</option>
          <option value="seoul">서울</option>
          <option value="busan">부산</option>
          <option value="daegu">대구</option>
          <option value="incheon">인천</option>
          <option value="gwangju">광주</option>
          <option value="daejeon">대전</option>
          <option value="ulsan">울산</option>
          <option value="gyeonggi">경기</option>
          <option value="gangwon">강원</option>
          <option value="chungbuk">충북</option>
          <option value="chungnam">충남</option>
          <option value="jeonbuk">전북</option>
          <option value="jeonnam">전남</option>
          <option value="gyeongbuk">경북</option>
          <option value="gyeongnam">경남</option>
          <option value="jeju">제주</option>
        </select>
      </div>
      <div :class="styles.signupForm__row">
        <label :class="styles.signupForm__label"><span :class="styles.signupForm__required">*</span> 성별</label>
        <div :class="styles.signupForm__radioGroup">
          <label :class="styles.signupForm__radioLabel">
            <input
              v-model="form.gender"
              type="radio"
              value="남성"
              :class="styles.signupForm__radio"
            />
            <span>남성</span>
          </label>
          <label :class="styles.signupForm__radioLabel">
            <input
              v-model="form.gender"
              type="radio"
              value="여성"
              :class="styles.signupForm__radio"
            />
            <span>여성</span>
          </label>
        </div>
      </div>
    </section>

    <!-- 생년월일 선택 모달 -->
    <div v-if="showBirthDateModal" :class="styles.signupForm__modalOverlay" @click="handleCloseBirthDateModal">
      <div :class="styles.signupForm__modal" @click.stop>
        <div :class="styles.signupForm__modalContent">
          <h3 :class="styles.signupForm__modalTitle">생년월일 선택</h3>
          
          <!-- 모바일: 휠 피커 -->
          <div :class="styles.signupForm__datePickerWrapper">
            <!-- 년도 휠 피커 -->
            <div :class="styles.signupForm__wheelPicker">
              <div :class="styles.signupForm__wheelPickerLabel">년</div>
              <div 
                :class="styles.signupForm__wheelPickerContainer"
                ref="yearPickerRef"
                @scroll="handleYearScroll"
              >
                <div 
                  :class="[
                    styles.signupForm__wheelPickerItem,
                    selectedYear === year ? styles['signupForm__wheelPickerItem--selected'] : ''
                  ]" 
                  v-for="year in years" 
                  :key="year" 
                  :data-value="year"
                >
                  {{ year }}년
                </div>
              </div>
              <!-- 중앙선 영역 (Observer root) -->
              <div 
                :class="styles.signupForm__centerLine"
                ref="yearCenterLineRef"
              ></div>
            </div>
            <!-- 월 휠 피커 -->
            <div :class="styles.signupForm__wheelPicker">
              <div :class="styles.signupForm__wheelPickerLabel">월</div>
              <div 
                :class="styles.signupForm__wheelPickerContainer"
                ref="monthPickerRef"
                @scroll="handleMonthScroll"
              >
                <div 
                  :class="[
                    styles.signupForm__wheelPickerItem,
                    selectedMonth === month ? styles['signupForm__wheelPickerItem--selected'] : ''
                  ]" 
                  v-for="month in months" 
                  :key="month" 
                  :data-value="month"
                >
                  {{ month }}월
                </div>
              </div>
              <!-- 중앙선 영역 (Observer root) -->
              <div 
                :class="styles.signupForm__centerLine"
                ref="monthCenterLineRef"
              ></div>
            </div>
            <!-- 일 휠 피커 -->
            <div :class="styles.signupForm__wheelPicker">
              <div :class="styles.signupForm__wheelPickerLabel">일</div>
              <div 
                :class="styles.signupForm__wheelPickerContainer"
                ref="dayPickerRef"
                @scroll="handleDayScroll"
              >
                <div 
                  :class="[
                    styles.signupForm__wheelPickerItem,
                    selectedDay === day ? styles['signupForm__wheelPickerItem--selected'] : ''
                  ]" 
                  v-for="day in availableDays" 
                  :key="day" 
                  :data-value="day"
                >
                  {{ day }}일
                </div>
              </div>
              <!-- 중앙선 영역 (Observer root) -->
              <div 
                :class="styles.signupForm__centerLine"
                ref="dayCenterLineRef"
              ></div>
            </div>
          </div>
          
          <!-- PC: 기존 select -->
          <div :class="[styles.signupForm__row, styles.signupForm__dateSelectRow]">
            <div :class="styles.signupForm__dateSelectGroup">
              <label :class="styles.signupForm__label">년</label>
              <select
                v-model="selectedYear"
                :class="styles.signupForm__select"
              >
                <option value="">선택</option>
                <option
                  v-for="year in years"
                  :key="year"
                  :value="year"
                >
                  {{ year }}
                </option>
              </select>
            </div>
            <div :class="styles.signupForm__dateSelectGroup">
              <label :class="styles.signupForm__label">월</label>
              <select
                v-model="selectedMonth"
                :class="styles.signupForm__select"
              >
                <option value="">선택</option>
                <option
                  v-for="month in months"
                  :key="month"
                  :value="month"
                >
                  {{ month }}
                </option>
              </select>
            </div>
            <div :class="styles.signupForm__dateSelectGroup">
              <label :class="styles.signupForm__label">일</label>
              <select
                v-model="selectedDay"
                :class="styles.signupForm__select"
              >
                <option value="">선택</option>
                <option
                  v-for="day in availableDays"
                  :key="day"
                  :value="day"
                >
                  {{ day }}
                </option>
              </select>
            </div>
          </div>
        </div>
        <div :class="styles.signupForm__modalActions">
          <button
            type="button"
            :class="styles.signupForm__buttonPrimary"
            :disabled="!selectedYear || !selectedMonth || !selectedDay"
            @click="handleConfirmBirthDate"
          >
            선택하기
          </button>
        </div>
      </div>
    </div>

    <!-- 약관 동의 -->
    <section :class="styles.signupForm__section" :ref="el => fieldRefs.terms = el as HTMLElement">
      <h2 :class="styles.signupForm__sectionTitle">약관 동의</h2>
      <div :class="styles.signupForm__row">
        <label :class="styles.signupForm__checkboxLabel">
          <input
            v-model="agreeAll"
            type="checkbox"
            :class="styles.signupForm__checkbox"
            @change="handleAgreeAll"
          />
          <span>전체 동의</span>
        </label>
      </div>
      <div :class="styles.signupForm__row">
        <label :class="styles.signupForm__checkboxLabel">
          <input
            v-model="form.agreeTerms"
            type="checkbox"
            :class="styles.signupForm__checkbox"
            required
          />
          <span>이용약관 동의 <span :class="styles.signupForm__required">(필수)</span></span>
        </label>
        <p v-if="errors.terms" :class="styles.signupForm__error">
          {{ errors.terms }}
        </p>
      </div>
      <div :class="styles.signupForm__row">
        <label :class="styles.signupForm__checkboxLabel">
          <input
            v-model="form.agreePrivacy"
            type="checkbox"
            :class="styles.signupForm__checkbox"
            required
          />
          <span>개인정보 수집 및 이용동의 <span :class="styles.signupForm__required">(필수)</span></span>
        </label>
      </div>
      <div :class="styles.signupForm__row">
        <label :class="styles.signupForm__checkboxLabel">
          <input
            v-model="form.agreeConsignment"
            type="checkbox"
            :class="styles.signupForm__checkbox"
          />
          <span>개인정보 처리 위탁 동의 (선택)</span>
        </label>
      </div>
      <div :class="styles.signupForm__row">
        <label :class="styles.signupForm__checkboxLabel">
          <input
            v-model="form.agreeEmail"
            type="checkbox"
            :class="styles.signupForm__checkbox"
          />
          <span>이메일 수신 동의 (선택)</span>
        </label>
      </div>
    </section>

    <button 
      type="submit" 
      :class="styles.signupForm__submitButton"
      :disabled="signUpLoading"
    >
      {{ signUpLoading ? '처리 중...' : '회원가입' }}
    </button>
  </form>
</template>

<script setup lang="ts">
import { ref, watch, computed, onMounted, onBeforeUnmount, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { EyeIcon } from '@/components/ui'
import { useSignUp } from '~/features/auth'
import { usePortoneCertification } from '~/features/auth/usePortoneCertification'
import { useAuthStore } from '~/stores/auth'
import { useToastStore } from '~/stores/toast'
import type { SignUpRequest } from '~/entities/user/types'
import styles from '~/styles/features/SignupForm.module.css'

const route = useRoute()
const router = useRouter()
const { execute: signUp, isLoading: signUpLoading, error: signUpError } = useSignUp()

// Portone PASS 인증
const toastStore = useToastStore()

const {
  requestCertification,
  isLoading: kycLoading,
  error: kycError,
  impUid,
  paymentId,
  identityToken: portoneIdentityToken,
  verification: portoneVerification,
  reset: resetPortone
} = usePortoneCertification()

// PASS 인증 상태
const isKycVerified = ref(false)
const identityToken = ref<string | null>(null)
const kycVerification = ref<any>(null)

// 모바일 인증 상태
const isVerifyingMobile = ref(false)
const isMobileVerified = ref(false)
const isMobileCodeVerified = ref(false)
const mobileVerificationCode = ref('')
const isVerifyingCode = ref(false)
const recoveryToken = ref<string | null>(null)
const mobileVerificationTimer = ref(0)
const mobileVerificationTimerInterval = ref<ReturnType<typeof setInterval> | null>(null)
const canResendMobile = computed(() => mobileVerificationTimer.value === 0 && isMobileVerified.value && !isMobileCodeVerified.value)
const showMobileVerificationModal = ref(false)
const canResendVerificationCode = computed(() => mobileVerificationTimer.value === 0 && isMobileVerified.value && !isMobileCodeVerified.value)

// 생년월일 선택 모달 상태
const showBirthDateModal = ref(false)
const selectedYear = ref<number | ''>('')
const selectedMonth = ref<number | ''>('')
const selectedDay = ref<number | ''>('')

// 년도 목록 (현재 연도부터 100년 전까지)
const years = computed(() => {
  const currentYear = new Date().getFullYear()
  return Array.from({ length: 101 }, (_, i) => currentYear - i)
})

// 월 목록 (1-12)
const months = computed(() => Array.from({ length: 12 }, (_, i) => i + 1))

// 선택 가능한 일 목록 (선택한 년/월에 따라 달라짐)
const availableDays = computed(() => {
  if (!selectedYear.value || !selectedMonth.value) {
    return []
  }
  
  const year = Number(selectedYear.value)
  const month = Number(selectedMonth.value)
  
  // 해당 월의 마지막 날짜 계산
  const lastDay = new Date(year, month, 0).getDate()
  
  return Array.from({ length: lastDay }, (_, i) => i + 1)
})

// 월이 변경되면 일자 선택 초기화 및 스크롤
watch(selectedMonth, async () => {
  if (isMonthScrolling) return
  selectedDay.value = ''
  await nextTick()
  if (selectedMonth.value && monthPickerRef.value && monthCenterLineRef.value) {
    const container = monthPickerRef.value
    const centerLine = monthCenterLineRef.value
    const targetItem = container.querySelector(`[data-value="${selectedMonth.value}"]`) as HTMLElement
    
    if (targetItem) {
      isMonthScrolling = true
      await nextTick()
      const containerRect = container.getBoundingClientRect()
      const centerLineRect = centerLine.getBoundingClientRect()
      const targetItemRect = targetItem.getBoundingClientRect()
      
      const centerLineCenter = centerLineRect.top - containerRect.top + centerLineRect.height / 2
      const targetItemCenter = targetItemRect.top - containerRect.top + targetItemRect.height / 2
      const scrollDelta = targetItemCenter - centerLineCenter
      
      container.scrollTop = container.scrollTop + scrollDelta
      
      requestAnimationFrame(() => {
        setTimeout(() => {
          isMonthScrolling = false
        }, 50)
      })
    }
  }
  // 일자 목록이 업데이트되면 첫 번째 일자 선택
  await nextTick()
  if (availableDays.value.length > 0 && !selectedDay.value) {
    const firstDay = availableDays.value[0]
    if (firstDay !== undefined) {
      selectedDay.value = firstDay
      await nextTick()
      if (dayPickerRef.value && dayCenterLineRef.value && !isDayScrolling) {
        const container = dayPickerRef.value
        const centerLine = dayCenterLineRef.value
        const targetItem = container.querySelector(`[data-value="${firstDay}"]`) as HTMLElement
        
        if (targetItem) {
          isDayScrolling = true
          await nextTick()
          const containerRect = container.getBoundingClientRect()
          const centerLineRect = centerLine.getBoundingClientRect()
          const targetItemRect = targetItem.getBoundingClientRect()
          
          const centerLineCenter = centerLineRect.top - containerRect.top + centerLineRect.height / 2
          const targetItemCenter = targetItemRect.top - containerRect.top + targetItemRect.height / 2
          const scrollDelta = targetItemCenter - centerLineCenter
          
          container.scrollTop = container.scrollTop + scrollDelta
          
          requestAnimationFrame(() => {
            setTimeout(() => {
              isDayScrolling = false
            }, 50)
          })
        }
      }
    }
  }
})

// 년도가 변경되면 일자 선택 초기화 및 스크롤
watch(selectedYear, async () => {
  if (isYearScrolling) return
  selectedDay.value = ''
  await nextTick()
  if (selectedYear.value && yearPickerRef.value && yearCenterLineRef.value) {
    const container = yearPickerRef.value
    const centerLine = yearCenterLineRef.value
    const targetItem = container.querySelector(`[data-value="${selectedYear.value}"]`) as HTMLElement
    
    if (targetItem) {
      isYearScrolling = true
      await nextTick()
      const containerRect = container.getBoundingClientRect()
      const centerLineRect = centerLine.getBoundingClientRect()
      const targetItemRect = targetItem.getBoundingClientRect()
      
      const centerLineCenter = centerLineRect.top - containerRect.top + centerLineRect.height / 2
      const targetItemCenter = targetItemRect.top - containerRect.top + targetItemRect.height / 2
      const scrollDelta = targetItemCenter - centerLineCenter
      
      container.scrollTop = container.scrollTop + scrollDelta
      
      requestAnimationFrame(() => {
        setTimeout(() => {
          isYearScrolling = false
        }, 50)
      })
    }
  }
  // 일자 목록이 업데이트되면 첫 번째 일자 선택
  await nextTick()
  if (availableDays.value.length > 0 && !selectedDay.value) {
    const firstDay = availableDays.value[0]
    if (firstDay !== undefined) {
      selectedDay.value = firstDay
      await nextTick()
      if (dayPickerRef.value && dayCenterLineRef.value && !isDayScrolling) {
        const container = dayPickerRef.value
        const centerLine = dayCenterLineRef.value
        const targetItem = container.querySelector(`[data-value="${firstDay}"]`) as HTMLElement
        
        if (targetItem) {
          isDayScrolling = true
          await nextTick()
          const containerRect = container.getBoundingClientRect()
          const centerLineRect = centerLine.getBoundingClientRect()
          const targetItemRect = targetItem.getBoundingClientRect()
          
          const centerLineCenter = centerLineRect.top - containerRect.top + centerLineRect.height / 2
          const targetItemCenter = targetItemRect.top - containerRect.top + targetItemRect.height / 2
          const scrollDelta = targetItemCenter - centerLineCenter
          
          container.scrollTop = container.scrollTop + scrollDelta
          
          requestAnimationFrame(() => {
            setTimeout(() => {
              isDayScrolling = false
            }, 50)
          })
        }
      }
    }
  }
})

// 일자 목록이 변경되면 스크롤 업데이트
watch(availableDays, async () => {
  if (isDayScrolling) return
  await nextTick()
  if (selectedDay.value && dayPickerRef.value && dayCenterLineRef.value && availableDays.value.length > 0) {
    const container = dayPickerRef.value
    const centerLine = dayCenterLineRef.value
    const targetItem = container.querySelector(`[data-value="${selectedDay.value}"]`) as HTMLElement
    
    if (targetItem) {
      isDayScrolling = true
      await nextTick()
      const containerRect = container.getBoundingClientRect()
      const centerLineRect = centerLine.getBoundingClientRect()
      const targetItemRect = targetItem.getBoundingClientRect()
      
      const centerLineCenter = centerLineRect.top - containerRect.top + centerLineRect.height / 2
      const targetItemCenter = targetItemRect.top - containerRect.top + targetItemRect.height / 2
      const scrollDelta = targetItemCenter - centerLineCenter
      
      container.scrollTop = container.scrollTop + scrollDelta
      
      requestAnimationFrame(() => {
        setTimeout(() => {
          isDayScrolling = false
        }, 50)
      })
    } else {
      // 선택된 일자가 없으면 첫 번째 일자 선택
      const firstDay = availableDays.value[0]
      if (firstDay !== undefined) {
        selectedDay.value = firstDay
        await nextTick()
        if (dayPickerRef.value) {
          isDayScrolling = true
          const targetScrollTop = 0 * 44 + 22 - 88 // 첫 번째 아이템 중앙이 중앙선에 오도록
          dayPickerRef.value.scrollTop = Math.max(0, targetScrollTop)
          requestAnimationFrame(() => {
            setTimeout(() => {
              isDayScrolling = false
            }, 50)
          })
        }
      }
    }
  }
})

// 휠 피커 ref
const yearPickerRef = ref<HTMLElement | null>(null)
const monthPickerRef = ref<HTMLElement | null>(null)
const dayPickerRef = ref<HTMLElement | null>(null)

// 중앙선 영역 ref (Observer root)
const yearCenterLineRef = ref<HTMLElement | null>(null)
const monthCenterLineRef = ref<HTMLElement | null>(null)
const dayCenterLineRef = ref<HTMLElement | null>(null)

// Intersection Observer를 사용하여 중앙선 영역과 교차하는 항목 자동 선택
const setupIntersectionObserver = (
  container: HTMLElement,
  centerLine: HTMLElement,
  items: HTMLElement[],
  onSelect: (value: number) => void
) => {
  if (!container || !centerLine) return null

  const observer = new IntersectionObserver(
    (entries: IntersectionObserverEntry[]) => {
      // intersectionRatio가 가장 높은 항목 찾기
      let maxRatio = 0
      let selectedEntry: IntersectionObserverEntry | null = null

      for (const entry of entries) {
        if (entry.intersectionRatio > maxRatio) {
          maxRatio = entry.intersectionRatio
          selectedEntry = entry
        }
      }

      // 중앙선과 교차하는 항목 선택
      if (selectedEntry !== null && selectedEntry.intersectionRatio > 0) {
        const target = selectedEntry.target as HTMLElement
        const value = Number(target.getAttribute('data-value'))
        if (!isNaN(value)) {
          onSelect(value)
        }
      }
    },
    {
      root: container,
      rootMargin: '-5.5rem 0px -5.5rem 0px', // 중앙선 영역만 관찰 (5.5rem = 88px)
      threshold: [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
    }
  )

  // 모든 아이템 관찰 시작
  items.forEach((item) => {
    observer.observe(item)
  })

  return observer
}

// 년도 Observer
let yearObserver: IntersectionObserver | null = null
watch([yearPickerRef, yearCenterLineRef, years], async () => {
  if (yearObserver) {
    yearObserver.disconnect()
    yearObserver = null
  }

  if (!yearPickerRef.value || !yearCenterLineRef.value) return

  await nextTick()

  const items = Array.from(
    yearPickerRef.value.querySelectorAll('[data-value]')
  ) as HTMLElement[]

  if (items.length > 0 && yearCenterLineRef.value) {
    yearObserver = setupIntersectionObserver(
      yearPickerRef.value,
      yearCenterLineRef.value,
      items,
      (value) => {
        if (selectedYear.value !== value) {
          selectedYear.value = value
        }
      }
    )
  }
})

// 월 Observer
let monthObserver: IntersectionObserver | null = null
watch([monthPickerRef, monthCenterLineRef, months], async () => {
  if (monthObserver) {
    monthObserver.disconnect()
    monthObserver = null
  }

  if (!monthPickerRef.value || !monthCenterLineRef.value) return

  await nextTick()

  const items = Array.from(
    monthPickerRef.value.querySelectorAll('[data-value]')
  ) as HTMLElement[]

  if (items.length > 0 && monthCenterLineRef.value) {
    monthObserver = setupIntersectionObserver(
      monthPickerRef.value,
      monthCenterLineRef.value,
      items,
      (value) => {
        if (selectedMonth.value !== value) {
          selectedMonth.value = value
        }
      }
    )
  }
})

// 일 Observer
let dayObserver: IntersectionObserver | null = null
watch([dayPickerRef, dayCenterLineRef, availableDays], async () => {
  if (dayObserver) {
    dayObserver.disconnect()
    dayObserver = null
  }

  if (!dayPickerRef.value || !dayCenterLineRef.value || !selectedYear.value || !selectedMonth.value) return

  await nextTick()

  const items = Array.from(
    dayPickerRef.value.querySelectorAll('[data-value]')
  ) as HTMLElement[]

  if (items.length > 0 && dayCenterLineRef.value) {
    dayObserver = setupIntersectionObserver(
      dayPickerRef.value,
      dayCenterLineRef.value,
      items,
      (value) => {
        if (selectedDay.value !== value) {
          selectedDay.value = value
        }
      }
    )
  }
})

// 스크롤 중 플래그 (무한 루프 방지)
let isYearScrolling = false
let isMonthScrolling = false
let isDayScrolling = false

// 스크롤 이벤트 핸들러 - 중앙선 위치의 아이템 선택
// 실제 DOM 요소의 위치를 확인하여 중앙선과 가장 가까운 항목 찾기
const handleYearScroll = () => {
  if (!yearPickerRef.value || !yearCenterLineRef.value || isYearScrolling) return
  
  const container = yearPickerRef.value
  const centerLine = yearCenterLineRef.value
  
  // 중앙선의 실제 위치 (컨테이너 기준)
  const containerRect = container.getBoundingClientRect()
  const centerLineRect = centerLine.getBoundingClientRect()
  const centerLineTop = centerLineRect.top - containerRect.top + container.scrollTop
  const centerLineCenter = centerLineTop + centerLineRect.height / 2
  
  // 모든 아이템 중에서 중앙선과 가장 가까운 항목 찾기
  const items = Array.from(container.querySelectorAll('[data-value]')) as HTMLElement[]
  let closestItem: HTMLElement | null = null
  let minDistance = Infinity
  
  items.forEach((item) => {
    const itemRect = item.getBoundingClientRect()
    const itemTop = itemRect.top - containerRect.top + container.scrollTop
    const itemCenter = itemTop + itemRect.height / 2
    const distance = Math.abs(itemCenter - centerLineCenter)
    
    if (distance < minDistance) {
      minDistance = distance
      closestItem = item
    }
  })
  
  if (closestItem) {
    const value = Number((closestItem as HTMLElement).getAttribute('data-value'))
    if (!isNaN(value) && selectedYear.value !== value) {
      isYearScrolling = true
      selectedYear.value = value
      requestAnimationFrame(() => {
        setTimeout(() => {
          isYearScrolling = false
        }, 50)
      })
    }
  }
}

const handleMonthScroll = () => {
  if (!monthPickerRef.value || !monthCenterLineRef.value || isMonthScrolling) return
  
  const container = monthPickerRef.value
  const centerLine = monthCenterLineRef.value
  
  const containerRect = container.getBoundingClientRect()
  const centerLineRect = centerLine.getBoundingClientRect()
  const centerLineTop = centerLineRect.top - containerRect.top + container.scrollTop
  const centerLineCenter = centerLineTop + centerLineRect.height / 2
  
  const items = Array.from(container.querySelectorAll('[data-value]')) as HTMLElement[]
  let closestItem: HTMLElement | null = null
  let minDistance = Infinity
  
  items.forEach((item) => {
    const itemRect = item.getBoundingClientRect()
    const itemTop = itemRect.top - containerRect.top + container.scrollTop
    const itemCenter = itemTop + itemRect.height / 2
    const distance = Math.abs(itemCenter - centerLineCenter)
    
    if (distance < minDistance) {
      minDistance = distance
      closestItem = item
    }
  })
  
  if (closestItem) {
    const value = Number((closestItem as HTMLElement).getAttribute('data-value'))
    if (!isNaN(value) && selectedMonth.value !== value) {
      isMonthScrolling = true
      selectedMonth.value = value
      requestAnimationFrame(() => {
        setTimeout(() => {
          isMonthScrolling = false
        }, 50)
      })
    }
  }
}

const handleDayScroll = () => {
  if (!dayPickerRef.value || !dayCenterLineRef.value || isDayScrolling) return
  
  const container = dayPickerRef.value
  const centerLine = dayCenterLineRef.value
  
  const containerRect = container.getBoundingClientRect()
  const centerLineRect = centerLine.getBoundingClientRect()
  const centerLineTop = centerLineRect.top - containerRect.top + container.scrollTop
  const centerLineCenter = centerLineTop + centerLineRect.height / 2
  
  const items = Array.from(container.querySelectorAll('[data-value]')) as HTMLElement[]
  let closestItem: HTMLElement | null = null
  let minDistance = Infinity
  
  items.forEach((item) => {
    const itemRect = item.getBoundingClientRect()
    const itemTop = itemRect.top - containerRect.top + container.scrollTop
    const itemCenter = itemTop + itemRect.height / 2
    const distance = Math.abs(itemCenter - centerLineCenter)
    
    if (distance < minDistance) {
      minDistance = distance
      closestItem = item
    }
  })
  
  if (closestItem) {
    const value = Number((closestItem as HTMLElement).getAttribute('data-value'))
    if (!isNaN(value) && selectedDay.value !== value) {
      isDayScrolling = true
      selectedDay.value = value
      requestAnimationFrame(() => {
        setTimeout(() => {
          isDayScrolling = false
        }, 50)
      })
    }
  }
}

// 컴포넌트 언마운트 시 Observer 정리
onBeforeUnmount(() => {
  if (yearObserver) {
    yearObserver.disconnect()
    yearObserver = null
  }
  if (monthObserver) {
    monthObserver.disconnect()
    monthObserver = null
  }
  if (dayObserver) {
    dayObserver.disconnect()
    dayObserver = null
  }
})

// 선택된 값으로 스크롤 위치 설정
// 실제 DOM 요소의 위치를 기준으로 중앙선에 맞춤
const scrollToSelected = async () => {
  await nextTick()
  await nextTick() // 한 번 더 대기하여 DOM이 완전히 렌더링되도록
  
  // 년도 스크롤
  if (yearPickerRef.value && yearCenterLineRef.value && selectedYear.value && !isYearScrolling) {
    const container = yearPickerRef.value
    const centerLine = yearCenterLineRef.value
    const targetItem = container.querySelector(`[data-value="${selectedYear.value}"]`) as HTMLElement
    
    if (targetItem) {
      isYearScrolling = true
      const containerRect = container.getBoundingClientRect()
      const centerLineRect = centerLine.getBoundingClientRect()
      const targetItemRect = targetItem.getBoundingClientRect()
      
      // 중앙선의 중앙 위치
      const centerLineCenter = centerLineRect.top - containerRect.top + centerLineRect.height / 2
      // 아이템의 중앙 위치 (현재 스크롤 기준)
      const targetItemCenter = targetItemRect.top - containerRect.top + targetItemRect.height / 2
      // 스크롤해야 할 거리
      const scrollDelta = targetItemCenter - centerLineCenter
      
      container.scrollTop = container.scrollTop + scrollDelta
      
      requestAnimationFrame(() => {
        setTimeout(() => {
          isYearScrolling = false
        }, 50)
      })
    }
  }
  
  // 월 스크롤
  if (monthPickerRef.value && monthCenterLineRef.value && selectedMonth.value && !isMonthScrolling) {
    const container = monthPickerRef.value
    const centerLine = monthCenterLineRef.value
    const targetItem = container.querySelector(`[data-value="${selectedMonth.value}"]`) as HTMLElement
    
    if (targetItem) {
      isMonthScrolling = true
      const containerRect = container.getBoundingClientRect()
      const centerLineRect = centerLine.getBoundingClientRect()
      const targetItemRect = targetItem.getBoundingClientRect()
      
      const centerLineCenter = centerLineRect.top - containerRect.top + centerLineRect.height / 2
      const targetItemCenter = targetItemRect.top - containerRect.top + targetItemRect.height / 2
      const scrollDelta = targetItemCenter - centerLineCenter
      
      container.scrollTop = container.scrollTop + scrollDelta
      
      requestAnimationFrame(() => {
        setTimeout(() => {
          isMonthScrolling = false
        }, 50)
      })
    }
  }
  
  // 일 스크롤
  if (dayPickerRef.value && dayCenterLineRef.value && selectedDay.value && availableDays.value.length > 0 && !isDayScrolling) {
    const container = dayPickerRef.value
    const centerLine = dayCenterLineRef.value
    const targetItem = container.querySelector(`[data-value="${selectedDay.value}"]`) as HTMLElement
    
    if (targetItem) {
      isDayScrolling = true
      const containerRect = container.getBoundingClientRect()
      const centerLineRect = centerLine.getBoundingClientRect()
      const targetItemRect = targetItem.getBoundingClientRect()
      
      const centerLineCenter = centerLineRect.top - containerRect.top + centerLineRect.height / 2
      const targetItemCenter = targetItemRect.top - containerRect.top + targetItemRect.height / 2
      const scrollDelta = targetItemCenter - centerLineCenter
      
      container.scrollTop = container.scrollTop + scrollDelta
      
      requestAnimationFrame(() => {
        setTimeout(() => {
          isDayScrolling = false
        }, 50)
      })
    }
  }
}

// 생년월일 모달 열기 시 기존 값으로 초기화
const handleOpenBirthDateModal = async () => {
  if (form.value.birthDate) {
    const parts = form.value.birthDate.split('-')
    if (parts.length === 3 && parts[0] && parts[1] && parts[2]) {
      selectedYear.value = parseInt(parts[0]) || ''
      selectedMonth.value = parseInt(parts[1]) || ''
      selectedDay.value = parseInt(parts[2]) || ''
    } else {
      // 기본값: 1996년 1월 1일
      selectedYear.value = 1996
      selectedMonth.value = 1
      await nextTick()
      selectedDay.value = 1
    }
  } else {
    // 기본값: 1996년 1월 1일
    selectedYear.value = 1996
    selectedMonth.value = 1
    await nextTick()
    selectedDay.value = 1
  }
  showBirthDateModal.value = true
  await scrollToSelected()
}

// 생년월일 확인
const handleConfirmBirthDate = () => {
  if (!selectedYear.value || !selectedMonth.value || !selectedDay.value) {
    return
  }
  
  const year = String(selectedYear.value)
  const month = String(selectedMonth.value).padStart(2, '0')
  const day = String(selectedDay.value).padStart(2, '0')
  
  form.value.birthDate = `${year}-${month}-${day}`
  createValidator('birthDate')()
  showBirthDateModal.value = false
}

// 생년월일 모달 닫기
const handleCloseBirthDateModal = () => {
  showBirthDateModal.value = false
  selectedYear.value = ''
  selectedMonth.value = ''
  selectedDay.value = ''
}

// 검증 규칙 선언
type ValidationRule = {
  required?: boolean
  pattern?: RegExp
  message: string
  custom?: (value: any, form: any) => string | null
}

const validationRules: Record<string, ValidationRule> = {
  phone: {
    required: true,
    pattern: /^01[0-9][0-9]{3,4}[0-9]{4}$/,
    message: '올바른 휴대폰 번호 형식을 입력해주세요. (예: 01012345678)'
  },
  name: {
    required: true,
    custom: (value) => value?.trim().length < 2 ? '이름은 2자 이상 입력해주세요.' : null,
    message: '이름을 입력해주세요.'
  },
  birthDate: {
    required: true,
    pattern: /^\d{4}-\d{2}-\d{2}$/,
    message: '올바른 생년월일 형식을 입력해주세요. (예: 1990-01-01)'
  },
  username: {
    required: true,
    pattern: /^[a-zA-Z0-9]+$/,
    message: '아이디는 영문과 숫자만 사용할 수 있습니다.'
  },
  nickname: {
    required: true,
    custom: (value) => {
      if (!value) return null
      if (value.trim().length < 2) {
        return '닉네임은 2자 이상이어야 합니다.'
      }
      if (value.trim().length > 20) {
        return '닉네임은 20자 이하여야 합니다.'
      }
      return null
    },
    message: '닉네임을 입력해주세요.'
  },
  password: {
    required: true,
    custom: (value) => {
      if (!value) return null
      const hasEnglish = /[a-zA-Z]/.test(value)
      const hasNumber = /[0-9]/.test(value)
      const hasSpecial = /[^a-zA-Z0-9\s]/.test(value)
      return (!hasEnglish || !hasNumber || !hasSpecial) 
        ? '비밀번호는 영문, 숫자, 특수문자를 모두 포함해야 합니다.' 
        : null
    },
    message: '비밀번호를 입력해주세요.'
  },
  passwordConfirm: {
    required: true,
    custom: (value, form) => {
      if (!value) return null
      if (value !== form.password) {
        return '비밀번호가 일치하지 않습니다.'
      }
      return null
    },
    message: '비밀번호 확인을 입력해주세요.'
  },
  zipCode: {
    required: true,
    pattern: /^\d{5}$/,
    message: '올바른 우편번호 형식을 입력해주세요. (5자리 숫자)'
  },
  address: {
    required: true,
    custom: (value) => value?.trim().length < 5 ? '주소를 정확히 입력해주세요.' : null,
    message: '기본주소를 입력해주세요.'
  },
  mobile: {
    required: true,
    pattern: /^01[0-9][0-9]{3,4}[0-9]{4}$/,
    message: '올바른 휴대전화 번호 형식을 입력해주세요. (예: 01012345678)'
  },
  email: {
    required: true,
    pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    message: '올바른 이메일 형식을 입력해주세요. (예: example@email.com)'
  },
  landline: {
    pattern: /^0[2-9]{1,2}[0-9]{3,4}[0-9]{4}$/,
    message: '올바른 전화번호 형식을 입력해주세요. (예: 0200000000)'
  }
}

// 에러 상태 관리
const errors = ref<Record<string, string>>({
  phone: '',
  name: '',
  birthDate: '',
  username: '',
  nickname: '',
  password: '',
  passwordConfirm: '',
  zipCode: '',
  address: '',
  detailAddress: '',
  landline: '',
  mobile: '',
  email: '',
  region: '',
  mobileVerificationCode: ''
})
const fieldRefs = ref<Record<string, HTMLElement | null>>({})

// errors 객체에 mobileVerificationCode 필드가 없으면 추가 (안전장치)
if (!errors.value.mobileVerificationCode) {
  errors.value.mobileVerificationCode = ''
}

// 비밀번호 표시/숨김 상태
const showPassword = ref(false)
const showPasswordConfirm = ref(false)

// 아이디 중복확인 상태
const isCheckingUsername = ref(false)
const isUsernameAvailable = ref<boolean | null>(null)
const isCheckingEmail = ref(false)
const isEmailAvailable = ref<boolean | null>(null)

// 공통 검증 함수
const validateField = (field: string, value: any) => {
  const rule = validationRules[field]
  if (!rule) return null

  // 필수 필드가 아니고 값이 없으면 검증 통과
  if (!rule.required && !value) {
    return null
  }

  // 필수 필드인데 값이 없으면 에러
  if (rule.required && !value) {
    return rule.message
  }

  // 값이 있을 때만 패턴 검증
  if (value && rule.pattern) {
    // phone, mobile, landline 필드는 하이픈 제거 후 검증
    const valueToTest = (field === 'phone' || field === 'mobile' || field === 'landline') 
      ? value.replace(/-/g, '') 
      : value
    if (!rule.pattern.test(valueToTest)) {
      return rule.message
    }
  }

  // 값이 있을 때만 커스텀 검증
  if (value && rule.custom) {
    return rule.custom(value, form.value)
  }

  return null
}


// 날짜 선택기 ref
const datePickerRef = ref<HTMLInputElement | null>(null)

// 생년월일 입력 처리 (자동 하이픈 추가)
const handleBirthDateInput = (event: Event) => {
  const input = event.target as HTMLInputElement
  if (!input) return
  
  let value = input.value.replace(/[^0-9]/g, '') // 숫자만 추출
  
  // 최대 8자리까지만 입력
  if (value.length > 8) {
    value = value.substring(0, 8)
  }
  
  // 자동으로 하이픈 추가 (YYYY-MM-DD 형식)
  let formattedValue = value
  if (value.length > 4) {
    formattedValue = value.substring(0, 4) + '-' + value.substring(4)
  }
  if (value.length > 6) {
    formattedValue = value.substring(0, 4) + '-' + value.substring(4, 6) + '-' + value.substring(6)
  }
  
  form.value.birthDate = formattedValue
  createValidator('birthDate')()
  
  // 날짜 선택기도 동기화
  if (datePickerRef.value && formattedValue.length === 10) {
    datePickerRef.value.value = formattedValue
  }
}

// 생년월일 포커스 아웃 시 유효성 검사 및 포맷팅
const handleBirthDateBlur = () => {
  const value = form.value.birthDate
  
  // 하이픈 제거 후 숫자만 추출
  const numbers = value.replace(/[^0-9]/g, '')
  
  if (numbers.length === 8) {
    // YYYYMMDD 형식으로 변환
    const year = numbers.substring(0, 4)
    const month = numbers.substring(4, 6)
    const day = numbers.substring(6, 8)
    
    // 유효한 날짜인지 확인
    const date = new Date(parseInt(year), parseInt(month) - 1, parseInt(day))
    const today = new Date()
    
    if (date.getFullYear() === parseInt(year) && 
        date.getMonth() === parseInt(month) - 1 && 
        date.getDate() === parseInt(day) &&
        date <= today) {
      // 유효한 날짜면 YYYY-MM-DD 형식으로 설정
      form.value.birthDate = `${year}-${month}-${day}`
      // 날짜 선택기도 동기화
      if (datePickerRef.value) {
        datePickerRef.value.value = `${year}-${month}-${day}`
      }
    } else {
      // 유효하지 않은 날짜면 에러 표시
      errors.value.birthDate = '올바른 생년월일을 입력해주세요.'
    }
  } else if (numbers.length > 0 && numbers.length < 8) {
    // 8자리가 아니면 에러 표시
    errors.value.birthDate = '생년월일을 8자리로 입력해주세요. (예: 19900101)'
  }
  
  createValidator('birthDate')()
}

// 날짜 선택기 열기
const openDatePicker = async () => {
  if (import.meta.server) return
  
  await nextTick()
  const picker = datePickerRef.value
  if (!picker) return
  
  // 텍스트 입력 값이 있으면 날짜 선택기에 반영
  if (form.value.birthDate) {
    const numbers = form.value.birthDate.replace(/[^0-9]/g, '')
    if (numbers.length === 8) {
      const year = numbers.substring(0, 4)
      const month = numbers.substring(4, 6)
      const day = numbers.substring(6, 8)
      const dateValue = `${year}-${month}-${day}`
      try {
        const date = new Date(parseInt(year), parseInt(month) - 1, parseInt(day))
        if (date.getFullYear() === parseInt(year) && 
            date.getMonth() === parseInt(month) - 1 && 
            date.getDate() === parseInt(day)) {
          picker.value = dateValue
        }
      } catch (e) {
        // 유효하지 않은 날짜는 무시
      }
    }
  }
  
  // showPicker API 지원 여부 확인
  if ('showPicker' in picker && typeof (picker as any).showPicker === 'function') {
    try {
      await (picker as any).showPicker()
    } catch (error) {
      // showPicker가 지원되지 않거나 사용자가 취소한 경우
      // 클릭 이벤트로 대체
      if (picker instanceof HTMLInputElement) {
        picker.focus()
        picker.click()
      }
    }
  } else {
    // showPicker가 없으면 클릭 이벤트 트리거
    if (picker instanceof HTMLInputElement) {
      picker.focus()
      picker.click()
    }
  }
}

// 날짜 선택기에서 날짜 선택 시
const handleDatePickerChange = (event: Event) => {
  const input = event.target as HTMLInputElement
  if (input.value) {
    form.value.birthDate = input.value
    createValidator('birthDate')()
  }
}

// 날짜 선택기 값 (YYYY-MM-DD 형식으로 변환)
const datePickerValue = computed(() => {
  const value = form.value.birthDate
  if (!value) return ''
  
  // 하이픈이 있는 경우 그대로 사용
  if (value.includes('-') && value.length === 10) {
    return value
  }
  
  // 숫자만 있는 경우 YYYY-MM-DD 형식으로 변환
  const numbers = value.replace(/[^0-9]/g, '')
  if (numbers.length === 8) {
    const year = numbers.substring(0, 4)
    const month = numbers.substring(4, 6)
    const day = numbers.substring(6, 8)
    return `${year}-${month}-${day}`
  }
  
  return ''
})

// 오늘 날짜를 최대값으로 설정
const maxDate = computed(() => {
  if (import.meta.server) return undefined
  const today = new Date()
  return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`
})

// 카카오 주소 검색 API
const loadKakaoAddressScript = () => {
  return new Promise<void>((resolve, reject) => {
    if (import.meta.server) {
      resolve()
      return
    }

    // 이미 로드되어 있는지 확인
    if (window.daum && window.daum.Postcode) {
      resolve()
      return
    }

    const script = document.createElement('script')
    script.src = '//t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js'
    script.async = true
    script.onload = () => resolve()
    script.onerror = () => reject(new Error('카카오 주소 검색 스크립트 로드 실패'))
    document.head.appendChild(script)
  })
}

const openAddressSearch = async () => {
  if (import.meta.server) return

  try {
    await loadKakaoAddressScript()

    if (!window.daum || !window.daum.Postcode) {
      toastStore.error('주소 검색 서비스를 불러올 수 없습니다.')
      return
    }

    new window.daum.Postcode({
      oncomplete: (data: any) => {
        // 주소 검색 결과 처리 - 선언형 방식
        const addr = data.userSelectedType === 'R' 
          ? data.roadAddress 
          : data.jibunAddress

        // 참고항목 조합 - 선언형 방식
        const extraAddr = data.userSelectedType === 'R'
          ? (() => {
              const parts: string[] = []
              
              // 법정동명이 있을 경우 추가 (법정리는 제외)
              if (data.bname !== '' && /[동|로|가]$/g.test(data.bname)) {
                parts.push(data.bname)
              }
              
              // 건물명이 있고, 공동주택일 경우 추가
              if (data.buildingName !== '' && data.apartment === 'Y') {
                parts.push(data.buildingName)
              }
              
              return parts.length > 0 ? ` (${parts.join(', ')})` : ''
            })()
          : ''

        // 우편번호와 주소 정보를 해당 필드에 넣는다.
        form.value.zipCode = data.zonecode
        form.value.address = addr + extraAddr
        // 커서를 상세주소 필드로 이동한다.
        // 상세주소 입력 필드가 있다면 포커스
        const detailInput = document.querySelector('input[placeholder="상세주소"]') as HTMLInputElement
        if (detailInput) {
          detailInput.focus()
        }
      },
      onresize: (size: any) => {
        // 팝업 크기 조정
      },
      width: '100%',
      height: '100%'
    }).open()
  } catch (error) {
    toastStore.error('주소 검색 중 오류가 발생했습니다.')
  }
}

// 전역 타입 선언
declare global {
  interface Window {
    daum?: {
      Postcode: new (options: any) => {
        open: () => void
      }
    }
  }
}


const form = ref({
  phone: '',
  name: '',
  birthDate: '',
  birthDateDisplay: '',
  username: '',
  nickname: '',
  password: '',
  passwordConfirm: '',
  zipCode: '',
  address: '',
  detailAddress: '',
  landline: '',
  mobile: '',
  email: '',
  region: '',
  gender: '여성',
  agreeTerms: true,
  agreePrivacy: false,
  agreeConsignment: false,
  agreeEmail: false
})



// 필드별 검증 함수 생성 (form 정의 이후에 위치)
const createValidator = (field: string) => () => {
  errors.value[field] = validateField(field, form.value[field as keyof typeof form.value]) || ''
}

// 아이디 한글 입력 방지
const preventKoreanInput = (event: KeyboardEvent) => {
  if (event.keyCode === 229) event.preventDefault()
}

const handleUsernameInput = () => {
  const username = form.value.username
  const koreanPattern = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/
  if (koreanPattern.test(username)) {
    form.value.username = username.replace(/[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/g, '')
  }
  createValidator('username')()
  // 아이디가 변경되면 중복확인 상태 초기화
  isUsernameAvailable.value = null
}

// 이메일 입력 처리
const handleEmailInput = () => {
  createValidator('email')()
  // 이메일이 변경되면 중복확인 상태 초기화
  isEmailAvailable.value = null
}

const handleCheckUsername = async () => {
  if (!form.value.username) {
    toastStore.error('아이디를 입력해주세요.')
    return
  }

  // 기본 형식 검증
  const usernameRule = validationRules.username
  if (usernameRule?.pattern && !usernameRule.pattern.test(form.value.username)) {
    toastStore.error(usernameRule.message)
    return
  }

  isCheckingUsername.value = true
  isUsernameAvailable.value = null
  errors.value.username = '' // 에러 메시지 초기화

  try {
    const { checkId } = await import('~/shared/api/auth')
    const response = await checkId(form.value.username)
    
    // API 응답: data가 true면 중복, false면 사용 가능
    const isDuplicate = response.data === true
    
    if (isDuplicate) {
      isUsernameAvailable.value = false
      errors.value.username = '이미 사용 중인 아이디입니다.'
      toastStore.error('이미 사용 중인 아이디입니다.')
    } else {
      isUsernameAvailable.value = true
      errors.value.username = '' // 사용 가능하면 에러 메시지 제거
      toastStore.success('사용 가능한 아이디입니다.')
    }
  } catch (error: any) {
    const errorMessage = error.response?.data?.message?.message || 
                        error.message || 
                        '아이디 중복확인에 실패했습니다.'
    isUsernameAvailable.value = false
    errors.value.username = errorMessage
    toastStore.error(errorMessage)
  } finally {
    isCheckingUsername.value = false
  }
}

// 이메일 중복 확인
const handleCheckEmail = async () => {
  if (!form.value.email) {
    toastStore.error('이메일을 입력해주세요.')
    return
  }

  // 기본 형식 검증
  const emailRule = validationRules.email
  if (emailRule?.pattern && !emailRule.pattern.test(form.value.email)) {
    toastStore.error(emailRule.message)
    return
  }

  isCheckingEmail.value = true
  isEmailAvailable.value = null
  errors.value.email = '' // 에러 메시지 초기화

  try {
    const { checkEmail } = await import('~/shared/api/auth')
    const response = await checkEmail(form.value.email)
    
    // API 응답: data가 true면 중복, false면 사용 가능
    const isDuplicate = response.data === true
    
    if (isDuplicate) {
      isEmailAvailable.value = false
      errors.value.email = '이미 사용 중인 이메일입니다.'
      toastStore.error('이미 사용 중인 이메일입니다.')
    } else {
      isEmailAvailable.value = true
      errors.value.email = '' // 사용 가능하면 에러 메시지 제거
      toastStore.success('사용 가능한 이메일입니다.')
    }
  } catch (error: any) {
    const errorMessage = error.response?.data?.message?.message || 
                        error.message || 
                        '이메일 중복확인에 실패했습니다.'
    isEmailAvailable.value = false
    errors.value.email = errorMessage
    toastStore.error(errorMessage)
  } finally {
    isCheckingEmail.value = false
  }
}

const handlePasswordInput = () => {
  createValidator('password')()
  // 비밀번호가 변경되면 비밀번호 확인도 다시 검증
  if (form.value.passwordConfirm) {
    createValidator('passwordConfirm')()
  }
}

// 비밀번호 확인 입력 시 검증
const handlePasswordConfirmInput = () => {
  createValidator('passwordConfirm')()
}


const agreeAll = ref(false)

const handleAgreeAll = () => {
  if (agreeAll.value) {
    form.value.agreeTerms = true
    form.value.agreePrivacy = true
    form.value.agreeConsignment = true
    form.value.agreeEmail = true
  } else {
    form.value.agreeTerms = false
    form.value.agreePrivacy = false
    form.value.agreeConsignment = false
    form.value.agreeEmail = false
  }
}

watch(
  () => [
    form.value.agreeTerms,
    form.value.agreePrivacy,
    form.value.agreeConsignment,
    form.value.agreeEmail
  ],
  () => {
    agreeAll.value =
      form.value.agreeTerms &&
      form.value.agreePrivacy &&
      form.value.agreeConsignment &&
      form.value.agreeEmail
  }
)

// 모든 필드 검증 - 선언형 방식
const validateAll = (): { field: string; message: string } | null => {
  // 필수 필드만 검증 (landline은 선택사항이므로 제외)
  Object.keys(validationRules)
    .filter(field => {
      const rule = validationRules[field]
      return rule && rule.required !== false
    })
    .forEach(field => {
      errors.value[field] = validateField(field, form.value[field as keyof typeof form.value]) || ''
    })
  
  // 선택사항 필드도 값이 있으면 검증 (landline 등)
  Object.keys(validationRules)
    .filter(field => {
      const rule = validationRules[field]
      return rule && rule.required === false && form.value[field as keyof typeof form.value]
    })
    .forEach(field => {
      errors.value[field] = validateField(field, form.value[field as keyof typeof form.value]) || ''
    })
  
  // 약관 동의 검증
  if (!form.value.agreeTerms || !form.value.agreePrivacy) {
    errors.value.terms = '필수 약관에 동의해주세요.'
  } else {
    errors.value.terms = ''
  }
  
  // 첫 번째 에러 필드 찾기
  const errorFields = Object.keys(errors.value).filter(field => errors.value[field])
  if (errorFields.length === 0) return null
  
  const firstErrorField = errorFields[0]
  if (!firstErrorField) return null
  
  return { field: firstErrorField, message: errors.value[firstErrorField] || '' }
}

// 타이머 포맷팅 (분:초)
const formatTimer = (seconds: number): string => {
  const minutes = Math.floor(seconds / 60)
  const secs = seconds % 60
  return `${minutes}:${String(secs).padStart(2, '0')}`
}

// 타이머 시작
const startMobileVerificationTimer = () => {
  // 기존 타이머 정리
  if (mobileVerificationTimerInterval.value) {
    clearInterval(mobileVerificationTimerInterval.value)
  }
  
  mobileVerificationTimer.value = 180 // 3분 = 180초
  
  mobileVerificationTimerInterval.value = setInterval(() => {
    mobileVerificationTimer.value--
    
    if (mobileVerificationTimer.value <= 0) {
      if (mobileVerificationTimerInterval.value) {
        clearInterval(mobileVerificationTimerInterval.value)
        mobileVerificationTimerInterval.value = null
      }
      mobileVerificationTimer.value = 0
    }
  }, 1000)
}

// 인증번호 재요청
const handleResendVerificationCode = async () => {
  if (import.meta.server) return

  // 휴대폰 번호 검증
  createValidator('phone')()
  if (errors.value.phone || !form.value.phone) {
    toastStore.error('올바른 휴대폰 번호를 입력해주세요.')
    return
  }

  isVerifyingMobile.value = true
  mobileVerificationCode.value = ''
  errors.value.mobileVerificationCode = ''

  try {
    const { verifyMobile } = await import('~/shared/api/auth')
    
    // 하이픈 제거
    const phoneWithoutHyphen = form.value.phone.replace(/-/g, '')
    
    const response = await verifyMobile({
      mobilePhoneNumber: phoneWithoutHyphen
    })

    if (response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') {
      // recoveryToken 저장 (응답의 data가 recoveryToken)
      if (response.data) {
        recoveryToken.value = response.data
      }
      // 타이머 재시작
      startMobileVerificationTimer()
      toastStore.success('인증번호가 재발송되었습니다. SMS를 확인해주세요.')
    } else {
      const errorMessage = response.message.message || '인증 요청에 실패했습니다.'
      toastStore.error(errorMessage)
    }
  } catch (error: any) {
    const errorMessage = error.response?.data?.message?.message || 
                        error.message || 
                        '인증 요청에 실패했습니다.'
    toastStore.error(errorMessage)
  } finally {
    isVerifyingMobile.value = false
  }
}

// 타이머 정리
const clearMobileVerificationTimer = () => {
  if (mobileVerificationTimerInterval.value) {
    clearInterval(mobileVerificationTimerInterval.value)
    mobileVerificationTimerInterval.value = null
  }
  mobileVerificationTimer.value = 0
}

// 모바일 인증 요청
const handleMobileVerification = async () => {
  if (import.meta.server) return

  // 휴대폰 번호 검증
  createValidator('phone')()
  if (errors.value.phone || !form.value.phone) {
    toastStore.error('올바른 휴대폰 번호를 입력해주세요.')
    return
  }

  isVerifyingMobile.value = true
  mobileVerificationCode.value = ''
  isMobileCodeVerified.value = false
  recoveryToken.value = null
  errors.value.mobileVerificationCode = ''

  try {
    const { verifyMobile } = await import('~/shared/api/auth')
    
    // 하이픈 제거
    const phoneWithoutHyphen = form.value.phone.replace(/-/g, '')
    
    const response = await verifyMobile({
      mobilePhoneNumber: phoneWithoutHyphen
    })

    if (response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') {
      // recoveryToken 저장 (응답의 data가 recoveryToken)
      if (response.data) {
        recoveryToken.value = response.data
      }
      isMobileVerified.value = true
      // 타이머 시작
      startMobileVerificationTimer()
      // 인증번호 입력 모달 열기
      showMobileVerificationModal.value = true
      mobileVerificationCode.value = ''
      errors.value.mobileVerificationCode = ''
      toastStore.success('인증번호가 발송되었습니다. SMS를 확인해주세요.')
    } else {
      const errorMessage = response.message.message || '인증 요청에 실패했습니다.'
      toastStore.error(errorMessage)
    }
  } catch (error: any) {
    const errorMessage = error.response?.data?.message?.message || 
                        error.message || 
                        '인증 요청에 실패했습니다.'
    toastStore.error(errorMessage)
  } finally {
    isVerifyingMobile.value = false
  }
}

// 인증번호 입력 처리
const handleVerificationCodeInput = () => {
  // 숫자만 입력 가능
  mobileVerificationCode.value = mobileVerificationCode.value.replace(/[^0-9]/g, '')
  errors.value.mobileVerificationCode = ''
}

// 인증번호 확인
const handleVerifyCode = async () => {
  if (!mobileVerificationCode.value || mobileVerificationCode.value.length !== 6) {
    errors.value.mobileVerificationCode = '인증번호 6자리를 입력해주세요.'
    return
  }

  if (!recoveryToken.value) {
    errors.value.mobileVerificationCode = '인증 요청을 먼저 해주세요.'
    toastStore.error('인증 요청을 먼저 해주세요.')
    return
  }

  isVerifyingCode.value = true

  try {
    const { verifyCode } = await import('~/shared/api/auth')
    
    const response = await verifyCode({
      recoveryToken: recoveryToken.value,
      code: mobileVerificationCode.value
    })

    if (response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') {
      isMobileCodeVerified.value = true
      // 인증 완료 시 타이머 정리
      clearMobileVerificationTimer()
      // 인증 완료 시 연락처 섹션의 휴대전화 번호 자동 채우기 (하이픈 없이 숫자만)
      if (form.value.phone) {
        // 하이픈 제거하여 숫자만 저장
        form.value.mobile = form.value.phone.replace(/-/g, '')
      }
      toastStore.success('인증이 완료되었습니다.')
      // 1초 후 모달 닫기
      setTimeout(() => {
        showMobileVerificationModal.value = false
      }, 1000)
    } else {
      const errorMessage = response.message.message || '인증번호 확인에 실패했습니다.'
      errors.value.mobileVerificationCode = errorMessage
      toastStore.error(errorMessage)
    }
  } catch (error: any) {
    const errorMessage = error.response?.data?.message?.message || 
                        error.message || 
                        '인증번호 확인에 실패했습니다.'
    errors.value.mobileVerificationCode = errorMessage
    toastStore.error(errorMessage)
  } finally {
    isVerifyingCode.value = false
  }
}

// PASS 인증 요청 (Portone SDK 사용)
const handleKycRequest = async () => {
  if (import.meta.server) return
  
  // 휴대폰 번호 검증
  createValidator('phone')()
  if (errors.value.phone) {
    return
  }
  
  try {
    // Portone PASS 인증 요청 - 회원가입용
    const result = await requestCertification('SIGN_UP')
    
    if (result && result.identityToken) {
      // 인증 성공 - 백엔드에서 identityToken 받음
      isKycVerified.value = true
      identityToken.value = result.identityToken
      kycVerification.value = result.verification
      
      // 인증 정보로 폼 자동 채우기
      if (result.verification) {
        const verification = result.verification
        if (verification.name) {
          form.value.name = verification.name
        }
        if (verification.birthDate) {
          // yyyy-MM-dd 형식으로 변환
          const birthDate = verification.birthDate
          if (birthDate.includes('-')) {
            form.value.birthDate = birthDate
          } else if (birthDate.length === 8) {
            // yyyyMMdd 형식인 경우
            form.value.birthDate = `${birthDate.substring(0, 4)}-${birthDate.substring(4, 6)}-${birthDate.substring(6, 8)}`
          }
        }
        if (verification.phoneNumber) {
          // 전화번호 형식 변환 (01012345678 -> 010-1234-5678)
          const phone = verification.phoneNumber.replace(/-/g, '')
          if (phone.length === 11) {
            form.value.phone = `${phone.substring(0, 3)}-${phone.substring(3, 7)}-${phone.substring(7)}`
            form.value.mobile = `${phone.substring(0, 3)}-${phone.substring(3, 7)}-${phone.substring(7)}`
          }
        }
        if (verification.gender) {
          // MALE/FEMALE -> 남성/여성 변환
          form.value.gender = verification.gender === 'MALE' ? '남성' : '여성'
        }
      }
      
      toastStore.success('본인인증이 완료되었습니다.')
    } else {
      toastStore.error(kycError.value || '본인인증에 실패했습니다.')
    }
  } catch (error) {
    toastStore.error('인증 요청 중 오류가 발생했습니다.')
  }
}

// 인증번호 입력 모달 닫기
const handleCloseMobileVerificationModal = () => {
  showMobileVerificationModal.value = false
  mobileVerificationCode.value = ''
  errors.value.mobileVerificationCode = ''
  // 타이머는 유지 (모달을 닫아도 타이머는 계속 진행)
}

// 휴대전화 입력 필드 클릭 처리
const handleMobileInputClick = () => {
  if (!isMobileCodeVerified.value) {
    toastStore.error('휴대폰 인증요청을 완료해주세요.')
  }
}

// 컴포넌트 언마운트 시 타이머 정리
onBeforeUnmount(() => {
  clearMobileVerificationTimer()
})

// Portone SDK는 직접 팝업을 띄우므로 콜백 처리가 필요 없음
// handleKycCallback 함수는 더 이상 사용하지 않음

const handleSubmit = async () => {
  if (import.meta.server) return
  
  // 모바일 인증 확인
  if (!isMobileCodeVerified.value) {
    toastStore.error('휴대폰 인증을 완료해주세요.')
    const phoneRef = fieldRefs.value.phone
    if (phoneRef) {
      phoneRef.scrollIntoView({ behavior: 'smooth', block: 'center' })
    }
    return
  }
  
  const error = validateAll()
  if (error && error.field) {
    // 에러 메시지가 없으면 기본 메시지 설정
    if (!errors.value[error.field]) {
      errors.value[error.field] = validationRules[error.field]?.message || error.message
    }
    
    // 첫 번째 에러 필드로 스크롤
    const errorRef = fieldRefs.value[error.field]
    if (errorRef) {
      errorRef.scrollIntoView({ behavior: 'smooth', block: 'center' })
    }
    return
  }
  
  // 지역 한글 매핑
  const regionMap: Record<string, string> = {
    'seoul': '서울특별시',
    'busan': '부산광역시',
    'daegu': '대구광역시',
    'incheon': '인천광역시',
    'gwangju': '광주광역시',
    'daejeon': '대전광역시',
    'ulsan': '울산광역시',
    'gyeonggi': '경기도',
    'gangwon': '강원도',
    'chungbuk': '충청북도',
    'chungnam': '충청남도',
    'jeonbuk': '전라북도',
    'jeonnam': '전라남도',
    'gyeongbuk': '경상북도',
    'gyeongnam': '경상남도',
    'jeju': '제주특별자치도'
  }
  
  // 회원가입 요청 데이터 구성
  const signUpData: SignUpRequest = {
    loginId: form.value.username,
    password: form.value.password,
    name: form.value.name,
    email: form.value.email,
    nickname: form.value.nickname,
    region: regionMap[form.value.region] || form.value.region,
    birth: form.value.birthDate, // yyyy-MM-dd 형식
    address: {
      zipcode: form.value.zipCode,
      address1: form.value.address,
      address2: form.value.detailAddress || undefined
    },
    telephoneNumber: form.value.landline ? form.value.landline.replace(/-/g, '') : undefined,
    mobileNumber: form.value.mobile.replace(/-/g, ''),
    gender: form.value.gender as '남성' | '여성',
    identityToken: identityToken.value || 'test',
    agreements: {
      termsOfUse: form.value.agreeTerms,
      privacyPolicy: form.value.agreePrivacy,
      thirdPartySharing: form.value.agreeConsignment,
      emailMarketing: form.value.agreeEmail
    }
  }
  
  try {
    const response = await signUp(signUpData)
    
    if (response && (response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') && response.data) {
      // 회원가입 성공 - 토큰 저장 및 로그인 처리
      const authStore = useAuthStore()
      
      authStore.setTokens({
        accessToken: response.data.accessToken,
        refreshToken: response.data.refreshToken
      })
      
      toastStore.success('회원가입이 완료되었습니다.')
      router.push('/login')
    } else {
      // 에러 메시지 표시
      toastStore.error(signUpError.value || response?.message?.message || '회원가입에 실패했습니다.')
    }
  } catch (error) {
    toastStore.error('회원가입 중 오류가 발생했습니다.')
  }
}

// Portone SDK는 직접 팝업을 띄우므로 onMounted에서 콜백 처리가 필요 없음
</script>

