<template>
  <div :class="styles.nftDetailDescription">
    <section :class="styles.nftDetailDescription__section">
      <h2 :class="styles.nftDetailDescription__title">• 아트워크 설명</h2>
      <p :class="styles.nftDetailDescription__text">{{ artwork.description.artwork }}</p>
    </section>
<!--    <section :class="styles.nftDetailDescription__section">-->
<!--      <h2 :class="styles.nftDetailDescription__title">• 브랜드 설명</h2>-->
<!--      <p :class="styles.nftDetailDescription__text">{{ artwork.description.brand }}</p>-->
<!--    </section>-->
    <section :class="styles.nftDetailDescription__section">
      <h2 :class="styles.nftDetailDescription__title">• 유의사항</h2>
      <ol :class="styles.nftDetailDescription__notes">
        <li
          v-for="(note, index) in artwork.description.notes"
          :key="index"
          v-html="note"
        ></li>
      </ol>
      <NuxtLink to="/nft" :class="styles.nftDetailDescription__backButton">
        목록으로
      </NuxtLink>
    </section>
  </div>
</template>

<script setup lang="ts">
import styles from '~/styles/features/NFTDetailDescription.module.css'

interface Artwork {
  id: string
  image: string
  brand: string
  title: string
  price: number
  description: {
    artwork: string
    brand: string
    notes: string[]
  }
}

defineProps<{
  artwork: Artwork
}>()
</script>

