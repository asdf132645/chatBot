// 로그인 비즈니스 로직
import { ref } from 'vue'
import { login } from '~/shared/api/auth'
import type { LoginRequest, ApiResponse, LoginResponse } from '~/entities/user/types'
import { useAuthStore } from '~/stores/auth'
import { useToastStore } from '~/stores/toast'
import { navigateTo } from '#app'

export const useLogin = () => {
  const isLoading = ref(false)
  const authStore = useAuthStore()
  const toastStore = useToastStore()

  const execute = async (data: LoginRequest & { keepLoggedIn?: boolean }): Promise<boolean> => {
    isLoading.value = true

    try {
      const response = await login(data)
      
      // httpStatus가 "OK" 또는 "200 OK"인 경우 성공
      if ((response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') && response.data) {
        // 스토어에 토큰 저장 (로그인 응답에는 user 정보가 없음)
        authStore.setTokens({
          accessToken: response.data.accessToken,
          refreshToken: response.data.refreshToken,
          keepLoggedIn: data.keepLoggedIn
        })
        
        toastStore.success('로그인에 성공했습니다.')
        return true
      } else {
        // 선언형 방식으로 에러 메시지 처리
        const errorMessage = (() => {
          const msg = response.message.message || '로그인에 실패했습니다.'
          return (msg === 'Authentication Fail' || msg.includes('Authentication Fail'))
            ? '아이디 및 비밀번호를 확인해주세요.'
            : msg
        })()
        
        toastStore.error(errorMessage)
        return false
      }
    } catch (err: any) {
      // 401 Unauthorized 에러 처리 - 선언형 방식
      if (err.response?.status === 401) {
        const errorMessage = (() => {
          const msg = err.response?.data?.message?.message || 
                     err.response?.data?.message ||
                     '로그인에 실패했습니다. 아이디와 비밀번호를 확인해주세요.'
          return (msg === 'Authentication Fail' || msg.includes('Authentication Fail'))
            ? '아이디 및 비밀번호를 확인해주세요.'
            : msg
        })()
        
        toastStore.error(errorMessage)
      } else {
        // 선언형 방식으로 에러 메시지 처리
        const errorMessage = (() => {
          const msg = err.response?.data?.message?.message || 
                     err.response?.data?.message || 
                     err.message || 
                     '로그인에 실패했습니다.'
          return (msg === 'Authentication Fail' || msg.includes('Authentication Fail'))
            ? '아이디 및 비밀번호를 확인해주세요.'
            : msg
        })()
        
        toastStore.error(errorMessage)
      }
      return false
    } finally {
      isLoading.value = false
    }
  }

  return {
    execute,
    isLoading
  }
}

