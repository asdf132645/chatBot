// 로그인 비즈니스 로직
import { ref } from 'vue'
import { login } from '~/shared/api/auth'
import type { LoginRequest, ApiResponse, LoginResponse } from '~/entities/user/types'
import { useAuthStore } from '~/stores/auth'
import { navigateTo } from '#app'

export const useLogin = () => {
  const isLoading = ref(false)
  const error = ref<string | null>(null)
  const authStore = useAuthStore()

  const execute = async (data: LoginRequest): Promise<boolean> => {
    isLoading.value = true
    error.value = null

    try {
      const response = await login(data)
      
      // API 응답 구조 변경에 따른 조건 수정
      if (response.message.httpStatus === '200 OK' && response.data) {
        // 스토어에 토큰 저장 (로그인 응답에는 user 정보가 없음)
        authStore.setTokens({
          accessToken: response.data.accessToken,
          refreshToken: response.data.refreshToken
        })
        
        return true
      } else {
        error.value = response.message.message || '로그인에 실패했습니다.'
        return false
      }
    } catch (err: any) {
      const errorMessage = err.response?.data?.message?.message || 
                         err.response?.data?.message || 
                         err.message || 
                         '로그인에 실패했습니다.'
      error.value = errorMessage
      return false
    } finally {
      isLoading.value = false
    }
  }

  return {
    execute,
    isLoading,
    error
  }
}

