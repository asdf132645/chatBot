// PortOne PASS 본인인증 composable
// REST API V2 방식으로 변경
import { ref } from 'vue'
import { startKycSession, verifyKyc } from '~/shared/api/auth'
import type { KycUsage, KycVerifyResponse } from '~/entities/user/types'

// Portone Store ID (Portone 콘솔에서 확인한 값)
const PORTONE_STORE_ID = 'store-f96143b6-7f41-4a9f-ab82-9a6cebf7babd'

// Portone Channel Key 또는 PG Provider (본인인증 채널 설정 필수)
// Portone 관리자 콘솔 > 결제 연동 > 채널 관리에서 확인
// channelKey 또는 pgProvider 중 하나는 반드시 필요합니다
const PORTONE_CHANNEL_KEY = import.meta.env.PORTONE_CHANNEL_KEY || ''
const PORTONE_PG_PROVIDER = import.meta.env.PORTONE_PG_PROVIDER || ''

// Portone SDK 타입 정의 (파일 최상위)
declare global {
  interface Window {
    PortOne?: {
      requestIdentityVerification: (request: {
        storeId: string
        identityVerificationId: string
      }) => Promise<{
        transactionType: 'IDENTITY_VERIFICATION'
        identityVerificationId: string
        identityVerificationTxId: string
        code?: string
        message?: string
        pgCode?: string
        pgMessage?: string
      } | undefined>
    }
  }
}

export const usePortoneCertification = () => {
  const isLoading = ref(false)
  const error = ref<string | null>(null)
  const impUid = ref<string | null>(null)
  const paymentId = ref<string | null>(null)
  const identityToken = ref<string | null>(null)
  const verification = ref<any>(null)

  /**
   * Portone SDK 로드 (CDN 방식)
   * 클라이언트에서 팝업을 띄우기 위해 필요
   */
  const loadPortoneSDK = (): Promise<typeof window.PortOne> => {
    return new Promise((resolve, reject) => {
      if (import.meta.server) {
        resolve(undefined)
        return
      }

      // 이미 로드되어 있는지 확인
      if (window.PortOne) {
        resolve(window.PortOne)
        return
      }

      // Portone SDK 스크립트 로드 (CDN)
      const script = document.createElement('script')
      script.src = 'https://cdn.portone.io/v2/browser-sdk.js'
      script.async = true
      script.onload = () => {
        if (window.PortOne) {
          resolve(window.PortOne)
        } else {
          reject(new Error('Portone SDK 로드 실패'))
        }
      }
      script.onerror = () => {
        reject(new Error('Portone SDK 스크립트 로드 실패'))
      }
      document.head.appendChild(script)
    })
  }

  /**
   * PASS 본인인증 요청
   * 1. 백엔드 KYC session API 호출하여 verificationId 받기
   * 2. 클라이언트에서 SDK로 팝업 띄우기
   * 3. 인증 완료 후 백엔드 KYC verify API 호출
   */
  const requestCertification = async (usage: KycUsage = 'SIGN_UP'): Promise<{ 
    imp_uid?: string
    paymentId?: string
    identityToken?: string
    verification?: any
  } | null> => {
    // 서버에서는 항상 null 반환
    if (import.meta.server) {
      return null
    }

    isLoading.value = true
    error.value = null
    impUid.value = null
    paymentId.value = null
    identityToken.value = null
    verification.value = null

    try {
      // 1. 백엔드 KYC session API 호출
      const redirectUrl = import.meta.client ? window.location.href : ''
      const sessionResponse = await startKycSession({
        usage,
        redirectUrl
      })

      if (sessionResponse.message.httpStatus !== '200 OK' || !sessionResponse.data) {
        const errorMessage = sessionResponse.message.message || '본인인증 세션 생성에 실패했습니다.'
        error.value = errorMessage
        console.error('❌ KYC 세션 생성 실패:', errorMessage)
        return null
      }

      const verificationId = sessionResponse.data.verificationId
      const authUrl = sessionResponse.data.authUrl

      console.log('✅ KYC 세션 생성 완료 - verificationId:', verificationId)

      // 2. Portone SDK 로드 (CDN) - 팝업을 띄우기 위해 필요
      const PortOne = await loadPortoneSDK()

      if (!PortOne || !PortOne.requestIdentityVerification) {
        throw new Error('Portone SDK를 사용할 수 없습니다.')
      }

      // 3. PASS 본인인증 요청 (팝업) - verificationId 사용
      // channelKey 또는 pgProvider 중 하나는 필수
      const requestParams: {
        storeId: string
        identityVerificationId: string
        channelKey?: string
        pgProvider?: string
      } = {
        storeId: PORTONE_STORE_ID,
        identityVerificationId: verificationId
      }
      
      // channelKey가 있으면 사용, 없으면 pgProvider 사용
      if (PORTONE_CHANNEL_KEY) {
        requestParams.channelKey = PORTONE_CHANNEL_KEY
      } else if (PORTONE_PG_PROVIDER) {
        requestParams.pgProvider = PORTONE_PG_PROVIDER
      } else {
        throw new Error('PORTONE_CHANNEL_KEY 또는 PORTONE_PG_PROVIDER 중 하나는 필수입니다. Portone 관리자 콘솔에서 확인해주세요.')
      }
      
      const sdkResult = await PortOne.requestIdentityVerification(requestParams)

      if (!sdkResult || !sdkResult.identityVerificationTxId) {
        const errorMessage = sdkResult?.message || sdkResult?.pgMessage || 'PASS 인증에 실패했습니다.'
        error.value = errorMessage
        console.error('❌ PASS 인증 실패:', errorMessage)
        return null
      }

      // 4. 백엔드 KYC verify API 호출
      const transactionId = sdkResult.identityVerificationTxId
      
      try {
        // 백엔드 KYC verify API 호출
        const kycResponse = await verifyKyc({
          verificationId,
          transactionId
        })
        
        if (kycResponse.message.httpStatus === '200 OK' && kycResponse.data) {
          // 인증 성공
          impUid.value = transactionId
          paymentId.value = verificationId
          identityToken.value = kycResponse.data.identityToken
          verification.value = kycResponse.data.verification

          console.log('✅ PASS 인증 성공 (백엔드 검증 완료)')
          console.log('verificationId:', verificationId)
          console.log('transactionId:', transactionId)
          console.log('identityToken:', kycResponse.data.identityToken)
          console.log('인증 결과:', kycResponse.data.verification)

          return {
            imp_uid: transactionId,
            paymentId: verificationId,
            identityToken: kycResponse.data.identityToken,
            verification: kycResponse.data.verification
          }
        } else {
          // 인증 실패
          const errorMessage = kycResponse.message.message || '본인인증 검증에 실패했습니다.'
          error.value = errorMessage
          console.error('❌ PASS 인증 검증 실패:', errorMessage)
          return null
        }
      } catch (apiError: any) {
        // 백엔드 API 호출 실패
        const errorMessage = apiError.response?.data?.message?.message || apiError.message || '본인인증 결과 조회 중 오류가 발생했습니다.'
        error.value = errorMessage
        console.error('❌ PASS 인증 결과 조회 실패:', apiError)
        return null
      }
    } catch (err: any) {
      const errorMessage = err.message || 'PASS 인증 중 오류가 발생했습니다.'
      error.value = errorMessage
      console.error('❌ PASS 인증 오류:', err)
      return null
    } finally {
      isLoading.value = false
    }
  }

  /**
   * 상태 초기화
   */
  const reset = () => {
    isLoading.value = false
    error.value = null
    impUid.value = null
    paymentId.value = null
    identityToken.value = null
    verification.value = null
  }

  return {
    requestCertification,
    isLoading,
    error,
    impUid,
    paymentId,
    identityToken,
    verification,
    reset
  }
}
