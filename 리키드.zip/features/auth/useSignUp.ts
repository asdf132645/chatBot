// 회원가입 비즈니스 로직
import { ref } from 'vue'
import { signUp } from '~/shared/api/auth'
import type { SignUpRequest, ApiResponse, SignUpResponse } from '~/entities/user/types'
import { useAuthStore } from '~/stores/auth'

export const useSignUp = () => {
  const isLoading = ref(false)
  const error = ref<string | null>(null)

  const execute = async (data: SignUpRequest): Promise<ApiResponse<SignUpResponse> | null> => {
    isLoading.value = true
    error.value = null

    try {
      const response = await signUp(data)
      
      if ((response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') && response.data) {
        return response
      } else {
        error.value = response.message.message
        return null
      }
    } catch (err: any) {
      const errorMessage = err.response?.data?.message?.message || '회원가입에 실패했습니다.'
      error.value = errorMessage
      return null
    } finally {
      isLoading.value = false
    }
  }

  return {
    execute,
    isLoading,
    error
  }
}

