// 토큰 재발급 비즈니스 로직
import { ref } from 'vue'
import { refreshToken } from '~/shared/api/auth'
import type { TokenRefreshRequest, ApiResponse, TokenRefreshResponse } from '~/entities/user/types'
import { useAuthStore } from '~/stores/auth'

export const useTokenRefresh = () => {
  const isLoading = ref(false)
  const error = ref<string | null>(null)
  const authStore = useAuthStore()

  const execute = async (refreshTokenValue: string): Promise<boolean> => {
    isLoading.value = true
    error.value = null

    try {
      const response = await refreshToken({ refreshToken: refreshTokenValue })
      
      // httpStatus가 "OK" 또는 "200 OK"인 경우 성공
      if ((response.message.httpStatus === 'OK' || response.message.httpStatus === '200 OK') && response.data) {
        // 스토어에 새 토큰 저장 (로그인 유지 옵션 유지)
        const keepLoggedIn = localStorage.getItem('access_token') !== null
        authStore.setTokens({
          accessToken: response.data.accessToken,
          refreshToken: response.data.refreshToken,
          keepLoggedIn
        })
        
        return true
      } else {
        error.value = response.message.message || '토큰 재발급에 실패했습니다.'
        return false
      }
    } catch (err: any) {
      const errorMessage = err.response?.data?.message?.message || 
                         err.response?.data?.message || 
                         err.message || 
                         '토큰 재발급에 실패했습니다.'
      error.value = errorMessage
      
      // 토큰 재발급 실패 시 로그아웃
      authStore.logout()
      
      return false
    } finally {
      isLoading.value = false
    }
  }

  return {
    execute,
    isLoading,
    error
  }
}

