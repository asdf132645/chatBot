// 토큰 재발급 비즈니스 로직
import { ref } from 'vue'
import { refreshToken } from '~/shared/api/auth'
import type { TokenRefreshRequest, ApiResponse, TokenRefreshResponse } from '~/entities/user/types'
import { useAuthStore } from '~/stores/auth'

export const useTokenRefresh = () => {
  const isLoading = ref(false)
  const error = ref<string | null>(null)
  const authStore = useAuthStore()

  const execute = async (refreshTokenValue: string): Promise<boolean> => {
    isLoading.value = true
    error.value = null

    try {
      const response = await refreshToken({ refreshToken: refreshTokenValue })
      
      // HTTP 상태 코드 또는 success 필드로 성공 여부 확인
      const isSuccess = response.message.httpStatus === '200 OK' || 
                       response.message.httpStatus === '200' ||
                       response.message.success === true ||
                       (response.data && response.data.accessToken && response.data.refreshToken)
      
      if (isSuccess && response.data) {
        // 스토어에 새 토큰 저장
        authStore.setTokens({
          accessToken: response.data.accessToken,
          refreshToken: response.data.refreshToken
        })
        
        return true
      } else {
        error.value = response.message.message || '토큰 재발급에 실패했습니다.'
        return false
      }
    } catch (err: any) {
      const errorMessage = err.response?.data?.message?.message || 
                         err.response?.data?.message || 
                         err.message || 
                         '토큰 재발급에 실패했습니다.'
      error.value = errorMessage
      
      // 토큰 재발급 실패 시 로그아웃
      authStore.logout()
      
      return false
    } finally {
      isLoading.value = false
    }
  }

  return {
    execute,
    isLoading,
    error
  }
}

