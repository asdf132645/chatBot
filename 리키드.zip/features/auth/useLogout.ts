// 로그아웃 비즈니스 로직
import { ref } from 'vue'
import { logout } from '~/shared/api/auth'
import { useAuthStore } from '~/stores/auth'
import { navigateTo } from '#app'

export const useLogout = () => {
  const isLoading = ref(false)
  const error = ref<string | null>(null)
  const authStore = useAuthStore()

  const execute = async (): Promise<boolean> => {
    isLoading.value = true
    error.value = null

    try {
      const response = await logout()
      
      if (response.message.httpStatus === '200 OK') {
        // 스토어에서 인증 정보 제거
        authStore.logout()
        
        // 메인 페이지로 이동
        await navigateTo('/')
        
        return true
      } else {
        error.value = response.message.message
        // 에러가 발생해도 로컬에서 로그아웃 처리
        authStore.logout()
        await navigateTo('/')
        return false
      }
    } catch (err: any) {
      // 에러가 발생해도 로컬에서 로그아웃 처리
      authStore.logout()
      await navigateTo('/')
      
      const errorMessage = err.response?.data?.message?.message || '로그아웃에 실패했습니다.'
      error.value = errorMessage
      return false
    } finally {
      isLoading.value = false
    }
  }

  return {
    execute,
    isLoading,
    error
  }
}

