// 로그아웃 비즈니스 로직
import { ref } from 'vue'
import { logout } from '~/shared/api/auth'
import { useAuthStore } from '~/stores/auth'
import { useToastStore } from '~/stores/toast'
import { navigateTo } from '#app'

export const useLogout = () => {
  const isLoading = ref(false)
  const authStore = useAuthStore()
  const toastStore = useToastStore()

  const execute = async (): Promise<boolean> => {
    isLoading.value = true

    try {
      const response = await logout()
      
      // httpStatus가 "OK", "200 OK", 또는 "CREATED"인 경우 성공
      if (response.message.httpStatus === 'OK' || 
          response.message.httpStatus === '200 OK' || 
          response.message.httpStatus === 'CREATED') {
        // 스토어에서 인증 정보 제거
        authStore.logout()
        
        toastStore.success('로그아웃 됐습니다.')
        
        // 메인 페이지로 이동
        await navigateTo('/')
        
        return true
      } else {
        const errorMessage = response.message.message || '로그아웃에 실패했습니다.'
        toastStore.error(errorMessage)
        // 에러가 발생해도 로컬에서 로그아웃 처리
        authStore.logout()
        await navigateTo('/')
        return false
      }
    } catch (err: any) {
      // 에러가 발생해도 로컬에서 로그아웃 처리
      authStore.logout()
      await navigateTo('/')
      
      const errorMessage = err.response?.data?.message?.message || '로그아웃에 실패했습니다.'
      toastStore.error(errorMessage)
      return false
    } finally {
      isLoading.value = false
    }
  }

  return {
    execute,
    isLoading
  }
}

