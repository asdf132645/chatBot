// PASS 인증 비즈니스 로직
import { ref } from 'vue'
import { startKycSession, verifyKyc } from '~/shared/api/auth'
import type {
  KycSessionRequest,
  KycVerifyRequest,
  ApiResponse,
  KycSessionResponse,
  KycVerifyResponse
} from '~/entities/user/types'

export const useKyc = () => {
  const isLoading = ref(false)
  const error = ref<string | null>(null)

  /**
   * PASS 인증 세션 시작
   */
  const startSession = async (data: KycSessionRequest): Promise<string | null> => {
    isLoading.value = true
    error.value = null

    try {
      const response = await startKycSession(data)
      
      if (response.message.success && response.data.authUrl) {
        return response.data.authUrl
      } else {
        error.value = response.message.message
        return null
      }
    } catch (err: any) {
      const errorMessage = err.response?.data?.message?.message || '인증 세션 시작에 실패했습니다.'
      error.value = errorMessage
      return null
    } finally {
      isLoading.value = false
    }
  }

  /**
   * PASS 결과 검증
   */
  const verify = async (data: KycVerifyRequest): Promise<ApiResponse<KycVerifyResponse> | null> => {
    isLoading.value = true
    error.value = null

    try {
      const response = await verifyKyc(data)
      
      if (response.message.success) {
        return response
      } else {
        error.value = response.message.message
        return null
      }
    } catch (err: any) {
      const errorMessage = err.response?.data?.message?.message || '인증 검증에 실패했습니다.'
      error.value = errorMessage
      return null
    } finally {
      isLoading.value = false
    }
  }

  return {
    startSession,
    verify,
    isLoading,
    error
  }
}

