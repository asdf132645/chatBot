<template>
  <form :class="styles.loginForm" @submit.prevent="handleSubmit">
    <div :class="styles.loginForm__row">
      <input
        v-model="form.username"
        type="text"
        :class="styles.loginForm__input"
        placeholder="아이디를 입력하세요"
        required
      />
    </div>
    <div :class="styles.loginForm__row">
      <input
        v-model="form.password"
        type="password"
        :class="styles.loginForm__input"
        placeholder="비밀번호를 입력하세요"
        required
      />
    </div>
    <div :class="styles.loginForm__options">
      <label :class="styles.loginForm__checkboxLabel">
        <input
          v-model="form.keepLoggedIn"
          type="checkbox"
          :class="styles.loginForm__checkbox"
        />
        <span>로그인 유지</span>
      </label>
      <NuxtLink to="/find-account" :class="styles.loginForm__link">
        아이디·비밀번호 찾기
      </NuxtLink>
    </div>
    <button 
      type="submit" 
      :class="styles.loginForm__submitButton"
      :disabled="isLoading"
    >
      {{ isLoading ? '로그인 중...' : '로그인' }}
    </button>
    <p v-if="error" :class="styles.loginForm__error">
      {{ error }}
    </p>
    <div :class="styles.loginForm__signup">
      <span>아직 회원이 아니신가요? </span>
      <NuxtLink to="/signup" :class="styles.loginForm__signupLink">회원가입</NuxtLink>
    </div>
  </form>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useLogin } from '~/features/auth'
import styles from '~/styles/features/LoginForm.module.css'

const router = useRouter()
const { execute: login, isLoading, error } = useLogin()

const form = ref({
  username: '',
  password: '',
  keepLoggedIn: false
})

const handleSubmit = async () => {
  if (!form.value.username || !form.value.password) {
    return
  }
  
  const success = await login({
    loginId: form.value.username,
    password: form.value.password
  })
  
  if (success) {
    // 로그인 성공 시 메인 페이지로 이동
    router.push('/')
  }
}
</script>

