<template>
  <section :class="styles.comingSoon">
    <Container>
      <div :class="styles.comingSoon__banner">
        <div :class="styles.comingSoon__text">
          <h2 :class="styles.comingSoon__heading">COMING SOON</h2>
          <div :class="styles.comingSoon__description">
            <p>리키드의 도시에는 작은 동네가 있고, 그 벽은 모두의 이야기로 채워집니다</p>
            <p>NFT 보유자는 그 벽 위에 지금의 낙서 한 줄을 남길 수 있으며, 그 흔적은 도시의 역사로 함께 기록됩니다</p>
          </div>
        </div>
        <div :class="styles.comingSoon__watermark">LIKID</div>
      </div>
    </Container>
  </section>
</template>

<script setup lang="ts">
import { Container } from '@/components/ui'
import styles from '~/styles/features/ComingSoonSection.module.css'
</script>
