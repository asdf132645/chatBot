(async () => {
  const fs = require('fs-extra');
  const path = require('path');
  const glob = require('glob');
  const { parse } = require('@vue/compiler-sfc');
  const recast = require('recast');
  const babelParser = require('@babel/parser');

  const langDir = path.resolve(__dirname, 'src/lang');
  const locales = ['ko', 'en', 'ja', 'zh', 'indo'];
  const vueFiles = glob.sync('src/**/*.{vue,js}', { nodir: true });

  let messages = {};
  locales.forEach(locale => {
    const filePath = path.join(langDir, `${locale}.json`);
    try {
      const raw = fs.readFileSync(filePath, 'utf-8');
      messages[locale] = JSON.parse(raw || '{}');
    } catch {
      messages[locale] = {};
    }
  });

  const hasHangul = (text) => /[\uAC00-\uD7A3]/.test(text);
  const isValidText = (text) =>
    hasHangul(text) &&
    text.length <= 120 &&
    !text.includes('$t(') &&
    !text.includes('require') &&
    !text.includes('{{') &&
    !text.includes('0"') &&
    !/^<\s*(template|script|style|div|span|p|ul|li|section|header|footer)\b/.test(text) &&
    !/session\..*?[가-힣]/.test(text); // v-if="session.abc > 공유" 같은 상황 방어

  const asyncReplace = async (str, regex, asyncFn) => {
    const matches = [...str.matchAll(regex)];
    const replacements = await Promise.all(matches.map(m => asyncFn(...m)));
    let result = '';
    let lastIndex = 0;
    matches.forEach((m, i) => {
      result += str.slice(lastIndex, m.index) + replacements[i];
      lastIndex = m.index + m[0].length;
    });
    result += str.slice(lastIndex);
    return result;
  };

  const addMessage = async (filename, usedKeys, text) => {
    const cleaned = text.replace(/\n/g, '<br/>').trim();

    if (cleaned.includes('><') || cleaned.includes('0"')) {
      return ''; // 이상한 텍스트는 아예 무시
    }


    const block = messages.ko[filename] || {};
    for (const [k, v] of Object.entries(block)) {
      if (v === cleaned) return `${filename}.${k}`;
    }

    let i = 1;
    let key = `${filename}_key${i}`;
    while (block[key]) i++, key = `${filename}_key${i}`;

    locales.forEach(locale => {
      if (!messages[locale][filename]) messages[locale][filename] = {};
      messages[locale][filename][key] = cleaned;
    });

    return `${filename}.${key}`;
  };

  for (const file of vueFiles) {
    let content = fs.readFileSync(file, 'utf-8');
    const { descriptor } = parse(content);
    let updated = content;
    const filename = path.basename(file, path.extname(file)).toLowerCase();
    const usedKeys = Object.keys(messages.ko[filename] || {});

    if (descriptor.template) {

      let raw = descriptor.template.content;

      // 여러 줄 <br/> 한글 묶어서 처리
      raw = await asyncReplace(
        raw,
        /<([\w-]+)([^>]*)>([\s\S]*?)<\/\1>/g,
        async (match, tag, attrs, inner) => {
          const lines = inner.split(/<br\s*\/?>/).map(x => x.trim());
          const validLines = lines.filter(x => isValidText(x));
          if (validLines.length >= 2 && validLines.length <= 10) {
            const combined = validLines.join('<br/>');
            const key = await addMessage(filename, usedKeys, combined);
            return `<${tag}${attrs} v-html="$t('${key}')"></${tag}>`;
          }
          return match;
        }
      );

      // 태그 닫힌 후 텍스트 존재하는 경우: </span> 텍스트
      raw = await asyncReplace(
        raw,
        /<\/([\w-]+)>\s*([가-힣][^<>\n]+?)\s*(?=<|$)/g,
        async (match, tag, text) => {
          if (isValidText(text)) {
            const key = await addMessage(filename, usedKeys, text.trim());
            return `</${tag}>{{ $t('${key}') }}`;
          }
          return match;
        }
      );

      // <태그>텍스트1<br/>텍스트2</태그>
      raw = await asyncReplace(
        raw,
        /<([\w-]+)([^>]*)>([^<>]*?[가-힣][^<>]*?)<br\s*\/?>\s*([^<>]*?[가-힣][^<>]*?)<\/\1>/gs,
        async (match, tag, attrs, a, b) => {
          const combined = `${a.trim()}<br/>${b.trim()}`;
          if (isValidText(combined)) {
            const key = await addMessage(filename, usedKeys, combined);
            return `<${tag}${attrs} v-html="$t('${key}')"></${tag}>`;
          }
          return match;
        }
      );

      // BaseIcon이 있어도 텍스트만 골라서 처리
      raw = await asyncReplace(
        raw,
        /<([\w-]+)([^>]*)>((?:(?!<\/\1>).)*?[가-힣]+(?:(?!<\/\1>).)*?)<\/\1>/gs,
        async (match, tag, attrs, inner) => {
          const textOnly = inner.replace(/<BaseIcon[^>]*\/?>/g, '').trim();
          if (isValidText(textOnly)) {
            const key = await addMessage(filename, usedKeys, textOnly);
            return `<${tag}${attrs}>{{ $t('${key}') }} ${inner.includes('<BaseIcon') ? inner.match(/<BaseIcon[^>]*\/?>/g).join(' ') : ''}</${tag}>`;
          }
          return match;
        }
      );

// <태그><BaseIcon />텍스트</태그> or <태그>텍스트<BaseIcon /></태그> — 모든 태그에 적용
//       raw = await asyncReplace(
//         raw,
//         /<([\w-]+)([^>]*)>\s*(<BaseIcon[^>]*\/?>)?\s*([^<>{}"'=]{1,50}?[가-힣]+[^<>{}"'=]{0,50}?)\s*(<BaseIcon[^>]*\/?>)?\s*<\/\1>/g,
//         async (match, tag, attrs, iconBefore, text, iconAfter) => {
//           // 💥 여기 조건을 강화해서 디렉티브 포함 태그는 아예 skip
//           const hasDirective = /v-(if|for|model|bind|show|on)=["'][^"']*["']/.test(attrs);
//           const hasDynamicBind = /\s:\w+=["'][^"']*["']/.test(attrs);
//           const hasComparisonOps = /[><=]/.test(attrs);
//           const hasQuoteInText = /[\"']/.test(text); // <<< 여기가 핵심. text 안에 따옴표 있는 건 무조건 거름
//
//           if (hasDirective || hasDynamicBind || hasComparisonOps || hasQuoteInText) {
//             return match;
//           }
//
//           if (!isValidText(text)) return match;
//
//           const key = await addMessage(filename, usedKeys, text.trim());
//           return `<${tag}${attrs}>${iconBefore || ''} {{ $t('${key}') }} ${iconAfter || ''}</${tag}>`;
//         }
//       );



      // <태그>텍스트<BaseIcon/></태그> or <태그><BaseIcon/>텍스트</태그>
      raw = await asyncReplace(
        raw,
        /<([\w-]+)([^>]*)>((?:[^<>]*?)?)([가-힣]+)((?:[^<>]*?)?)<\/\1>/g,
        async (match, tag, attrs, before, text, after) => {
          //  디렉티브 내부에 한글 들어간 경우는 절대 건드리지 않음
          if (
            /v-(if|show|model|for|else-if)=["'][^"']*?[가-힣]+[^"']*?["']/.test(attrs)
          ) return match;

          //  BaseIcon이나 컴포넌트가 섞인 경우도 제외
          if (before.includes('<') || after.includes('<')) return match;

          const fullText = `${before}${text}${after}`.trim();
          if (isValidText(fullText)) {
            const key = await addMessage(filename, usedKeys, fullText);
            return `<${tag}${attrs}>{{ $t('${key}') }}</${tag}>`;
          }
          return match;
        }
      );


      // BaseIcon 포함 태그에서 텍스트만 추출 + BaseIcon 순서 고정 유지 (안전버전)
      raw = await asyncReplace(
        raw,
        /<([\w-]+)([^>]*)>([^<]*?)\s*(<BaseIcon[^>]*\/?>)\s*<\/\1>/g,
        async (match, tag, attrs, text, icon) => {
          if (isValidText(text.trim())) {
            const key = await addMessage(filename, usedKeys, text.trim());
            return `<${tag}${attrs}>{{ $t('${key}') }} ${icon}</${tag}>`;
          }
          return match;
        }
      );

      // BaseIcon 앞에 텍스트 있는 경우 변환 (아이콘은 유지)
      raw = await asyncReplace(
        raw,
        /<([\w-]+)([^>]*)>\s*(<BaseIcon[^>]*\/?>)\s*([^<]+?)\s*<\/\1>/g,
        async (match, tag, attrs, icon, text) => {
          if (isValidText(text.trim())) {
            const key = await addMessage(filename, usedKeys, text.trim());
            return `<${tag}${attrs}>${icon} {{ $t('${key}') }}</${tag}>`;
          }
          return match;
        }
      );

      // v-if, v-for, v-model 같은 디렉티브에 한글이 들어간 경우는 건드리지 않도록 방어
      raw = await asyncReplace(
        raw,
        /<([\w-]+)([^>]*)>/g,
        async (match, tagName, attrs) => {
          if (
            /v-(if|for|model|show|bind)=["'][^"']*?[가-힣]+[^"']*?["']/.test(attrs) ||
            /["'][^"']*{{[^}]+}}[^"']*["']/.test(attrs) ||
            /v-if=["'][^"']*\$t\([^)]*\)[^"']*["']/.test(attrs)
          ) {
            return match; // 디렉티브에 {{}} 섞인 한글은 무조건 건너뜀
          }
          return match;
        }
      );



      // 속성(title, okBtnName 등)에 한글 있을 때만 변환, BUT 닫힘 태그가 있는 경우에만 적용
      raw = await asyncReplace(
        raw,
        /<([\w-]+)((?:.|\n)*?)(?<!\/)>/g,
        async (match, tagName, attrs) => {
          //  닫는 태그 없는 경우(<img />, <input />, <BaseIcon /> 등) 스킵
          const selfClose = /\/\s*>$/.test(match) || /<\s*BaseIcon\b/.test(match);
          if (selfClose) return match;

          let newAttrs = attrs;
          const targets = ['title', 'placeholder', 'aria-label', 'alt', 'label', 'text', 'okBtnName', 'cancelBtnName'];

          for (const attr of targets) {
            const attrRegex = new RegExp(`${attr}=["']([^"']*?[가-힣][^"']*?)["']`);
            const matchAttr = newAttrs.match(attrRegex);
            if (matchAttr && isValidText(matchAttr[1])) {
              const key = await addMessage(filename, usedKeys, matchAttr[1].trim());
              newAttrs = newAttrs.replace(attrRegex, `:${attr}="$t('${key}')"`);
            }
          }

          return `<${tagName}${newAttrs}>`;
        }
      );







      updated = updated.replace(descriptor.template.content, raw);
    }

    const transformScript = async (script, isSetup) => {
      const b = recast.types.builders;
      const ast = recast.parse(script, {
        parser: {
          parse: src => babelParser.parse(src, {
            sourceType: 'module',
            plugins: ['typescript', 'jsx', 'decorators-legacy']
          })
        }
      });

      const literalPaths = [];
      recast.types.visit(ast, {
        visitCallExpression(path) {
          // console.log(...) 체크
          const callee = path.node.callee;
          const isConsoleLog =
            callee.type === 'MemberExpression' &&
            callee.object.name === 'console' &&
            callee.property.name === 'log';

          if (isConsoleLog) {
            // log 내부 문자열은 무시
            return false;
          }

          this.traverse(path);
        },
        visitLiteral(path) {
          if (
            typeof path.node.value === 'string' &&
            isValidText(path.node.value)
          ) {
            literalPaths.push(path);
          }
          this.traverse(path);
        }
      });


      for (const path of literalPaths) {
        const val = path.node.value;
        const key = await addMessage(filename, usedKeys, val);
        const callee = isSetup
          ? b.identifier('t')
          : b.memberExpression(b.thisExpression(), b.identifier('$t'));
        path.replace(b.callExpression(callee, [b.literal(key)]));
      }

      let transformed = recast.print(ast).code;
      if (isSetup && transformed.includes('t(')) {
        if (!/useI18n/.test(transformed)) {
          transformed = `import { useI18n } from 'vue-i18n';\n${transformed}`;
        }
        if (!/const\s+{[^}]*t[^}]*}\s*=\s*useI18n\(\)/.test(transformed)) {
          transformed = transformed.replace(/(import[^;]+;)/, `$1\nconst { t } = useI18n();`);
        }
      }

      return transformed;
    };

    if (descriptor.scriptSetup) {
      const original = descriptor.scriptSetup.content;
      const transformed = await transformScript(original, true);
      updated = updated.replace(
        /<script setup[^>]*>[\s\S]*?<\/script>/,
        `<script setup>\n${transformed.trim()}\n</script>`
      );
    }

    if (descriptor.script && descriptor.script.content) {
      const original = descriptor.script.content;
      const transformed = await transformScript(original, false);
      updated = updated.replace(
        /<script[^>]*>[\s\S]*?<\/script>/,
        `<script>\n${transformed.trim()}\n</script>`
      );
    }

    if (updated !== content) {
      fs.writeFileSync(file, updated, 'utf-8');
      console.log(`업데이트됨: ${file}`);
    }
  }

  locales.forEach(locale => {
    const filePath = path.join(langDir, `${locale}.json`);
    fs.ensureFileSync(filePath);
    fs.writeFileSync(filePath, JSON.stringify(messages[locale], null, 2), 'utf-8');
  });

  console.log('다국어 저장 완료');
})();
