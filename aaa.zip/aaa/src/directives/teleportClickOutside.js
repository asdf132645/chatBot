const teleportClickOutsideDirective  = {
    beforeMount(el, binding) {
      el.clickOutsideHandler = (event) => {
        // teleport된 DOM 노드와 바인딩된 함수에 대해 클릭 감지
        const teleportNode = document.getElementById(binding.arg); // ID에 맞게 수정
        if (
          !(el.contains(event.target) || teleportNode?.contains(event.target))
        ) {
          binding.value(event);
        }
      };
      document.addEventListener('click', el.clickOutsideHandler);
    },
    unmounted(el) {
      document.removeEventListener('click', el.clickOutsideHandler);
    },
  };
  
  export default teleportClickOutsideDirective ;