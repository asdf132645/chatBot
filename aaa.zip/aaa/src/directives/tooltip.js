// directives/tooltip.js
function createTooltip(el, binding) {
  const options = typeof binding.value === 'string'
    ? { text: binding.value }
    : binding.value || {};

  const tooltipText = options.text || '';
  const delay = options.delay || 0;
  const placement = options.placement || 'top';

  if (!tooltipText) return;

  const tooltip = document.createElement('div');
  tooltip.className = 'custom-tooltip';
  tooltip.textContent = tooltipText;
  document.body.appendChild(tooltip);
  el._tooltipElement = tooltip;

  let timeout;

  const showTooltip = () => {
    timeout = setTimeout(() => {
      tooltip.classList.add('show');

      const rect = el.getBoundingClientRect();
      const scrollX = window.scrollX;
      const scrollY = window.scrollY;

      const { offsetWidth: tipWidth, offsetHeight: tipHeight } = tooltip;
      let top = 0, left = 0;

      switch (placement) {
        case 'bottom':
          top = rect.bottom + 8 + scrollY;
          left = rect.left + rect.width / 2 - tipWidth / 2 + scrollX;
          break;
        case 'left':
          top = rect.top + rect.height / 2 - tipHeight / 2 + scrollY;
          left = rect.left - tipWidth - 8 + scrollX;
          break;
        case 'right':
          top = rect.top + rect.height / 2 - tipHeight / 2 + scrollY;
          left = rect.right + 8 + scrollX;
          break;
        case 'top':
        default:
          top = rect.top - tipHeight - 8 + scrollY;
          left = rect.left + rect.width / 2 - tipWidth / 2 + scrollX;
      }

      tooltip.style.top = `${top}px`;
      tooltip.style.left = `${left}px`;
    }, delay);
  };

  const hideTooltip = () => {
    clearTimeout(timeout);
    tooltip.classList.remove('show');
  };

  el._showTooltip = showTooltip;
  el._hideTooltip = hideTooltip;

  el.addEventListener('mouseenter', showTooltip);
  el.addEventListener('mouseleave', hideTooltip);
}

function destroyTooltip(el) {
  if (el._tooltipElement) {
    el.removeEventListener('mouseenter', el._showTooltip);
    el.removeEventListener('mouseleave', el._hideTooltip);
    document.body.removeChild(el._tooltipElement);
    delete el._tooltipElement;
    delete el._showTooltip;
    delete el._hideTooltip;
  }
}

export default {
  mounted(el, binding) {
    createTooltip(el, binding);
  },
  updated(el, binding) {
    destroyTooltip(el);
    createTooltip(el, binding);
  },
  unmounted(el) {
    destroyTooltip(el);
  }
};
