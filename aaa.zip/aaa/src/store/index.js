import { createStore } from 'vuex';
import GlobalConstants from '@/constants';
import { CustomUISetting } from '@/util/customUISetting';
import docsBridge from '@/domains/docsChat/application/docsBridge.store';

// Create a new store instance.
const store = createStore({
  modules: {
    docsBridge,          // 라우트 브릿지 모듈 등록
  },
  state() {
    return {
      loginUser: {
        // Login User Info
        siteCd: '',
        userNm: '',
        userId: '',
        userEmail: '',
        curCmpnId: '',
        curCmpnNm: '',
        sub_domain: '',          // Sub doamin
      },
      newChat: {
        flag: false,
        message: '',
      },
      session: {
        id: '',
        convList: [],
        answerList: [],
        convId: '',
        searchType: '',
        shareType: '',
        chatbotCode: '',
        promptId: '',
      },
      ACCESS_TOKEN_KEY: GlobalConstants.ACCESS_TOKEN,
      isFileLoading: false,
      showDocsAnswer: '',
      isAdmin: false, // 전체 관리자 여부 - 권한 관리 페이지 보여짐,
      selectedTab: 'FileTabMangeWrapper', // 파일관리자 탭
      fileGroupType: 'corp', // 전사인지 부서인지 구분
      showWelcome: true,
      userChatbot: new CustomUISetting(),
      checkLogin: false,
      isChatSending: false, // 현재 채팅을 보내고 있는지 아닌지 판단하는 전역 변수
      docsType: {},
      multiAnswer: false,
    };
  },
  getters: {
    loginUser(state) {
      return state.loginUser;
    },
    newChat(state) {
      return state.newChat;
    },
    checkLogin(state) {
      return state.checkLogin;
    },
    getIsFileLoading(state) {
      return state.isFileLoading;
    },
    getShowDocsAnswer(state) {
      return state.showDocsAnswer;
    },
    getDocsType(state) {
      return state.docsType;
    },
    userChatbot(state) {
      return state.userChatbot;
    },
    multiAnswer: (state) => state.multiAnswer,
    showWelcome: (state) => state.showWelcome,
    session: (state) => state.session,
    selectedTab: (state) => state.selectedTab,
    isChatSending: (state) => state.isChatSending,
  },
  mutations: {
    setLoginUser(state, loginUser) {
      state.loginUser = loginUser;
    },
    setNewChat(state, newChat) {
      state.newChat = newChat;
    },
    setIsAdmin(state, isAdmin) {
      state.isAdmin = isAdmin;
    },
    setTokenKey(state, tokenKey) {
      state.ACCESS_TOKEN_KEY = tokenKey;
    },
    setUserChatbot(state, userChatbot) {
      state.userChatbot = userChatbot;
    },
    setIsFileLoading(state, isFileLoading) {
      state.isFileLoading = isFileLoading;
    },
    setMultiAnswer(state, multiAnswer) {
      state.multiAnswer = multiAnswer;
    },
    setSubDomain(state, subDomain) {
      state.sub_domain = subDomain;
    },
    setSelectedTab(state, tabName) {
      state.selectedTab = tabName; // 탭 변경
    },
    setShowWelcome(state, showWelcome) {
      state.showWelcome = showWelcome; // 탭 변경
    },
    setShowDocsAnswer(state, showDocsAnswer) {
      state.showDocsAnswer = showDocsAnswer;
    },
    setSession(state, session) {
      state.session = session; // 탭 변경
    },
    setFileGroupType(state, type) {
      state.fileGroupType = type;
    },
    setCheckLogin(state, checkLogin) {
      state.checkLogin = checkLogin;
    },
    setIsChatSending(state, isChatSending) {
      state.isChatSending = isChatSending;
    },
    setDocsType(state, type) {
      state.docsType = type;
    },
  },
});

// vuex 추출 (main.js에서 import)
export { store };
