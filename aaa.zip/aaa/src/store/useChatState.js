import { reactive } from 'vue';

const state = reactive({
  session: null,
  answerWrapper: [],
  isWaiting: false,
});

export function useChatState() {
  function getSession() {
    return state.session;
  }

  function setSession(session) {
    state.session = session;
  }

  function setWaiting(isWaiting) {
    state.isWaiting = isWaiting;
  }

  function pushAnswer(chat) {
    state.answerWrapper.push(chat);
  }


  return {
    state,
    getSession,
    setSession,
    setWaiting,
    pushAnswer,
  };
}
