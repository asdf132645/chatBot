<template>
<svg :width="size" :height="size" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M17.2777 13.8896C17.9524 13.8896 18.5188 14.4465 18.4156 15.1128C17.8103 19.0328 14.4545 21.9433 10.4072 21.9433C5.92928 21.9433 2.2998 18.3138 2.2998 13.837C2.2998 10.1486 5.10191 6.71279 8.25665 5.93595C8.93454 5.76858 9.62928 6.24542 9.62928 6.94332C9.62928 11.6717 9.78823 12.8949 10.6861 13.5602C11.584 14.2254 12.6398 13.8896 17.2777 13.8896Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M21.6921 9.95121C21.7458 6.91331 18.0142 2.01647 13.4669 2.10068C13.1132 2.107 12.83 2.40173 12.8142 2.75437C12.6995 5.25226 12.8542 8.4891 12.9406 9.95647C12.9669 10.4133 13.3258 10.7723 13.7816 10.7986C15.29 10.8849 18.6448 11.0028 21.1069 10.6302C21.4416 10.5796 21.6869 10.2891 21.6921 9.95121Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
</template>
<script>
export default { 
    name: 'ChartIcon',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
