<template>
    <svg :width="size" :height="size" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M12.2744 19.75V4.75" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M6.25 13.7012L12.275 19.7512M12.275 19.7512L18.299 13.7012" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
   
</template>
<script>
export default { 
    name: 'SearchArrowDownIcon',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
