<template>
  <svg :width="size" :height="size" viewBox="0 0 24 24" fill="none">
    <circle cx="12" cy="12" r="12" fill="#3AD06A" />
    <path d="M7 12l3 3 7-7" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
  </svg>
</template>
<script setup>
import { defineProps } from 'vue'
defineProps({ size: { type: Number, default: 24 } })
</script>