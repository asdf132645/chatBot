<template>
   <svg :width="size" :height="size" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M18.154 4.45556V0H2.81474C1.26554 0 0 1.32222 0 2.94444V21.0556C0 22.6778 1.26554 24 2.81474 24H21.176C22.7361 24 23.9908 22.6778 23.9908 21.0556V6.23333H19.8341C18.8959 6.23333 18.1322 5.43333 18.1322 4.45556H18.154Z" fill="#1D6D43"/>
    <path d="M18.1441 4.45556C18.1441 5.43333 18.9074 6.23333 19.8452 6.23333H24L18.1441 0V4.45556Z" fill="#E0F4E9"/>
    <path d="M9 16V7H14.9826V8.54687H10.8505V10.7266H14.6734V12.269H10.8505V14.4531H15V16H9Z" fill="white"/>
    </svg>
</template>
<script>
export default { 
    name: 'CsvIcon',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
