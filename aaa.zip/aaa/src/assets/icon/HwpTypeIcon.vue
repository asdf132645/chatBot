<template>
<svg :width="size" :height="size" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect :width="size" :height="size" rx="4" fill="#E8F5E8"/>    
<path d="M20.1027 10.9704V8H9.8765C8.8437 8 8 8.88148 8 9.96296V22.037C8 23.1185 8.8437 24 9.8765 24H22.1174C23.1574 24 23.9939 23.1185 23.9939 22.037V12.1556H21.2227C20.5973 12.1556 20.0881 11.6222 20.0881 10.9704H20.1027Z" fill="#4CAF50"/>
<path d="M20.096 10.9704C20.096 11.6222 20.6049 12.1556 21.2302 12.1556H24L20.096 8V10.9704Z" fill="#81C784"/>
<path d="M12.5 19.3333H11.5V13.3333H12.5V19.3333ZM15.5 19.3333H14.5V13.3333H15.5V19.3333ZM18.5 19.3333H17.5V13.3333H18.5V19.3333ZM12.5 16.3333H18.5V15.3333H12.5V16.3333Z" fill="white"/>
</svg>
</template>
<script>
export default { 
    name: 'HwpTypeIcon',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
