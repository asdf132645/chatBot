<template>
  <svg :width="size" :height="size" viewBox="0 0 24 24" fill="none">
    <circle cx="12" cy="12" r="12" fill="#EF4E4E" />
    <path d="M12 7v5" stroke="white" stroke-width="2" stroke-linecap="round" />
    <circle cx="12" cy="16" r="1.5" fill="white" />
  </svg>
</template>
<script setup>
import { defineProps } from 'vue'
defineProps({ size: { type: Number, default: 24 } })
</script>
