<template>
    <svg class="stroke" :width="size" :height="size" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="11.7669" cy="11.7659" r="8.98856" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M18.0186 18.4844L21.5426 21.9992" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
</template>
<script>
export default { 
    name: 'SearchIcon',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
