<template><svg class="stroke" :width="size" :height="size" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10.1729 16.6285H6.93784" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M13.7979 7.37072H6.93772" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M17.0811 12.0387H6.93833" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M22 16.6857V7.31429C22 4.04762 19.6879 2 16.4148 2H7.58516C4.31208 2 2 4.0381 2 7.31429V16.6857C2 19.9619 4.31208 22 7.58516 22H16.4148C19.6879 22 22 19.9619 22 16.6857Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
</template>
<script>
export default { 
    name: 'PaperIcon',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
Edit