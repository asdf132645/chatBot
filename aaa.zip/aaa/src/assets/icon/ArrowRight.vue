<template>
    <svg :width="size" :height="size" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M8.43451 5.43353C8.74693 5.12111 9.25346 5.12111 9.56588 5.43353L15.5659 11.4335C15.8783 11.746 15.8783 12.2525 15.5659 12.5649L9.56588 18.5649C9.25346 18.8773 8.74693 18.8773 8.43451 18.5649C8.12209 18.2525 8.12209 17.746 8.43451 17.4335L13.8688 11.9992L8.43451 6.5649C8.12209 6.25248 8.12209 5.74595 8.43451 5.43353Z" fill="currentColor"/>
    </svg>
</template>
<script>
export default { 
    name: 'ArrowRight',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
