<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="icon"
  >
    <path
      d="M6 2h9l5 5v15a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <polyline
      points="15 2 15 7 20 7"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <text
      x="12"
      y="17"
      text-anchor="middle"
      font-size="5"
      font-family="Arial, sans-serif"
      fill="currentColor"
    >JPG</text>
  </svg>
</template>

<script>
export default {
  name: "JpgIcon",
  props: {
    size: { type: Number, default: 24 },
  },
};
</script>

<style scoped>
.icon {
  display: block;
}
</style>
