<template>
  <svg :width="size" :height="size" viewBox="0 0 24 24" fill="none">
    <path d="M4 4v5h5" stroke="#333" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
    <path d="M20 20v-5h-5" stroke="#333" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
    <path d="M4 9a9 9 0 0 1 16 0M20 15a9 9 0 0 1-16 0" stroke="#333" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
  </svg>
</template>
<script setup>
import { defineProps } from 'vue'
defineProps({ size: { type: Number, default: 24 } })
</script>