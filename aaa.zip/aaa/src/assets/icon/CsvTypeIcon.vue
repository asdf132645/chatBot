<template>
<svg :width="size" :height="size" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect :width="size" :height="size" rx="4" fill="white"/>
<rect :width="size" :height="size" rx="4" fill="#E9F3EA"/>
<path d="M20.1027 10.9704V8H9.8765C8.8437 8 8 8.88148 8 9.96296V22.037C8 23.1185 8.8437 24 9.8765 24H22.1174C23.1574 24 23.9939 23.1185 23.9939 22.037V12.1556H21.2227C20.5972 12.1556 20.0881 11.6222 20.0881 10.9704H20.1027Z" fill="#1D6D43"/>
<path d="M20.096 10.9704C20.096 11.6222 20.6049 12.1556 21.2302 12.1556H24L20.096 8V10.9704Z" fill="#E0F4E9"/>
<path d="M14 18.6667V12.6667H17.9884V13.6979H15.2337V15.151H17.7823V16.1794H15.2337V17.6354H18V18.6667H14Z" fill="white"/>
</svg>
</template>
<script>
export default { 
    name: 'CsvTypeIcon',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
