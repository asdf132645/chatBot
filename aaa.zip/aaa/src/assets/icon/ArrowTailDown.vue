<template>
    <svg :width="size" :height="size" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M11.7256 4.25L11.7256 19.25" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M5.701 10.3008L11.725 4.25078L17.75 10.3008" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
</template>
<script>
export default { 
    name: 'ArrowTailDown',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
