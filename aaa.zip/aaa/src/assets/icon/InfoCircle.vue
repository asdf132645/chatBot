<template>
    <svg class="stroke" :width="size" :height="size" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M2 12C2 6.481 6.48 2 12 2C17.53 2 22 6.481 22 12C22 17.521 17.53 22 12 22C6.48 22 2 17.521 2 12ZM11.12 8.21C11.12 7.731 11.52 7.33 12 7.33C12.48 7.33 12.87 7.731 12.87 8.21V12.63C12.87 13.111 12.48 13.5 12 13.5C11.52 13.5 11.12 13.111 11.12 12.63V8.21ZM12.01 16.681C11.52 16.681 11.13 16.281 11.13 15.801C11.13 15.321 11.52 14.931 12 14.931C12.49 14.931 12.88 15.321 12.88 15.801C12.88 16.281 12.49 16.681 12.01 16.681Z" fill="currentColor"/>
</svg>

</template>
<script>
export default { 
    name: 'InfoCircle',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
