<template>
  <svg width="10" height="6" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M5 0L0.669873 6H9.33013L5 0Z" fill="currentColor" />
  </svg>
</template>

<script>
export default {
  name: 'ArrowFullUp',
  props: {
    size: {
      type: Number,
      default: 24 // 현재 안 쓰지만 통일성을 위해 유지
    }
  }
}
</script>
