<template>
    <svg :width="size" :height="size" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M15.5655 18.5665C15.2531 18.8789 14.7465 18.8789 14.4341 18.5665L8.43412 12.5665C8.1217 12.254 8.1217 11.7475 8.43412 11.4351L14.4341 5.4351C14.7465 5.12268 15.2531 5.12268 15.5655 5.4351C15.8779 5.74751 15.8779 6.25405 15.5655 6.56647L10.1312 12.0008L15.5655 17.4351C15.8779 17.7475 15.8779 18.254 15.5655 18.5665Z" fill="currentColor"/>
    </svg>
</template>
<script>
export default { 
    name: 'ArrowLeft',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
