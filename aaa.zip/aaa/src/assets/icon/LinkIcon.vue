<template>
<svg :width="size" :height="size+1" class="stroke" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M9.5 8.5H7C4.79086 8.5 3 10.2909 3 12.5C3 14.7091 4.79086 16.5 7 16.5H9.5M14.5 8.5H17C19.2091 8.5 21 10.2909 21 12.5C21 14.7091 19.2091 16.5 17 16.5H14.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
<path d="M7.5 12.5H16.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
</svg>

</template>
<script>
export default { 
    name: 'LinkIcon',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
