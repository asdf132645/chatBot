<template>
    <svg class="stroke" :width="size" :height="size" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10.33 16.593H4.0293" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M19.9997 16.5533C19.9997 15.2576 18.9424 14.207 17.6374 14.207C16.3316 14.207 15.2734 15.2576 15.2734 16.5533C15.2734 17.8489 16.3316 18.8995 17.6374 18.8995C18.9424 18.8995 19.9997 17.8489 19.9997 16.5533Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M13.1406 6.89969H19.4413" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M8.72629 6.84625C8.72629 5.5506 7.66813 4.5 6.36314 4.5C5.05816 4.5 4 5.5506 4 6.84625C4 8.14191 5.05816 9.19251 6.36314 9.19251C7.66813 9.19251 8.72629 8.14191 8.72629 6.84625Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
</template>
<script>
export default { 
    name: 'ListIcon',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
Edit