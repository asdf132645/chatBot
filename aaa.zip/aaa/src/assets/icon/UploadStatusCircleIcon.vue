<template>
  <svg :width="size" :height="size" viewBox="0 0 24 24" fill="none">
    <circle cx="12" cy="12" r="9" stroke="#C5C5C5" stroke-width="2" />
  </svg>
</template>
<script setup>
import { defineProps } from 'vue'

defineProps({ size: { type: Number, default: 24 } })
</script>