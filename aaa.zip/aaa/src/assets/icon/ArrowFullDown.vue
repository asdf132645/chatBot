<template>
    <svg width="10" height="6" class="stroke" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M5 6L9.33013 0H0.669873L5 6Z" fill="currentColor" />
    </svg>
</template>
<script>
export default { 
    name: 'ArrowFullDown',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
