<template>
<svg
    :width="size" :height="size" class="stroke"
    stroke="currentColor"
    viewBox="0 0 24 24"
    xmlns="http://www.w3.org/2000/svg"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
    >
    <path d="M6 2H18C18.5523 2 19 2.44772 19 3V21L12 17L5 21V3C5 2.44772 5.44772 2 6 2Z" fill="currentColor"/>
</svg>
        
</template>
<script>
export default { 
    name: 'FavoriteIcon',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
