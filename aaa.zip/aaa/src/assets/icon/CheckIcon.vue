<template>
    <svg class="stroke" :width="size" :height="size+1" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
        <g clip-path="url(#clip0_332_13796)">
        <path d="M5 12.5L10 17.5L20 7.5" stroke="currentColor" stroke-width="2.57143" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        <defs>
        <clipPath id="clip0_332_13796">
        <rect width="24" height="24" fill="white" transform="translate(0 0.5)"/>
        </clipPath>
        </defs>
    </svg>
</template>
<script>
export default { 
    name: 'CheckIcon',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
