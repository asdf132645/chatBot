<template>
<svg class="stroke" :width="size+1" :height="size" viewBox="0 0 24 24" fill="none"
  xmlns="http://www.w3.org/2000/svg" aria-label="cloud">
  <!-- cloud outline -->
  <path
    d="M6 17.5h11a4 4 0 0 0 .5-7.97 6 6 0 0 0-11.2-1.66A4.5 4.5 0 0 0 6 17.5Z"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
    stroke-linejoin="round"
  />
  <!-- inner subtle line -->
  <path
    d="M8 14.5h8"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
    stroke-linejoin="round"
  />
</svg>




</template>
<script>
export default { 
    name: 'CloudIcon',
    props: {
        size: { 
            type: Number, 
            default: 24
        }
    },
}
</script>
