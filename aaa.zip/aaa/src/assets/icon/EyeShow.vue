<template>
  <svg
    class="stroke"
    :width="size"
    :height="size"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M12.002 19.354C15.81 19.354 19.293 16.616 21.254 12.052C19.293 7.488 15.81 4.75 12.002 4.75H11.998C8.19 4.75 4.707 7.488 2.746 12.052C4.707 16.616 8.19 19.354 11.998 19.354H12.002Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M15.162 12.0526C15.162 13.7986 13.746 15.2136 12 15.2136C10.254 15.2136 8.838 13.7986 8.838 12.0526C8.838 10.3056 10.254 8.89062 12 8.89062C13.746 8.89062 15.162 10.3056 15.162 12.0526Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>

<script>
export default {
  name: 'EyeShow',
  props: {
    size: {
      type: Number,
      default: 24,
    },
  },
}
</script>
