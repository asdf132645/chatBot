<template>
  <div class="conv-history-wrapper">

    <!-- 검색창 -->
    <QueryInputer
        :maxWidth="400"
        ref="convHistoryQueryInputer"
        id="convHistoryQueryInputer"
        class="conv-history-inputer"        
        placeholder="대화이력을 검색해주세요."
        :isUploadHidden="true"
        :isInteractionHidden="true"
        @submit="searchConvHistory"
    />

    <!-- 현재 페이지 경로 -->
    <div class="document-crumble-wrapper" >
        <div class="document-crumble-item">
            <BaseIcon name="Home" :size="18" />
            <span class="document-crumble-path">
                대화이력 관리
            </span>
        </div>
    </div>

    
    <!-- 문서 필터보기 옵션  -->
    <div class="data-option-group">
        <button class="btn" @click.stop="toggleDriveDrop($event, 'docType')">
            카테고리
            <BaseIcon :size="16" :ml="6" name="ArrowDown" />
        </button>
        <button class="btn" @click.stop="toggleDriveDrop($event, 'author')" v-if="pageViewType !== 'myDrive'">
            채팅자명
            <BaseIcon :size="16" :ml="6" name="ArrowDown" />
        </button>   
        <button class="btn" @click.stop="toggleDriveDrop($event, 'updateDate')">
            대화날짜
            <BaseIcon :size="16" :ml="6" name="ArrowDown" />
        </button>            
    </div>

        <!-- 리스트 뷰 -->
    <div class="data-list-wrapper">
        <div class="list-th-wrapper">
            <div class="list-th check-input">
                <NewCustomCheck class="check-item" id="selectedAllRow" v-model="selectedAllRow" />
            </div>
            <div class="list-th" v-for="thName in thList" :key="thName">{{ thName }}</div>
            <div class="list-th"></div>
        </div>

        <div class="list-td-wrapper">
            <div
                class="list-tr"
                v-for="tr in trList"
                :key="tr?.id"
                @click="handleTrClick(tr)"
            >
                <div class="list-td strong check-input">
                    <NewCustomCheck class="check-item" :id="tr?.id" v-model="tr.selected" />
                </div>
                <div class="list-td">{{ tr?.content ?? '' }}</div>
                <div class="list-td">{{ tr?.author ?? '' }}</div>
                <div class="list-td">{{ tr?.updatedTime ?? '' }}</div>
                <div class="list-td">
                    <button class="btn btn-icon" @click.stop="toggleDriveModal('edit', tr)">
                        <BaseIcon :size="20" name="EditFull" />
                    </button>
                    <button class="btn btn-icon" @click.stop="toggleDriveModal('delete', tr)">
                        <BaseIcon :size="20" name="DeleteOutline" />
                    </button>
                </div>
            </div>
        </div>
    </div>

        <!-- 우측 상단 드롭다운 -->
    <DropDown
      :width="154"
      :top="driveDropPosition.y"
      :left="driveDropPosition.x -154"
      :isOpenDrop="isDriveDrop"
      @close="isDriveDrop = false"
      dropdownName="drive-menu-wrapper"
    >
      <template #content>

        <template v-if="dropType === 'author'">
          <CustomSearch
            id="authorSearch"
            v-model="authorSearchValue"
            :placeholder="'이름을 검색하세요.'"
            @update:modelValue="handleAuthorSearchInput"
          />

          <CustomList 
            :lists="filterUserList"
            :maxHeight="300"
            :isClickable="true"
            @listClick="handleSearchUserClick"
          />
          
        </template>
        <template v-if="dropType === 'docType'">
            <CustomList 
                :lists="docTypeList"
                :maxHeight="300"
                :isClickable="true"
                @listClick="handleSearchDocTypeClick"
            />
        </template>
        <template v-else>
            <ul>  
                <template v-if="dropType === 'updateDate'">
                    <li>
                        <button class="nav-btn" @click="filterSearchDocuments('date','today')">오늘</button>
                    </li>
                    <li>
                        <button class="nav-btn" @click="filterSearchDocuments('date','7days')">지난 7일</button>
                    </li>
                    <li>
                        <button class="nav-btn" @click="filterSearchDocuments('date','30days')">지난 30일</button>
                    </li>
                </template>

                <template v-if="dropType === 'updateDate'">
                    <li>
                        <button class="nav-btn" @click="filterSearchDocuments('date','today')">오늘</button>
                    </li>
                    <li>
                        <button class="nav-btn" @click="filterSearchDocuments('date','7days')">지난 7일</button>
                    </li>
                    <li>
                        <button class="nav-btn" @click="filterSearchDocuments('date','30days')">지난 30일</button>
                    </li>
                </template>
            </ul>
        </template>

       
      </template>
    </DropDown>
  </div>
</template>

<script setup>
import BaseIcon from '@/component/BaseIcon.vue';
import CustomSearch from '@/component/CustomSearch.vue';
import CustomList from '@/component/CustomList.vue';
import DropDown from '@/component/DropDown.vue';
import NewCustomCheck from '@/shared/component/common/NewCustomCheck';
import QueryInputer from '@/component/QueryInputer.vue';

import { ref, reactive, computed } from 'vue';

const isDriveDrop = ref(false);


const thList = ref(['대화내용', '채팅자명', '최근대화날짜']);
const trList = reactive([
  {
    id: '1234',
    name: '2025년 상반기 헬프나우 전략 기획안',
    author: '박기철',
    updatedTime: '2025-08-27',
    createdTime: '2025-08-27',
    fileSize: '128349',
    type: 'pdf',
    position: '',
    selected: false,
    content: '샘플 컨텐츠 A',
  },
  {
    id: '1235',
    name: '2025년 하반기 마케팅 플랜',
    author: '이수진',
    updatedTime: '2025-09-01',
    createdTime: '2025-08-30',
    fileSize: '93456',
    type: 'docx',
    position: '',
    selected: false,
    content: '샘플 컨텐츠 B',
  },
]);



const dropType = ref('docType');
const driveDropPosition = reactive({ x: 0, y: 0 });

const filterUserList = ref([]);
const userList = ref([
  { id: '1234', name: '박기철' },
  { id: '1235', name: '이수진' },
  { id: '1236', name: '김민지' },
]);

const docTypeList = ref([
  { id: '234', name: '일반보고서' },
  { id: '235', name: '출장보고서' },
  { id: '236', name: '기타' },
]);

const authorSearchValue = ref('');

const selectedAllRow = computed({
  get() {
    if (!trList.length) return false;
    const checked = trList.filter(tr => tr.selected).length;
    return checked > 0 && checked === trList.length;
  },
  set(val) {
    trList.forEach(tr => (tr.selected = !!val));
  },
});

const handleTrClick = (tr) => {
  console.log(tr);
}

function searchConvHistory(value) {
  console.log('searchConvHistory', value);
}

function handleAuthorSearchInput(value) {
  // userList 배열에서 userName에 value가 포함된 모든 사용자를 찾는 함수
  console.log('user', value);
  filterUserList.value = [];
  if (value && value.trim() !== '') {
    filterUserList.value = userList.value.filter(user => user.userName.includes(value));
  } else { 
    filterUserList.value = userList.value;
  }
}

function handleSearchDocTypeClick(docType) {
  console.log('handleSearchDocTypeClick', docType);
}

function handleSearchUserClick(user) {
  console.log('handleSearchUserClick', user);
}

function filterSearchDocuments(searchType, searchValue) {
  console.log('filterSearchDocuments', searchType, searchValue);
}

function toggleDriveDrop(event, type) {
  driveDropPosition.x = event.clientX;
  driveDropPosition.y = event.clientY - 10;
  dropType.value = type;
  isDriveDrop.value = true;
}

</script>
