<template>
  <div class="ai-box-wrapper">
    <div class="ai-box-header">
      <div class="ai-box-header-title">
        <BaseIcon name="ArrowTailLeft" :size="20" @click="goBack" style="cursor: pointer;" />
        {{ currentDoc.name || 'S-Box' }}
      </div>

      <button class="btn" @click.stop="toggleDriveDrop($event)">참고 문서 목록</button>
    </div>

      <div class="ai-box-body">
        <div v-if="chatList.length === 0" class="ai-box-body-empty">
          <div class="empty-content">
            <div class="empty-title">{{ currentDoc.name }}에 대해서 무엇이 궁금한가요?</div>
            <div class="empty-subtitle">
              <div class="rolling-text">
                <div 
                  v-for="(text, index) in rollingTexts" 
                  :key="index"
                  class="rolling-item"
                  :class="{ 'active': currentRollingIndex === index }"
                >
                  {{ text }}
                </div>
              </div>
            </div>
          </div>
        </div>
      <RagAnswerContent
        v-for="answer in chatList"
        :id="`rag-answer-${answer.id}`"
        :key="answer.id"
        :answer="answer"
        :queryLoading="queryLoading"
        :lastAnswer="chatList[chatList.length - 1] === answer"
        @toggleState="handleToggleState"
      /> 
    </div>

    <div class="ai-box-footer">
      <QueryInputer
        ref="ragQueryInputer"
        id="ragQueryInputer"
        :isQueryLoading="isStreaming"
        :placeholder="`${currentDoc.name}에 대해서 궁금한 내용을 입력하세요!`"
        :isUploadHidden="true"
        :isInteractionHidden="true"
        :isMultiAnswer="true"
        @submit="handleSubmitQuery"
      />
      <div class="ai-box-footer-box">
      </div>
    </div>

    <DropDown
      :width="300"
      :top="driveDropPosition.y"
      :left="driveDropPosition.x - 300"
      :isOpenDrop="isOpenAiDrop"
      @close="isOpenAiDrop = false"
      dropdownName="ai-box-menu-wrapper"
    >
      <template #content>
        <CustomList 
          :lists="driveFileUploadList"
          :maxHeight="300"
          :isAvatar="false"
          :removePadding="true"
          :border="true"
        />
      </template>
    </DropDown>
  </div>
</template>

<script setup>
import { ref, reactive, computed, defineProps, defineEmits, defineExpose, onMounted, onBeforeUnmount, watch, nextTick } from 'vue';
import { useStore } from 'vuex';
import { useRagChat } from '@/domains/ragChat/application/useRagChat';
import BaseIcon from '@/component/BaseIcon.vue';
import QueryInputer from '@/component/QueryInputer.vue';
import RagAnswerContent from '@/domains/ragChat/presentation/RagAnswerContent.vue';
import CustomList from '@/component/CustomList.vue';
import DropDown from '@/component/DropDown.vue';

// 부모로부터 받는 props
const props = defineProps({
  fileTagValue: { type: String, default: '' },
  fileSummaryValue: { type: String, default: '' },
  filePromptValue: { type: String, default: '' },
  currentTab: { type: String, default: 'tag' },
  currentDoc: { type: Object, default: null },
  sBoxName: { type: String, default: '' },
  driveFileUploadList: { type: Array, default: () => [] }
});
console.log(props);

// RAG 채팅 훅 사용
const {
  chatList,
  isStreaming,
  queryLoading,
  startRagChat,
  toggleAnswerState,
  clearChatList,
  updateConfig
} = useRagChat();

const ragQueryInputer = ref(null);

const emit = defineEmits(['goBack']);
// Store
const store = useStore();

// DropDown 정보
const isOpenAiDrop = ref(true);
const driveDropPosition = reactive({ x: 0, y: 0 });

function toggleDriveDrop(event) {
  driveDropPosition.x = event.clientX;
  driveDropPosition.y = event.clientY;
  isOpenAiDrop.value = true;
}

// 세션 정보
const session = computed(() => store.getters.session || {});
const sessionId = computed(() => session.value.session_id || '');

// RAG 설정
const multiDomainIds = ref([
  {
    label: props.currentDoc.name,
    type: "domain",
    domainId: props.currentDoc.nodeId
  }
]);

const insightPromptId = ref('4bd9cbed-9346-4dd3-b5e5-ff4c2a5514eb');

// 쿼리 처리 상태
const isQueryProcessing = ref(false);

// 롤업 텍스트 관련
const currentRollingIndex = ref(0);
const rollingTexts = ref([
  '이 문서의 주요 내용을 요약해주세요',
  '핵심 키워드와 개념을 알려주세요',
  '이 문서에서 중요한 데이터나 통계는 무엇인가요?',
  '이 문서의 결론이나 요점을 설명해주세요',
  '이 문서와 관련된 추가 정보가 있나요?'
]);

// 롤업 애니메이션 타이머
let rollingTimer = null;

// 롤업 애니메이션 시작
function startRollingAnimation() {
  if (rollingTimer) {
    clearInterval(rollingTimer);
  }
  
  rollingTimer = setInterval(() => {
    currentRollingIndex.value = (currentRollingIndex.value + 1) % rollingTexts.value.length;
  }, 2000);
}

// 롤업 애니메이션 중지
function stopRollingAnimation() {
  if (rollingTimer) {
    clearInterval(rollingTimer);
    rollingTimer = null;
  }
}

// 설정 업데이트
if (multiDomainIds.value.length > 0) {
  updateConfig({ multiDomainIds: multiDomainIds.value });
}
if (insightPromptId.value) {
  updateConfig({ insightPromptId: insightPromptId.value });
}


/**
 * 쿼리 처리 시작/종료 핸들러
 * @param {boolean} isProcessing - 처리 중 여부
 */

async function handleSubmitQuery(query, isMultiAnswer) {
  // QueryInputer 인풋창 비우기
  if (ragQueryInputer.value && ragQueryInputer.value.clearInput) {
    ragQueryInputer.value.clearInput();
  }
  if (!query || !query.trim()) {
    console.warn('빈 쿼리입니다.');
    return;
  }

  if (isStreaming.value) {
    console.warn('이미 처리 중입니다.');
    return;
  }

  console.log('handleSubmitQuery', query, isMultiAnswer);

  try {   
    isQueryProcessing.value = true;    
    await startRagChat({
      query: query.trim(),
      sessionId: sessionId.value,
      multiDomainIds: multiDomainIds.value,
      insightPromptId: insightPromptId.value, 
      isMultiAnswer: isMultiAnswer,
      onScroll: scrollToBottom
    });

    console.log('RAG 쿼리 처리 완료:', 
      {
        query: query.trim(),
        answer: chatList.value[chatList.value.length - 1]?.answer || ''
      }
    );

  } catch (error) {
    console.error('RAG 쿼리 처리 오류:', error);
  } finally {
    isQueryProcessing.value = false;
  }
}

function handleToggleState(params) {
  toggleAnswerState(params.answerId);
}

/**
 * 답변 완료 핸들러
 * @param {Object} result - 답변 결과
 */

/**
 * 부모에서 쿼리 전송
 * @param {string} query - 쿼리
 */
function sendFromParent(query) {
  if (ragQueryInputer.value) {
    ragQueryInputer.value.sendFromParent(query);
  }
}
/**
 * 뒤로가기
 */
function goBack() {
  emit('goBack');
}

// 스크롤 디바운싱을 위한 타이머
let scrollTimer = null;

/**
 * 화면 하단으로 스크롤 (디바운싱 적용)
 */
function scrollToBottom() {
  // 기존 타이머가 있으면 취소
  if (scrollTimer) {
    clearTimeout(scrollTimer);
  }
  
  // 다음 틱에서 실행하여 DOM 업데이트 후 스크롤
  nextTick(() => {
    const aiBoxBody = document.querySelector('.ai-box-body');
    if (aiBoxBody) {
      aiBoxBody.scrollTo({
        top: aiBoxBody.scrollHeight,
        behavior: 'smooth'
      });
    }
  });
  
  // 디바운싱: 100ms 후에 한 번 더 스크롤 (스트리밍 완료 후 최종 스크롤)
  scrollTimer = setTimeout(() => {
    nextTick(() => {
      const aiBoxBody = document.querySelector('.ai-box-body');
      if (aiBoxBody) {
        aiBoxBody.scrollTo({
          top: aiBoxBody.scrollHeight,
          behavior: 'smooth'
        });
      }
    });
  }, 100);
}

// chatList 변화 감지하여 애니메이션 제어 및 자동 스크롤
watch(chatList, (newList, oldList) => {
  if (newList.length === 0) {
    startRollingAnimation();
  } else {
    stopRollingAnimation();
    
    // 스트리밍 중이거나 새로운 답변이 추가된 경우 자동 스크롤
    if (isStreaming.value || (newList.length > (oldList?.length || 0))) {
      scrollToBottom();
    }
  }
}, { immediate: true });

// 스트리밍 상태 변화 감지하여 자동 스크롤
watch(isStreaming, (newValue, oldValue) => {
  // 스트리밍이 시작되면 자동 스크롤 시작
  if (newValue && !oldValue) {
    scrollToBottom();
  }
});

// 컴포넌트 마운트 시 초기 프롬프트 처리
onMounted(() => {
  // filePromptValue가 존재하고 공백이 아니면 자동으로 RAG 쿼리 실행
  if (props.filePromptValue && props.filePromptValue.trim()) {
    setTimeout(() => {
      sendFromParent(props.filePromptValue.trim());
    }, 100);
  }
});

// 컴포넌트 언마운트 시 타이머 정리
onBeforeUnmount(() => {
  stopRollingAnimation();
  if (scrollTimer) {
    clearTimeout(scrollTimer);
    scrollTimer = null;
  }
});

// 부모에서 호출할 수 있는 메서드 정의
defineExpose({
  /**
   * 채팅 리스트 초기화
   */
  clearChat() {
    clearChatList();
  },

  /**
   * 특정 답변으로 스크롤
   * @param {string} answerId - 답변 ID
   */
  scrollToAnswer(answerId) {
    const element = document.getElementById(`rag-answer-${answerId}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }
});

</script>

<style scoped>
.ai-box-body-empty {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  /* min-height: 400px; */
  /* padding: 2rem; */
}

.empty-content {
  text-align: center;
  max-width: 500px;
}

.empty-icon {
  margin-bottom: 1.5rem;
  opacity: 0.6;
}

.empty-title {
  font-size: 1.5rem;
  font-weight: 600;
  color: #333;
  margin-bottom: 1rem;
  line-height: 1.4;
}

.empty-subtitle {
  height: 2.5rem;
  overflow: hidden;
  position: relative;
}

.rolling-text {
  position: relative;
  height: 100%;
}

.rolling-item {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1rem;
  color: #666;
  opacity: 0;
  transform: translateY(20px);
  transition: all 0.5s ease-in-out;
}

.rolling-item.active {
  opacity: 1;
  transform: translateY(0);
}

.rolling-item:not(.active) {
  transform: translateY(-20px);
}
</style>

