<template>
  <div class="document-drive-wrapper">
    <!-- 좌측 메뉴 -->
    <div class="document-drive-menu">
      <div class="document-drive-menu-wrapper">
        <div
          class="menu-item"
          v-for="(item, idx) in menuList"
          :key="idx"
        >
          <button
            v-if="item.type === 'button'"
            class="btn"
            :class="{ 'text-primary': item.check, 'disabled': item.disabled }"
            @click="handleMenuClick(item)"
          >
            <BaseIcon :name="item.icon" :size="item.size" />
            {{ item.label }}
            <div v-if="item.check" class="check-icon">
              <BaseIcon name="Check" :size="19" />
            </div>
          </button>
          <div v-else-if="item.type === 'divider'" class="divider horizontal"></div>
        </div>
      </div>

<!--      <div class="document-drive-usage-wrapper">-->
<!--        <div class="usage-number">현재 {{ formatBytes(storageInfo.totalIndexedSize) }} 사용중!</div>-->
<!--        <div class="usage-box">-->
<!--          <span class="usage-line-bar"><span :style="`width: ${storageInfo.usagePercentage.toFixed(2)}%;`"-->
<!--                                             class="usage-line-bar-fill"></span></span>-->
<!--          <span class="usage-count">{{ storageInfo.usagePercentage.toFixed(2) }}%</span>-->
<!--        </div>-->
<!--      </div>-->
    </div>

    <!-- 우측 콘텐츠 -->
    <div class="document-drive-content">
      <div class="document-drive-section document-drive-manager-wrapper"
           :class="{ 'drive-page-view': pageViewType !== 'home' }">

        <template v-if="!currentAiBoxDetail">
          <!-- 메인 페이지 메세지 -->
          <div class="message-wrapper" v-if="pageViewType === 'home'">
            <div class="message-text-header">안녕하세요!</div>
            <div class="message-text-main">
              <span class="highlight-text-outline">Agentic AI </span>
              <span class="highlight-text">드라이브</span> 입니다.
            </div>
            <div class="message-text-description">
              드라이브에서 문서를 관리하고 공유 가능하며,<br />AI를 이용하여 문서를 번역, 요약, 분석을 할 수 있습니다.
            </div>
          </div>

          <!-- 검색창 -->
          <QueryInputer
            :maxWidth="pageViewType === 'home' ? 600 : 600"
            ref="driveQueryInputerSerch"
            id="driveQueryInputerSerch"
            class="doc-drive-inputer"
            :class="{ 'drive-page-view': pageViewType !== 'home' }"
            placeholder="드라이브에서 검색해주세요."
            :isSearch="true"
            :isUploadHidden="true"
            :isInteractionHidden="true"
            :enableReset="true"
            @resetResult="resetSearchResult"
            @submit="searchDocuments"
          />

          <!-- 현재 페이지 경로 -->
          <div class="document-crumble-wrapper" v-if="pageViewType !== 'home'">
            <div class="document-crumble-item">
              <BaseIcon name="Home" :size="18" />
              <span class="document-crumble-path">
                <span @click="handleCrumbleClick()">{{ pageViewLabel }}</span>
                <span v-for="breadcrumbItem in breadcrumbPath" :key="breadcrumbItem.id">
                  <span> > </span>
                  <span @click="handleCrumbleClick(breadcrumbItem.id)">{{ breadcrumbItem.name }}</span>
                </span>
              </span>
            </div>
          </div>

          <!-- 문서 필터보기 옵션  -->
          <div class="data-option-group">
            <button
              class="btn btn-icon"
              title="카테고리(카드) 보기"
              :class="{ 'primary': viewType === 'category' }"
              @click="handleTypeClick('category')"
            >
              <BaseIcon :size="20" name="Category" />
            </button>

            <button
              class="btn btn-icon"
              title="리스트 보기"
              :class="{ 'primary': viewType === 'list' }"
              @click="handleTypeClick('list')"
            >
              <BaseIcon :size="20" name="List" />
            </button>
            <div class="divider"></div>
            <!-- <button class="btn" @click.stop="toggleDriveDrop($event, 'docType')">
              문서유형
              <BaseIcon :size="16" :ml="6" name="ArrowDown" />
            </button>
            <button class="btn" @click.stop="toggleDriveDrop($event, 'updateDate')">
              수정날짜
              <BaseIcon :size="16" :ml="6" name="ArrowDown" />
            </button>
            <button class="btn disabled" @click.stop="toggleDriveDrop($event, 'author')"
                    v-if="pageViewType !== 'myDrive'">
              이름
              <BaseIcon :size="16" :ml="6" name="ArrowDown" />
            </button>
            <div class="divider"></div> -->

            <template v-if="selectedTrList > 0 && selectedCategory !== 'aiBox'">
              <div class="selected-list-info">
                <span> {{ selectedTrList }} 건 선택</span>
                <button class="btn btn-icon" @click="handleSelectedListClear">
                  <BaseIcon name="Close" :size="18" />
                </button>
              </div>
              <button class="btn s-box-add"
                      @click="handleSummaryClick('sBox')">
                <BaseIcon name="LinkGraph" :mr="6" :size="18" />
                S-Box 담기
              </button>
            </template>


            <template v-if="pageViewType !== 'aiBox'">
              <button class="btn btn-add" @click.stop="toggleDriveDrop($event, 'add')">
                <BaseIcon :size="18" :mr="8" name="AddPlus" />
                추가하기
              </button>
            </template>

            <!-- <template v-if="pageViewType === 'aiBox'">
              <button class="btn btn-add" @click.stop="toggleDriveModal('aiBox')">
                <BaseIcon :size="18" :mr="8" name="AddPlus" />
                S-Box 추가하기
              </button>
            </template> -->
          </div>

          <!-- 리스트 뷰 -->
          <div class="data-list-wrapper" v-if="viewType === 'list'">
            <div class="list-th-wrapper">
              <template v-if="selectedCategory !== 'aiBox'">
                <div class="list-th check-input">
                  <NewCustomCheck class="check-item" id="selectedAllRow" v-model="selectedAllRow" />
                </div>
                <div class="list-th"  v-for="thName in thList" :key="thName">{{ thName }}</div>
                <div class="list-th"></div>
              </template>
              <template v-else>
                <div class="list-th"  v-for="thName in aiThList" :key="thName">{{ thName }}</div>
              </template>
            </div>

            <div class="list-td-wrapper">
              <div class="list-tr" v-for="tr in trList" :key="tr.id"
                   @click="handleTrClick(tr)"
                   @dblclick="handleCardDblClick(tr)"
                   :class="{ 'updated-item': updatedItemIds.includes(tr.id) }"
              >
                <div class="list-td strong check-input" v-if="tr?.category !== 'aiBox'">
                  <NewCustomCheck class="check-item" :id="tr.name" v-model="tr.selected" />
                </div>
                <div class="list-td strong">{{ tr.name }}
                  <div v-if="tr.nodeId"></div>
                </div>
                <div class="list-td">{{ tr.author }}</div>
                <div class="list-td">{{ tr.updatedTime }}</div>
                <div class="list-td" v-if="tr?.category !== 'aiBox'">{{ tr.fileSize }}</div>
                <div class="list-td" v-if="tr?.category !== 'aiBox'">
                  <button class="btn btn-icon" @click.stop="toggleDriveModal('edit', tr)">
                    <BaseIcon :size="20" name="EditFull" />
                  </button>
                  <button class="btn btn-icon" @click.stop="toggleDriveModal('delete', tr)">
                    <BaseIcon :size="20" name="DeleteOutline" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          <!-- 카드 뷰 -->
          <div class="custom-card-list card-wrapper" v-if="viewType === 'category'">
            <div
              class="card-item"
              v-for="card in trList"
              :key="card.id"
              @click="handleTrClick(card)"
              @dblclick="handleCardDblClick(card)"
              :class="{ 'checked': card.selected, 'updated-item': updatedItemIds.includes(card.id) }"
            >
              <div class="card-header">
                <div class="card-header-box">
                  <div class="card-icon">
                    <div class="card-icon-badge-wrapper">
                      <div class="card-new-badge" v-if="card?.nodeId && card?.nodeId !==''">
                        <span>채팅 가능</span>
                      </div>
                    </div>

                    <BaseIcon v-if="card.category !== 'aiBox'" :name="getFileIcon(card.type)" :size="32" />
                    <BaseIcon v-else :name="getFileIconAiBox(card?.nodeId)" :size="32" />
                  </div>

                </div>
                <button class="card-btn-group btn" @click.stop="toggleDriveDrop($event, 'card', card)">
                  <BaseIcon :size="18" name="DotsVertical" />
                </button>
              </div>
              <div class="card-item-body">
                <div class="card-item-title">
                  {{ card.name }}
                </div>
                <div class="card-item-desc">
                  {{ card.author }}
                  <div class="divider"></div>
                  {{ card.updatedTime }}
                </div>
              </div>
            </div>
          </div>
        </template>

        <!-- S-Box 상세 페이지 -->
        <template v-if="currentAiBoxDetail">
          <AiBoxWrapper
            :fileTagValue="fileTagValue"
            :fileSummaryValue="fileSummaryValue"
            :filePromptValue="filePromptValue"
            :currentTab="currentTab"
            :currentDoc="currentDoc"
            :sBoxName="sBoxName"
            :driveFileUploadList="driveFileUploadList"
            @goBack="handleGoBack"
          />
        </template>


        <!-- 파일 리스트 보기 (AI 드라이브) -->
        <div class="drive-file-list-wrapper" v-if="pageViewType === 'aiBox' && isFileListOpen && !currentAiBoxDetail">
          <div class="drive-file-list-header">
            <div class="drive-file-list-header-title">
              <template v-if="!currentDrivePosition">
                <BaseIcon name="Cloud" :size="20" />
                AI 드라이브 정보
              </template>

              <!-- 현재 드라이브 위치 (단일 드라이브 정보만 출력) -->
              <template v-else>
                <button class="btn btn-icon" @click="handleBackToParent">
                  <BaseIcon name="ArrowTailLeft" :size="20" />
                </button>
                {{ currentDrivePosition.name }}
              </template>

              <button class="btn btn-icon ml-auto" @click="isFileListOpen = false">
                <BaseIcon name="Close" :size="20" />
              </button>
            </div>
          </div>


          <div class="drive-file-list-body">
            <CustomSearch
              class="drive-file-list-search"
              id="driveFileListSearch"
              v-model="driveFileListSearchValue"
              :placeholder="'파일을 검색하세요.'"
            />
            <div class="drive-file-list-body-box">
              <div class="drive-file-list-body-item" v-for="item in driveFileList" :key="item.id"
                   @click="handleDriveFileItemClick(item)"
              >
                <BaseIcon :name="item.type === 'folder' ? 'Drive' : 'Paper'" :size="item.type === 'folder' ? 20 : 18" />
                <span class="item-name" :title="item.name">{{ item.name }}</span>
                <button class="btn btn-add" v-if="item.type !== 'folder'" @click="handleAddFile(item)">
                  <BaseIcon name="AddPlus" :size="16" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!--  AI 답변: ChatBubbleList + QueryInputer -->

      <template v-if="!currentAiBoxDetail">
        <div class="document-drive-aside aside-wrapper" v-if="isAsideOpen" style="position: relative">

          <div class="aside-header">
            <div class="aside-header-title">
              <template v-if="currentSideType === 'summary'">
                <button class="btn btn-icon" @click="currentSideType = 'sBox'">
                  <BaseIcon name="ArrowTailLeft" :size="20" />
                </button>
                AI 답변
              </template>
              <template v-if="currentSideType === 'sBox'">
                <BaseIcon name="LinkGraph" :size="20" />
                S-Box
              </template>
            </div>
            <div class="btn-group">
              <button class="btn btn-icon" @click="closeAsideOpen()">
                <BaseIcon name="Close" :size="20" />
              </button>
            </div>
          </div>

          <div class="aside-body" ref="asideBodyRef">

            <template v-if="currentSideType === 'summary'">
              <div class="ai-summary-wrapper">
                <!-- 오버레이 -->
                <div
                  class="editor-loading-overlay"
                  :class="{ 'is-visible': showEditorOverlay }"
                  aria-hidden="true"
                >
                  <div class="editor-skeleton">
                    <div class="skeleton-line" style="width: 40%"></div>
                    <div class="skeleton-line" style="width: 90%"></div>
                    <div class="skeleton-line" style="width: 80%"></div>
                    <div class="skeleton-line" style="width: 70%"></div>
                  </div>
                </div>
                <ChatBubbleList
                  :chatList="chatList"
                  :renderMarkdownStream="renderMarkdownStream"
                  :formatDate="formatDate"
                  :isStreaming="isStreaming"
                  @mounted="onBubbleMounted"
                />
              </div>
            </template>
            <template v-if="currentSideType === 'sBox'">
              <div class="tab-header">
                <div class="tab-label"
                     :class="{
                    'active': currentTab === tab.id,
                    'disabled': tab.disabled
                  }"
                     v-for="tab in tabList" :key="tab.id"
                     @click="handleTabClick(tab.id)">{{ tab.label }}
                </div>
              </div>


              <div class="tab-body">
                <template v-if="currentTab === 'fileList'">
                  <div class="file-list-wrapper">
                    <div class="file-upload-list" v-if="driveFileUploadList.length > 0">
                      <div class="file-upload-item" v-for="file in driveFileUploadList" :key="file.id">
                        <div class="file-upload-item-box">
                          <div class="file-upload-item-name" :title="file.name">
                            {{ file.name }}
                          </div>

                          <div class="file-upload-item-description">
                            {{ file.position }}
                            <div class="divider"></div>
                            {{ file.size }}
                            <div class="divider"></div>
                            {{ file.type }}
                          </div>
                        </div>

                        <template v-if="!currentAiBoxDetail">

                          <button class="btn btn-ai"
                                  @click="handleSummaryClick('summary',file)"
                                  v-if="pageViewType === 'aiBox'">파일요약
                          </button>
                          <!--                          <div class="divider" v-if="pageViewType === 'aiBox'"></div>-->
                          <!--                          <button class="btn" @click="removeFromUploadList(file.id)">-->
                          <!--                            <BaseIcon name="DeleteOutline" :size="18" />-->
                          <!--                          </button>-->
                        </template>

                      </div>
                    </div>

                    <!--                    <div class="file-upload-item-add"-->
                    <!--                         v-if="pageViewType === 'aiBox' && !isFileListOpen && !currentAiBoxDetail">-->
                    <!--                      <button class="btn file-upload-item-add-box" @click="isFileListOpen = true">-->
                    <!--                        <BaseIcon name="AddPlus" :size="18" :mr="6" />-->
                    <!--                        파일을 추가하세요.-->
                    <!--                      </button>-->
                    <!--                    </div>-->
                  </div>
                </template>

                <template v-if="currentTab === 'aiAnalysis'">
                  <div class="ai-analysis-wrapper">
                    <div class="btn-group narrow">
                      <button class="btn" :class="{ 'active': currentTabPanel === panel.id }"
                              @click="handleAiAnalysisPanelClick(panel)" v-for="panel in aiAnalysisPanels"
                              :key="panel.id">
                        <BaseIcon name="Check" :size="18" v-if="panel.checked" :mr="6" />
                        {{ panel.label }}
                      </button>
                    </div>

                    <div class="aside-box">
                      <template v-if="currentTabPanel === 'prompt'">
                        <CustomTextarea
                          id="filePromptInput"
                          v-model="filePromptValue"
                          placeholder="프롬프트를 입력하세요."
                        />
                      </template>
                      <template v-if="currentTabPanel === 'summary'">
                        <CustomTextarea
                          id="fileSummaryInput"
                          v-model="fileSummaryValue"
                          placeholder="파일 요약을 입력하세요."
                        />
                      </template>
                      <template v-if="currentTabPanel === 'instruction'">
                        <CustomTextarea
                          id="fileInstructionInput"
                          v-model="fileInstructionValue"
                          placeholder="지침을 입력하세요."
                        />
                      </template>
                      <template v-if="currentTabPanel === 'tag'">
                        <CustomInput
                          id="fileTagInput"
                          v-model="fileTagValue"
                          placeholder="추가 태그를 입력하세요."
                        />
                      </template>
                    </div>
                  </div>
                </template>

                <template v-if="currentTab === 'history'">

                </template>
              </div>

            </template>

          </div>

          <div class="aside-footer"
               :class="{ 
                'border': currentSideType === 'sBox',
                'remove-padding': currentSideType === 'summary'
                }"
               v-if="!currentAiBoxDetail"
          >
            <template v-if="currentSideType === 'summary'">
              <!-- <QueryInputer
                ref="driveQueryInputer"
                id="driveQueryInputer"
                class="doc-answer-inputer"
                placeholder="요청사항(프롬프트)를 입력하세요."
                :isQueryLoading="isChatLoading"
                :isUploadHidden="true"
                :isInteractionHidden="true"
                :noShadow="true"
                :fileList="fileList"
                :maxFiles="5"
                :abortSignal="uploadAbortCtrl.signal"
                @submit="suggestSendChat"
                @fileIds="handleFileIds"
                @fileUpload="handleFileUpload"
                @fileError="onFileUploadError"
                @clearFiles="clearAllFiles"
                @fileProcessed="onFileProcessed"
              /> -->
            </template>

            <template v-if="currentSideType === 'sBox'">
              <div class="btn-group">


                <template v-if="!shouldShowProgressBar && isAllNodeIdsValid">
                  <!--              <button class="btn btn-default" @click="handleAiAnalysis">AI 분석실행</button>-->
                  <!-- 인덱싱 처리 되면 자동 저장되도록 필요. 폴더명은 자동생성 이후 사용자가 변경토록 -->
                  <!--                <template v-if="shouldShowProgressBar && !isAllNodeIdsValid">-->
                </template>
                <template v-else>
                  <button class="btn btn-default ml-auto" v-if="pageViewType !== 'aiBox'"
                          @click="toggleDriveModal('aiBox')">S-Box 저장
                  </button>
                  <div v-if="pageViewType === 'aiBox' && !currentDoc.nodeId" class="loading-spinner"></div>

                  <p class="default-text"
                     v-if="pageViewType === 'aiBox' && !currentDoc.nodeId">
                    현재 인덱싱이 준비중 입니다.
                  </p>
                  <button class="btn btn-default"
                          @click="sBoxRunAnalysis"
                          v-if="pageViewType === 'aiBox' && currentDoc.nodeId">채팅 시작
                  </button>
                </template>

              </div>
            </template>
          </div>
        </div>
      </template>

      <ToastContainer />
    </div>

    <!-- 우측 상단 드롭다운 -->
    <DropDown
      :width="dropType === 'author' ? 260 : 200"
      :top="driveDropPosition.y"
      :left="driveDropPosition.x - (dropType === 'author' ? 260 : 154)"
      :isOpenDrop="isDriveDrop"
      @close="isDriveDrop = false"
      dropdownName="drive-menu-wrapper"
    >
      <template #content>

        <template v-if="dropType === 'author'">
          <CustomSearch
            id="authorSearch"
            v-model="authorSearchValue"
            :placeholder="'이름을 검색하세요.'"
            @update:modelValue="handleAuthorSearchInput"
          />

          <CustomList
            :lists="filterUserList"
            :maxHeight="300"
            :isClickable="true"
            @listClick="handleSearchUserClick"
          >
          </CustomList>
        </template>

        <template v-if="dropType === 'folder'">
          <CustomSearch
            id="authorSearch"
            v-model="authorSearchValue"
            :placeholder="'이름을 검색하세요.'"
            @update:modelValue="handleAuthorSearchInput"
          />

          <CustomList
            :lists="folderList"
            :maxHeight="300"
            :isClickable="true"
            :isAvatar="false"
            @listClick="handleFolderClick"
          >
          </CustomList>
        </template>

        <template v-else>
          <ul class="custom-list-wrapper">
            <template v-if="dropType === 'add'">
              <li @click="callUploadDocument">
                <button class="nav-btn">
                  <BaseIcon name="ArrowTailDown" :size="20" :mr="8" />
                  파일 업로드
                </button>
              </li>
              <li @click="toggleDirectoryModal">
                <button class="nav-btn">
                  <BaseIcon name="Folder" :size="20" :mr="8" />
                  새폴더
                </button>
              </li>
            </template>

            <template v-if="dropType === 'docType'">
              <li>
                <button class="nav-btn" @click="searchDocuments('', pageViewId.value)">
                  모든 문서
                </button>
              </li>
              <li>
                <button class="nav-btn" @click="filterSearchDocuments('file','txt')">
                  <BaseIcon name="WordType" :size="20" :mr="8" />
                  TXT 파일
                </button>
              </li>
              <li>
                <button class="nav-btn" @click="filterSearchDocuments('file','pdf')">
                  <BaseIcon name="PdfType" :size="20" :mr="8" />
                  PDF 파일
                </button>
              </li>
              <li>
                <button class="nav-btn" @click="filterSearchDocuments('file','csv')">
                  <BaseIcon name="CsvType" :size="20" :mr="8" />
                  CSV 파일
                </button>
              </li>
              <li>
                <button class="nav-btn" @click="filterSearchDocuments('file','doc')">
                  <BaseIcon name="WordType" :size="20" :mr="8" />
                  DOC 파일
                </button>
              </li>
              <li>
                <button class="nav-btn" @click="filterSearchDocuments('file','hwp')">
                  <BaseIcon name="HwpType" :size="20" :mr="8" />
                  HWP 파일
                </button>
              </li>
              <li>
                <button class="nav-btn" @click="filterSearchDocuments('file','hwpx')">
                  <BaseIcon name="HwpType" :size="20" :mr="8" />
                  HWPX 파일
                </button>
              </li>
            </template>

            <template v-if="dropType === 'updateDate'">
              <!-- <li>
                <button class="nav-btn" @click="filterSearchDocuments('date','')">모든 날짜</button>
              </li> -->
              <li>
                <button class="nav-btn" @click="filterSearchDocuments('date','today')">오늘</button>
              </li>
              <li>
                <button class="nav-btn" @click="filterSearchDocuments('date','7days')">지난 7일</button>
              </li>
              <li>
                <button class="nav-btn" @click="filterSearchDocuments('date','30days')">지난 30일</button>
              </li>
            </template>

            <template v-if="dropType === 'card'">
              <li>
                <button class="nav-btn" @click="toggleDriveModal('edit', modalTr)">
                  <BaseIcon name="EditFull" :size="20" :mr="8" />
                  수정하기
                </button>
              </li>
              <li>
                <button
                  class="nav-btn"
                  :class="{ disabled: modalTr.type === 'directory' }"
                  @click="callDownloadDocument(modalTr.id, modalTr.name)">
                  <BaseIcon name="Download" :size="20" :mr="8" />
                  다운로드
                </button>
              </li>
              <li>
                <button class="nav-btn" @click="toggleDriveModal('delete', modalTr)">
                  <BaseIcon name="Delete" :size="20" :mr="8" />
                  삭제하기
                </button>
              </li>
              <li>
                <button class="nav-btn disabled" @click="toggleDriveModal('share')">
                  <BaseIcon name="UserPlus" :size="20" :mr="8" />
                  공유하기
                </button>
              </li>
              <li>
                <button class="nav-btn disabled">
                  <BaseIcon name="Copy" :size="20" :mr="8" />
                  복사하기
                </button>
              </li>

              <li>
                <button class="nav-btn disabled">
                  <BaseIcon name="Search" :size="19" :mr="9" />
                  상세보기
                </button>
              </li>

            </template>

            <template v-if="dropType === 'share'">
              <li v-for="user in userList" :key="user.id">
                <button class="nav-btn">
                  {{ user.name }}
                  <span>{{ user.userEmail }}</span>
                </button>
              </li>
            </template>

            <template v-if="dropType === 'shareStatus'">
              <li>
                <button class="nav-btn" @click.stop="changeSharedUserStatus('editor')">
                  수정자
                </button>
              </li>
              <li>
                <button class="nav-btn" @click.stop="changeSharedUserStatus('viewer')">
                  뷰어
                </button>
              </li>
              <li>
                <button class="nav-btn" @click.stop="deleteSharedUser()">
                  공유 해제
                </button>
              </li>
            </template>
          </ul>
        </template>
      </template>
    </DropDown>

    <MyModal
      width="500"
      :title="modalTitle"
      :isOpenModal="isOpenModal"
      :okBtnName="'확인'"
      :cancelBtnName="'취소'"
      @close="handleModalClose"
      @sendData="handleDocumentModal"
    >
      <template #content>
        <template v-if="modalType === 'edit'">
          <div class="form-wrapper">

            <div class="custom-control row-style row-center">
              <label class="custom-label">현재 문서 위치</label>
              <button class="btn btn-default disabled" @click.stop="toggleDriveDrop($event, 'folder')">
                내 드라이브
                <BaseIcon name="ArrowFullDown" :size="20" :ml="6" />
              </button>
            </div>

            <CustomInput
              label="문서 이름"
              id="editDocumentName"
              placeholder="문서 이름을 수정하세요."
              name="editDocumentName"
              v-model="documentInfo.title"
            />

            <CustomInput
              label="암호 설정"
              :disabled="true"
              id="editPasswordInput"
              placeholder="암호를 수정하세요."
              name="passwordInput"
              v-model="documentInfo.password"
            />

            <TagList
              :tagList="documentInfo.tags"
              @onEnter="handleAddTag"
              @onDelete="handleDeleteTag" />
          </div>
        </template>
        <template v-if="modalType === 'delete'">
          <p> {{ modalTr.type === 'directory' ? '폴더' : '문서' }} 를 삭제하시겠습니까?</p>
        </template>
        <template v-if="modalType === 'share'">

          <div class="form-wrapper">
            <CustomInput
              label="공유할 사용자"
              id="shareUserInput"
              :placeholder="'공유할 사용자를 입력하세요.'"
              name="shareUserInput"
            />

            <div class="user-list-wrapper custom-control">
              <div class="user-list-item-header custom-label">
                현재 공유 받은 사용자
              </div>

              <CustomList :lists="sharedUserList">
                <template #default="{ listItem }">
                  <div class="share-status ml-auto" @click.stop="toggleDriveDrop($event, 'shareStatus', listItem)">
                    {{ listItem.shareStatus === 'editor' ? '수정자' : '뷰어' }}
                    <BaseIcon name="ArrowFullDown" :size="20" :ml="8" />
                  </div>
                </template>
              </CustomList>
            </div>
          </div>
        </template>

        <template v-if="modalType === 'aiBox'">
          <div class="form-wrapper">
            <CustomInput
              label="폴더 이름"
              id="sBoxDirectoryName"
              placeholder="예: 리포트_요약"
              name="sBoxDirectoryName"
              v-model="sBoxDirectoryName"
            />
          </div>
        </template>
      </template>

      <template #footer>
        <template v-if="modalType === 'share'">
          <button class="btn btn-link">
            <BaseIcon name="Link" :size="20" :mr="8" />
            링크 공유
          </button>
        </template>
      </template>
    </MyModal>

    <MyModal
      width="580"
      title="폴더 생성"
      :isOpenModal="isOpenDirectoryModal"
      :okBtnName="'확인'"
      :cancelBtnName="'취소'"
      @close="handleDirectoryModalClose"
      @sendData="handleDirectoryModalSendData"
    >
      <template #content>
        <CustomInput
          label="폴더 이름"
          id="editDirectoryName"
          placeholder="폴더 이름을 입력하세요."
          name="editDirectoryName"
          v-model="editDirectoryNameValue"
        />
      </template>
    </MyModal>

    <!-- 커스텀 토스트 컨테이너 -->


  </div>
</template>

<script setup>
import { ref, reactive, computed, defineOptions, onMounted, onBeforeUnmount, nextTick } from 'vue';
import { useStore } from 'vuex';
import { useI18n } from 'vue-i18n';
import { useToast } from 'vue-toastification';
import { useCustomToast } from '@/composables/useCustomToast';
import { v1 as uuidv1 } from 'uuid';
import ToastContainer from '@/shared/component/common/ToastContainer.vue';


import AiBoxWrapper from '@/views/docsAnswer/AiBoxWrapper.vue';
import NewCustomCheck from '@/shared/component/common/NewCustomCheck';
import QueryInputer from '@/component/QueryInputer';
import DropDown from '@/component/DropDown.vue';
import CustomInput from '@/component/CustomInput.vue';
import CustomSearch from '@/component/CustomSearch.vue';
import CustomTextarea from '@/component/CustomTextarea.vue';
import BaseIcon from '@/component/BaseIcon.vue';
import CustomList from '@/component/CustomList.vue';
import TagList from '@/component/TagList.vue';
import ChatBubbleList from '@/domains/docsChat/presentation/ChatBubbleList.vue';
import MyModal from '@/component/MyModal.vue';

import { formatDate } from '@/composables/chatUtils';
import { fileManageApi } from '@/domains/fileMange/infrastructure/fileManageApi';

import { useChatView } from '@/domains/chat/application/useChatView';
import {
  updateDocument,
  deleteDocument,
  downloadDocument,
  // uploadDocFile,
  uploadMultipleDocFiles,
  createDocumentDirectory,
  copyDocument,
  getIntegratedDocumentsList,
  updateDocumentDirectory,
  softDeleteDocumentDirectory,
} from '@/domains/docsChat/infrastructure/docsApi';
import { getDomainInfo } from '@/domains/chat/infrastructure/chatApi';
import { useFileManage } from '@/domains/fileMange/application/useFileManage';

// SSE + 파일 업로드
import { doSseChatCall } from '@/domains/docsChat/application/useChatStream';
import { useFileAttachments } from '@/composables/useFileAttachments';
// import { useReportTemplates } from '@/domains/report/application/useReportTemplates';

// 컴포넌트 메타
defineOptions({ name: 'DocumentDriveWrapper' });

/* =========================
 * 드라이브 상태
 * ========================= */
const isDriveDrop = ref(false);
const isOpenModal = ref(false);
const editDirectoryNameValue = ref('');
const isOpenDirectoryModal = ref(false);
const isAsideOpen = ref(false);
const driveDropPosition = reactive({ x: 0, y: 0 });
const viewType = ref('category');
const dropType = ref('docType');
const pageViewType = ref('home');
const pageViewLabel = ref('내 드라이브');
const pageViewId = ref('myDrive');
const modalTitle = ref('');
const modalType = ref('');
const selectedSharedUser = ref({});
const currentDirectory = ref(null);
const currentAiBoxDetail = ref(false);

// 용량 관련 데이터
// const storageInfo = ref({
//   limitStorageSize: 0,      // 전체 용량 (bytes)
//   totalIndexedSize: 0,      // 사용 중인 용량 (bytes)
//   usagePercentage: 0,        // 사용률 (%)
// });

// 용량 포맷팅 함수
// const formatBytes = (bytes) => {
//   if (bytes === 0) return '0 B';
//   const k = 1024;
//   const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
//   const i = Math.floor(Math.log(bytes) / Math.log(k));
//   return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
// };
const currentTab = ref('fileList');
const currentSideType = ref('');
const sBoxName = ref('');

const currentDrivePosition = ref(null);
const currentTabPanel = ref('prompt');
const isFileListOpen = ref(false);
const driveFileListSearchValue = ref('');

//s-box 파일 정보 관련 변수들
const fileTagValue = ref('');
const fileSummaryValue = ref('');
const filePromptValue = ref('');

// 템플릿 관련
// const { load: loadTemplates, templates } = useReportTemplates();
// const agentCode = getDomainInfo().chatbotCode || '';
// 모달 상태
const sBoxDirectoryName = ref('');
const sBoxDirectoryId = ref(null);

// S-Box 업로드 상태 관리
const uploadStatus = reactive({
  isUploading: false,
  status: 'idle', // 'idle', 'pending', 'completed', 'error'
  currentCnt: 0,
  totalCnt: 0,
  failedCnt: 0,
  failedFiles: [],
  successFiles: [],
  successDocNames: [],
});

// AI 분석 오버레이 상태
const showEditorOverlay = ref(false);
const documentInfo = ref({
  title: '',
  password: '',
  tags: [],
});

const aiAnalysisPanels = ref([
  { id: 'prompt', label: '프롬프트', checked: true },
  { id: 'summary', label: '문서요약', checked: false },
  { id: 'instruction', label: '지침', checked: false },
  { id: 'tag', label: '추천태그', checked: false },
]);

const tabList = ref([
  { id: 'fileList', label: '파일목록', disabled: false },
  // { id: 'aiAnalysis', label: 'AI 분석', disabled: false },
  // { id: 'history', label: '작업이력', disabled: false },
]);

const filterUserList = ref([]);

const folderList = ref([
  { id: '1', name: '폴더1' },
  { id: '2', name: '폴더2' },
  { id: '3', name: '폴더3' },
]);

const sharedUserList = ref([
  { id: '1', name: '박기철', userEmail: 'park@aaaaaaa.co.kr', isShared: true, shareStatus: 'editor' },
  { id: '2', name: '이수진', userEmail: 'lee@aaaaaaa.co.kr', isShared: true, shareStatus: 'viewer' },
  { id: '3', name: '김민지', userEmail: 'kim@aaaaaaa.co.kr', isShared: true, shareStatus: 'viewer' },
]);

const userList = ref([
  { id: '1', name: '홍길동', userEmail: 'hong@aaaaaaa.co.kr', isShared: false, shareStatus: '' },
  { id: '2', name: '장보고', userEmail: 'jang@aaaaaaa.co.kr', isShared: false, shareStatus: '' },
  { id: '3', name: '신사임당', userEmail: 'shin@aaaaaaa.co.kr', isShared: false, shareStatus: '' },
  { id: '4', name: '이순신', userEmail: 'lee.soonshin@aaaaaaa.co.kr', isShared: false, shareStatus: '' },
  { id: '5', name: '유관순', userEmail: 'yoo@aaaaaaa.co.kr', isShared: false, shareStatus: '' },
  { id: '6', name: '최영호', userEmail: 'choi@aaaaaaa.co.kr', isShared: false, shareStatus: '' },
  { id: '7', name: '정민호', userEmail: 'jeong@aaaaaaa.co.kr', isShared: false, shareStatus: '' },
  { id: '8', name: '박지훈', userEmail: 'park@aaaaaaa.co.kr', isShared: false, shareStatus: '' },
  { id: '9', name: '이지호', userEmail: 'lee@aaaaaaa.co.kr', isShared: false, shareStatus: '' },
  { id: '10', name: '김민지', userEmail: 'kim@aaaaaaa.co.kr', isShared: false, shareStatus: '' },
  { id: '11', name: '최영호', userEmail: 'choi@aaaaaaa.co.kr', isShared: false, shareStatus: '' },
  { id: '12', name: '정민호', userEmail: 'jeong@aaaaaaa.co.kr', isShared: false, shareStatus: '' },
]);

const driveFileUploadList = ref([]);
const defaultDriveFileList = ref([
  { id: 'favorite', category: 'favorite', name: '중요문서함', type: 'folder' },
  { id: 'share', category: 'share', name: '공유문서함', type: 'folder' },
  { id: 'myDrive', category: 'myDrive', name: '내 드라이브', type: 'folder' },
  { id: 'departmentDrive', category: 'departmentDrive', name: '부서 드라이브', type: 'folder' },
  { id: 'companyDrive', category: 'companyDrive', name: '전사 드라이브', type: 'folder' },
]);
const driveFileList = ref(defaultDriveFileList.value);

// const driveFileUploadList = ref([]);

const modalTr = ref(null);

/* 최근/현재 클릭한 문서 추적 (payload content에 사용) */
const currentDoc = ref(null);

const thList = ['이름', '작성자', '수정날짜', '파일크기'];
const aiThList = ['이름', '작성자', '수정날짜'];

const menuList = reactive([
  { id: 'home', type: 'button', icon: 'Home', size: 18, label: '홈', check: true, disabled: false },
  { id: 'aiBox', type: 'button', icon: 'LinkGraph', size: 20, label: 'S-Box', check: false, disabled: false },
  { id: 'divider', type: 'divider' },
  { id: 'favorite', type: 'button', icon: 'Star', size: 20, label: '중요 문서함', check: false, disabled: true },
  { id: 'shareDrive', type: 'button', icon: 'UserGroup', size: 20, label: '공유 문서함', check: false, disabled: true },
  { id: 'divider', type: 'divider' },
  { id: 'myDrive', type: 'button', icon: 'User', size: 20, label: '내 드라이브', check: false, disabled: false },
  { id: 'departmentDrive', type: 'button', icon: 'Bag', size: 20, label: '부서 드라이브', check: false, disabled: false },
  { id: 'companyDrive', type: 'button', icon: 'Bag', size: 20, label: '전사 드라이브', check: false, disabled: false },
  { id: 'divider', type: 'divider' },
  { id: 'trash', type: 'button', icon: 'DeleteOutline', size: 20, label: '휴지통', check: false, disabled: true },
]);

const trList = reactive([
  {
    id: '1234',
    name: '2025년 상반기 헬프나우 전략 기획안',
    author: '박기철',
    updatedTime: '2025-08-27',
    createdTime: '2025-08-27',
    fileSize: '128349',
    type: 'pdf',
    position: '',
    selected: false,
    content: '샘플 컨텐츠 A',
  },
  {
    id: '1235',
    name: '2025년 하반기 마케팅 플랜',
    author: '이수진',
    updatedTime: '2025-09-01',
    createdTime: '2025-08-30',
    fileSize: '93456',
    type: 'docx',
    position: '',
    selected: false,
    content: '샘플 컨텐츠 B',
  },
]);
const isAllNodeIdsValid = ref(false);
const authorSearchValue = ref('');
const selectedCategory = ref('');

const selectedTrList = computed(() => trList.filter(tr => tr.selected).length);
const selectedAllRow = computed({
  get() {
    if (!trList.length) return false;
    const checked = trList.filter(tr => tr.selected).length;
    return checked > 0 && checked === trList.length;
  },
  set(val) {
    trList.forEach(tr => (tr.selected = !!val));
  },
});

// 브레드크럼 경로 계산
const breadcrumbPath = computed(() => {
  if (!currentDirectory.value?.directoryIdPath) return [];

  // directoryIdPath에서 ID들을 추출 (첫 번째 "/" 제거)
  const pathIds = currentDirectory.value.directoryIdPath.split('/').filter(id => id);

  // path에서 이름들을 추출 (첫 번째 "/" 제거)
  const pathNames = currentDirectory.value.position?.split('/').filter(name => name) || [];

  // ID와 이름을 매핑하여 브레드크럼 아이템 생성
  const breadcrumbItems = [];
  for (let i = 0; i < pathIds.length; i++) {
    if (pathNames[i]) {
      breadcrumbItems.push({
        id: pathIds[i],
        name: pathNames[i],
      });
    }
  }

  return breadcrumbItems;
});

// 분석실행
const sBoxRunAnalysis = () => {
  currentAiBoxDetail.value = true;

  // trList에서 체크된 항목들의 이름을 S-Box 이름으로 설정
  const selectedItems = trList.filter(tr => tr.selected);
  if (selectedItems.length > 0) {
    sBoxName.value = selectedItems.map(item => item.name).join(', ');
  } else {
    sBoxName.value = 'S-Box';
  }

  // filePromptValue가 있으면 채팅으로 전달
  if (filePromptValue.value.trim()) {
    // AiBoxWrapper에 프롬프트 내용을 전달하기 위해 이벤트 발생
    // 또는 직접 suggestSendChat 호출
    suggestSendChat(filePromptValue.value.trim(), true);
  }
};

// 뒤로가기 처리
const handleGoBack = () => {
  currentAiBoxDetail.value = false;
};

function deleteSharedUser() {
  sharedUserList.value = sharedUserList.value.filter(u => u.id !== selectedSharedUser.value.id);
}

const toast = useToast();
const customToast = useCustomToast();

// 파일매니저 도메인 훅
const { uploadSBoxFiles } = useFileManage();

onMounted(async () => {
  // 인덱싱 부분 넣어야하는 부분 여기서 호출
  // [GET]https://bb8-api-proxy.dev.helpnow.ai/filemgr-dev/knowledge-docs/agents/d1bd5af9-6bc2-4e5a-80f7-179ba37806ac/docs/size
  searchDocuments('', pageViewId.value);
  filterUserList.value = [...userList.value];

  // S-Box 파일 목록 자동 업데이트 타이머 시작
  sBoxUpdateTimer = setInterval(() => {
    updateSBoxFileList();
  }, 3000);

  // 파일매니저 API 호출
  // try {
  //   const agentCode = store.getters.session?.chatbotCode || 'd1bd5af9-6bc2-4e5a-80f7-179ba37806ac';
  //   const response = await fileManageApi.getDocsSize(agentCode);
  //
  //   // 응답값으로 용량 정보 업데이트
  //   if (response.data) {
  //     storageInfo.value.limitStorageSize = response.data.limitStorageSize;
  //     storageInfo.value.totalIndexedSize = response.data.totalIndexedSize;
  //     storageInfo.value.usagePercentage = (response.data.totalIndexedSize / response.data.limitStorageSize) * 100;
  //   }
  //
  // } catch (error) {
  //   customToast.error('파일 상태 확인 중 문제가 발생했습니다.', {
  //     showCloseButton: true,
  //     autoClose: false,
  //   });
  // }
});

// S-Box 파일 목록 자동 업데이트 타이머
let sBoxUpdateTimer = null;
// 이전 trList 상태를 저장하는 변수
let previousTrListState = null;
// 변경된 항목의 ID를 저장하는 배열
const updatedItemIds = ref([]);

onBeforeUnmount(() => {
  // 컴포넌트 언마운트 시 타이머 정리
  if (sBoxUpdateTimer) {
    clearInterval(sBoxUpdateTimer);
    sBoxUpdateTimer = null;
  }
});

function handleSelectedListClear() {
  trList.forEach(tr => (tr.selected = false));
}

function handleTrClick(tr) {
  if (selectedCategory.value === 'aiBox') {
    currentDoc.value = tr; // 마지막 클릭 항목 저장
    // handleSelectedListClear();
    handleSummaryClick('openAiBoxDir', tr);
  } else {
    tr.selected = !tr.selected;
    if (tr.type !== 'directory') {
      currentDoc.value = tr; // 마지막 클릭 항목 저장
    }
  }
}

function handleTabClick(tabId) {
  currentTab.value = tabId;
}

function handleCardDblClick(tr) {

  currentDoc.value = tr; // 마지막 클릭 항목 저장

  if (tr.type !== 'directory') {
    return;
  }

  // 디렉토리일 때는 디렉토리 클릭 처리

  if (tr.type === 'directory' && pageViewType.value !== 'aiBox') {
    handleDirectoryClick(tr);
  } else {
    if (currentDoc.value.nodeId) {
      currentAiBoxDetail.value = true;
    } else {
      customToast.error(`S-Box 파일을 분석중입니다. 잠시 후 다시 시도해주세요.`, {
        showCloseButton: true,
        autoClose: false,
      })
      return;
    }

  }
}

function handleAiAnalysisPanelClick(panel) {
  currentTabPanel.value = panel.id;

  aiAnalysisPanels.value.forEach(p => p.checked = false);
  panel.checked = true;
}


/**
 * 디렉토리 클릭 시 처리하는 함수
 * @param {Object} directory - 클릭된 디렉토리 정보
 */
function handleDirectoryClick(directory) {
  // 디렉토리 클릭 시 처리 로직
  // 이어지는 작업은 사용자가 처리할 예정
  console.log('디렉토리 클릭:', directory);
  currentDirectory.value = directory;
  console.log('currentDirectory', currentDirectory.value);
  searchDocuments('', pageViewId.value, false, '', '', directory.id);
}

function handleTypeClick(type) {
  viewType.value = type;
}

function toggleDriveDrop(event, type, selectedItem) {
  driveDropPosition.x = event.clientX;
  driveDropPosition.y = event.clientY - 10;
  dropType.value = type;
  isDriveDrop.value = true;

  type === 'shareStatus' ? selectedSharedUser.value = selectedItem : {};

  if (type === 'card') {
    modalTr.value = selectedItem;
    currentDoc.value = selectedItem; // 카드 메뉴 클릭 기준 추적
  }
}

function handleMenuClick(item) {
  currentDirectory.value = null;
  currentAiBoxDetail.value = false;
  pageViewType.value = item.id;
  pageViewLabel.value = item.label;
  pageViewId.value = item.id;
  menuList.forEach(menu => {
    menu.check = menu.id === item.id;
  });
  if (item.id === 'home') {
    console.log('handleMenuClick home');
    searchDocuments('', 'myDrive');
  } else if (item.id === 'aiBox') {
    isFileListOpen.value = false;
    console.log('handleMenuClick aiBox');
    searchDocuments('', 'aiBox');
  } else if (item.id === 'trash') {
    console.log('handleMenuClick trash');
    searchDocuments('', 'myDrive', true);
  } else {
    console.log('handleMenuClick else', pageViewId.value);
    searchDocuments('', pageViewId.value);
  }
  currentSideType.value = '';
  isAsideOpen.value = false;
  driveFileUploadList.value = [];
}

// sBox 탭에서 클릭 후 아이템 클릭 시 헬퍼 함수
async function showSBoxFileListPanel() {
  isAsideOpen.value = true;        // 우측 패널 열기
  currentSideType.value = 'sBox';  // sBox 패널
  currentTab.value = 'fileList';   // 파일목록 탭 노출

  // 현재 선택된 파일들만 표시 (전체 S-Box 목록을 로드하지 않음)
  // driveFileUploadList에 이미 선택된 파일들이 있으므로 별도 로드 불필요
}

function closeAsideOpen() {
  isAsideOpen.value = false;
  currentSideType.value = '';
  driveFileUploadList.value = [];
}

function handleFolderClick(folder) {
  console.log('handleFolderClick', folder);
}

function handleSearchUserClick(user) {
  filterSearchDocuments('author', user.name);
  isDriveDrop.value = false;
  authorSearchValue.value = '';
}

function toggleDriveModal(type, selectedItem) {

  // pageViewType이 'aiBox'인 경우에는 파일이 없어도 모달을 열 수 있어야 함

  if (
    type === 'aiBox' &&
    pageViewType.value !== 'aiBox' &&
    driveFileUploadList.value.length === 0
  ) {
    customToast.info('저장할 파일이 없습니다.');
    return;
  }

  modalType.value = type;
  sBoxDirectoryName.value = '';
  // 객체 타입 판단
  const isDirectory = selectedItem?.type === 'directory';
  const isDocument = selectedItem?.type && selectedItem.type !== 'directory';
  isDocument;

  switch (type) {
    case 'edit':
      modalTitle.value = isDirectory ? '폴더 수정' : '문서 수정';
      break;
    case 'delete':
      modalTitle.value = isDirectory ? '폴더 삭제' : '문서 삭제';
      break;
    case 'share':
      modalTitle.value = '문서 공유';
      break;
    case 'aiBox':
      modalTitle.value = 'AI Box 추가';
      break;
  }

  modalTr.value = selectedItem;
  isOpenModal.value = true;
  isDriveDrop.value = false;

  if (selectedItem) {
    currentDoc.value = selectedItem; // 카드 메뉴 클릭 기준 추적
    if (type === 'edit') {
      documentInfo.value.title = selectedItem.name; // 편집 모달일 때 현재 문서/폴더 이름 설정
      documentInfo.value.password = selectedItem?.password || ''; // 편집 모달일 때 현재 문서 암호 설정
      documentInfo.value.tags = selectedItem?.tags || []; // 편집 모달일 때 현재 문서 태그 설정
    }
  }
}

function handleAuthorSearchInput(value) {
  // userList 배열에서 userName에 value가 포함된 모든 사용자를 찾는 함수
  filterUserList.value = [];
  if (value && value.trim() !== '') {
    filterUserList.value = userList.value.filter(user => user.userName.includes(value));
  } else {
    filterUserList.value = userList.value;
  }
}

function changeSharedUserStatus(status) {
  selectedSharedUser.value.shareStatus = status;
}

function toggleDirectoryModal() {
  isDriveDrop.value = false;
  isOpenDirectoryModal.value = true;
}

function handleDirectoryModalClose() {
  isOpenDirectoryModal.value = false;
}

async function handleDirectoryModalSendData() {
  try {
    const agentCode = getDomainInfo().chatbotCode;
    const email = store.state.loginUser.userEmail;
    const userNm = store.state.loginUser.userNm;
    await createDocumentDirectory(editDirectoryNameValue.value, pageViewId.value === 'home' ? 'myDrive' : pageViewId.value, currentDirectory.value?.id, agentCode, email, userNm);
    customToast.success('폴더가 생성되었습니다.', {
      showCloseButton: true,
      autoClose: false,
    });
    nextTick(() => {
      searchDocuments('', pageViewId.value, false, '', '', currentDirectory.value?.id);
    });
  } catch (error) {
    customToast.error('폴더 생성 중 문제가 발생했습니다. 잠시 후 다시 시도해주세요.', {
      showCloseButton: true,
      autoClose: false,
    });
  } finally {
    editDirectoryNameValue.value = '';
    isOpenDirectoryModal.value = false;
  }
}

function handleModalClose() {
  isOpenModal.value = false;
  documentInfo.value.title = ''; // 모달 닫을 때 입력값 초기화
  documentInfo.value.password = ''; // 모달 닫을 때 입력값 초기화
  documentInfo.value.tags = []; // 모달 닫을 때 입력값 초기화
  sBoxDirectoryName.value = '';
}

// S-Box 저장 함수
async function handleSBoxSave() {


  const sessionId = uuidv1();

  try {
    // 버튼 클릭 즉시 우측 패널 열기
    // await showSBoxFileListPanel();

    const agentCode = getDomainInfo().chatbotCode;
    const email = store.state.loginUser.userEmail;
    const userNm = store.state.loginUser.userNm;
    console.log('driveFileUploadList', driveFileUploadList);


    // 파일이 선택되었는지 확인
    if (!driveFileUploadList.value || driveFileUploadList.value.length === 0) {
      customToast.error('S-Box에 담을 파일을 선택해주세요.', {
        showCloseButton: true,
        autoClose: false,
      });
      return;
    }

    // 업로드 상태 초기화
    uploadStatus.isUploading = true;
    uploadStatus.status = 'pending';

    let directoryResponse;

    // 이미 S-Box 디렉토리가 생성되어 있는지 확인
    if (sBoxDirectoryId.value) {
      directoryResponse = { id: sBoxDirectoryId.value };
    } else {
      // 디렉토리가 생성되지 않은 경우 에러
      customToast.error('S-Box 디렉토리가 생성되지 않았습니다.', {
        showCloseButton: true,
        autoClose: false,
      });
      return;
    }

    // 선택 파일 복사
    const copyResults = [];
    const copyPromises = driveFileUploadList.value
      .map(async (file) => {
        try {
          if (!file.id) {
            customToast.error(`파일 ID가 없습니다: ${file.name}`, {
              showCloseButton: true,
              autoClose: false,
            });
            return null;
          }

          const result = await copyDocument(
            file.id,
            'aiBox',
            directoryResponse.id,
            file.name,
            userNm,
            email,
            agentCode,
          );

          // 복사 완료 표시 및 결과 저장
          file.copied = true;
          file.copiedDocumentKey = result.documentKey;
          file.content = result.content || '';
          copyResults.push(result);
          return result;
        } catch (error) {
          customToast.error(`파일 복사 실패: ${file.name} - ${error.message}`, {
            showCloseButton: true,
            autoClose: false,
          });
          throw error;
        }
      });
    await Promise.all(copyPromises);

    // 파일매니저 API로 S-Box 파일 업로드
    let uploadSuccess = false;
    try {
      // copyResults에서 documentKey 추출
      const documentKeys = copyResults.map(result => result.documentKey);
      const worker = { email, name: userNm };
      const uploadResult = await uploadSBoxFiles(agentCode, documentKeys, worker, sBoxDirectoryName.value || 'S-Box', sessionId);

      if (uploadResult.success) {
        uploadSuccess = true;
      } else {
        uploadSuccess = false;
      }
    } catch (uploadError) {
      uploadSuccess = false;
    }

    // 업로드 완료 처리
    if (uploadSuccess) {
      uploadStatus.isUploading = false;
      uploadStatus.status = 'completed';

      // 성공 메시지 표시
      const selectedFileNames = driveFileUploadList.value.map(file => file.name);
      const fileNamesText = selectedFileNames.length > 0 ? selectedFileNames.join(', ') : '선택된 파일';

      customToast.success(`S-Box 업로드가 완료되었습니다. (${fileNamesText})`, {
        showCloseButton: true,
        autoClose: false,
      });

      // 완료 후 상태 초기화 (3초 후)
      setTimeout(() => {
        resetSBoxUploadState();
      }, 3000);
    } else {
      uploadStatus.isUploading = false;
      uploadStatus.status = 'error';
    }
    sBoxDirectoryName.value = '';
  } catch (error) {
    customToast.error('S-Box 저장 중 문제가 발생했습니다. 잠시 후 다시 시도해주세요.', {
      showCloseButton: true,
      autoClose: false,
    });
    uploadStatus.isUploading = false;
    uploadStatus.status = 'error';
    sBoxDirectoryName.value = '';
  }
}
// S-Box 저장 완료 후 상태 초기화 함수
function resetSBoxUploadState() {
  uploadStatus.isUploading = false;
  uploadStatus.status = 'idle';
  uploadStatus.currentCnt = 0;
  uploadStatus.totalCnt = 0;
  uploadStatus.failedCnt = 0;
  uploadStatus.failedFiles = [];
  uploadStatus.successFiles = [];
  uploadStatus.successDocNames = [];
  isAllNodeIdsValid.value = false;

  // 파일 복사 상태 초기화
  driveFileUploadList.value.forEach(file => {
    file.copied = false;
    file.copiedDocumentKey = null;
  });
}

// S-Box 파일 목록 자동 업데이트 함수
async function updateSBoxFileList() {
  // S-Box 카테고리가 선택되어 있을 때만 업데이트
  if (selectedCategory.value === 'aiBox') {
    try {
      // fetchDocumentsData를 직접 호출해서 응답값 받기
      const data = await fetchDocumentsData('aiBox', false, null);

      // 응답에서 directories와 documents 배열 추출
      const currentDirectories = data?.directories || [];
      const currentDocuments = data?.documents || [];

      // searchDocuments와 동일한 형식으로 데이터 변환
      const directoryItems = currentDirectories.map(item => ({
        id: item.id,
        name: item.name,
        author: item.creatorName,
        content: '',
        updatedTime: formatDate(item.updatedAt),
        createdTime: formatDate(item.createdAt),
        fileSize: 0,
        type: 'directory',
        position: item.path,
        directoryIdPath: item.directoryIdPath,
        selected: false,
        category: item.category,
        nodeId: item.nodeId,
        parentId: item.parentId,
      }));

      const documentItems = currentDocuments.map(item => ({
        id: item.documentKey,
        name: item.title,
        author: item.author,
        content: item.content,
        updatedTime: formatDate(item.updatedAt),
        createdTime: formatDate(item.createdAt),
        fileSize: item.fileSize,
        filePath: item.filePath,
        type: item.extension,
        position: '',
        selected: false,
        category: item.category,
        nodeId: item.nodeId,
        parentId: item.parentId,
        knowledgeDocumentIdPath: item.knowledgeDocumentIdPath,
      }));

      // 전체 데이터를 합쳐서 현재 상태 생성
      const currentTrListState = JSON.stringify([...directoryItems, ...documentItems].map(item => ({
        id: item.id,
        name: item.name,
        type: item.type,
        nodeId: item.nodeId,
        parentId: item.parentId,
        updatedAt: item.updatedTime,
        createdAt: item.createdTime,
        author: item.author,
        fileSize: item.fileSize,
        category: item.category,
        directoryIdPath: item.directoryIdPath,
        knowledgeDocumentIdPath: item.knowledgeDocumentIdPath
      })));

      // 이전 상태와 비교해서 변경사항이 없으면 패스
      if (previousTrListState === currentTrListState) {
        return;
      }

      // 변경된 항목 감지
      const changedItemIds = detectChangedItems(previousTrListState, currentTrListState);

      // 변경사항이 있으면 searchDocuments 호출해서 trList 업데이트
      await searchDocuments('', 'aiBox');

      // currentDoc이 설정되어 있다면 업데이트된 trList에서 해당 항목을 찾아서 currentDoc 업데이트
      if (currentDoc.value && currentDoc.value.id) {
        const updatedCurrentDoc = trList.find(item => item.id === currentDoc.value.id);
        if (updatedCurrentDoc) {
          currentDoc.value = updatedCurrentDoc;
        }
      }

      // 변경된 항목에 하이라이트 효과 적용
      if (changedItemIds.length > 0) {
        updatedItemIds.value = changedItemIds;
        
        // 3초 후 하이라이트 효과 제거
        setTimeout(() => {
          updatedItemIds.value = [];
        }, 3000);
      }

      // 현재 상태를 이전 상태로 저장
      previousTrListState = currentTrListState;
    } catch (e) {
      console.error('S-Box 파일 목록 업데이트 실패:', e);
      // 에러가 발생해도 토스트는 표시하지 않음 (자동 업데이트이므로)
    }
  }
}

// 변경된 항목을 감지하는 함수
function detectChangedItems(previousState, currentState) {
  if (!previousState) return [];
  
  try {
    const previousItems = JSON.parse(previousState);
    const currentItems = JSON.parse(currentState);
    
    const changedIds = [];
    
    // 새로 추가된 항목 감지
    const currentIds = new Set(currentItems.map(item => item.id));
    const previousIds = new Set(previousItems.map(item => item.id));
    
    // 새로 추가된 항목
    currentIds.forEach(id => {
      if (!previousIds.has(id)) {
        changedIds.push(id);
      }
    });
    
    // 기존 항목의 변경사항 감지
    previousItems.forEach(prevItem => {
      const currentItem = currentItems.find(item => item.id === prevItem.id);
      if (currentItem) {
        // 중요한 필드들 비교
        const hasChanged = 
          prevItem.name !== currentItem.name ||
          prevItem.nodeId !== currentItem.nodeId ||
          prevItem.parentId !== currentItem.parentId ||
          prevItem.updatedAt !== currentItem.updatedAt ||
          prevItem.author !== currentItem.author ||
          prevItem.fileSize !== currentItem.fileSize;
          
        if (hasChanged) {
          changedIds.push(currentItem.id);
        }
      }
    });
    
    return changedIds;
  } catch (error) {
    console.error('변경된 항목 감지 중 오류:', error);
    return [];
  }
}


async function handleDocumentModal() {
  // 객체 타입 판단
  const isDirectory = modalTr.value?.type === 'directory';
  const isDocument = modalTr.value?.type && modalTr.value.type !== 'directory';

  if (modalType.value === 'edit') {
    if (isDirectory) {
      // 디렉토리 수정
      await updateDocumentDirectory(modalTr.value.id, {
        name: documentInfo.value.title,
        category: pageViewId.value === 'home' ? 'myDrive' : pageViewId.value,
        parentId: currentDirectory.value?.id || null,
        agentCode: getDomainInfo().chatbotCode,
      });
      customToast.success('폴더가 수정되었습니다.');
    } else if (isDocument) {
      // 문서 수정
      await updateDocument(modalTr.value.id, {
        title: documentInfo.value.title,
        password: documentInfo.value.password,
        tags: documentInfo.value.tags,
      });
      customToast.success('문서가 수정되었습니다.');
    }

    isOpenModal.value = false;
    nextTick(() => {
      searchDocuments('', pageViewId.value);
    });
  } else if (modalType.value === 'delete') {
    isOpenModal.value = false;

    try {
      const agentCode = store.getters.session?.chatbotCode || 'd1bd5af9-6bc2-4e5a-80f7-179ba37806ac';

      if (isDirectory) {
        // 디렉토리 삭제 (논리적 삭제)
        await softDeleteDocumentDirectory(modalTr.value.id);
        customToast.success('폴더가 삭제되었습니다.');
      } else if (isDocument) {
        // 문서 삭제
        await deleteDocument(modalTr.value.id);
        customToast.success('문서가 삭제되었습니다.');
      }

      // 추가 삭제 API 호출
      try {
        //  도메인 노드 삭제 API
        if(modalTr.value.nodeId !== '' && modalTr.value.nodeId){
          await fileManageApi.deleteDomainNode(agentCode, modalTr.value.nodeId);
        }

        // 인덱스 크기 재계산 API
        await fileManageApi.recalculateIndexSize(agentCode);

        //  문서 크기 조회 API (로그용)
        await fileManageApi.getDocsSize(agentCode);
      } catch (apiError) {
        customToast.error('파일매니저 상태 업데이트 중 문제가 발생했습니다.', {
          showCloseButton: true,
          autoClose: false,
        });
        isOpenModal.value = false;
      }

    } catch (error) {
      console.error('삭제 실패:', error);
      customToast.error('삭제 중 문제가 발생했습니다. 잠시 후 다시 시도해주세요.', {
        showCloseButton: true,
        autoClose: false,
      });
    }


    nextTick(() => {
      searchDocuments('', pageViewId.value);
    });
    return;
  }

  if (modalType.value === 'aiBox') {
    // S-Box 저장 처리
    if (!sBoxDirectoryName.value.trim()) {
      customToast.error('폴더 이름을 입력해주세요.');
      return;
    }

        try {
      const agentCode = getDomainInfo().chatbotCode;
      const email = store.state.loginUser.userEmail;
      const userNm = store.state.loginUser.userNm;

      // 디렉터리 생성 API 호출
      const directoryResponse = await createDocumentDirectory(
        sBoxDirectoryName.value,
        'aiBox',
        null,
        agentCode,
        email,
        userNm,
      );

      // 생성된 디렉터리 정보 저장
      sBoxDirectoryId.value = directoryResponse.id;

      // 선택된 파일명들 가져오기
      const selectedFileNames = driveFileUploadList.value.map(file => file.name);
      const fileNamesText = selectedFileNames.length > 0 ? selectedFileNames.join(', ') : '선택된 파일';

      customToast.success(`S-Box의 (${sBoxDirectoryName.value})에 (${fileNamesText})이 생성되었습니다.`, {
        showCloseButton: true,
        autoClose: false,
      });
      isOpenModal.value = false;
      currentSideType.value = '';
      isAsideOpen.value = false;
      handleSelectedListClear();
      await handleSBoxSave();
      driveFileUploadList.value = [];
    } catch (error) {
      customToast.error('디렉터리 생성 중 문제가 발생했습니다.', {
        showCloseButton: true,
        autoClose: false,
      });
    }
  }

}

// TAG 핸들링
function handleAddTag(tag) {
  documentInfo.value.tags.push(tag);
}

function handleDeleteTag(tag) {
  documentInfo.value.tags = documentInfo.value.tags.filter((t) => t !== tag);
}

/* position 값 치환 함수 */
function convertPosition(position) {
  const positionMap = {
    'myDrive': '내 드라이브',
    'departmentDrive': '부서 드라이브',
    'companyDrive': '전사 드라이브',
  };
  return positionMap[position] || position;
}

/* size 값 치환 함수 */
function convertFileSize(size) {
  if (!size) return '0 B';

  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let sizeNum = parseInt(size);
  let unitIndex = 0;

  while (sizeNum >= 1024 && unitIndex < units.length - 1) {
    sizeNum /= 1024;
    unitIndex++;
  }

  return `${sizeNum.toFixed(1)} ${units[unitIndex]}`;
}

/* driveFileUploadList에서 아이템 삭제 함수 */
// function removeFromUploadList(fileId) {
//   const index = driveFileUploadList.value.findIndex(item => item.id === fileId);
//   if (index > -1) {
//     driveFileUploadList.value.splice(index, 1);
//   }
// }

/* 데이터를 가져오는 별도 함수 */
async function fetchDocumentsData(category, deleted = false, directoryId = null) {
  try {
    const integratedResponse = await getIntegratedDocumentsList({
      keyword: '',
      category: category,
      deleted: deleted,
      directoryId: directoryId,
    });

    return integratedResponse;
  } catch (error) {
    customToast.error(`데이터 가져오기 오류:`, {
      showCloseButton: true,
      autoClose: false,
    })
    throw error;
  }
}

/* driveFileList에 데이터를 변환하여 넣는 함수 */
function populateDriveFileList(data, category) {
  const convertedData = [];

  // 디렉토리 처리
  if (data && data.directories && data.directories.length > 0) {
    const directories = data.directories.map(item => ({
      id: item.id,
      directoryId: item.id,
      name: item.name,
      type: 'folder',
      size: '-',
      position: convertPosition(category),
      category: category,
      content: '',
      fileSize: 0,
      author: item.creatorName,
      createdAt: item.createdAt,
      updatedAt: item.updatedAt,
      path: item.path,
      directoryIdPath: item.directoryIdPath,
      parentId: item.parentId,
      selected: false,
    }));
    convertedData.push(...directories);
  }

  // 문서 처리
  if (data && data.documents && data.documents.length > 0) {
    const documents = data.documents.map(item => ({
      id: item.documentKey || item.id,
      directoryId: item.directoryId,
      name: item.name || item.title,
      type: 'file',
      size: item.fileSize ? convertFileSize(item.fileSize) : '0 B',
      position: convertPosition(category),
      category: category,
      content: item.content || '',
      fileSize: item.fileSize || 0,
      author: item.author || item.creatorName,
      createdAt: item.createdAt,
      updatedAt: item.updatedAt,
      path: item.path,
      directoryIdPath: item.directoryIdPath,
      parentId: item.parentId,
      selected: false,
    }));
    convertedData.push(...documents);
  }

  driveFileList.value = convertedData;
  console.log('변환된 driveFileList (디렉토리 + 문서):', driveFileList.value);
}

function handleAddFile(doc) {
  const isDuplicate = driveFileUploadList.value.some(item => item.id === doc.id);
  if (isDuplicate) {
    customToast.info(`이미 sBox에 추가된 파일입니다.`, {
      showCloseButton: true,
      autoClose: false,
    })
    return;
  }
  driveFileUploadList.value.push({
    ...doc,
    position: convertPosition(doc.category),
    size: convertFileSize(doc.fileSize),
    content: doc.content || '', // content 속성 추가
    copied: false, // 복사 상태 초기화
    copiedDocumentKey: null, // 복사된 documentKey 초기화
  });
  customToast.success(`${doc.name} 파일이 sBox에 추가되었습니다.`, {
    showCloseButton: true,
    autoClose: false,
  })

  // S-Box 저장 로직은 실행하지 않음 - 단순히 목록에만 추가
}

/* driveFileList 아이템 클릭 함수 */
function handleDriveFileItemClick(item) {

  if (item.type === 'folder') {
    // 기본 드라이브 리스트의 폴더인 경우 (id가 null)
    if (item.id === null) {
      console.log('기본 드라이브 리스트 폴더 클릭:', item.category);
      // 해당 카테고리의 루트 파일 목록 가져오기
      fetchDocumentsData(item.category, false, null)
        .then(data => {
          populateDriveFileList(data, item.category);
          // currentDrivePosition에 카테고리 정보 설정
          currentDrivePosition.value = {
            id: item.name,
            directoryId: null,
            name: item.name,
            type: 'folder',
            category: item.category,
            parentId: null,
            path: '/',
            directoryIdPath: '/',
            author: '',
            createdAt: '',
            updatedAt: '',
          };
          currentDirectory.value = null;
        })
        .catch(() => {
          customToast.error('파일 목록을 불러오는 중 문제가 발생했습니다.', {
            showCloseButton: true,
            autoClose: false,
          });
        });
    } else {
      // 실제 폴더인 경우 해당 폴더로 이동
      currentDirectory.value = item;

      // 현재 드라이브 위치에 폴더 정보 저장 (필요한 모든 정보 포함)
      currentDrivePosition.value = {
        id: item.id,
        directoryId: item.directoryId,
        name: item.name,
        type: item.type,
        category: item.category,
        parentId: item.parentId,
        path: item.path,
        directoryIdPath: item.directoryIdPath,
        author: item.author,
        createdAt: item.createdAt,
        updatedAt: item.updatedAt,
      };


      // 폴더 내부 파일 목록 가져오기
      fetchDocumentsData(item.category, false, item.directoryId)
        .then(data => {
          console.log('폴더 내부 데이터 가져오기 완료, currentDrivePosition 유지:', currentDrivePosition.value);
          populateDriveFileList(data, item.category);
          console.log('populateDriveFileList 완료 후 currentDrivePosition:', currentDrivePosition.value);
        })
        .catch(() => {
          customToast.error('폴더 내부 파일 목록을 불러오는 중 문제가 발생했습니다.', {
            showCloseButton: true,
            autoClose: false,
          });
        });
    }
  }
}

/* 카테고리 표시명 가져오기 함수 */
function getCategoryDisplayName(category) {
  const categoryMap = {
    'favorite': '중요문서함',
    'share': '공유문서함',
    'myDrive': '내 드라이브',
    'departmentDrive': '부서 드라이브',
    'companyDrive': '전사 드라이브',
  };
  return categoryMap[category] || category;
}

/* 기본 드라이브 리스트 표시 함수 */
function showDefaultDriveList() {
  driveFileList.value = [...defaultDriveFileList.value];
  currentDrivePosition.value = null;
  currentDirectory.value = null;
  console.log('기본 드라이브 리스트 표시 완료:', driveFileList.value);
  console.log('currentDrivePosition 초기화:', currentDrivePosition.value);
}

/* 뒤로가기 함수 - 상위 디렉토리로 이동 */
async function handleBackToParent() {

  if (!currentDrivePosition.value) {
    return;
  }

  try {
    // 상위 디렉토리 ID 가져오기
    const parentId = currentDrivePosition.value.parentId;

    if (parentId) {
      // 상위 디렉토리가 있는 경우
      fetchDocumentsData(currentDrivePosition.value.category, false, parentId)
        .then(data => {
          populateDriveFileList(data, currentDrivePosition.value.category);
          // 상위 디렉토리 정보로 currentDrivePosition 업데이트
          const parentDirectory = data.directories?.find(dir => dir.id === parentId);
          if (parentDirectory) {
            currentDrivePosition.value = {
              id: parentDirectory.id,
              directoryId: parentDirectory.id,
              name: parentDirectory.name,
              type: 'folder',
              category: currentDrivePosition.value.category,
              parentId: parentDirectory.parentId,
              path: parentDirectory.path,
              directoryIdPath: parentDirectory.directoryIdPath,
              author: parentDirectory.creatorName,
              createdAt: parentDirectory.createdAt,
              updatedAt: parentDirectory.updatedAt,
            };
            currentDirectory.value = currentDrivePosition.value;
            console.log('뒤로가기 후 currentDrivePosition:', currentDrivePosition.value);
          } else {
            // 상위 디렉토리가 없으면 카테고리 레벨로 이동
            const categoryName = getCategoryDisplayName(currentDrivePosition.value.category);
            currentDrivePosition.value = {
              id: null,
              directoryId: null,
              name: categoryName,
              type: 'folder',
              category: currentDrivePosition.value.category,
              parentId: null,
              path: '/',
              directoryIdPath: '/',
              author: '',
              createdAt: '',
              updatedAt: '',
            };
            currentDirectory.value = null;
            console.log('카테고리 레벨로 이동 - currentDrivePosition:', currentDrivePosition.value);
          }
        })
        .catch(() => {
          customToast.error('상위 폴더를 불러오는 중 문제가 발생했습니다.', {
            showCloseButton: true,
            autoClose: false,
          });
        });
    } else {
      // 상위 디렉토리가 없는 경우 (루트로 이동) - defaultDriveFileList 표시
      showDefaultDriveList();
    }
  } catch (error) {
    customToast.error(`뒤로가기 처리 중 오류가 발생했습니다.`, {
      showCloseButton: true,
      autoClose: false,
    })
  }
}

/* 선택 목록 요약 -> 채팅 전송 */
async function handleSummaryClick(type, item = null) {
  currentSideType.value = type;
  // driveFileUploadList.value = [];
  const selectedDocs = trList.filter(tr => tr.selected);

  // type에 따른 분기 처리
  switch (type) {
    case 'summary': {

      // sBox에 담긴 파일만 요약
      console.log('item', item);
      const pathList = item.knowledgeDocumentIdPath ? [item.knowledgeDocumentIdPath.replace('/mnt/efs', '')] : [item.filePath.replace('/mnt/efs', '')];

      isAsideOpen.value = true;
      await nextTick(); // DOM 업데이트 대기
      await suggestSendChat('', false, pathList);

      // aside-body 스크롤을 맨 아래로
      setTimeout(() => {
        if (asideBodyRef.value) {
          asideBodyRef.value.scrollTo({
            top: asideBodyRef.value.scrollHeight,
            behavior: 'smooth',
          });
        }
      }, 200);
      break;
    }

    case 'sBox': {
      // sBox 담기 처리 로직
      const folders = selectedDocs.filter(doc => doc.type === 'directory');
      const files = selectedDocs.filter(doc => doc.type !== 'directory');

      if (folders.length > 0) {
        customToast.info(`폴더는 sBox에 담을 수 없습니다. 파일만 추가됩니다.`, {
          showCloseButton: true,
          autoClose: false,
        });
        handleSelectedListClear();
      }

      if (files.length === 0) return;

      // 중복 파일 체크
      const duplicateFiles = [];
      const newFiles = [];

      files.forEach(doc => {
        const isDuplicate = driveFileUploadList.value.some(item => item.id === doc.id);
        if (isDuplicate) {
          duplicateFiles.push(doc.name);
        } else {
          newFiles.push(doc);
        }
      });

      // 중복 파일이 있는 경우 알림
      if (duplicateFiles.length > 0) {
        const duplicateNames = duplicateFiles.join(', ');
        customToast.info(`이미 sBox에 추가된 파일입니다: ${duplicateNames}`, {
          showCloseButton: true,
          autoClose: false,
        });
      }

      // 새 파일들만 driveFileUploadList에 추가
      newFiles.forEach(doc => {
        const convertedDoc = {
          id: doc.id,
          name: doc.name,
          type: doc.type,
          author: doc.author,
          updatedTime: doc.updatedTime,
          fileSize: doc.fileSize,
          filePath: doc.filePath,
          content: doc.content || '', // content 속성 추가
          position: convertPosition(doc.category),
          size: convertFileSize(doc.fileSize),
          selected: false,
          copied: false,
          copiedDocumentKey: null,
        };
        driveFileUploadList.value.push(convertedDoc);
      });


      // 우측 패널만 열기 (S-Box 저장 로직은 실행하지 않음)
      showSBoxFileListPanel();
      break;
    }

    case 'openAiBoxDir': {
      if (!item) return;

      //  디렉토리 클릭: 해당 디렉토리의 파일들을 sBox 목록(driveFileUploadList)에 채워 넣기
      if (item.type === 'directory') {
        const dirId = item.directoryId || item.id;

        // 선택 해제(원치 않는 기본 선택 전송 방지)
        trList.forEach(tr => (tr.selected = false));

        try {
          const data = await fetchDocumentsData('aiBox', false, dirId);
          const docs = (data?.documents || []).map(d => ({
            id: d.documentKey || d.id,
            name: d.name || d.title,
            category: 'aiBox',
            fileSize: d.fileSize || 0,
            type: d.extension || 'file',
            content: d.content || '',
            filePath: d.filePath,
            knowledgeDocumentIdPath: d.knowledgeDocumentIdPath,
          }));

          //  sBox 파일목록으로 세팅
          driveFileUploadList.value = docs.map(dd => ({
            ...dd,
            position: convertPosition('aiBox'),
            size: convertFileSize(dd.fileSize),
            copied: false, // 복사 상태 초기화
            copiedDocumentKey: null, // 복사된 documentKey 초기화
          }));

          // S-Box 패널의 fileList 탭 보여주기
          showSBoxFileListPanel();
        } catch (e) {
          customToast.error('폴더 내부 파일 목록을 불러오는 중 문제가 발생했습니다.', {
            showCloseButton: true,
            autoClose: false,
          });
        }
        return;
      }

      //  파일 클릭: 해당 파일만 sBox에 추가하고 fileList 탭 보여주기
      handleAddFile(item);
      showSBoxFileListPanel();
      return;
    }


    default:
      console.warn('알 수 없는 type:', type);
      break;
  }
}

function filterSearchDocuments(searchType, searchValue) {
  console.log('filterSearchDocuments', searchType, searchValue);
  searchDocuments('', pageViewId.value == 'home' ? 'myDrive' : pageViewId.value, false, searchType, searchValue, currentDirectory.value?.id);
  isDriveDrop.value = false;
}
function resetSearchResult() {
  searchDocuments('', pageViewId.value);
}

async function searchDocuments(payload, category, deleted, searchType, searchValue, directoryId) {
  isDriveDrop.value = false;
  selectedCategory.value = category;
  const integratedResponse = await getIntegratedDocumentsList(
    {
      keyword: payload,
      category: category ? category : pageViewId.value,
      searchType: searchType,
      searchValue: searchValue,
      agentCode: getDomainInfo().chatbotCode,
      directoryId: directoryId ? directoryId : null,
      documentStatus: deleted ? 'DELETED' : 'ACTIVE',
      directoryStatus: deleted ? 'DELETED' : 'ACTIVE',
      sortBy: 'createdAt',
      sortDirection: 'DESC',
    });
  // documents와 directories를 합쳐서 documentData 구성
  const documents = integratedResponse.documents || [];
  const directories = integratedResponse.directories || [];

  // documents를 기존 형식으로 변환
  // aiBox 카테고리가 아닌 경우에만 nodeId, parentId 필터링 적용
  const documentItems = documents
    .map(item => ({
      id: item.documentKey,
      name: item.title,
      author: item.author,
      content: item.content,
      updatedTime: formatDate(item.updatedAt),
      createdTime: formatDate(item.createdAt),
      fileSize: convertFileSize(item.fileSize),
      filePath: item.filePath,
      type: item.extension,
      position: '',
      selected: false,
      category: item.category,
      nodeId: item.nodeId,
      parentId: item.parentId,
      knowledgeDocumentIdPath: item.knowledgeDocumentIdPath,
    }));

  // directories를 기존 형식에 맞춰 변환
  // aiBox 카테고리가 아닌 경우에만 nodeId, parentId 필터링 적용
  const directoryItems = directories
    .map(item => ({
      id: item.id,
      name: item.name,
      author: item.creatorName,
      content: '',
      updatedTime: formatDate(item.updatedAt),
      createdTime: formatDate(item.createdAt),
      fileSize: 0,
      type: 'directory',
      position: item.path,
      directoryIdPath: item.directoryIdPath,
      selected: false,
      category: item.category,
      nodeId: item.nodeId,
      parentId: item.parentId,
    }));

  // 두 배열을 합쳐서 trList에 추가
  trList.length = 0;
  [...directoryItems, ...documentItems].forEach(item => {
    trList.push(item);
  });

  // currentDoc이 설정되어 있다면 업데이트된 trList에서 해당 항목을 찾아서 currentDoc 업데이트
  if (currentDoc.value && currentDoc.value.id) {
    const updatedCurrentDoc = trList.find(item => item.id === currentDoc.value.id);
    if (updatedCurrentDoc) {
      currentDoc.value = updatedCurrentDoc;
    }
  }
}

/**
 * 문서 다운로드
 * @param {string} documentKey - 다운로드할 문서 키값
 * @param {Event} event - 클릭 이벤트 객체
 */
async function callDownloadDocument(documentKey, filename) {
  try {
    const response = await downloadDocument(documentKey, filename);
    customToast.info(`${response.filename} 파일이 다운로드되었습니다.`, {
      showCloseButton: true,
      autoClose: false,
    });
  } catch (error) {
    customToast.error('파일 다운로드 중 오류가 발생했습니다.', {
      showCloseButton: true,
      autoClose: false,
    });
  }
}

/**
 * 파일 탐색기가 호출되고 해당 파일이 입력되면 해당 파일을 서버의 업로드 api 에 요청, 업로드 완료 후 파일 목록 업데이트
 */
async function callUploadDocument() {
  // 숨겨진 파일 input 요소 생성
  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.multiple = true; // 다중 파일 선택 허용
  fileInput.accept = '.pdf,.txt,.csv,.doc,.docx,.xls,.xlsx,.hwp,.hwpx'; // 허용할 파일 형식
  fileInput.style.display = 'none';

  // 파일 선택 이벤트 리스너 추가
  fileInput.addEventListener('change', async (event) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    try {
      // 업로드 시작 토스트
      customToast.info(`${files.length}개 파일 업로드 중입니다...`);


      const sessionId = session.value.session_id;
      const agentCode = getDomainInfo().chatbotCode;
      const email = store.state.loginUser.userEmail;
      const userNm = store.state.loginUser.userNm;

      // 다중 파일 업로드 API 호출
      const uploadParams = {
        sessionId: sessionId,
        files: files,
        agentCode: agentCode,
        email: email,
        userNm: userNm,
        category: pageViewId.value === 'home' ? 'myDrive' : pageViewId.value,
        directoryId: currentDirectory.value?.id,
      };


      await uploadMultipleDocFiles(uploadParams);

      // 성공 토스트
      customToast.success(`${files.length}개 파일이 성공적으로 업로드되었습니다.`, {
        showCloseButton: true,
        autoClose: false,
      });

      // 파일 목록 새로고침
      console.log('callUploadDocument', pageViewId.value);
      await searchDocuments('', pageViewId.value, false, '', '', currentDirectory.value?.id);

    } catch (error) {
      customToast.error('파일 업로드 중 문제가 발생했습니다. 잠시 후 다시 시도해주세요.', {
        showCloseButton: true,
        autoClose: false,
      });
    } finally {
      // 파일 input 정리
      document.body.removeChild(fileInput);
    }
  });

  // 파일 input을 DOM에 추가하고 클릭 이벤트 발생
  document.body.appendChild(fileInput);
  fileInput.click();
}

/**
 * file extension 에 따라 WorkType, PdfType, CsvType, DocType 아이콘 변경
 */
const getFileIconAiBox = (nodeId) => {
  // nodeId가 빈 문자열이면 빨간색 드라이브 아이콘, 있으면 초록색 드라이브 아이콘
  if (!nodeId || nodeId === '') {
    return 'FolderOff';
  } else {
    return 'FolderOn';
  }
};

function getFileIcon(extension) {
  switch (extension) {
    case 'txt':
      return 'WordType';
    case 'csv':
      return 'CsvType';
    case 'pdf':
      return 'PdfType';
    case 'directory':
      return 'Drive';
    case 'hwp':
      return 'HwpType';
    case 'hwpx':
      return 'HwpType';
    default:
      return 'WordType';
  }
}

/* =========================
 * AI 박스 - 챗버블/입력 (SSE + 파일 업로드 연동)
 * ========================= */
const store = useStore();
const { t } = useI18n();

  // 채팅 상태
  const chatList = ref([]);
  // const isChatLoading = ref(false);
  const isStreaming = ref(false); // 실시간 스트리밍 상태

// 스크롤 헬퍼
const { onGoBottomRef } = useChatView();
const chatScrollRef = ref(null);
const asideBodyRef = ref(null);

function onBubbleMounted(el) {
  if (!el) return;
  chatScrollRef.value = el;
  onGoBottomRef(chatScrollRef);
}

// 파일 업로드(공용 컴포저블) - QueryInputer와 바인딩
const {
  fileList,
  // handleFileUpload,
  // handleFileIds,
  // onFileUploadError,
  // clearAllFiles,
  // onFileProcessed,
} = useFileAttachments();

// AbortController
let chatAbortCtrl = null;
// const uploadAbortCtrl = new AbortController();
const keepFilesAfterSend = ref(false);

// marked 렌더러 (스트리밍 변환)
const marked = require('marked');

function renderMarkdownStream(letters) {
  if (!letters) return;
  const renderer = new marked.Renderer();
  renderer.link = (href, title, text) =>
    `<a href=${href} target="_blank" style="text-decoration: underline;">${text}</a>`;
  renderer.code = (code, language) =>
    `<pre class="custom-code-block"><code class="language">${language || ''}<br/>${code}</code></pre>`;

  // 취소선(strikethrough) 렌더러를 비활성화하여 ~ 문자를 그대로 표시
  renderer.del = (text) => text;

  marked.setOptions({
    renderer,
    gfm: true,
    headerIds: false,
    tables: true,
    breaks: true,
    pedantic: false,
    smartLists: true,
    smartypants: false,
  });
  // 데이터 전처리
  // letters = letters.replace(/\|\n\n\|/g, '|\n|');

  // 데이터 전처리 - 표 렌더링을 위한 개행 처리

  // 표 시작 전에 빈 줄 추가 (마크다운 표 인식을 위해)
  letters = letters.replace(/([^\n])\n(\|)/g, '$1\n\n$2');  // 표 시작 전에 빈 줄 추가
  letters = letters.replace(/^(\|)/gm, '\n$1');              // 문서 시작이 표인 경우

  // 표 구분자 정리
  letters = letters.replace(/\|\n\n\|/g, '|\n|');           // 빈 줄이 있는 표 구분자 정리
  letters = letters.replace(/\|\s*\n\s*\|/g, '|\n|');       // 파이프 사이의 공백과 개행 정리
  letters = letters.replace(/\|\|/g, '|\n|');               // 연속된 파이프를 개행으로 분리

  // 표의 각 행이 제대로 구분되도록 처리
  letters = letters.replace(/(\|[^|\n]*\|)\s*\n\s*(\|[^|\n]*\|)/g, '$1\n$2');

  // 연속된 빈 줄 정리 (표는 보존)
  letters = letters.replace(/\n\n\n+/g, '\n\n');
  return marked(letters);
}


// 업로드 상태 가드
function readyToSend() {
  const isFileLoading = store.getters.getIsFileLoading;
  if (isFileLoading) {
    customToast.info(`파일 업로드가 진행 중입니다. 업로드 완료 후 전송이 가능합니다.`, {
      showCloseButton: true,
      autoClose: false,
    });
    return false;
  }
  if (fileList.value.length && !fileList.value.every(f => f?.status === 'uploaded')) {
    customToast.info(`파일 업로드가 아직 완료되지 않았습니다. 업로드 완료 후 전송해 주세요.`, {
      showCloseButton: true,
      autoClose: false,
    });
    return false;
  }
  return true;
}

// 완료/취소 마킹
function completeLastBubble(answer = '') {
  const last = chatList.value[chatList.value.length - 1];
  if (!last) return;
  last.answer = answer || last.answer || '';
  last._status = 'ready';
  last._progress = 100;
  onGoBottomRef(chatScrollRef);
}

function normalizePayload(p) {
  if (typeof p === 'string') return p.trim();
  if (p && typeof p === 'object' && typeof p.message === 'string') return p.message.trim();
  return '';
}

function cancelLastBubble() {
  const last = chatList.value[chatList.value.length - 1];
  if (last && last._status === 'pending') {
    last._status = 'canceled';
    last.state = '중단됨';
    last._progress = 100;
  }
}

const shouldShowProgressBar = computed(() => {
  return uploadStatus.isUploading && (uploadStatus.status === 'pending' || uploadStatus.status === 'proceeding');
});

// 세션 참조(문서 화면에서 쓰는 전역 세션 그대로 사용)
const session = computed(() => store.getters.session || {});


// 라우터 경유 SSE + 리포suggestSendChat트 미요청
async function suggestSendChat(payload, queryPostBool = true, pathList = []) {

  // 기존 스트림 중지
  if (chatAbortCtrl) {
    try {
      chatAbortCtrl.abort();
    } catch (e) {
      console.warn('chatAbortCtrl abort error:', e);
    }
  }
  chatAbortCtrl = new AbortController();

  const userQuery = pathList.length > 0 ? '요약해줘' : normalizePayload(payload);
  // if (!userQuery) {
  //   customToast.info('프롬프트를 입력해 주세요.');
  //   return;
  // }

  if (!readyToSend()) return;

  chatList.value = []; // 채팅 리스트 초기화

  // 쿼리 사용할거면 queryPostBool -> 이거 ture 로 바꾸세요
  const queryPost = !queryPostBool ? '' : userQuery;
  const queryId = uuidv1();

  try {
    const sseResult = await doSseChatCall({
      query: queryPost,
      session,
      localSessionId: ref(session.value?.session_id || ''),
      fileList,
      currentTemplate: { id: 'drive', title: 'Drive Chat', desc: '' },
      chatListRef: chatList,
      chatScrollRef,
      onGoBottomRef,
      t,
      toast,
      renderMarkdown: (md) => renderMarkdownStream(md),
      isStreaming: isStreaming, // 스트리밍 상태 전달
      emit: undefined,
      editor: { contentRef: ref(''), titleRef: ref('') },
      queryId,
      signal: chatAbortCtrl.signal,
      useRouter: true,
      shouldFetchReport: false,
      speedMs: 0, // 실시간 스트리밍을 위해 0으로 설정
      payloadBuilder: () => ({
        'tool_id': '2bb62b7d-38e4-49bc-b700-e24fdfbd3f2f',
        'version_id': '9144856a-0a97-4bda-bf2f-2f545418e448',
        messages: JSON.stringify([
          { role: 'user', content: `${userQuery}` },
        ]),
        'stream': true,
        'file_list': [
          ...pathList,
        ],
      }),
    });

    if (sseResult?.answer) {
      completeLastBubble(sseResult.answer);
    } else {
      completeLastBubble();
    }
  } catch (err) {
    if (err?.name === 'AbortError') {
      cancelLastBubble();
    } else {
      completeLastBubble('처리 중 오류가 발생했어요.');
    }
  } finally {
    chatAbortCtrl = null;
    if (!keepFilesAfterSend.value) fileList.value = [];
    else keepFilesAfterSend.value = false;
  }
}

async function handleCrumbleClick(id = null) {
  if (id) {
    // 전달받은 ID로 디렉토리 정보를 찾아서 currentDirectory 설정
    const targetDirectory = trList.find(item => item.id === id && item.type === 'directory');
    if (targetDirectory) {
      currentDirectory.value = targetDirectory;
    } else {
      // trList에 없는 경우, ID만으로 설정
      currentDirectory.value = { id: id };
    }
  } else {
    // 루트로 이동
    currentDirectory.value = null;
  }
  await searchDocuments('', pageViewId.value, false, '', '', currentDirectory.value?.id);
}
</script>

<style scoped>

p.default-text {
  width: 100%;
  font-size: 0.9rem;
  font-weight: 600;
}

/* 업데이트된 항목 하이라이트 애니메이션 */
.updated-item {
  animation: highlightUpdate 3s ease-in-out;
  position: relative;
}

@keyframes highlightUpdate {
  0% {
    background-color: #3b82f6;
    box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.7);
    transform: scale(1);
  }
  10% {
    background-color: #60a5fa;
    box-shadow: 0 0 0 10px rgba(59, 130, 246, 0.3);
    transform: scale(1.02);
  }
  20% {
    background-color: #93c5fd;
    box-shadow: 0 0 0 5px rgba(59, 130, 246, 0.1);
    transform: scale(1.01);
  }
  30% {
    background-color: #dbeafe;
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.05);
    transform: scale(1);
  }
  100% {
    background-color: transparent;
    box-shadow: none;
    transform: scale(1);
  }
}

/* 리스트 뷰에서의 업데이트 효과 */
.list-tr.updated-item {
  border-left: 4px solid #3b82f6;
  border-radius: 4px;
}

/* 카드 뷰에서의 업데이트 효과 */
.card-item.updated-item {
  border: 2px solid #3b82f6;
  border-radius: 8px;
}
</style>
