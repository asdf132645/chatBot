<template>
  <div class="document-answer-wrapper">
    <div class="document-answer-box">
      <div class="anwser-wrapper">
        <div class="doc-answer-content">
<!--          <div class="doc-answer-option">-->
<!--            <button class="btn btn-select" @click.stop="toggleDropItem($event, 'template')">-->
<!--              {{ currentTemplate.title }}-->
<!--              <BaseIcon name="ArrowFullDown" :size="16" />-->
<!--            </button>-->

<!--            <button class="btn file-select" @click.stop="toggleDropItem($event, 'fileList')">-->
<!--              <BaseIcon name="Folder" :size="20" />-->
<!--            </button>-->
<!--          </div>-->

          <!-- 버블 넣는 곳 -->
          <ChatBubbleList
            ref="chatBubbleListRef"
            :chatList="chatList"
            :searchList="searchList"
            :queryLoading="queryLoading"
            :renderMarkdownStream="renderMarkdownStream"
            :formatDate="formatDate"
            @mounted="onBubbleMounted"
            @open-editor="handleOpenEditor"
          />

          <FileList
            v-if="fileList.length"
            :fileList="fileList"
            @deleteFile="deleteFile"
            class="mt8"
          />
          <!--
                    <user-prompt-gallery
                      :show="showGallery"
                      :chatbotCode="session.chatbotCode"
                      @update:show="showGallery = $event"
                      @select="applyPrompt"
                    /> -->

          <!-- 파일 업로드 필수 + 업로드 완료 후 RAG 호출 -->
          <QueryInputer
            ref="queryInputer"
            id="answerQueryInputer"
            class="doc-answer-inputer"
            placeholder="무엇을 도와드릴까요?"
            :sessionId="session.session_id"
            :fileList="fileList"
            :maxFiles="1"
            :docsBtnFilesZeroDisabled="fileList.length === 0"
            :abortSignal="uploadAbortCtrl.signal"
            :isQueryLoading="isChatLoading"
            :isInteractionHidden="false"
            :noShadow="true"
            :isSelectedModel="false"
            @submit="suggestSendChat"
            @fileIds="handleFileIds"
            @fileUpload="handleFileUpload"
            @fileError="onFileUploadError"
            @clearFiles="clearAllFiles"
            @fileProcessed="onFileProcessed"
          />
        </div>
      </div>

      <DocsEditor
        :key="editorKey"
        :isEditor="isEditor"
        :editorTitle="editorTitle"
        :contentEditor="contentEditor"
        :quillFormats="quillFormats"
        :showEditorOverlay="showEditorOverlay"
        :chatDropPosition="chatDropPosition"
        :docList="docList"
        @toggle-related="toggleRelatedDocumentList"
        @select-doc="selectedTemplate"
        @editor-ready="onEditorReady"
        @save-txt="saveTxt"
      />
    </div>

    <div class="related-document-list-wing" v-if="isRelatedDocumentListOpen">
      <div class="related-document-list-wrapper">
        <div class="related-document-list-header">
          <div class="related-document-list-header-title">
            <BaseIcon name="file" :size="18" />
            참고자료
          </div>
          <button class="btn" @click="toggleRelatedDocumentList">
            <BaseIcon name="Close" :size="18" />
          </button>
        </div>
        <div class="related-document-list conversation-menu-wrapper">
          <ul>
            <li v-for="doc in relatedDocumentList" :key="doc.id">
              <button class="nav-btn">
                <BaseIcon name="SummaryDocType" :size="20" :mr="8" />
                <div class="doc-title">
                  {{ doc.title }}
                  <div class="doc-desc">{{ doc.desc }}</div>
                </div>
              </button>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <DropDown
      :top="chatDropPosition.y"
      :left="chatDropPosition.x"
      :isOpenDrop="isTemplateDrop"
      @close="isTemplateDrop = false"
      dropdownName="drive-menu-wrapper"
    >
      <template #content>
        <template v-if="dropType === 'template'">
          <CustomList
            :lists="renderList"
            :maxHeight="300"
            :isClickable="true"
            :isAvatar="false"
            :removePadding="true"
            :border="true"
            @listClick="(template) => selectedTemplate(template, true)" />
        </template>
        <template v-if="dropType === 'fileList'">
          <CustomList
            :lists="[]"
            :maxHeight="300"
            :isClickable="true"
            :isAvatar="false"
            :removePadding="true"
            :border="true"
            @listClick="selectedTemplate" />
        </template>
      </template>
    </DropDown>

  </div>
</template>

<script setup>
import { reactive, ref, computed, onMounted, defineEmits, watch, nextTick, onBeforeUnmount } from 'vue';
import { onBeforeRouteLeave, useRoute } from 'vue-router';
import { v1 as uuidv1 } from 'uuid';
import { useStore } from 'vuex';
import { useToast } from 'vue-toastification';

import BaseIcon from '@/component/BaseIcon.vue';
import QueryInputer from '@/component/QueryInputer.vue';
import DropDown from '@/component/DropDown.vue';
import FileList from '@/views/fileManage/component/FileList.vue';
// import { usePromptClipboard } from '@/composables/usePromptClipboard';

import { useI18n } from 'vue-i18n';
import { useChatView } from '@/domains/chat/application/useChatView';

import { doSseChatCall } from '@/domains/docsChat/application/useChatStream';
import { stripExt, getFileIconName, formatDate } from '@/composables/chatUtils';
import { doRagReportGet } from '@/domains/docsChat/application/useReportFetch';
import { getDomainInfo, getQueryList } from '@/domains/chat/infrastructure/chatApi';
import { useReportTemplates } from '@/domains/report/application/useReportTemplates';
import * as chatApi from '@/domains/chat/infrastructure/chatApi';
import ChatBubbleList from '@/domains/docsChat/presentation/ChatBubbleList.vue';
import DocsEditor from '@/domains/docsChat/presentation/DocsEditor.vue';
import CustomList from '@/component/CustomList.vue';
import { useFileAttachments } from '@/composables/useFileAttachments';
import { useHtmlToText } from '@/composables/useHtmlToText';
import { renderMdToHtml } from '@/composables/markdown';
import { uploadDocTxt, startDocsSearchStream, endDocsSearchStream } from '@/domains/docsChat/infrastructure/docsApi';
// import { useDownloader } from '@/composables/useDownloader';

const marked = require('marked');

/* =========================
 * Reactive state / store
 * ========================= */
const route = useRoute();
const store = useStore();
const toast = useToast();
const { t } = useI18n();
const emit = defineEmits(['answerEnd', 'newSessionCreated']);
const session = computed(() => store.getters.session || {});
const isFileLoading = computed(() => store.getters.getIsFileLoading);
const isDocsType = computed(() => store.getters.getDocsType);
const { load, templates } = useReportTemplates();
const { onGoBottomRef } = useChatView();

/* =========================
 * 파일 txt 관련 함수, html 변환
 * ========================= */
const {
  fileList,
  uploadedFileIds: serverFileIds,
  handleFileUpload,
  handleFileIds,
  onFileUploadError,
  clearAllFiles,
  onFileProcessed,
  deleteFile,
} = useFileAttachments();

const { htmlToText } = useHtmlToText({
  linkStyle: 'inline',      // "텍스트 (URL)"
  imageStyle: 'alt',        // "[IMG: alt]"
  tableStyle: 'tsv',        // 탭 구분 표
  headingUppercase: false,
});
// const { downloadTextFile } = useDownloader();

const agentCode = getDomainInfo().chatbotCode || '';
const alive = ref(true);

/* =========================
 * state
 * ========================= */
const queryInputer = ref(null);
const chatDropPosition = reactive({ x: 0, y: 0 });
const isTemplateDrop = ref(false);
const isRelatedDocumentListOpen = ref(false);

const contentEditor = ref('');
const editorTitle = ref('문서명');
const txtFile = ref('');
const isEditor = ref(true);
const isEditorLoading = ref(false);
let editorLoadingShownAt = 0;
let hideOverlayTimer = null;

const showEditorOverlay = computed(() =>
  isEditor.value &&
  (isEditorLoading.value || isChatLoading.value) &&
  !isBootstrapping.value,
);

const localQuery = ref('');
const pendingQuery = ref('');
const chatList = ref([]);
const docHistory = ref([]);
const chatScrollRef = ref(null);
const localSessionId = ref('');
const isChatLoading = ref(false);
const keepFilesAfterSend = ref(false);
const isBootstrapping = ref(false);
const hasConsumedBridge = ref(false);
const editorKey = ref(0);
const dropType = ref(null);

// 문서 검색 상태 관리
const searchList = ref([]);
const queryLoading = ref(false);
let searchStreamReader = null;

// ChatBubbleList의 토글 상태를 제어하기 위한 ref
const chatBubbleListRef = ref(null);

let chatAbortCtrl = null; // SSE 취소용
const uploadAbortCtrl = new AbortController(); // 업로드 취소용 (미사용이어도 unmount에서 중단)

/* =========================
 * 프롬프트용
 * ========================= */

// const { applyPromptCore } = usePromptClipboard({
//   t,
//   queryInputerRef: queryInputer, // QueryInputer의 ref
// });

/* =========================
 * 에디터용
 * ========================= */
const quillFormats = [
  'header', 'bold', 'italic', 'underline', 'strike', 'blockquote',
  'list', 'bullet', 'indent', 'link', 'code-block', 'image',
];

/* =========================
 * 배열
 * ========================= */
let currentTemplate = reactive({
  id: 'suggestion',
  title: '제안서',
  desc: '비즈니스 제안 내용을 효과적으로 전달하는 문서',
});

const relatedDocumentList = ref([
  { id: 'doc1', title: '문서1', desc: '문서1 내용을 효과적으로 전달하는 문서' },
  { id: 'doc2', title: '문서2', desc: '문서2 내용을 효과적으로 전달하는 문서' },
]);

const docList = ref([
  { id: 'doc1', title: '문서1', desc: '문서1 내용을 효과적으로 전달하는 문서' },
  { id: 'doc2', title: '문서2', desc: '문서2 내용을 효과적으로 전달하는 문서' },
]);

const renderList = computed(() => (templates.value || []).map(t => ({ ...t, name: t.title })));

/* =========================
 * UI 헬퍼 함수들
 * ========================= */
function showEditorLoading() {
  if (hideOverlayTimer !== null) {
    clearTimeout(hideOverlayTimer);
    hideOverlayTimer = null;
  }
  isEditorLoading.value = true;
  editorLoadingShownAt = Date.now();
}

function hideEditorLoadingWithMin(ms = 500) {
  const elapsed = Date.now() - editorLoadingShownAt;
  const remain = Math.max(ms - elapsed, 0);
  if (hideOverlayTimer !== null) {
    clearTimeout(hideOverlayTimer);
    hideOverlayTimer = null;
  }
  hideOverlayTimer = window.setTimeout(() => {
    isEditorLoading.value = false;
    hideOverlayTimer = null;
  }, remain);
}


function toggleRelatedDocumentList() {
  isRelatedDocumentListOpen.value = !isRelatedDocumentListOpen.value;
}

// function toggleDropItem(event, type) {
//   dropType.value = type;
//   chatDropPosition.x = event.clientX;
//   chatDropPosition.y = event.clientY;
//
//   if (type === 'template') {
//     // console.log('template');
//   } else if (type === 'fileList') {
//     // console.log('fileList');
//   }
//   isTemplateDrop.value = true;
// }

/* =========================
 * 맨 위 셀렉트 박스로 어떤 템플릿으로 할건지 선택하는부분
 * ========================= */
async function selectedTemplate(template, forceNewSession = false, withOverlay = true) {
  if (!template) return;

  chatAbortCtrl?.abort?.();

  currentTemplate.id = template.id;
  currentTemplate.title = template.title;
  currentTemplate.desc = template.desc;

  isTemplateDrop.value = false;

  isEditor.value = true;
  isChatLoading.value = false;
  if (withOverlay) {
    showEditorLoading();
  } else {
    // 초기 진입 등: 오버레이 강제 OFF 상태로 시작
    isEditorLoading.value = false;
  }

  editorTitle.value = template.title || '문서명';
  contentEditor.value = '';
  editorKey.value += 1;

  chatList.value = [];
  docHistory.value = [];
  fileList.value = [];
  serverFileIds.value = [];
  pendingQuery.value = '';

  hideEditorLoadingWithMin(withOverlay ? 400 : 0);
  
  // 템플릿 변경 시 항상 isDocsType 업데이트
  store.commit('setDocsType', template);
  
  if (forceNewSession) {
    //  유저가 템플릿을 "새 문서"처럼 선택한 케이스: 진짜 새 세션 발급
    const newId = uuidv1();
    localSessionId.value = newId;
    const newSession = commitSessionForDocs(
      editorTitle.value,
      true,          // isNew = true
      newId,
      newId,         // convId 동일 사용
    );
    await store.commit('setSession', newSession);
  } else {
    //  초기 진입 등 자동 선택: 기존 세션 유지
    localSessionId.value = session.value.session_id;
    await store.commit('setSession', commitSessionForDocs(
      editorTitle.value,
      session.value.isNew ?? false,
      session.value.session_id,
      session.value.convId,
    ));
  }
}

/* =========================
 * 마크다운 관련 함수
 * ========================= */

function renderMarkdownStream(letters) {
  if (!letters) return;
  const renderer = new marked.Renderer();
  renderer.link = (href, title, text) => `<a href=${href} target="_blank" style="text-decoration: underline;">${text}</a>`;
  renderer.code = (code, language) => `<pre class="custom-code-block"><code class="language">${language}<br/>${code}</code></pre>`;
  marked.setOptions({
    renderer,
    gfm: true,
    headerIds: false,
    tables: true,
    breaks: true,
    pedantic: false,
    smartLists: true,
    smartypants: false,
  });
  letters = letters.replace(/\|\n\n\|/g, '|\n|');
  return marked(letters);
}


const coerceHtml = raw => (raw == null ? '' : (typeof raw === 'string' ? raw : String(raw)));

function renderMarkdown(md) {
  return renderMdToHtml(md);
}


function onEditorReady() {
  hideEditorLoadingWithMin(400);
}

/* =========================
 * Chat item 헬퍼
 * ========================= */
function setEditorFromResult(r) {

  
  const html = coerceHtml(!r?.report?.html ? r?.report?.content : r?.report?.html);

  
  contentEditor.value = html;
  editorKey.value += 1;
  editorTitle.value = r?.report?.fileName || '문서명';
  
  txtFile.value = htmlToText(html, {
    linkStyle: 'inline', // "텍스트 (URL)"
    imageStyle: 'alt',   // "[IMG: alt]"
    tableStyle: 'tsv',   // 탭 구분
  });
  // const safeName = String(html || '문서')
  //   .replace(/[\\/:*?"<>|]/g, '_'); // 파일명 금지문자 치환
  // downloadTextFile(`${safeName}.txt`, txtFile.value, { bom: true, eol: 'CRLF' });
}

function toChatItem(r, i, sid) {
  const chatItem = {
    _idx: Date.parse(r?.date) || (Date.now() + i),
    sessionId: r?.session_id || sid,
    query: r?.query || '',
    answer: r?.StreamingAnswers ?? r?.report?.fileName ?? '',
    files: Array.isArray(r?.fileList) ? r.fileList.map(f => f?.name).filter(Boolean) : [],
    _status: 'ready',
    _progress: 100,
    state: '',
    report: r?.report || undefined,
  };

  
  return chatItem;
}

/* =========================
 * Abortion - 대화가 끊겼을 경우 대비 /  helpers 함수 모음
 * ========================= */
const normalizePayload = p =>
  (typeof p === 'string' ? p.trim() : (p?.message || '').trim());

const readyToSend = () => {
  if (isFileLoading.value) {
    toast.info('파일 업로드가 진행 중입니다. 업로드 완료 후 전송이 가능합니다.');
    return false;
  }
  if (fileList.value.length && !fileList.value.every(f => f?.status === 'uploaded')) {
    toast.info('파일 업로드가 아직 완료되지 않았습니다. 업로드 완료 후 전송해 주세요.');
    return false;
  }
  return true;
};

const beginEditorRun = () => {
  if (!isEditor.value) isEditor.value = true;
  contentEditor.value = '';
  editorTitle.value = '문서명';
  showEditorLoading();
  isChatLoading.value = true;
  onGoBottomRef(chatScrollRef);
};

const markLastChatCanceled = () => {
  const last = chatList.value[chatList.value.length - 1];
  if (last && last._status === 'pending') {
    last._status = 'canceled';
    last.state = '중단됨';
    last._progress = 100;
  }
};
// 쿼리 저장하기
const buildSavePayload = ({ report, streamingAnswer, fileListArr, queryId, query }) => {
  const payload = {
    agent_id: session.value.chatbotCode,
    query_id: queryId,
    session_id: session.value.session_id,
    email: store.state.loginUser.userEmail,
    seq_no: chatList.value.length,
    query,
    report,
    StreamingAnswers: streamingAnswer,
    isDocsType: isDocsType.value,
    fileList: fileListArr,
  };

  
  return payload;
};
// 세션 업데이트 하기
const commitSessionForDocs = (query, isNew, session_id, convId) => ({
  id: session_id,
  agent_code: getDomainInfo().chatbotCode,
  chatbotCode: getDomainInfo().chatbotCode,
  user_email: session.value.user_email,
  session_id: session_id,
  convId: convId,
  query,
  title: query,
  created_at: new Date().toISOString(),
  conversationDate: new Date().toISOString(),
  isNew: isNew,
  chatMode: 'docs',
  accessLevel: route.query.accessLevel,
});

/* =========================
 * rag 로 전달하는 스트리밍 함수 + 안에 리포트 파일즈 불러오는 부분도 있음
 * ========================= */
async function suggestSendChat(payload) {
  // QueryInputer 인풋창 비우기
  if (queryInputer.value && queryInputer.value.clearInput) {
    queryInputer.value.clearInput();
  }
  //  기존 스트림 중단
  if (chatAbortCtrl) {
    try {
      chatAbortCtrl.abort();
    }
      // eslint-disable-next-line no-empty
    catch (e) {
    }
  }
  chatAbortCtrl = new AbortController();

  //  입력
  const query = normalizePayload(payload);
  if (!query) return;
  if (!readyToSend()) return;

  if (session.value.isNew) {
    store.commit('setNewChat', { flag: true, message: query });
  }

  //  에디터 준비
  localQuery.value = query;
  beginEditorRun();

  // 검색 상태 초기화
  searchList.value = [];
  queryLoading.value = true;

  // 파일 업로드 상태 추가 (파일이 있을 때만)
  if (fileList.value.length > 0) {
    searchList.value.push({
      id: 'file_upload',
      status: 'loading',
      keyword: fileList.value[0].name,
      statusDetail: '파일 업로드 진행중',
    });
  }

  // 문서 검색 스트림 시작
  startDocsSearchListSSE();

  //  스트리밍
  const queryId = uuidv1();
  let sseResult;
  try {
    sseResult = await doSseChatCall({
      query,
      session,
      localSessionId,
      fileList,
      currentTemplate,
      chatListRef: chatList,
      chatScrollRef,
      onGoBottomRef,
      t,
      toast,
      renderMarkdown,
      isChatLoading,
      emit,
      editor: { contentRef: contentEditor, titleRef: editorTitle },
      queryId,
      signal: chatAbortCtrl.signal,
      // 라우터 SSE 쓸지 선택 (true면 ragRouterUrl, false면 ragEditorSseUrl)
      useRouter: false,
      //   - 도구/번역 등 리포트 불필요한 흐름: false
      shouldFetchReport: true,
      //타자효과 속도
      speedMs: 10,
    });
    isChatLoading.value = false;

    // 검색 스트림 종료
    endDocsSearchListSSE();

  } catch (err) {
    fileList.value = [];
    if (err?.name === 'AbortError') {
      isChatLoading.value = false;
      hideEditorLoadingWithMin(0);
      markLastChatCanceled();
      chatAbortCtrl = null;
      return;
    }
    chatAbortCtrl = null;
    throw err;
  } finally {
    chatAbortCtrl = null;
    isChatLoading.value = false;
    isBootstrapping.value = false;
    hideEditorLoadingWithMin(0);
    fileList.value = [];

    // 에러 발생 시에도 검색 스트림 종료
    endDocsSearchListSSE();
  }

  // 저장
  const { report, answer: streamingAnswer, fileListArr } = sseResult || {};
  try {
    await chatApi.saveDocsQuery(
      buildSavePayload({ report, streamingAnswer, fileListArr, queryId, query }),
    );
  } catch (e) {
    console.error('Error saving query:', e);
  }

  // doRagReportGet 추가 실행
  try {
    const ragResult = await doRagReportGet({
      session,
      localSessionId: localSessionId.value,
      toast,
      renderMarkdown,
      editor: { contentRef: contentEditor, titleRef: editorTitle },
      queryId: queryId,
    });

    // doRagReportGet이 null을 반환하면 (report_files가 빈 배열이거나 content가 없는 경우) 에러 메시지 표시
    if (ragResult === null) {
      contentEditor.value = '<p>죄송합니다. 다시 시도해주세요.</p>';
      editorKey.value += 1;
    }
  } catch (err) {
    console.error('RAG 리포트 가져오기 실패:', err);
    contentEditor.value = '<p>죄송합니다. 다시 시도해주세요.</p>';
    editorKey.value += 1;
  }

  // LnbWrapper에 새로운 대화 추가 (첫 번째 쿼리인 경우)
  const wasNewSession = session.value.isNew;
  
  //  세션 갱신
  const updatedSession = commitSessionForDocs(query, false, session.value.session_id, session.value.convId);
  await store.commit('setSession', updatedSession);

  // 첫 번째 쿼리인 경우 LnbWrapper에 새로운 대화 추가
  if (wasNewSession) {
    // LnbWrapper에 보낼 때는 isNew: true로 설정
    const sessionForLnb = { ...updatedSession, isNew: true };
    emit('newSessionCreated', sessionForLnb);
  }

  // 파일 첨부 정리
  if (!keepFilesAfterSend.value) {
    fileList.value = [];
  } else {
    keepFilesAfterSend.value = false;
  }


}

// /* =========================
//  * 리포트 창 여는 부분
//  * ========================= */
async function isEditorOpen(chat) {
  if (!isEditor.value) isEditor.value = true;

  // 오버레이/상태 준비
  if (hideOverlayTimer !== null) {
    clearTimeout(hideOverlayTimer);
    hideOverlayTimer = null;
  }
  isEditorLoading.value = true;
  isChatLoading.value = false;

  // 1) 전달된 chat 객체에 HTML이 이미 있으면 그걸 먼저 보여주고, 필요하면 뒤에 fetch로 갱신
  try {
    const optimisticTitle = chat?.report?.fileName || editorTitle.value || '문서명';
    const optimisticHtml = chat?.report?.html || '';
    if (optimisticHtml) {
      editorTitle.value = optimisticTitle;
      contentEditor.value = optimisticHtml;
      editorKey.value += 1;
    }
  } catch (err) {
    console.warn('낙관적 렌더링 실패(무시 가능):', err);
  }

  // 2) query_id가 있는 경우 서버에서 최신 리포트 가져와 에디터에 주입
  const qid = chat?.report?.query_id || chat?.query_id;
  if (!qid) {
    // query_id가 없다면 낙관적 값만으로 종료
    hideEditorLoadingWithMin(0);
    return;
  }

  try {
    await doRagReportGet({
      session,
      localSessionId: localSessionId.value,
      toast,
      renderMarkdown,
      editor: { contentRef: contentEditor, titleRef: editorTitle },
      queryId: qid,
    });

    // doRagReportGet 내부에서 contentRef/titleRef 갱신됨
    editorKey.value += 1;
  } catch (err) {
    console.error('리포트 로드 실패:', err);
    toast.error('리포트를 불러오지 못했습니다.');
  } finally {
    hideEditorLoadingWithMin(0);
  }
}


/* =========================
 * txt 문서 저장소로 보내는 함수
 * ========================= */

async function saveTxt(newDocInfo) {
  const md = (newDocInfo?.markdown ?? '').trim();
  if (!md) {
    toast.info('저장할 내용이 없습니다.');
    return;
  }

  const safeTitle = (newDocInfo?.title || String(editorTitle.value || '문서명'))
    .replace(/[\\/:*?"<>|]/g, '_');
  const filename = `${safeTitle}.md`;

  const sessionId = session.value.session_id || localSessionId.value || uuidv1();
  const agentCode = getDomainInfo().chatbotCode;
  const email = store.state.loginUser.userEmail;
  const userNm = store.state.loginUser.userNm;

  try {
    showEditorLoading();

    await uploadDocTxt({
      sessionId,
      filename,
      content: md
      ,agentCode, email, userNm
    });

    toast.success('MD 문서가 저장되었습니다.');
  } catch (e) {
    console.error('MD 저장 실패:', e);
    toast.error('MD 저장에 실패했습니다.');
  } finally {
    hideEditorLoadingWithMin(300);
  }
}



/* =========================
 * watch
 * ========================= */
watch(isChatLoading, (loading) => {
  if (loading) {
    showEditorLoading();
  } else {
    hideEditorLoadingWithMin(600);
    hideEditorLoadingWithMin(0);
  }
});
watch(() => session.value.session_id, async (sid, prev) => {

  if (!sid || sid === prev) {
    return;
  }
  
  try {
    await initDocsForSession(sid, 'watch');
  } catch (error) {
    console.error('initDocsForSession 실행 중 오류:', error);
  }
}, { immediate: false });

/* =========================
 * 최초실행과 docs 에서 전달 받은 스토어값을 기존 변수들의 넣는 부분
 * ========================= */
async function initDocsForSession(sid = session.value.session_id) {

  if (!sid) {
    return;
  }
  
  if (isBootstrapping.value) {
    return;
  }
  
  isBootstrapping.value = true;

  try {
    // 템플릿 로드
    if (templates.value?.length === 0) {
      await load(agentCode, { accessLevel: route.query.accessLevel, page: 1, perPage: 7 });
    }
    
    localSessionId.value = sid;
    isEditor.value = true;
    isEditorLoading.value = false;

    // 쿼리 리스트 가져오기
    const { data } = await getQueryList({ email: store.state.loginUser.userEmail, session_id: sid });
    const rows = Array.isArray(data?.result) ? data.result : [];

    if (rows.length === 0) {
      if (templates.value?.length === 0) {
        const initTpl = toTemplateShape(isDocsType.value) || currentTemplate;
        await selectedTemplate(initTpl, false, false); // 초기 진입: 오버레이 X
      }

      contentEditor.value = '';
      editorTitle.value = '문서명';
      chatList.value = [];
      return;
    }

    const first = rows[0];
    
    // 템플릿 먼저 선택(초기화 일어남) - >  그 다음 실제 컨텐츠 주입
    const tplLike = first?.isDocsType || isDocsType.value;
    
    if (templates.value?.length === 0 || first?.isDocsType?.title !== '') {
      const resolvedTpl = toTemplateShape(tplLike) || currentTemplate;
      await selectedTemplate(resolvedTpl, false, false);         // 초기화
      store.commit('setDocsType', resolvedTpl);
    } else if (first?.isDocsType) {
      // 템플릿이 이미 로드되어 있고 first.isDocsType이 있으면 직접 설정
      store.commit('setDocsType', first.isDocsType);
    }
    
    // chatList 먼저 설정
    chatList.value = rows
      .slice()
      .sort((a, b) => (a?.seq_no ?? 0) - (b?.seq_no ?? 0))
      .map((r, i) => toChatItem(r, i, sid));
    

    
    // 에디터 내용 설정
    const i = rows.findIndex(r => !r || r.report == null); // 만약 내용이 없거나 비어있으면 다른걸로 넣어야하니깐 이렇게 넣음
    const target =
      (i > 0 ? rows[i - 1] : null) ||
      rows.find(r => r && r.report != null) ||
      rows[0];

    
    setEditorFromResult(target);

    await nextTick();
    onGoBottomRef(chatScrollRef);
    
  } catch (error) {
    console.error('initDocsForSession 실행 중 오류:', error);
    throw error; // 상위로 에러 전파
  } finally {
    isBootstrapping.value = false;
  }
}

// 템플릿 안전 변환 하도록 하는 헬퍼 함수
function toTemplateShape(tplLike) {
  if (!tplLike) return null;
  if (typeof tplLike === 'string') {
    const found = (templates.value || []).find(x => x.id === tplLike);
    if (found) {
      return {
        id: found.id,
        title: found.title || '문서명',
        desc: found.description ?? found.desc ?? '',
      };
    }
    return { id: tplLike, title: '문서명', desc: '' };
  }
  // 객체 형태일 때
  return {
    id: tplLike.id,
    title: tplLike.title || '문서명',
    desc: tplLike.description ?? tplLike.desc ?? '',
  };
}

//특정 조건이 만족될 때까지 polling 하면서 기다리는 유틸 함수(localSessionId 등 준비될 때까지)
function waitFor(pred, { interval = 30, timeout = 5000 } = {}) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const timer = setInterval(() => {
      if (pred()) {
        clearInterval(timer);
        resolve(true);
      } else if (Date.now() - start > timeout) {
        clearInterval(timer);
        reject(new Error('waitFor timeout'));
      }
    }, interval);
  });
}

// 문서 검색 스트림 시작
async function startDocsSearchListSSE() {
  try {
    const response = await startDocsSearchStream(session.value.chatbotCode, session.value.session_id);
    if (!response.body) return;

    // 1. 검색 시작하면 chatBubbleList 열리게 하기
    if (chatList.value.length > 0) {
      const lastChatIndex = chatList.value.length - 1;
      // ChatBubbleList의 마지막 채팅 상태를 열기
      if (chatBubbleListRef.value && chatBubbleListRef.value.openState) {
        chatBubbleListRef.value.openState(lastChatIndex);
      }

      // 검색 시작 상태 표시
      searchList.value.push({
        id: 'search_start',
        status: 'loading',
        keyword: '검색 시작',
        statusDetail: '문서 검색을 시작합니다',
      });
    }

    searchStreamReader = response.body.pipeThrough(new TextDecoderStream()).getReader();

    let readable = true;
    while (readable) {
      const { done, value } = await searchStreamReader.read();

      if (value && value.startsWith('data:')) {
        let eventData = value.slice(6).trim();
        let dataList = eventData.split('\n\ndata: ');

        dataList.forEach((d) => {
          try {
            let eventItem = JSON.parse(d);

            // 2. 별도 내부 전처리 없이 그냥 eventItem에 나온 데이터를 적합하게 붙여주기
            // ID는 timestamp로 설정
            const searchItem = {
              id: eventItem.timestamp || Date.now(),
              status: 'loading',
              keyword: eventItem.event || '이벤트',
              statusDetail: eventItem.content || eventItem.agentName || eventItem.taskName || '처리 중',
            };

            // 중복 방지를 위해 기존 항목이 있으면 업데이트, 없으면 추가
            const existingIndex = searchList.value.findIndex(item => item.id === searchItem.id);
            if (existingIndex >= 0) {
              searchList.value[existingIndex] = searchItem;
            } else {
              searchList.value.push(searchItem);
            }

            // 3. 검색 끝나면 chatBubbleList 닫히게 하기
            if (eventItem.event === 'disconnected') {
              readable = false;
              // 검색 완료 상태로 변경
              searchList.value.forEach(item => {
                if (item.status === 'loading') {
                  item.status = 'check';
                  item.statusDetail = '완료';
                }
              });

              // ChatBubbleList의 마지막 채팅 상태를 닫기
              if (chatList.value.length > 0) {
                const lastChatIndex = chatList.value.length - 1;
                if (chatBubbleListRef.value && chatBubbleListRef.value.closeState) {
                  chatBubbleListRef.value.closeState(lastChatIndex);
                }
              }
            }

          } catch (error) {
            console.error('문서 검색 SSE JSON parsing error:', error, 'Received data:', d);
          }
        });
      }

      if (done) {
        readable = false;
      }

      // 폴링 간격
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  } catch (err) {
    console.warn('문서 검색 스트림 시작 실패:', err);
  }
}

// 문서 검색 스트림 종료
function endDocsSearchListSSE() {
  if (searchStreamReader) {
    try {
      searchStreamReader.cancel();
      searchStreamReader = null;
    } catch (error) {
      console.warn('문서 검색 스트림 종료 중 오류:', error);
    }
  }

  // 검색 완료 상태로 업데이트
  queryLoading.value = false;

  // 검색 스트림 종료 API 호출
  if (session.value.chatbotCode && session.value.session_id) {
    endDocsSearchStream(session.value.chatbotCode, session.value.session_id).catch(console.warn);
  }
}

// 다른 화면에서 준비된 파일·프롬프트·템플릿 정보를 문서 화면 초기 진입 시 복원하고 즉시 실행해주는 브릿지 역할 함수”
async function applyBridgePending() {
  if (hasConsumedBridge.value) return;
  const pending = store.getters['docsBridge/getPending'];
  if (!pending) return;

  await waitFor(() => !!localSessionId.value).catch(() => {
  });
  if (!templates.value?.length) {
    await load(agentCode, { accessLevel: route.query.accessLevel, page: 1, perPage: 7 }).catch(() => {
    });
  }

  if (pending.template) {
    store.commit('setDocsType', pending.template);
    selectedTemplate(pending.template);
  }

  if (Array.isArray(pending.fileList) && pending.fileList.length) {
    fileList.value = pending.fileList.map((f, i) => ({
      id: f.id || crypto?.randomUUID?.() || `${localSessionId.value || 'pending'}:${Date.now()}:${i}`,
      name: f.name, size: f.size, type: f.type, file: f.file,
      status: f.status || 'uploaded',
      fileType: f.fileType || getFileIconName(f.type),
    }));
    const last = fileList.value[fileList.value.length - 1];
    if (last?.name) editorTitle.value = stripExt(last.name);
    if (store.getters.getIsFileLoading) store.commit('setIsFileLoading', false);
  }

  if (Array.isArray(pending.uploadedFileIds)) {
    serverFileIds.value = pending.uploadedFileIds.slice();
  }

  await nextTick();
  keepFilesAfterSend.value = true;

  if (pending.message) {
    await suggestSendChat({ message: pending.message });
  }

  hasConsumedBridge.value = true;
  store.commit('docsBridge/consume');
}

// DOM 준비 후 대입 하기 위한 처리 chatScrollRef 자체가 null 이라서 해당 부분 없으면 에러남
function onBubbleMounted(el) {
  if (!el) return;
  if (!chatScrollRef || typeof chatScrollRef !== 'object') return;
  nextTick(() => {
    chatScrollRef.value = el;
  });
}

async function handleOpenEditor(chat) {
  await isEditorOpen(chat);
}

/* =========================
 * 라이프 사이클
 * ========================= */
onBeforeRouteLeave(() => {
  chatAbortCtrl?.abort?.();
  uploadAbortCtrl.abort();
  endDocsSearchListSSE();
  clearTimeout(hideOverlayTimer);
  isChatLoading.value = false;
  isEditorLoading.value = false;
});
onBeforeUnmount(() => {
  alive.value = false;
  chatAbortCtrl?.abort?.();
  uploadAbortCtrl.abort();
  endDocsSearchListSSE();
  clearTimeout(hideOverlayTimer);
  isChatLoading.value = false;
  isEditorLoading.value = false;
});
onMounted(async () => {
  await initDocsForSession(session.value.session_id, 'mounted');
  await applyBridgePending();

});

</script>


