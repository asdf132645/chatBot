<template>
  <div class="document-wrapper">
    <div class="document-content-wrapper">
      <!-- 템플릿 영역 -->

      <div class="welcome-text-wrapper">
        <div class="welcome-text-header">안녕하세요! <span>서울시청</span>님!</div>
        <div class="welcome-text-question">어떠한 <span class="highlight-text">타입</span>의 문서를 만들고 싶으세요?</div>
        <div class="welcome-text-description">새 템플릿 만들기 버튼을 통해<br />쉽고 빠르게 문서 템플릿을 만들어보세요.</div>
      </div>

      <div class="document-template-wrapper">
        <div class="document-template-header document-header-wrapper">
          <div class="document-template-header-title header-title">
            <div class="header-title-left">
              <div class="btn-group">
                <div class="search-input-wrapper">
                  <button class="btn btn-icon" @click="handleSearch" :disabled="isSearching">
                    <BaseIcon :size="20" :name="isSearching ? 'Loading' : 'Search'" />
                  </button>
                  <input 
                    type="text" 
                    v-model="searchKeyword"
                    placeholder="템플릿 제목, 내용 검색" 
                    @keyup.enter="handleSearch"
                    :disabled="isSearching"
                  />
                  <button @click="searchingEmpty">
                    <BaseIcon :size="24" name="Close" />
                  </button>
                </div>
              </div>
              <div class="divider"></div>
              <button class="btn"
                      :class="{ active: accessLevel === 'public' }"
                      @click="accessLevel = 'public'; onAccessChange()"
              >
                <BaseIcon :size="18" :mr="8" name="Check" v-if="accessLevel === 'public'" />
                전체 템플릿
              </button>
              <div class="divider"></div>
              <button class="btn"
                      :class="{ active: accessLevel === 'private' }"
                      @click="accessLevel = 'private'; onAccessChange()"
              >
                <BaseIcon :size="18" :mr="8" name="Check" v-if="accessLevel === 'private'" />
                개인 템플릿
              </button>
            </div>

            <button class="btn" @click="handleAddTemplateCardClick">
              <BaseIcon :size="18" :mr="4" name="AddPlus" />
              새 템플릿 만들기
            </button>
          </div>
        </div>

        <div class="document-template-content">
          <!-- 카드형(Grid) -->
          <Transition
            :css="false"
            mode="out-in"
            @before-leave="lockHeight"
            @after-enter="unlockHeight"
            @enter="cardEnter"
            @leave="cardLeave"
          >
            <div
              :key="pageInfo.currentPage"
              v-if="viewMode === 'grid'"
              class="document-template-card-list custom-card-list"
              ref="cardListRef"
            >
              <!-- 템플릿 카드 -->
              <div
                class="document-template-card card-item"
                v-for="template in renderList"
                :class="{ 'checked': template.checked }"
                :key="template.id"
                @click="handleTemplateCardClick(template)"
              >
                <div class="card-header">
                  <div class="card-icon" :class="{ 'new': template.new }">
                    <div class="card-icon-badge-wrapper">
                      <div class="card-new-badge" v-if="template.new">NEW</div>
                      <div class="card-pin-badge" v-if="template.isPinned">
                        <BaseIcon :size="14" name="Pin" />
                      </div>
                    </div>
                    <BaseIcon :size="20" :name="template.icon" />
                  </div>
                  <div class="card-btn-group">
                    <button class="btn" @click.stop="toggleDropItem($event, 'card', template)">
                      <BaseIcon :size="16" name="DotsVertical" />
                    </button>
                  </div>
                </div>

                <div class="card-body">
                  <div class="card-title">{{ template.title }}</div>
                  <div class="card-desc">{{ template.description || template.desc }}</div>
                </div>

                <div class="card-badge-wrapper">
                  <div class="card-checked-badge card-badge" v-if="template.checked">
                    <BaseIcon :size="16" name="Check" />
                  </div>
                </div>
                <!-- <TransitionGroup name="card" tag="div">
                </TransitionGroup> -->
              </div>

              <button
                class="page-arrow-btn left"
                v-if="showLeftArrow"
                :disabled="loading"
                @click="goPrev"
              >
                <BaseIcon :size="30" name="ArrowLeft" />
              </button>

              <button
                class="page-arrow-btn right"
                v-if="showRightArrow"
                :disabled="loading"
                @click="goNext"
              >
                <BaseIcon :size="30" name="ArrowRight" />
              </button>
            </div>
          </Transition>

          <div class="page-info" v-if="showPagerDots">
            <span
              v-for="p in pageDots"
              :key="p"
              :class="{ active: p === pageInfo.currentPage }"
              @click="setPage(p)"
              :title="`${p} 페이지로 이동`"
            ></span>
          </div>

          <div class="template-loading" v-if="loading">불러오는 중…</div>
        </div>
      </div>

      <FileList
        v-if="fileList.length"
        :fileList="fileList"
        @deleteFile="deleteFile"
      />

      <QueryInputer
        ref="queryInputer"
        id="answerQueryInputer"
        class="doc-answer-inputer"
        :placeholder="'생성하고 싶은 문서에 대해 설명해주세요.'"
        :sessionId="session.session_id"
        :fileList="fileList"
        :maxFiles="1"
        :disableUpload="disableUploadForcing"
        :isQueryLoading="false"
        :isInteractionHidden="true"
        :isSelectedModel="true"
        @submit="onSubmitQuery"
        @fileIds="handleFileIds"
        @fileUpload="handleFileUpload"
        @fileError="onFileUploadError"
        @clearFiles="clearAllFiles"
        @fileProcessed="onFileProcessed"
      />

      <!-- 최근 문서 -->
      <!-- <div class="document-recent-wrapper">
        <div class="document-recent-header document-header-wrapper">
          <h2 class="document-recent-header-title header-title">
            <BaseIcon :size="18" name="Send" />
            최근 작업 문서
          </h2>
        </div>
        <div class="document-recent-content">
          <div class="document-recent-list">
            <div
              class="document-item"
              v-for="item in recentDocumentList"
              :key="item.id"
              @click="handleDocumentItemClick(item)"
            >
              <div class="item-label">{{ item.type }}</div>
              <div class="item-title">{{ item.title }}</div>
              <div class="item-update-time">{{ item.updateTime }}</div>
            </div>
          </div>
        </div>
      </div> -->
    </div>

    <!-- 새 템플릿 모달: 생성/수정 공용 -->
    <MyModal
      width="1200"
      :isOpenModal="isOpen"
      :title="selectedTemplateId ? (isFixedTemplate(selectedTemplateId) ? '템플릿 미리보기' : '템플릿 수정') : '새 템플릿 만들기'"
      :okBtnName="selectedTemplateId ? (isFixedTemplate(selectedTemplateId) ? '' : '저장') : '추가'"
      :hideOkBtn="selectedTemplateId && isFixedTemplate(selectedTemplateId)"
      @sendData="handleSendData"
      @close="handleClose"
    >
      <template #content>
        <div class="template-add-wrapper">
          
          <div class="template-add-option-wrapper">

            <div class="custom-control row-style row-center">
              <div class="custom-label">
                자동 템플릿 추출
              </div>

<!--              <button -->
<!--                class="btn btn-default" -->
<!--                :disabled="selectedTemplateId && isFixedTemplate(selectedTemplateId)"-->
<!--                @click.stop="toggleDropItem($event, 'file')"-->
<!--              >-->
                <button
                class="btn btn-default"
                @click="toBeDevAlert"
              >
                <BaseIcon name="File" :size="16" :mr="8" />
                파일 등록
              </button>              
            </div>

            <CustomInput
              label="템플릿 제목"
              id="templateTitleInput"
              placeholder="템플릿 제목을 입력해주세요."
              name="templateTitleInput"
              v-model="newTemplate.title"
            />

            <CustomTextarea
              label="템플릿 설명"
              class="flex-1"
              :heightFull="true"
              id="templateDescInput"
              placeholder="템플릿 설명을 입력해주세요."
              name="templateDescInput"
              v-model="newTemplate.desc"
              :disabled="selectedTemplateId && isFixedTemplate(selectedTemplateId)"
            /> 
          </div>

          <div class="template-add-editor-wrapper">
            <div class="input-label">템플릿 작성</div>
            <div class="template-add-editor docs-editor-wrapper">
              <div class="editor-wrapper">
                <div ref="modalEditorRoot"></div>
              </div>
            </div>
          </div>
        </div>

        <template>
          <p>문서를 삭제하시겠습니까?</p>
        </template>
      </template>
    </MyModal>

    <!-- 카드별 점 3개 메뉴 -->
    <DropDown
      :width="154"
      :top="convDropPosition.y"
      :left="convDropPosition.x - 150"
      :isOpenDrop="isTemplateDrop"
      @close="isTemplateDrop = false"
      dropdownName="conversation-menu-wrapper"
    >
      <template #content>        
        <ul>
          <template v-if="dropType === 'card'">
            <li>
              <button class="nav-btn" @click="onTogglePinFromMenu">
                <BaseIcon :name="isPinned ? 'PinVan' : 'Pin'" :size="20" :mr="8" />
                {{ isPinned ? '핀 해제' : '핀 고정' }}
              </button>
            </li>
            <li v-if="isFixedTemplate(menuTarget?.id)">
              <button class="nav-btn" @click="onPreviewFromMenu">
                <BaseIcon name="EyeShow" :size="20" :mr="8" />
                미리보기
              </button>
            </li>
            <li v-if="!isFixedTemplate(menuTarget?.id)">
              <button class="nav-btn" @click="onEditFromMenu">
                <BaseIcon name="AddChat" :size="20" :mr="8" />
                수정하기
              </button>
            </li>
            <li v-if="!isFixedTemplate(menuTarget?.id)">
              <button class="nav-btn" @click="onDeleteFromMenu">
                <BaseIcon name="Delete" :size="20" :mr="8" />
                삭제하기
              </button>
            </li>
          </template>
          <template v-if="dropType === 'file'">
            <li>
              <button class="nav-btn disabled" @click="onTogglePinFromMenu">                
                내 PC 
              </button>
            </li>
            <li>
              <button class="nav-btn disabled">
                AI 드라이브
              </button>
            </li>
          </template>
        </ul>
      </template>
    </DropDown>
    <ConfirmToast
      v-if="isConfirmOpen"
      :message="confirmMessage"
      confirmText="삭제"
      cancelText="취소"
      @resolve="handleConfirmResolve"
      />
  </div>

</template>

<script setup>
import {
  ref, reactive, computed, nextTick, onMounted, onBeforeUpdate, onUpdated, defineOptions, watch,
} from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useStore } from 'vuex'
import '@toast-ui/editor/dist/toastui-editor.css'
import Editor from '@toast-ui/editor'
import ConfirmToast from '@/shared/component/common/ConfirmToast'

import BaseIcon from '@/component/BaseIcon.vue'
import QueryInputer from '@/component/QueryInputer.vue'
import DropDown from '@/component/DropDown.vue'
import CustomInput from '@/component/CustomInput.vue'
import CustomTextarea from '@/component/CustomTextarea.vue'
import MyModal from '@/component/MyModal.vue'
import FileList from '@/views/fileManage/component/FileList.vue'

import { useReportTemplates } from '@/domains/report/application/useReportTemplates'
import { getDomainInfo } from '@/domains/chat/infrastructure/chatApi'
import {
  getDocumentsList, 
  // downloadDocument
} from '@/domains/docsChat/infrastructure/docsApi'
import { useFileAttachments } from '@/composables/useFileAttachments'
import { useToast } from 'vue-toastification'
import { formatDate } from '@/composables/chatUtils'

defineOptions({ name: 'DocumentWrapper' })

/* router / store */
const router = useRouter()
const route = useRoute()
const store = useStore()

const session = computed(() => store.getters.session || {})
const agentCode = getDomainInfo().chatbotCode || ''

const isConfirmOpen = ref(false)
const confirmMessage = ref('')
let confirmResolve = null;


/* const / util */
const SEVEN_DAYS = 7 * 24 * 60 * 60 * 1000
const isAnyTemplateChecked = computed(() => renderList.value.some(t => t.checked))
const disableUploadForcing = computed(() => !isAnyTemplateChecked.value)
const FIXED_TEMPLATE_IDS = [
  "68b54469b1368b6de760fa3d",
  // "68b9394c92d50ea54d90f06d",
  // "68b9394c92d50ea54d90f06e",
  // "68b9394c92d50ea54d90f06f",
  // "68b9394c92d50ea54d90f070",
  // "68b9394c92d50ea54d90f071",
  // "68b9394c92d50ea54d90f072",
  // "68b9394c92d50ea54d90f073",
  // "68b9394c92d50ea54d90f074"
]
const toast = useToast();

function isFixedTemplate(id) {
  return FIXED_TEMPLATE_IDS.includes(id)
}
function openConfirm(message) {
  confirmMessage.value = message
  isConfirmOpen.value = true
  return new Promise((resolve) => {
    confirmResolve = resolve
  })
}

function handleConfirmResolve(ok) {
  isConfirmOpen.value = false
  if (confirmResolve) {
    confirmResolve(ok)
    confirmResolve = null
  }
}


const searchingEmpty = () => {
  searchKeyword.value = '';
  handleSearch();
}
/** createdAt → 7일 이내 NEW */
function isNewByCreatedAt(createdAt) {
  if (!createdAt) return false
  const ts = Date.parse(createdAt)
  if (Number.isNaN(ts)) return false
  return (Date.now() - ts) <= SEVEN_DAYS
}

/** pageInfo 정규화 */
function normPageInfo(piRef) {
  const v = piRef?.value || {}
  return {
    currentPage: v.currentPage ?? v.current_page ?? 1,
    totalPages:  v.totalPages  ?? v.total_pages  ?? 1,
    perPage:     v.perPage     ?? v.per_page     ?? 8,
    hasNext:     v.hasNext     ?? v.has_next     ?? false,
    hasPrev:     v.hasPrev     ?? v.has_prev     ?? false,
  }
}

/** 스크롤 부모 */
function getScrollParent(el) {
  let node = el
  while (node && node !== document.body) {
    const { overflowY, overflow } = getComputedStyle(node)
    const canScroll = /(auto|scroll)/.test(overflowY) || /(auto|scroll)/.test(overflow)
    if (canScroll && node.scrollHeight > node.clientHeight) return node
    node = node.parentElement
  }
  return document.scrollingElement || document.documentElement
}

/** 높이 잠금 */
function lockHeight(el) {
  const h = el.getBoundingClientRect().height
  el.style.minHeight = `${Math.max(h, 1)}px`
}
function unlockHeight(el) {
  el.style.minHeight = ''
}

/* 도메인 훅 (템플릿 API) */
const { loading, templates, pageInfo, load, create, update, remove } = useReportTemplates()

/* 좌측(카드) UI 상태 */
const viewMode = ref('grid')
const accessLevel = ref('public')
const isPaging = ref(false)

/* 검색 상태 */
const searchKeyword = ref('')
const isSearching = ref(false)

/* 카드/드롭다운 상태 */
const cardListRef = ref(null)
const convDropPosition = reactive({ x: 0, y: 0 })
const isTemplateDrop = ref(false)
const menuTarget = ref(null)
const isPinned = ref(false)
const dropType = ref(null)

/* 카드 선택 상태 */
const selectedCardId = ref('')

/* 파일 첨부 상태 */
const {
  fileList, uploadedFileIds, handleFileUpload, handleFileIds,
  onFileUploadError, clearAllFiles, onFileProcessed, deleteFile,
} = useFileAttachments()

/* 모달 상태 */
const isOpen = ref(false)
const selectedTemplateId = ref('')
const contentEditor = ref('') // 모달 에디터 HTML
const newTemplate = reactive({ title: '', desc: '', isPinned: '' })

/* 최근 문서 (예시) */
const recentDocumentList = ref([
  { id: 'asdf0asdf81200512_12', type: '제안서',  title: 'AI Chatting 제안서',                   updateTime: '2025-01-01' },
  { id: 'asdf0asd232450512_12', type: '기획서',  title: '기획서 예시 타이틀',                           updateTime: '2025-01-01' },
  { id: 'asdf0as242420512_12',  type: '보도자료', title: '2025년 대통령선거 결과안내',                   updateTime: '2025-01-01' },
  { id: 'asdf0asdf854512_12',   type: '출장 보고서', title: '2004년 7월 27일 대전 한수원 출장 보고서',     updateTime: '2025-01-01' },
  { id: 'asdf0asdf854512_12x',  type: '출장 보고서', title: '2004년 7월 27일 현장지원 대전 한수원 출장 보고서', updateTime: '2025-01-01' },
])

// 최근 문서 로드
async function loadRecentDocumentList() {
  try {
    const res = await getDocumentsList({
      page: 1,
      size: 6,
    })
    
    // getDocumentsList 데이터를 recentDocumentList 형식으로 변환
    if (res.content && Array.isArray(res.content)) {
      recentDocumentList.value = res.content.map(doc => ({
        id: doc.documentKey,
        type: doc.extension || '문서',
        title: doc.title,
        updateTime: formatDate(doc.updatedAt)
      }))
    } else {
      recentDocumentList.value = []
    }
  } catch (error) {
    recentDocumentList.value = []
  }
}

/* computed */
const renderList = computed(() =>
  (templates.value || []).map(t => {
    const createdAt = t.created_at || t.createdAt
    return {
      ...t,
      icon: t.icon || 'Paper',
      new: isNewByCreatedAt(createdAt),
      checked: t.id === selectedCardId.value,
      description: t.description ?? t.desc,
    }
  })
)

const pageDots = computed(() => {
  const pi = normPageInfo(pageInfo)
  const total = Number(pi.totalPages || 1)
  const current = Number(pi.currentPage || 1)
  if (total <= 5) return Array.from({ length: total }, (_, i) => i + 1)
  const start = Math.max(1, Math.min(current - 2, total - 4))
  return [start, start + 1, start + 2, start + 3, start + 4]
})

/* 라이프 사이클 */
onMounted(async () => {
  selectedCardId.value = ''
  await reloadFirstPage()
  await loadRecentDocumentList()
})

const  toBeDevAlert = () => {
  toast.info('본 기능은 현재 개발 중입니다. 추후 업데이트를 통해 제공될 예정입니다.');
}

/* 템플릿 list: 로드/페이징 */
async function reloadFirstPage() {
  try {
    await load(agentCode, { accessLevel: accessLevel.value, page: 1, perPage: 8 })
  } catch (err) {
    console.error('템플릿 첫 페이지 로딩 실패:', err)
  }
}

async function loadPageAndScroll(page) {
  if (isPaging.value) return
  isPaging.value = true

  const el = cardListRef?.value
  const parent = el ? getScrollParent(el) : null

  let prevMinHeight = ''
  if (el) {
    prevMinHeight = el.style.minHeight
    lockHeight(el)
  }

  try {
    const pi = normPageInfo(pageInfo)
    const perPage = pi.perPage || 8
    await load(agentCode, { accessLevel: accessLevel.value, page, perPage })
    selectedCardId.value = ''

    await nextTick()
    if (el && parent) {
      const parentRect = parent.getBoundingClientRect()
      const elRect = el.getBoundingClientRect()
      const offsetTop = (parent.scrollTop || 0) + (elRect.top - parentRect.top) - 8
      parent.scrollTo({ top: Math.max(offsetTop, 0), behavior: 'smooth' })
    }
  } catch (err) {
    console.error('페이지 로딩 실패:', err)
  } finally {
    if (el) el.style.minHeight = prevMinHeight
    isPaging.value = false
  }
}

async function onAccessChange() {
  // 접근 레벨 변경 시 검색어가 있으면 검색, 없으면 전체 로드
  if (searchKeyword.value.trim()) {
    await handleSearch()
  } else {
    await loadTemplates()
  }
}
async function goPrev() {
  if (isPaging.value) return
  const pi = normPageInfo(pageInfo)
  const prev = Math.max(1, (pi.currentPage || 1) - 1)
  if (!pi.hasPrev || prev === pi.currentPage) return
  await loadPageAndScroll(prev)
}
async function goNext() {
  if (isPaging.value) return
  const pi = normPageInfo(pageInfo)
  const next = Math.min(pi.totalPages || 1, (pi.currentPage || 1) + 1)
  if (!pi.hasNext || next === pi.currentPage) return
  await loadPageAndScroll(next)
}
async function setPage(p) {
  if (isPaging.value) return
  const pi = normPageInfo(pageInfo)
  const total = Number(pi.totalPages || 1)
  const target = Math.min(Math.max(1, Number(p)), total)
  if (target === pi.currentPage) return
  await loadPageAndScroll(target)
}

/* 카드 / 드롭다운 / 모달 */
function handleTemplateCardClick(template) {
  selectedCardId.value = template.id
}
function toggleDropItem(event, type, template) {
  convDropPosition.x = event.clientX
  convDropPosition.y = event.clientY
  dropType.value = type

  if (type === 'card') {
    menuTarget.value = template || null
    isPinned.value = template.isPinned
  }

  if (type === 'file') {
    console.log('file');
  }

  isTemplateDrop.value = true
}
function handleAddTemplateCardClick() {
  resetModalForm()
  isOpen.value = true
}
function openEdit(template) {
  const t = template || menuTarget.value
  if (!t) return
  selectedTemplateId.value = t.id
  newTemplate.title = t.title || ''
  newTemplate.desc = t.description ?? t.desc ?? ''
  newTemplate.isPinned = !!t.isPinned
  contentEditor.value = t.content || ''
  isOpen.value = true
}
function onEditFromMenu() {
  openEdit(menuTarget.value)
  isTemplateDrop.value = false
}

function onPreviewFromMenu() {
  openEdit(menuTarget.value)
  isTemplateDrop.value = false
}

async function onTogglePinFromMenu() {
  try {
    await togglePin(menuTarget.value)
  } catch (err) {
    console.error('핀 토글 실패:', err)
  } finally {
    isTemplateDrop.value = false
  }
}
async function togglePin(template) {
  const t = template || menuTarget.value
  if (!t) return
  const next = !t.isPinned
  try {
    const res = await update(agentCode, t.id, {
      title: t.title ?? '',
      description: t.description ?? t.desc ?? '',
      content: t.content ?? '',
      is_pinned: next,
    })
    if (res.data.status === 'fail') {
      if (res.data.message === "This template can't be updated. It may not exist or belong to another user.") {
        toast.error('템플릿 핀고정 기능을 사용할 수 없습니다. 다른 사용자의 템플릿 입니다.');
      }
      return;
    }
  } catch (err) {
    console.error('핀 토글 API 실패:', err)
    throw err
  } finally {
    try {
      const pi = normPageInfo(pageInfo)
      await load(agentCode, {
        accessLevel: accessLevel.value,
        page: pi.currentPage || 1,
        perPage: pi.perPage || 8,
      })
    } catch (e) {
      console.error('토글 후 새로고침 실패:', e)
    }
  }
}

/* ★ 이부분 변경 */
async function onDeleteFromMenu() {
  isTemplateDrop.value = false
  const targetId = menuTarget.value?.id
  if (!targetId) return
  const ok = await openConfirm('이 템플릿을 삭제할까요? 되돌릴 수 없습니다.')
  if (!ok) return

  try {
    const res =  await remove(agentCode, targetId);
    if (res.data.status === 'fail') {
      if (res.data.message === 'This template can\'t be deleted. It may not exist or belong to another user.') {
        toast.error('템플릿을 삭제할 수 없습니다. 다른 사용자의 템플릿 입니다.');
      }
      return;
    }else{
      toast.info('삭제 완료');
    }
  } catch (err) {
    toast.error('템플릿 삭제 실패');

    console.error('템플릿 삭제 실패:', err)
    return
  }

  try {
    const pi = normPageInfo(pageInfo)
    await load(agentCode, {
      accessLevel: accessLevel.value,
      page: pi.currentPage,
      perPage: pi.perPage,
    })
  } catch (err) {
    console.error('삭제 후 목록 새로고침 실패:', err)
  } finally {
    menuTarget.value = null
  }
}

async function handleSendData() {
  // 모달 에디터 최신 본문을 contentEditor에 싱크
  syncFromModalEditor()

  const payload = {
    title: newTemplate.title || '',
    description: newTemplate.desc || '',
    content: contentEditor.value || '',
    is_pinned: !!newTemplate.isPinned,
  }

  try {
    if (selectedTemplateId.value) {
      const res = await update(agentCode, selectedTemplateId.value, payload);
      if (res.data.status === 'fail') {
        if (res.data.message === "This template can't be updated. It may not exist or belong to another user.") {
          toast.error('템플릿을 수정할 수 없습니다. 다른 사용자의 템플릿 입니다.');
        }
        return;
      }else{
        toast.info('수정 완료');
      }
    } else {
      await create(agentCode, payload)
    }
  } catch (err) {
    console.error('템플릿 저장 실패:', err)
    return
  }

  try {
    const pi = normPageInfo(pageInfo)
    await load(agentCode, {
      accessLevel: accessLevel.value,
      page: pi.currentPage,
      perPage: pi.perPage,
    })
  } catch (err) {
    console.error('저장 후 목록 새로고침 실패:', err)
  }

  resetModalForm()
  isOpen.value = false
}
function handleClose() {
  resetModalForm()
  isOpen.value = false
}
function resetModalForm() {
  newTemplate.title = ''
  newTemplate.desc = ''
  newTemplate.isPinned = ''
  contentEditor.value = ''
  selectedTemplateId.value = ''
  destroyModalEditor()
}
/* 서브밋 (→ 문서 생성 화면으로 브릿지) */
function onSubmitQuery(payload) {
  const message = (typeof payload === 'string' ? payload : payload?.message || '').trim()
  if (!message) return

  const chosen = (templates.value || []).find(t => t.id === selectedCardId.value) || null
  const templateLite = chosen
    ? { id: chosen.id, title: chosen.title, desc: chosen.description ?? chosen.desc }
    : null

  store.commit('docsBridge/setPending', {
    message,
    fileList: fileList.value,
    uploadedFileIds: uploadedFileIds.value,
    template: templateLite,
  })
  store.commit('setShowDocsAnswer', 'docs')

  router.push({
    name: 'Main',
    query: { ...route.query, accessLevel: accessLevel.value },
  })
}

/* flip 애니메이션 */
const prefersReduce =
  (typeof window !== 'undefined' && 'matchMedia' in window)
    ? window.matchMedia('(prefers-reduced-motion: reduce)')
    : { matches: false }

let prevRects = new Map()
onBeforeUpdate(() => {
  prevRects.clear()
  const list = cardListRef.value
  if (!list) return
  list.querySelectorAll('.document-template-card').forEach(el => {
    prevRects.set(el, el.getBoundingClientRect())
  })
})

onUpdated(() => {
  if (prefersReduce?.matches) return
  const list = cardListRef.value
  if (!list) return

  list.querySelectorAll('.document-template-card').forEach(el => {
    const prev = prevRects.get(el)
    const next = el.getBoundingClientRect()
    if (!prev) return

    const dx = prev.left - next.left
    const dy = prev.top - next.top
    if (dx === 0 && dy === 0) return

    el.style.transform = `translate(${dx}px, ${dy}px)`
    el.style.transition = 'none'

    requestAnimationFrame(() => {
      const anim = el.animate(
        [
          { transform: `translate(${dx}px, ${dy}px)`, opacity: 0.9 },
          { transform: 'translate(0, 0)', opacity: 1 },
        ],
        { duration: 200, easing: 'cubic-bezier(.2,.8,.2,1)' }
      )
      anim.onfinish = () => { el.style.transform = ''; el.style.transition = '' }
      anim.onerror  = () => { el.style.transform = ''; el.style.transition = '' }
    })
  })

  prevRects.clear()
})

function cardEnter(el, done) {
  if (prefersReduce?.matches) return done()
  el.style.willChange = 'transform, opacity'
  const anim = el.animate(
    [
      { opacity: 0, transform: 'scale(.98)' },
      { opacity: 1, transform: 'scale(1)'  },
    ],
    { duration: 180, easing: 'ease-out' }
  )
  anim.onfinish = () => { el.style.willChange = ''; done() }
  anim.onerror  = () => { el.style.willChange = ''; done() }
}
function cardLeave(el, done) {
  if (prefersReduce?.matches) return done()
  el.style.willChange = 'transform, opacity'
  const anim = el.animate(
    [
      { opacity: 1, transform: 'scale(1)'  },
      { opacity: 0, transform: 'scale(.98)' },
    ],
    { duration: 140, easing: 'ease-in' }
  )
  anim.onfinish = () => { el.style.willChange = ''; done() }
  anim.onerror  = () => { el.style.willChange = ''; done() }
}

/* 화살표/페이저 표시 */
const showLeftArrow = computed(() => {
  const pi = normPageInfo(pageInfo)
  return Number(pi.totalPages) > 1 && !!pi.hasPrev
})
const showRightArrow = computed(() => {
  const pi = normPageInfo(pageInfo)
  return Number(pi.totalPages) > 1 && !!pi.hasNext
})
const showPagerDots = computed(() => {
  const pi = normPageInfo(pageInfo)
  return Number(pi.totalPages) > 1
})

/* =======================
  모달용 TOAST UI Editor
======================= */
const modalEditorRoot = ref(null)
let modalEditor = null

watch(isOpen, async (open) => {
  if (open) {
    await nextTick()
    try {
      // 기존 인스턴스가 남아있다면 정리
      if (modalEditor) {
        modalEditor.destroy()
        modalEditor = null
      }

      const isFixed = selectedTemplateId.value && isFixedTemplate(selectedTemplateId.value)
      
      modalEditor = new Editor({
        el: modalEditorRoot.value,
        height: '520px',
        initialEditType: 'markdown',
        previewStyle: 'vertical',
        hideModeSwitch: true,
        usageStatistics: false,
        initialValue: '', // 아래 setMarkdown로 주입
        toolbarItems: isFixed ? [] : [
          ['heading', 'bold', 'italic', 'strike'],
          ['hr', 'quote'],
          ['ul', 'ol', 'task'],
          ['table', 'link'],
          ['code', 'codeblock'],
          ['scrollSync'],
        ],
        readOnly: isFixed,
      })

      // 기존/선택 템플릿 본문 반영 (마크다운만 사용)
      const markdown = String(contentEditor.value || '')
      modalEditor.setMarkdown(markdown)

      // 변경 이벤트 → contentEditor에 실시간 반영 (마크다운만 사용)
      modalEditor.on('change', () => {
        contentEditor.value = modalEditor.getMarkdown()
      })
    } catch (err) {
      console.error('모달 에디터 초기화 실패:', err)
    }
  } else {
    // 닫힐 때 정리
    destroyModalEditor()
  }
})

function syncFromModalEditor() {
  if (!modalEditor) return
  contentEditor.value = modalEditor.getMarkdown()
}

function destroyModalEditor() {
  if (!modalEditor) return
  try {
    modalEditor.destroy()
  } catch (err) {
    console.error('모달 에디터 destroy 실패:', err)
  } finally {
    modalEditor = null
  }
}

/* 검색 관련 함수들 */
async function handleSearch() {
  if (!searchKeyword.value.trim()) {
    // 검색어가 비어있으면 전체 목록 로드
    await loadTemplates()
    return
  }

  isSearching.value = true
  try {
    // 백엔드 API에 키워드 파라미터 추가
    await load(agentCode, {
      accessLevel: accessLevel.value,
      keyword: searchKeyword.value.trim()
    })
  } catch (error) {
    console.error('검색 실패:', error)
  } finally {
    isSearching.value = false
  }
}

async function loadTemplates() {
  try {
    await load(agentCode, {
      accessLevel: accessLevel.value
    })
  } catch (error) {
    console.error('템플릿 로드 실패:', error)
  }
}

// 최근 문서 아이템 클릭 처리
// async function handleDocumentItemClick(item) {
//   try {
//     const response = await downloadDocument(item.id, item.title);
//     toast.success(`${response.filename} 파일이 다운로드되었습니다.`);
//   } catch (error) {
//     toast.info('파일 다운로드 중 오류가 발생했습니다.');
//   }
// }
</script>
