<template>
  <div>
    <div class="login-wrapper" v-html="$t('')">
      <img :src="require('@/assets/images/loginImage.svg')"/>
    </div>
    <div class="login-body">
      <form class="login-form-wrapper form-wrapper">
        <CustomInput 
          id="userEmail"
          :label="$t('loginview.loginview_key2')"
          name="email"
          :placeholder="$t('loginview.loginview_key1')"
          v-model="userEmail"
        />

        <CustomPs 
          id="userPassword"
          :label="$t('loginview.loginview_key5')"
          name="password"
          :placeholder="$t('loginview.loginview_key4')"
          v-model="userPs"
        />

        <CustomCheck 
          id="savedUserInfo"
          :label="$t('loginview.loginview_key6')"
          v-model="savedUserInfo"
        />     
        
        <CustomSubmit 
          id="userLogin"
          label="로그인"
          @sumbit="checkLogin"
        />

        <div class="login-error-box">
          <span class="error-emssage">{{ errorMessage }}</span>
        </div>
      </form>
    </div>
    <div class="login-footer">
      <div class="copyright">Copyright© BESPIN GLOBAL. All Rights Reserved.</div>
    </div>    
  </div> 
</template>

<script>
import CustomInput from '@/component/CustomInput';
import CustomPs from '@/component/CustomPs';
import CustomCheck from '@/component/CustomCheck';
import CustomSubmit from '@/component/CustomSubmit';

export default {
  name: 'LoginView',
  components: {
    CustomInput,
    CustomPs, 
    CustomCheck, 
    CustomSubmit
  },
  data() {
    return {
      userEmail: "",
      userPs: "",
      savedUserInfo: false, 
      errorMessage: this.$t("loginview.loginview_key3")
    };
  },
  created() {
  },
  methods: {
    checkLogin() {
      // console.log('login');
    }
  }
};
</script>

