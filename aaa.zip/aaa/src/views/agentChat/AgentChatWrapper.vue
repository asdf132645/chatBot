<template>
  <div class="agent-chat-wrapper">
    <div class="agent-chat-header">

    </div>

      <div class="agent-chat-body">
        <div v-if="chatList.length === 0" class="agent-chat-body-empty">
          <div class="agent-chat-empty-content">
            <div class="agent-chat-empty-title">{{ safeCurrentDoc.name }}에 대해서 무엇이 궁금한가요?</div>
            <div class="agent-chat-empty-subtitle">
              <div class="agent-chat-rolling-text">
                <div 
                  v-for="(text, index) in rollingTexts" 
                  :key="index"
                  class="agent-chat-rolling-item"
                  :class="{ 'active': currentRollingIndex === index }"
                >
                  {{ text }}
                </div>
              </div>
            </div>
          </div>
        </div>
      <AgentAnswerContent
        v-for="answer in chatList"
        :id="`agent-answer-${answer.id}`"
        :key="answer.id"
        :answer="answer"
        :queryLoading="queryLoading"
        :lastAnswer="chatList[chatList.length - 1] === answer"
        @toggleState="handleToggleState"
      /> 
    </div>

    <div class="agent-chat-footer">
      <div class="agent-chat-query-inputer-wrapper">
        <QueryInputer
          ref="agentQueryInputer"
          id="agentQueryInputer"
          :isQueryLoading="isStreaming"
          :placeholder="`${safeCurrentDoc.name}에 대해서 궁금한 내용을 입력하세요!`"
          :isUploadHidden="true"
          :isInteractionHidden="true"
          :isMultiAnswer="true"
          @submit="handleSubmitQuery"
        />
      </div>
      <div class="agent-chat-footer-box">
      </div>
    </div>

  </div>
</template>

<script setup>
import { ref, computed, defineProps, defineExpose, onMounted, onBeforeUnmount, watch, nextTick } from 'vue';
import { useStore } from 'vuex';
import { useAgentChat } from '@/domains/agentChat/application/useAgentChat';
import { getDomainInfo } from '@/domains/chat/infrastructure/chatApi';
import QueryInputer from '@/component/QueryInputer.vue';
import AgentAnswerContent from '@/domains/agentChat/presentation/AgentAnswerContent.vue';

// 부모로부터 받는 props
const props = defineProps({
  fileTagValue: { type: String, default: '' },
  fileSummaryValue: { type: String, default: '' },
  filePromptValue: { type: String, default: '' },
  currentTab: { type: String, default: 'tag' },
  currentDoc: { type: Object, default: null },
  sBoxName: { type: String, default: '' }
});

// Agent 채팅 훅 사용
const {
  chatList,
  isStreaming,
  queryLoading,
  startAgentChat,
  toggleAnswerState,
  clearChatList,
  updateConfig
} = useAgentChat();

const agentQueryInputer = ref(null);

// Store
const store = useStore();


// 세션 정보
const session = computed(() => store.getters.session || {});
const sessionId = computed(() => session.value.session_id || '');

// currentDoc 안전 처리
const safeCurrentDoc = computed(() => props.currentDoc || { name: 'Agent Chat' });

// Agent 설정
const insightPromptId = ref('4bd9cbed-9346-4dd3-b5e5-ff4c2a5514eb');

// 쿼리 처리 상태
const isQueryProcessing = ref(false);

// 롤업 텍스트 관련
const currentRollingIndex = ref(0);
const rollingTexts = ref([
  '이 문서의 주요 내용을 요약해주세요',
  '핵심 키워드와 개념을 알려주세요',
  '이 문서에서 중요한 데이터나 통계는 무엇인가요?',
  '이 문서의 결론이나 요점을 설명해주세요',
  '이 문서와 관련된 추가 정보가 있나요?'
]);

// 롤업 애니메이션 타이머
let rollingTimer = null;

// 롤업 애니메이션 시작
function startRollingAnimation() {
  if (rollingTimer) {
    clearInterval(rollingTimer);
  }
  
  rollingTimer = setInterval(() => {
    currentRollingIndex.value = (currentRollingIndex.value + 1) % rollingTexts.value.length;
  }, 2000);
}

// 롤업 애니메이션 중지
function stopRollingAnimation() {
  if (rollingTimer) {
    clearInterval(rollingTimer);
    rollingTimer = null;
  }
}

// 설정 업데이트
if (insightPromptId.value) {
  updateConfig({ insightPromptId: insightPromptId.value });
}


/**
 * 쿼리 처리 시작/종료 핸들러
 * @param {boolean} isProcessing - 처리 중 여부
 */

async function handleSubmitQuery(query, isMultiAnswer) {
  // QueryInputer 인풋창 비우기
  if (agentQueryInputer.value && agentQueryInputer.value.clearInput) {
    agentQueryInputer.value.clearInput();
  }
  if (!query || !query.trim()) {
    console.warn('빈 쿼리입니다.');
    return;
  }

  if (isStreaming.value) {
    console.warn('이미 처리 중입니다.');
    return;
  }


  try {   
    isQueryProcessing.value = true;    
    await startAgentChat({
      query: query.trim(),
      sessionId: sessionId.value,
      agentCode: getDomainInfo().chatbotCode, // 에이전트 코드
      language: "ko", // 언어 코드
      isMultiAnswer: isMultiAnswer,
      onScroll: scrollToBottom
    });

  } catch (error) {
    console.error('에이전트 쿼리 처리 오류:', error);
  } finally {
    isQueryProcessing.value = false;
  }
}

function handleToggleState(params) {
  toggleAnswerState(params.answerId);
}

/**
 * 답변 완료 핸들러
 * @param {Object} result - 답변 결과
 */

/**
 * 부모에서 쿼리 전송
 * @param {string} query - 쿼리
 */
function sendFromParent(query) {
  if (agentQueryInputer.value) {
    agentQueryInputer.value.sendFromParent(query);
  }
}

// 스크롤 디바운싱을 위한 타이머
let scrollTimer = null;

/**
 * 화면 하단으로 스크롤 (디바운싱 적용)
 */
function scrollToBottom() {
  // 기존 타이머가 있으면 취소
  if (scrollTimer) {
    clearTimeout(scrollTimer);
  }
  
  // 다음 틱에서 실행하여 DOM 업데이트 후 스크롤
  nextTick(() => {
    const agentChatBody = document.querySelector('.agent-chat-body');
    if (agentChatBody) {
      agentChatBody.scrollTo({
        top: agentChatBody.scrollHeight,
        behavior: 'smooth'
      });
    }
  });
  
  // 디바운싱: 100ms 후에 한 번 더 스크롤 (스트리밍 완료 후 최종 스크롤)
  scrollTimer = setTimeout(() => {
    nextTick(() => {
      const agentChatBody = document.querySelector('.agent-chat-body');
      if (agentChatBody) {
        agentChatBody.scrollTo({
          top: agentChatBody.scrollHeight,
          behavior: 'smooth'
        });
      }
    });
  }, 100);
}

// chatList 변화 감지하여 애니메이션 제어 및 자동 스크롤
watch(chatList, (newList, oldList) => {
  if (newList.length === 0) {
    startRollingAnimation();
  } else {
    stopRollingAnimation();
    
    // 스트리밍 중이거나 새로운 답변이 추가된 경우 자동 스크롤
    if (isStreaming.value || (newList.length > (oldList?.length || 0))) {
      scrollToBottom();
    }
  }
}, { immediate: true });

// 스트리밍 상태 변화 감지하여 자동 스크롤
watch(isStreaming, (newValue, oldValue) => {
  // 스트리밍이 시작되면 자동 스크롤 시작
  if (newValue && !oldValue) {
    scrollToBottom();
  }
});

// 컴포넌트 마운트 시 초기 프롬프트 처리
onMounted(() => {
  // filePromptValue가 존재하고 공백이 아니면 자동으로 Agent 쿼리 실행
  if (props.filePromptValue && props.filePromptValue.trim()) {
    setTimeout(() => {
      sendFromParent(props.filePromptValue.trim());
    }, 100);
  }
});

// 컴포넌트 언마운트 시 타이머 정리
onBeforeUnmount(() => {
  stopRollingAnimation();
  if (scrollTimer) {
    clearTimeout(scrollTimer);
    scrollTimer = null;
  }
});

// 부모에서 호출할 수 있는 메서드 정의
defineExpose({
  /**
   * 채팅 리스트 초기화
   */
  clearChat() {
    clearChatList();
  },

  /**
   * 특정 답변으로 스크롤
   * @param {string} answerId - 답변 ID
   */
  scrollToAnswer(answerId) {
    const element = document.getElementById(`agent-answer-${answerId}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }
});

</script>
