<template>
  <div class="page-section">
    <div class="page-header">
      <div class="page-item-group">
        <div class="page-item check-input">
          <NewCustomCheck
            class="check-item"
            id="selectedAllRow"
            :label="$t('filetab.filetab_key2')"
            v-model="selectedAllRow"
          />
        </div>

        <button class="page-item" @click="openSelectedDeleteModal" :disabled="selectedIds.length === 0">
          <BaseIcon :size="20" name="DeleteOutline" />
        </button>

        <div class="search-input page-item">
          <input
            type="text"
            v-model="searchKeyword"
            @keydown.enter="handleSearch"
            :placeholder="$t('filetab.filetab_key3')"
          />
          <button class="search-icon icon" @click="handleSearch">
            <BaseIcon name="InputSearch" />
          </button>
        </div>
      </div>

      <div class="file-usage ml-auto">
        <BaseIcon name="Folder" :size="18" />
        <span class="count">{{ usage }}</span>
      </div>
    </div>

    <div class="page-body">
      <div class="table">
        <table>
          <thead>
          <tr>
            <th v-for="th in tableTh" :key="th.id" :width="th.size">{{ th.name }}</th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="(td, index) in files" :key="td.id">
            <td class="center">
              <NewCustomCheck
                class="page-item check-item"
                :id="td.id"
                v-model="td.selected"
              />
            </td>
            <td class="center">{{ totalCount - ((currentPage - 1) * pageSize + index) }}</td>
            <td>{{ td.fileName }}</td>
            <td class="primary center">{{ td.fileSize }}</td>
            <td class="center">{{ td.userName }} <span>({{ td.userId }})</span></td>
            <td class="center">{{ td.updateDate }}</td>
            <td class="center">
              <button class="btn-table" @click="handleDownload(td.id)">
                <BaseIcon :size="16" name="Download" />
              </button>
              <button class="btn-table" @click="openSingleDeleteModal(td.id)">
                <BaseIcon :size="16" name="DeleteOutline" />
              </button>
            </td>
          </tr>
          </tbody>
        </table>

        <TablePagination
          :totalCount="totalCount"
          :page="currentPage"
          :perPage="pageSize"
          :perPageOptions="[10, 20, 50]"
          @changePage="changePage"
          @changePerPage="changePageSize"
        />
      </div>
    </div>

    <MyModal
      :isOpenModal="isOpenModal"
      :title="$t('filetab.filetab_key4')"
      width="400"
      :okBtnName="$t('filetab.filetab_key5')"
      :isLinkCopy="false"
      @close="isOpenModal = false"
      @sendData="confirmDelete"
    >
      <template #content>
        <p>{{ $t('filetab.filetab_key1') }}</p>
      </template>
    </MyModal>

    <BaseToast ref="toastRef" />
  </div>
</template>

<script setup>
import { useI18n } from 'vue-i18n';
const { t } = useI18n();

import { ref, onMounted, watch, computed, defineProps } from 'vue'
import { useFileManage } from '@/domains/fileMange/application/useFileManage'
import BaseIcon from '@/component/BaseIcon'
import TablePagination from '@/component/TablePagination'
import MyModal from '@/component/MyModal.vue'
import NewCustomCheck from '@/shared/component/common/NewCustomCheck.vue'
import BaseToast from '@/shared/component/common/BaseToast.vue'

const props = defineProps({
  groupType: { type: String, default: 'corp' },
})

const selectedAllRow = ref(false)
const isOpenModal = ref(false)
const deleteTargetIds = ref([])
const searchKeyword = ref('')
const currentPage = ref(1)
const pageSize = ref(20)
const totalCount = ref(0)
const toastRef = ref(null)

const tableTh = ref([
  { id: 'selected', name: '', size: 40 },
  { id: 'index', name: 'No.', size: 60 },
  { id: 'name', name: t("filetab.filetab_key6"), size: '' },
  { id: 'fileSize', name: t("filetab.filetab_key7"), size: 100 },
  { id: 'proposer', name: t("filetab.filetab_key8"), size: 180 },
  { id: 'register', name: t("filetab.filetab_key9"), size: 120 },
  { id: 'buttonGroup', name: t("filetab.filetab_key10"), size: 120 },
])

const { files, usage, loadFiles, deleteFile, downloadFile } = useFileManage()

watch(selectedAllRow, val => {
  files.value = files.value.map(file => ({ ...file, selected: val }))
})

const selectedIds = computed(() => files.value.filter(f => f.selected).map(f => f.id))

async function getList() {
  const group = props.groupType === 'corp' ? 'corp' : 'dept'
  try {
    const res = await loadFiles({
      group,
      page: currentPage.value,
      pageSize: pageSize.value,
      keyword: searchKeyword.value,
    })
    totalCount.value = res?.totalCount || 0
  } catch {
    toastRef.value?.show(t("filetab.filetab_key11"), 'error')
  }
}

function changePage(page) {
  currentPage.value = page
  getList()
}

function changePageSize(size) {
  pageSize.value = size
  currentPage.value = 1
  getList()
}

function handleSearch() {
  currentPage.value = 1
  getList()
}

function openSingleDeleteModal(fileId) {
  deleteTargetIds.value = [fileId]
  isOpenModal.value = true
}

function openSelectedDeleteModal() {
  if (selectedIds.value.length > 0) {
    deleteTargetIds.value = [...selectedIds.value]
    isOpenModal.value = true
  }
}

async function confirmDelete() {
  await Promise.all(
    deleteTargetIds.value.map(id =>
      deleteFile(id).catch(() => {
        toastRef.value?.show(t("filetab.filetab_key12"), 'error')
      })
    )
  )
  isOpenModal.value = false
  deleteTargetIds.value = []
  getList()
}

async function handleDownload(fileId) {
  try {
    const res = await downloadFile(fileId)
    if (res?.success) {
      toastRef.value?.show(t("filetab.filetab_key13"), 'success')
    } else {
      toastRef.value?.show(t("filetab.filetab_key14"), 'error')
    }
  } catch (e) {
    toastRef.value?.show(t("filetab.filetab_key14"), 'error')
  }
}

onMounted(() => {
  getList()
})
</script>
