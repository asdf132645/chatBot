<template>
  <div>
    <component :is="currentTab" :groupType="groupType" />
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useStore } from 'vuex'

import FileTabMangeWrapper from '@/views/fileManage/fileTab.vue'
import FileUploadRequest from '@/views/fileManage/FileUploadRequest.vue'
import FileApproval from '@/views/fileManage/FileApproval.vue'

const store = useStore()

const currentTab = computed(() => {
  const tab = store.getters.selectedTab
  return tab === 'FileTabMangeWrapper'
    ? FileTabMangeWrapper
    : tab === 'FileUploadRequest'
      ? FileUploadRequest
      : FileApproval
})

// 전사/부서 타입 가져오기
const groupType = computed(() => store.state.fileGroupType)
</script>
