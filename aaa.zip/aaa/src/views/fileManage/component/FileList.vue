<template>
  <div class="files-wrapper">
    <div
      v-for="file in fileListArray"
      :key="file.id || `${file.name}-${file.size}`"
      class="file-item"
      :title="file.name"
    >
      <div v-if="isFileLoading" class="spinner-icon" />
      <BaseIcon v-if="file.fileType" :size="14" :name="file.fileType || 'File'" />
      <span class="file-item-name">{{ file.name }}</span>
      <button
        :disabled="isFileLoading"
        class="btn-close"
        @click="onDeleteFile(file.id)"
      >
        <BaseIcon :size="14" name="Close" />
      </button>
    </div>
  </div>
</template>

<script setup>
import { computed, defineProps, defineEmits } from 'vue'
import { useStore } from 'vuex'
import BaseIcon from '@/component/BaseIcon.vue'

const props = defineProps({
  fileList: { type: Array, default: () => [] }
})
const emit = defineEmits(['deleteFile'])

const fileListArray = computed(() => props.fileList)

const store = useStore()
const isFileLoading = computed(() => store.state.isFileLoading) // 혹은 getter 사용

function onDeleteFile(fileId) {
  emit('deleteFile', fileId)
}
</script>
ㄴ