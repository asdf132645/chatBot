<template>
    <div>
    <Teleport to="#modal-destination">
      <Transition>
        <div v-if="isOpenModal" class="modal-container">
          <div class="modal-box file-upload-modal remove-padding-modal">
            <div class="modal-header">
              <h3 class="modal-title">{{ $t('fileuploadmodal.fileuploadmodal_key3') }}</h3>
              <button class="close-button" @click="closeUploadModal">
                <BaseIcon :size="24" name="Close" />
              </button>
            </div>
            <div class="modal-body">
              <div 
                class="attach-item file-upload-item" 
                v-for="(attachItem) in localAttachList" 
                :key="attachItem.id"
              >
                <div class="item-head">
                  <span class="title-icon">
                    <BaseIcon :size="32" :name="attachItem.type" />
                  </span>
                </div>
                <div class="item-body">
                  <h5 class="title">{{ attachItem.title }}</h5>

                  <template v-if="attachItem.status === 'progress'">
                    <div class="progress-bar">
                      <div 
                        class="progress" 
                        :style="{ width: attachItem.progress + '%'}"
                      ></div>
                    </div>
                  </template>
                  <template v-else>
                    <div class="row items-center">
                      <p class="size">{{ attachItem.size }}MB</p>
                      <p class="status complete" v-if="attachItem.status === 'complete'">{{ $t('fileuploadmodal.fileuploadmodal_key4') }}</p>
                      <p class="status error" v-if="attachItem.status === 'error'">{{ $t('fileuploadmodal.fileuploadmodal_key5') }}</p>
                    </div>
                  </template>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>

    <Teleport to="#modal-destination">
        <Transition>
        <div v-if="isErrorModalOpen" 
          class="modal-container message-modal">
            <div class="modal-box">
              <div class="modal-header">
                <button class="close-button" @click="closeErrorModal">
                  <BaseIcon :size="24" name="Close" />
                </button>
              </div>

              <!-- 실패했을 때 메세지 -->
              <div class="modal-body">
                <div><BaseIcon :size="32" name="InfoCircle" /></div>
                <h4 class="title">{{ $t('fileuploadmodal.fileuploadmodal_key6') }}</h4>
                <p class="desc" v-html="$t('fileuploadmodal.fileuploadmodal_key1')"></p>
                <div class="files">
                  <div class="file-label" v-for="file in failedFiles" :key="file.id">{{ file.title }}</div>               
                </div>
              </div>

              <!-- 성공했을 때 메세지 -->
              <div class="modal-body" v-if="false">
                <div class="message-icon"><BaseIcon :size="20" name="Check" /></div>
                <h4 class="title">{{ $t('fileuploadmodal.fileuploadmodal_key7') }}</h4>
                <p class="desc" v-html="$t('fileuploadmodal.fileuploadmodal_key2')"></p>                
              </div>
            </div>
        </div>
        </Transition>
    </Teleport>
    </div>
  </template>
  
  <script>
import axios from 'axios';
import BaseIcon from '@/component/BaseIcon.vue';
  
  export default {
    name: 'FileUploadModal',
    components: { BaseIcon },
    props: {
      isOpenModal: Boolean,
      attachList: Array, // [{ id, title, size, type, status: 'progress' | 'complete' | 'error', progress }]
    },
    data() {
      return {
        localAttachList: JSON.parse(JSON.stringify(this.attachList)),
        isErrorModalOpen: false,
        failedFiles: [],
      };
    },
    watch: {
      attachList: {
        handler(newList) {
          this.localAttachList = JSON.parse(JSON.stringify(newList));
        },
        deep: true,
      },
    },
    methods: {
        simulateUpload(index) {
        let progress = 0;
        this.localAttachList[index].status = 'progress';
        
        const interval = setInterval(() => {
            if (progress >= 100) {
            clearInterval(interval);
            if (Math.random() < 0.5) { // 30% chance of failure
                this.localAttachList[index].status = 'error';
                this.failedFiles.push(this.localAttachList[index]);
                this.isErrorModalOpen = true;
            } else {
                this.localAttachList[index].status = 'complete';
            }
            } else {
            progress += 10;
            this.localAttachList[index].progress = progress;
            }
        }, 500);
        },
        async uploadFile(file, index) {
        try {
            const formData = new FormData();
            formData.append('file', file);
            
            await axios.post('/upload', formData, {
            onUploadProgress: (progressEvent) => {
                const percent = Math.round((progressEvent.loaded / progressEvent.total) * 100);
                this.$set(this.localAttachList, index, { ...this.localAttachList[index], progress: percent });
            },
            });
            
            this.$set(this.localAttachList, index, { ...this.localAttachList[index], status: 'complete' });
        } catch (error) {
            this.$set(this.localAttachList, index, { ...this.localAttachList[index], status: 'error' });
            this.failedFiles.push(this.localAttachList[index]);
            this.isErrorModalOpen = true;
        }
        },
        closeUploadModal() {
        this.$emit('close', this.localAttachList.filter(file => file.status === 'complete'));
        },
        closeErrorModal() {
        this.isErrorModalOpen = false;
        },
    },
    mounted() {
      // Simulate upload when modal opens
      this.localAttachList.forEach((file, index) => {
        this.simulateUpload(index);
      });
    }
  };
</script>
  
