<template>
  <div class="files-wrapper">
    <div
      v-for="file in fileList"
      :key="file.id || `${file.name}-${file.size}-${file.type}`"
      class="file-item"
    >
      <BaseIcon :size="14" :mr="6" :name="file.fileType || 'File'" />
      <span class="file-item-name">{{ file.name }}</span>
      <button
        class="ml8 close-btn"
        @click.stop="deleteFile(file.id)"
        type="button"
      >
        <BaseIcon :size="14" name="Close" />
      </button>
    </div>
  </div>
</template>

<script>
import BaseIcon from '@/component/BaseIcon.vue'

export default {
  name: 'FileList',
  components: {
    BaseIcon,
  },
  props: {
    fileList: {
      type: Array,
      default: () => [],
    },
  },
  methods: {
    deleteFile(fileId) {
      this.$emit('deleteFile', fileId)
    },
  },
}
</script>
