<template>
  <div class="page-section">
    <!-- 헤더 -->
    <div class="page-header">
      <div class="page-item-group">
        <!-- 전체 선택 체크박스 -->
        <div class="page-item check-input">
          <NewCustomCheck
            class="check-item"
            id="selectedAllRow"
            :label="$t('fileapproval.fileapproval_key4')"
            v-model="selectedAllRow"
          />
        </div>

        <button
          class="page-item"
          :disabled="!hasSelected"
          @click="approveFiles"
          :class="{ 'disabled': !hasSelected }"
        >{{ $t('fileapproval.fileapproval_key1') }} <BaseIcon name="Check" :size="14" :mr="4" /></button>

        <button
          class="page-item"
          :disabled="!hasSelected"
          @click="openRejectMultiple"
          :class="{ 'disabled': !hasSelected }"
        >{{ $t('fileapproval.fileapproval_key2') }} <BaseIcon name="Close" :size="14" :mr="4" /></button>

        <!-- 검색 -->
        <div class="search-input page-item">
          <input
            type="text"
            :placeholder="$t('fileapproval.fileapproval_key5')"
            v-model="searchText"
            @keyup.enter="getFileApprovalList"
          />
          <button class="search-icon icon" @click="getFileApprovalList">
            <BaseIcon name="InputSearch" />
          </button>
        </div>

        <!-- 상태 필터 -->
        <div class="toggle-btn-group">
          <div class="toggle-label-icon">
            <BaseIcon name="Filter" :size="14" />
          </div>
          <div
            class="toggle-btn"
            v-for="status in approval"
            :key="status.id"
            :class="{ selected: selectedStatus === status.id }"
            @click="selectStatus(status.id)"
          >
            <BaseIcon name="Check" :size="14" :mr="4" v-if="selectedStatus === status.id" />
            {{ status.name }}
          </div>
        </div>
      </div>
    </div>

    <!-- 테이블 -->
    <div class="page-body">
      <div class="table">
        <table>
          <thead>
          <tr>
            <th v-for="th in tableTh" :key="th.id" :width="th.size">{{ th.name }}</th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="(td, index) in tableItems" :key="td.id">
            <td class="center">
              <NewCustomCheck class="check-item" :id="td.id" v-model="td.selected" />
            </td>
            <td class="center">
              {{ totalCount - ((currentPage - 1) * pageSize + index) }}
            </td>
            <td>{{ td.fileName }}</td>
            <td class="primary center">{{ td.fileSize }}</td>
            <td class="center">{{ td.proposer }} <span>({{ td.proposerId }})</span></td>
            <td class="center">{{ td.proposeDate }}</td>
            <td class="center">{{ approvalStatusLabel(td.approvalStatus) }}</td>
            <td class="center">{{ td.approvalDate }}</td>
            <td class="center">{{ td.approver }} <span>{{ td.approverId }}</span></td>
            <td class="center">
              <button class="btn-table" @click="openRejectionModal(td)">
                <BaseIcon :size="16" name="Paper" />
              </button>
            </td>
          </tr>
          </tbody>
        </table>

        <!-- 페이징 -->
        <TablePagination
          :totalCount="totalCount"
          :page="currentPage"
          :perPage="pageSize"
          :perPageOptions="[10, 20, 50]"
          @changePage="changePage"
          @changePerPage="changePageSize"
        />
      </div>
    </div>

    <!-- 반려 모달 -->
    <MyModal
      width="385"
      v-if="isRejectedModal"
      :isOpenModal="isRejectedModal"
      :title="$t('fileapproval.fileapproval_key6')"
      :okBtnName="$t('fileapproval.fileapproval_key2')"
      @close="isRejectedModal = false"
      @sendData="rejectedFile"
    >
      <template #content>
        <p class="desc">{{ $t('fileapproval.fileapproval_key3') }}</p>
        <div class="textarea mt-20">
          <textarea
            v-model="rejectedReason"
            :placeholder="$t('fileapproval.fileapproval_key3')"
          />
          <div class="text-limit-message">{{ rejectedReason.length }} / 500</div>
        </div>
      </template>
    </MyModal>

    <BaseToast ref="toastRef" />
  </div>
</template>

<script setup>
import { useI18n } from 'vue-i18n';
const { t } = useI18n();

import { ref, defineProps, onMounted, computed, watch } from 'vue'
import BaseIcon from '@/component/BaseIcon.vue'
import TablePagination from '@/component/TablePagination.vue'
import MyModal from '@/component/MyModal.vue'
import { fileManageApi } from '@/domains/fileMange/infrastructure/fileManageApi'
import NewCustomCheck from '@/shared/component/common/NewCustomCheck.vue'
import BaseToast from '@/shared/component/common/BaseToast.vue'

const toastRef = ref(null)

const props = defineProps({
  groupType: { type: String, default: 'corp' },
})

// 상태 변수들
const isRejectedModal = ref(false)
const rejectedReason = ref('')
const selectedAllRow = ref(false)
const selectedStatus = ref('all')
const searchText = ref('')
const currentPage = ref(1)
const pageSize = ref(10)
const totalCount = ref(0)
const tableItems = ref([])
const selectedFile = ref(null)

const approval = [
  { id: 'all', name: t("fileapproval.fileapproval_key7") },
  { id: 'pending', name: t("fileapproval.fileapproval_key8") },
  { id: 'approved', name: t("fileapproval.fileapproval_key1") },
  { id: 'rejected', name: t("fileapproval.fileapproval_key2") },
]

const tableTh = [
  { id: 'selected', name: '', size: 40 },
  { id: 'index', name: 'No.', size: 60 },
  { id: 'name', name: t("fileapproval.fileapproval_key9"), size: '' },
  { id: 'fileSize', name: t("fileapproval.fileapproval_key10"), size: 100 },
  { id: 'proposer', name: t("fileapproval.fileapproval_key11"), size: 180 },
  { id: 'proposeDate', name: t("fileapproval.fileapproval_key12"), size: 100 },
  { id: 'approvalStatus', name: t("fileapproval.fileapproval_key13"), size: 100 },
  { id: 'approvalDate', name: t("fileapproval.fileapproval_key14"), size: 100 },
  { id: 'approver', name: t("fileapproval.fileapproval_key15"), size: 180 },
  { id: 'rejection', name: t("fileapproval.fileapproval_key16"), size: 80 },
]

const hasSelected = computed(() => tableItems.value.some(item => item.selected))

watch(selectedAllRow, (val) => {
  tableItems.value.forEach(item => {
    item.selected = val
  })
})

function approvalStatusLabel(status) {
  switch (status) {
    case 'approved': return t("fileapproval.fileapproval_key1");
    case 'pending': return t("fileapproval.fileapproval_key8");
    case 'rejected': return t("fileapproval.fileapproval_key2");
    default: return status
  }
}

function selectStatus(id) {
  selectedStatus.value = id
  currentPage.value = 1
  getFileApprovalList()
}

function changePage(page) {
  currentPage.value = page
  getFileApprovalList()
}

function changePageSize(size) {
  pageSize.value = size
  currentPage.value = 1
  getFileApprovalList()
}

function openRejectionModal(file) {
  selectedFile.value = file
  rejectedReason.value = ''
  isRejectedModal.value = true
}

function openRejectMultiple() {
  selectedFile.value = null
  rejectedReason.value = ''
  isRejectedModal.value = true
}

async function rejectedFile() {
  const selected = selectedFile.value
    ? [selectedFile.value]
    : tableItems.value.filter(item => item.selected)

  if (selected.length === 0) {
    toastRef.value?.show(t("fileapproval.fileapproval_key17"), 'warning')
    isRejectedModal.value = false
    return
  }

  const ids = selected.map(item => item.id)

  try {
    await fileManageApi.rejectFilesApi({ ids, reason: rejectedReason.value })
    selected.forEach(item => {
      item.approvalStatus = 'rejected'
      item.rejection = rejectedReason.value
    })
    toastRef.value?.show(`${ids.length}개의 파일이 반려되었습니다.`, 'success')
  } catch (e) {
    toastRef.value?.show(t("fileapproval.fileapproval_key18"), 'error')
  }

  isRejectedModal.value = false
}

async function approveFiles() {
  const selected = tableItems.value.filter(item => item.selected)
  if (selected.length === 0) {
    toastRef.value?.show(t("fileapproval.fileapproval_key19"), 'warning')
    return
  }

  const ids = selected.map(item => item.id)

  try {
    await fileManageApi.approveFilesApi(ids)
    selected.forEach(item => {
      item.approvalStatus = 'approved'
    })
    toastRef.value?.show(`${ids.length}개의 파일이 승인되었습니다.`, 'success')
  } catch (e) {
    toastRef.value?.show(t("fileapproval.fileapproval_key20"), 'error')
  }
}

async function getFileApprovalList() {
  const params = {
    groupType: props.groupType,
    page: currentPage.value,
    pageSize: pageSize.value,
    keyword: searchText.value,
    approvalStatus: selectedStatus.value,
  }

  const res = await fileManageApi.getUploadRequestList(params)

  tableItems.value = res.items.map(item => ({
    ...item,
    selected: false,
  }))
  totalCount.value = res.totalCount
}

onMounted(getFileApprovalList)
</script>
