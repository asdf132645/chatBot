<template>
  <div class="page-section" @dragover.prevent="isDragging = true" @dragleave.prevent="isDragging = false" @drop.prevent="handleDrop">
    <div class="page-header">
      <div class="page-item-group">
        <div class="search-input page-item">
          <input type="text" :placeholder="$t('fileuploadrequest.fileuploadrequest_key6')" v-model="searchText" @keyup.enter="reloadList" />
          <button class="search-icon icon" @click="reloadList">
            <BaseIcon name="InputSearch" />
          </button>
        </div>
        <button class="page-item" :disabled="uploading" @click="triggerFileInput">{{ $t('fileuploadrequest.fileuploadrequest_key1') }} <BaseIcon name="Upload" :size="14" :mr="4" /></button>
        <span class="desc">{{ $t('fileuploadrequest.fileuploadrequest_key2') }} </span>
      </div>
    </div>
    <!-- 상단 상태 알림 모달 -->
    <UploadDetailModal
      :uploadedFiles="uploadedFiles"
      :uploading="uploading"
      :cancelUpload="cancelUpload"
      :clearUploads="clearUploads"
    >
      <template #content>
        <div class="upload-summary">{{ uploadStatusMessage }}</div>

        <ul class="upload-file-list">
          <li
            v-for="file in uploadedFiles"
            :key="file.id"
            class="upload-file-item"
            :class="{
          cancelled: file.status === 'CANCELED',
          failed: file.status === 'FAILED'
        }"
          >
            <div class="file-info-wrapper">
          <span>
            {{ file.fileName }}
            <template v-if="file.status === 'CANCELED'">{{ $t('fileuploadrequest.fileuploadrequest_key3') }}</template>
          </span>

              <button
                v-if="file.status === 'READY'"
                class="cancel-btn"
                @click.stop="cancelUpload(file.id)"
              >{{ $t('fileuploadrequest.fileuploadrequest_key4') }}</button>
            </div>

            <BaseIcon :name="statusIcon(file.status)" :size="14" />
          </li>
        </ul>
      </template>
    </UploadDetailModal>




    <div class="page-body">
      <div v-if="isDragging" class="dragging-message">
        <div>
          <div>
            <div class="file-upload-img-wrapper">
              <img class="file-upload-img" :src="require('@/assets/images/FileUpload.svg')" />
            </div>
          </div>
          <div>
            <div class="file-upload-title">{{ $t('fileuploadrequest.fileuploadrequest_key5') }}</div>
            <div class="file-upload-desc">Click to upload or drag and drop</div>
          </div>
        </div>
      </div>

      <!-- 테이블 -->
      <div class="table">
        <table>
          <thead>
          <tr>
            <th v-for="th in tableTh" :key="th.id" :width="th.size">{{ th.name }}</th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="(td, index) in tableItems" :key="td.id">
            <td class="center">{{ totalCount - (currentPage - 1) * pageSize - index }}</td>
            <td>
                <span class="file-name">
                  {{ td.fileName }}
                </span>
            </td>
            <td class="primary center">{{ td.fileSize }}</td>
            <td class="center">{{ td.proposeDate }}</td>
            <td class="center">{{ statusLabel(td.status) }}</td>
            <td class="center">{{ td.approvalDate }}</td>
            <td class="center">{{ td.approver }} <span>({{ td.approverId }})</span></td>
            <td class="center">
              <button class="btn-table"
                      v-if="td.status === 'REJECTED'"
                      @click.stop="openRejectedReasonModal(td)"

              ><BaseIcon :size="16" name="Paper" /></button>
            </td>
          </tr>
          </tbody>
        </table>

        <TablePagination
          :totalCount="totalCount"
          :page="currentPage"
          :perPage="pageSize"
          :perPageOptions="[10, 20, 50]"
          @changePage="changePage"
          @changePerPage="changePageSize"
        />
      </div>
    </div>

    <!-- 파일 input -->
    <input type="file" ref="fileInput" style="display: none" multiple @change="handleFileInputChange" accept=".pdf,.csv" />

    <!--  파일 상세 모달 -->
    <UploadDetailModal
      v-if="selectedFile"
      :file="selectedFile"
      :total-upload-count="uploadedFiles.length"
      @close="selectedFile = null"
      @cancel="cancelUpload"
    />
    <MyModal
      width="385"
      v-if="isRejectedModal"
      :isOpenModal="isRejectedModal"
      :title="$t('fileuploadrequest.fileuploadrequest_key7')"
      okBtnName=""
      @close="isRejectedModal = false"
    >
      <template #content>
        <p>{{ rejectedReason || '사유 없음' }}</p>
      </template>
    </MyModal>

  </div>
</template>

<script setup>
import { useI18n } from 'vue-i18n';
const { t } = useI18n();

import { ref, onMounted, defineProps, computed } from 'vue';
import BaseIcon from '@/component/BaseIcon.vue'
import TablePagination from '@/component/TablePagination.vue'
import UploadDetailModal from '@/domains/fileMange/presentation/UploadDetailModal.vue'
import { useFileUploadRequestList } from '@/domains/fileMange/application/useFileUploadRequestList'
import { uploadFileRequest } from '@/domains/fileMange/application/uploadFileRequest'
import MyModal from '@/component/MyModal.vue';
import { fileManageApi } from '@/domains/fileMange/infrastructure/fileManageApi';

const props = defineProps({ groupType: { type: String, default: 'corp' } })

const tableTh = [
  { id: 'index', name: 'No.', size: 60 },
  { id: 'name', name: t("fileuploadrequest.fileuploadrequest_key8"), size: '' },
  { id: 'fileSize', name: t("fileuploadrequest.fileuploadrequest_key9"), size: 100 },
  { id: 'proposeDate', name: t("fileuploadrequest.fileuploadrequest_key10"), size: 120 },
  { id: 'status', name: t("fileuploadrequest.fileuploadrequest_key11"), size: 100 },
  { id: 'approvalDate', name: t("fileuploadrequest.fileuploadrequest_key12"), size: 120 },
  { id: 'approver', name: t("fileuploadrequest.fileuploadrequest_key13"), size: 120 },
  { id: 'rejectReason', name: t("fileuploadrequest.fileuploadrequest_key14"), size: 120 },
]

const tableItems = ref([])
const totalCount = ref(0)
const currentPage = ref(1)
const pageSize = ref(10)
const searchText = ref('')
const isDragging = ref(false)
const fileInput = ref(null)
const uploading = ref(false)
const uploadedFiles = ref([])
const uploadErrorCount = ref(0)
const selectedFile = ref(null)
const isRejectedModal = ref(false)
const rejectedReason = ref('')

const statusIcon = (status) => {
  switch (status) {
    case 'READY': return 'UploadStatusCircle'
    case 'UPLOADING': return 'UploadStatusRefresh'
    case 'COMPLETED': return 'UploadStatusCheck'
    case 'REJECTED': return 'UploadStatusAlert'
    case 'FAILED': return 'UploadStatusAlert'
    case 'CANCELED': return 'UploadStatusClose'
    case 'REVIEWING': return 'UploadStatusCircle'
    default: return 'READY'
  }
}


const getFileUploadReqList = async () => {
  const res = await useFileUploadRequestList({
    groupType: props.groupType,
    page: currentPage.value,
    pageSize: pageSize.value,
    keyword: searchText.value.trim(),
  })
  tableItems.value = res.items
  totalCount.value = res.totalCount
}

const changePage = (page) => { currentPage.value = page; getFileUploadReqList() }
const changePageSize = (size) => { pageSize.value = size; currentPage.value = 1; getFileUploadReqList() }
const reloadList = () => { currentPage.value = 1; getFileUploadReqList() }
const triggerFileInput = () => fileInput.value?.click()

const handleFileInputChange = (e) => {
  const files = Array.from(e.target.files || [])
  processFiles(files)
}
const handleDrop = (e) => {
  isDragging.value = false
  const files = Array.from(e.dataTransfer.files || [])
  processFiles(files)
}
const uploadStatusMessage = computed(() => {
  const total = uploadedFiles.value.length
  const failed = uploadedFiles.value.filter(f => f.status === 'FAILED').length

  if (uploading.value) {
    return `${total}개 파일 업로드 중`
  }

  if (failed > 0) {
    return `${total}개 중 ${total - failed}개 파일 업로드 완료`
  }

  return `${total}개 파일 업로드 완료`
})

const openRejectedReasonModal = (file) => {
  rejectedReason.value = file.rejectReason || ''
  isRejectedModal.value = true
}

const processFiles = async (files) => {
  uploading.value = true
  uploadErrorCount.value = 0

  const fileRows = files.map((file, idx) => ({
    id: `${Date.now()}-${idx}`,
    fileName: file.name,
    fileSize: formatSize(file.size),
    proposeDate: new Date().toISOString().slice(0, 10),
    status: 'UPLOADING',
    approvalDate: '-',
    approver: '-',
    approverId: '-',
    rejectReason: '',
  }))

  // 화면에 추가
  tableItems.value.unshift(...fileRows)
  totalCount.value += fileRows.length

  // FormData로 묶기
  const formData = new FormData()
  files.forEach(file => {
    formData.append('files', file) // 백엔드에서 files[]로 받을 경우
  })

  try {
    // 업로드 요청 (백엔드에서 multiple files 처리 필요)
    const res = await uploadFileRequest(formData) //multipart/form-data 처리 필수

    // res.data는 업로드된 파일 응답이라고 생각하고 임의로 만들었습니다.
    const uploaded = res.data || []

    uploaded.forEach((fileResult) => {
      const matched = fileRows.find(f => f.fileName === fileResult.fileName)
      if (matched) Object.assign(matched, fileResult)
    })
  } catch (e) {
    // 전체 실패 시
    fileRows.forEach(row => {
      row.status = 'FAILED'
      row.rejectReason = e.message || t("fileuploadrequest.fileuploadrequest_key15")
      uploadErrorCount.value++
    })
  }
  uploadedFiles.value = fileRows
  uploading.value = false
}



const cancelUpload = async (fileId) => {
  const file = uploadedFiles.value.find(f => f.id === fileId)
    || tableItems.value.find(f => f.id === fileId)

  if (!file) return

  if (file.status === 'READY') {
    // 실제 취소 api 호출하는곳
    await fileManageApi.cancelUploadRequest(fileId)
    file.status = 'CANCELED'
    file.cancelable = false
  }

  selectedFile.value = null
}

const clearUploads = () => {
  uploadedFiles.value = []
  uploadErrorCount.value = 0
}

const formatSize = (bytes) => {
  const mb = bytes / 1024 / 1024
  return mb.toFixed(1) + 'MB'
}
const statusLabel = (status) => {
  switch (status) {
    case 'COMPLETED':
      return t("fileuploadrequest.fileuploadrequest_key16");
    case 'READY':
      return t("fileuploadrequest.fileuploadrequest_key17");
    case 'CANCELED':
      return t("fileuploadrequest.fileuploadrequest_key18");
    case 'FAILED':
      return t("fileuploadrequest.fileuploadrequest_key19");
    case 'REJECTED':
      return t("fileuploadrequest.fileuploadrequest_key20");
    case 'UPLOADING':
      return t("fileuploadrequest.fileuploadrequest_key21");
    default:
      return status // 예상치 못한 경우 그대로 출력
  }
}


onMounted(() => getFileUploadReqList())
</script>
