<template>
  <div class="answer-page-wrapper">
    <div class="answer-page-box">
      <AnswerContent
        v-for="answer in answerWrapper"
        :key="answer.id"
        :answer="answer"
      />
    </div>
  </div>
</template>
<script>
import AnswerContent from '@/component/AnswerContent.vue'
export default {
  name: 'AnswerWrapper',
  components: {
    AnswerContent,
  },
  data() {
    return {
      answerWrapper: [], 
    };
  },
  created() {
    this.answerWrapper = []; 
  },
  methods: { 
  }
};
</script>
