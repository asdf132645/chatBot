<template>
  <aside>
    <div v-if="isLoading">
      <div class="reference-group">
        <div class="reference-item" style="padding: 0 !important">
          <img class="blinking" :src="require('@/assets/images/refer_paragraph_light.svg')" />
        </div>
        <div class="reference-item" style="padding: 0 !important">
          <img class="blinking" :src="require('@/assets/images/refer_paragraph_light.svg')" />
        </div>
        <div class="reference-item" style="padding: 0 !important">
          <img class="blinking" :src="require('@/assets/images/refer_paragraph_light.svg')" />
        </div>
      </div>
    </div>
    <transition name="fade">
      <div v-if="!isLoading && shouldShow">
        <div class="aside-title wrapper-title">
          <div class="ref-area" @click="activeReference()" v-if="hasFileList">
            <span class="title-icon" v-if="isRefOpen"><BaseIcon name="BulbIdea"/></span>
            <span class="title-icon" v-if="!isRefOpen"><BaseIcon name="BulbIdeaOff"/></span>
            <h4 class="title-text">{{ $t('referencewrapper.referencewrapper_key1') }}</h4>
          </div>
          <div class="ref-area attach-area" @click="activeAttach()" v-if="hasAttachList">
            <span class="title-icon" v-if="isAttachOpen"><BaseIcon name="FolderOn"/></span>
            <span class="title-icon" v-if="!isAttachOpen"><BaseIcon name="FolderOff"/></span>
            <h4 class="title-text">{{ $t('referencewrapper.referencewrapper_key2') }}</h4>
          </div>
        </div>
        <div class="reference-group">
          <transition name="fade">
            <div v-if="isRefOpen && hasFileList" class="reference-group-wrapper">
              <div
                class="reference-item"
                v-for="(item, idx) in pagedFileList"
                :key="item.id"
                @click="openUrl(btnUrls[idx])"
                :title="item.doc_title"
              >
                <h4 class="title">{{ item.source_id }}</h4>
                <p class="desc line-clamp">{{ item.content }}</p>
                <span class="filename">{{ item.doc_title }}</span>
              </div>
            </div>
          </transition>

          <transition name="fade">
            <div v-if="isAttachOpen && hasAttachList">
              <div class="attach-item" v-for="att in attachList" :key="att.id">
                <div class="item-head">
                  <BaseIcon :size="32" :name="att.type" />
                </div>
                <div class="item-body">
                  <h4 class="title">{{ att.filename }}</h4>
                  <p class="desc">{{ formatSize(att) }}</p>
                </div>
              </div>
            </div>
          </transition>
        </div>

        <div
          class="reference-group-control-wrapper"
          v-if="totalPage > 1 && hasFileList"
        >
          <div class="reference-group-control">
            <div class="pagination-status">
              <span class="current-page">{{ currentPage }}</span> /
              <span class="total-page">{{ totalPage }}</span>
            </div>
            <button
              class="pagination-btn left"
              :disabled="isFirstPage"
              @click="prevPage"
            >
              <BaseIcon name="ArrowLeft" :size="18" />
            </button>
            <button
              class="pagination-btn right"
              :disabled="isLastPage"
              @click="nextPage"
            >
              <BaseIcon name="ArrowRight" :size="18" />
            </button>
          </div>
        </div>
      </div>
    </transition>
  </aside>
</template>

<script setup>
import { ref, computed, watch, onMounted, defineProps } from 'vue';
import { useStore } from 'vuex';
import BaseIcon from '@/component/BaseIcon.vue';

// props 정의
const props = defineProps({
  answer: { type: Object, default: () => ({ messages: [] }) },
  answerHeight: { type: Number, default: 900 },
  isLoading: { type: Boolean, default: true },
  fileList: { type: Array, default: () => [] },
  attachList: { type: Array, default: () => [] },
});

const store = useStore();

// state
const currentPage = ref(1);
const totalPage = ref(0);
const pagingSize = ref(3);
const isRefOpen = ref(true);
const isAttachOpen = ref(false);

// computed
const hasFileList = computed(() => props.fileList.length > 0);
const hasAttachList = computed(() => props.attachList.length > 0);
const shouldShow = computed(() => hasFileList.value || hasAttachList.value);

const btnUrls = computed(() => {
  let raw = props.answer.messages;
  let msgs = [];
  if (typeof raw === 'string') {
    try {
      msgs = JSON.parse(raw);
    } catch (e) {
      console.error(e);
    }
  } else if (Array.isArray(raw)) {
    msgs = raw;
  }
  return msgs
    .filter(item => Array.isArray(item.content))
    .flatMap(item => item.content)
    .map(card => card.buttonList?.[0]?.btnOuaUrl)
    .filter(url => !!url);
});

const pagedFileList = computed(() => {
  const start = (currentPage.value - 1) * pagingSize.value;
  return props.fileList.slice(start, start + pagingSize.value);
});

const isFirstPage = computed(() => currentPage.value <= 1);
const isLastPage = computed(() => currentPage.value >= totalPage.value);

// methods
function calculatePaging() {
  pagingSize.value = Math.max(1, Math.floor(props.answerHeight / 300));
  totalPage.value = Math.ceil(props.fileList.length / pagingSize.value);
  if (currentPage.value > totalPage.value) {
    currentPage.value = Math.max(1, totalPage.value);
  }
}

function updateVisibility() {
  if (hasFileList.value) {
    isRefOpen.value = true;
    isAttachOpen.value = false;
  } else if (hasAttachList.value) {
    isRefOpen.value = false;
    isAttachOpen.value = true;
  } else {
    isRefOpen.value = false;
    isAttachOpen.value = false;
  }
}

function prevPage() {
  if (currentPage.value > 1) currentPage.value--;
}

function nextPage() {
  if (currentPage.value < totalPage.value) currentPage.value++;
}

function activeReference() {
  isRefOpen.value = true;
  isAttachOpen.value = false;
}

function activeAttach() {
  isRefOpen.value = false;
  isAttachOpen.value = true;
}

function openUrl(url) {
  if (store.getters.session.chatbotCode === '58a4440d-9f6e-4070-800b-931555355465')
    return;
  if (url) window.open(url, '_blank');
}
function formatBytes(input) {
  const bytes = typeof input === 'number' ? input : Number(input) || 0;
  if (bytes === 0) return '0 B';
  const k = 1024;
  const units = ['B','KB','MB','GB','TB','PB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  const val = bytes / Math.pow(k, i);
  // 값 크기에 따라 소수점 자리수 조절
  const fixed = val >= 100 ? 0 : val >= 10 ? 1 : 2;
  return `${val.toFixed(fixed)} ${units[i]}`;
}

function formatSize(att) {
  const bytes = att?.sizeBytes ?? att?.size ?? 0;
  return formatBytes(bytes);
}

// watch & lifecycle
watch(
  () => props.fileList,
  () => {
    calculatePaging();
    updateVisibility();
  },
  { deep: true, immediate: true },
);
watch(
  () => props.attachList,
  () => updateVisibility(),
  { deep: true, immediate: true },
);
watch(
  () => props.answerHeight,
  () => calculatePaging(),
  { immediate: true },
);

onMounted(() => {
  calculatePaging();
  updateVisibility();
});
</script>
