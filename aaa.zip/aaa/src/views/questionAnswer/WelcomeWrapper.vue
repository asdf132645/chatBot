<template>
  <div class="welcome-page-wrapper" :class="{ 'dragging': isDragging }">
    <div class="welcome-page-box">
      <!-- 헤더 -->
      <div class="welcome-header-wrapper">
        <div class="header-title-hello">
          <span v-if="userChatbot.chatbotName">{{ userChatbot.chatbotName }}</span>
        </div>
        <div class="header-title-question" v-if="userChatbot.description">
          {{ userChatbot.description }}
        </div>
        <div class="header-title-desc" v-if="welcomeMessage.length">
          <div class="pre" v-for="(msg, i) in welcomeMessage" :key="i" v-html="msg" />
        </div>
      </div>

      <!-- 입력창 -->
      <QueryInputer
        v-if="session"
        ref="queryInputer"
        id="welcomeQueryInputer"        
        :fileList="fileListArray"
        :isQueryLoading="store.state.isChatSending"
        :sessionId="session.convId"
        :isSelectedModel="true"
        @submit="welcomeMessgeSendAnswerWrapper"
        @fileIds="handleFileIds"
        @fileUpload="handleFileUpload"
        :placeholder="t('welcomewrapper.welcomewrapper_key4')"
        @fileError="onFileUploadError"
        @clearFiles="clearAllFiles"
        @fileProcessed="onFileProcessed"
      />

      <!-- 업로드된 파일 리스트 -->
      <FileList
        v-if="Array.isArray(fileListArray) && fileListArray.length > 0"
        :fileList="fileListArray || []"
        @deleteFile="deleteFile"
      />

      <!-- 추천 프롬프트 -->
      <RecommendList
        class="mt8"
        v-if="pinnedRecommendList.length"
        page="welcome"
        :title="t('welcomewrapper.welcomewrapper_key2')"
        :recommendList="pinnedRecommendList"
        @submit="welcomeMessgeSendAnswerWrapper"
      />
      
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, defineProps, defineEmits, computed, nextTick } from 'vue';
import { useI18n } from 'vue-i18n';
import QueryInputer from '@/component/QueryInputer.vue';
import RecommendList from '@/component/RecommendList';
import FileList from '@/views/fileManage/component/FileList.vue';
import { deleteFileIds } from '@/domains/chat/infrastructure/fileUpload/fileMgrApi';
import { usePrompt } from '@/domains/prompt/application/usePrompt';
import { useChat } from '@/domains/chat/application/useChat';
import { useStore } from 'vuex';
import { v1 as uuidv1 } from 'uuid';

const { isDragging, fileListArray } = defineProps({
  isDragging: Boolean,
  showFileList: Boolean,
  fileListArray: { type: Array, default: () => [] },
});

const emit = defineEmits(['submit',
  'fileUpload', 'deleteFile', 'welcomeMessgeSendAnswerWrapper', 'fileIds', 'fileUploadError',
  'clearFiles', 
  'fileProcessed']);
const store = useStore();
const { t } = useI18n();
const queryInputer = ref(null);
const fileIds = ref([]);
const session = computed(() => store.getters.session);
import { getFileIconName } from '@/composables/chatUtils';

const { fetchUserPrompts } = usePrompt();

const {
  defaultWelcomeMessage,
  userChatbot,
  welcomeMessage,
  pinnedRecommendList,
  initPageDataSet,
} = useChat(emit);

// 마운트 시 초기 웰컴 메시지 로딩 및 프롬프트 목록 가져오기
onMounted(async () => {
  // 이전에 받아온 메시지가 있으면 사용, 아니면 기본 메시지
  await nextTick();
  await welcomeEvent();
  const code = session.value?.chatbotCode;
  if (code) {
    await fetchUserPrompts(code, 1);
  }
});


// 파일 아이디 수신
function handleFileIds(ids) {
  fileIds.value = ids;
  emit('fileIds', ids);
}

function handleFileUpload(files) {
  const toAppend = files.map(file => ({
    id: uuidv1(),
    name: file.name,
    size: file.size,
    type: file.type,
    file,
    status: 'ready',
    fileType: getFileIconName(file.type),
  }));
  emit('fileUpload', toAppend);
}


// 파일 삭제 핸들러
function deleteFile(id) {
  if (fileIds.value.length) {
    deleteFileIds(fileIds.value[0]).catch(() => {
    });
    fileIds.value = [];
  }
  emit('deleteFile', id);
}

// 쿼리인풋에서 받아온 내용을 새로운 타이틀로 저장 하는 부분
async function welcomeMessgeSendAnswerWrapper(payload) {
  let query = typeof payload === 'string' ? payload.trim() : (payload.message?.trim() || '');
  if (!query) return;
  store.commit('setShowWelcome', false); // 웰컴페이지 안 보이게 하고 앤서래퍼 페이지 보이게
  emit('welcomeMessgeSendAnswerWrapper', payload); // send 함수를 호출하기 위해서 에밋으로 호출
  store.commit('setNewChat', {
    flag: true,
    message: payload,
  }); // 새로운 채팅일 경우 lnb 에서 추가 하는 스토어

}

function onFileUploadError(payload) {
  // 자식에서 온 에러를 상위로 그대로 전달
  emit('fileUploadError', payload)
}

function clearAllFiles() {
  // 자식이 실패 시 전체 파일 초기화가 필요하다고 알림
  emit('clearFiles')
}

function onFileProcessed({ file }) {
  // 성공 후 파일 상태 변경 필요 알림
  emit('fileProcessed', { file })
}

async function welcomeEvent() {
  try {
    // useChat의 initPageDataSet를 호출해서 첫 번째 welcome 화면에서 필요한 UI 정보를 받아오는 함수
    const res = await initPageDataSet({
      linkedIntent: 'Default Welcome Intent',
      startQuery: null,
      calendarParameters: null,
      accordionParameters: null,
      req_ai_response: false,
      sbData: null,
      msgObj: null,
      isInit: false,
    });
    // 방금 받아온 메시지에서 simpleResponse만 추출
    const raw = res?.sbData?.messages || '[]';
    const parsed = JSON.parse(raw);
    const simples = parsed.flatMap(m => m.simpleResponse).filter(Boolean);
    welcomeMessage.value = simples.length
      ? simples
      : defaultWelcomeMessage.value;
  } catch (e) {
    console.error('welcomeEvent() 실패', e);
  }
}

</script>

<style scoped>
.modal-content.scroll-container {
  position: relative;
  height: 72vh;
  overflow-y: auto;
}
</style>
