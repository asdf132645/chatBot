<template>
  <div class="answer-page-wrapper" :class="{ 'dragging': isDragging }">
    <div class="answer-page-box">
      <AnswerContent
        v-for="(answer, index) in answerWrapper"
        :id="`answer-${answer.id}`"
        :lastAnswer="answerWrapper[answerWrapper.length - 1] === answer"
        :key="answer.id"
        :answer="answer"
        :searchList="answer.searchList"
        :queryLoading="answer.queryLoading"
        :recomLoading="answer.recomLoading"
        :answerLoading="store.state.isChatSending"
        :currIndex="index"
        :isStateOpen="answer.isStateOpen"
        @submitQuery="suggestSendChat"
        @openImageModal="openImageModal"
        @toggleState="() => toggleAnswerState(index)"
        :response="answer.response"
      />

      <div class="answer-query-wrapper">
        <FileList
          :fileList="fileList"
          @deleteFile="deleteFile"
        />
        
        <QueryInputer
          ref="queryInputer"
          id="answerQueryInputer"
          class="mt6"
          :isQueryLoading="store.state.isChatSending"
          :sessionId="session.session_id"
          :fileList="fileList"
          :placeholder="t('answerwrapper.answerwrapper_key4')"
          :isSelectedModel="true"
          @submit="suggestSendChat"
          @fileIds="handleFileIds"
          @fileUpload="handleFileUpload"
          @fileError="onFileUploadError"
          @clearFiles="clearAllFiles"
          @fileProcessed="onFileProcessed"
        />
      </div>

      <DropDown
        :width="154"
        :top="answerDropPosition.y"
        :left="answerDropPosition.x"
        :isOpenDrop="isAnswerDrop"
        @close="isAnswerDrop.value = false"
        dropdownName="answerdrop-menu-wrapper"
      >
        <template #content>
          <ul>
            <li>
              <button class="nav-btn" @click.stop="deleteAnswer">
                <BaseIcon name="Delete" :size="20" :mr="8" />
                {{ t('answerwrapper.answerwrapper_key3') }}
              </button>
            </li>
          </ul>
        </template>
      </DropDown>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, nextTick, defineProps, defineEmits, defineExpose } from 'vue'
import { useStore } from 'vuex'
import { useI18n } from 'vue-i18n'
// import { v1 as uuidv1 } from 'uuid'

// components
import FileList from '@/views/fileManage/component/FileList.vue'
import QueryInputer from '@/component/QueryInputer.vue'
import AnswerContent from '@/component/AnswerContent.vue'
// import UserPromptGallery from '../../domains/prompt/presentation/UserPromptGallery.vue'
import DropDown from '@/component/DropDown.vue'
import BaseIcon from '@/component/BaseIcon.vue'

// domain
import { useChat } from '@/domains/chat/application/useChat'
import { deleteFileIds } from '@/domains/chat/infrastructure/fileUpload/fileMgrApi'



//  props: 부모가 fileList를 내려준다
const props = defineProps({
  isDragging: { type: Boolean, default: false },
  showFileList: { type: Boolean, default: false },
  uploadedFileIds: { type: Array, default: () => [] },
  isQueryLoading: { type: Boolean, default: false },
  position: { type: String, default: 'bottom' },
  mode: { type: String, default: '' },
  basicName: { type: String, default: '' },
  type: { type: String, default: '' },
  confidence: { type: Boolean, default: false },
  closeButton: { type: Boolean, default: false },
  isAdmin: { type: Boolean, default: false },
  isCurrentAgent: { type: Boolean, default: false },
  currUserInfo: {
    type: Object,
    default: () => ({
      chatbotCode: '',
      userId: '',
      username: '',
      phoneNumber: '',
      location: '',
      date: '',
      sessionId: '',
      status: ''
    })
  },
  fileList: { type: Array, default: () => [] } // 부모 단일 소스
})

const emit = defineEmits([
  'queryProcess',
  'fileUpload',
  'deleteFile',
  // ↓ 자식 이벤트 재전달 파일 관련
  'fileIds',
  'fileUploadError',
  'clearFiles',
  'fileProcessed',
])

const {
  answerWrapper,
  send,
  initChatPage
} = useChat(emit)

// answerWrapper의 상태를 직접 토글하는 함수
const toggleAnswerState = (index) => {
  if (answerWrapper.value[index]) {
    const currentState = answerWrapper.value[index].isStateOpen
    answerWrapper.value[index].isStateOpen = !currentState
  }
}

const store = useStore()
const { t } = useI18n();
const queryInputer = ref(null)

const isImageModal = ref(false)
const recomImage = ref([])
const imageId = ref('')
const isAnswerDrop = ref(false)
const answerDropPosition = ref({ x: 0, y: 0 })
const fileIds = ref([]); //(AnswerWrapper 내부 QueryInputer용)

// 부모가 준 리스트를 그대로 사용
const fileList = computed(() => props.fileList)

// 세션
const session = computed(() => store.getters.session)
import { getFileIconName } from '@/composables/chatUtils';


// const copyToClipboard = (text) => {
//   if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
//     navigator.clipboard.writeText(text).catch(err => console.warn(t('answerwrapper.answerwrapper_key16'), err))
//   } else {
//     const textarea = document.createElement('textarea')
//     textarea.value = text
//     textarea.style.position = 'fixed'
//     textarea.style.left = '-9999px'
//     document.body.appendChild(textarea)
//     textarea.focus()
//     textarea.select()
//     try { document.execCommand('copy') } catch (err) { console.warn(t('answerwrapper.answerwrapper_key17'), err) }
//     document.body.removeChild(textarea)
//   }
// }

const openImageModal = (imageModalParam) => {
  isImageModal.value = true
  imageId.value = imageModalParam.imageId
  recomImage.value = imageModalParam.recomImage
}

function handleFileIds(ids) {
  // 자식이 내려준 successFiles를 상위로 그대로 전달
  fileIds.value = ids || []
  emit('fileIds', fileIds.value)
}

// 업로드: 자식에서 리스트 수정 X → 부모에 알림
const handleFileUpload = (files) => {
  const toAppend = files.map(file => ({
    id: session.value.session_id,
    name: file.name,
    size: file.size,
    type: file.type,
    file,
    status: 'ready',
    fileType: getFileIconName(file.type)
  }))
  emit('fileUpload', toAppend)
}

// 삭제: 자식에서 리스트 수정 X → 부모에 알림 (+ 서버 정리는 옵션)
const deleteFile = (fileId) => {
  if (fileIds.value.length > 0) {
    deleteFileIds(fileIds.value[0]).catch(console.warn)
    fileIds.value = []
  }
  emit('deleteFile', fileId)
}

const deleteAnswer = () => {
  if (answerWrapper.value.length === 0) return
  answerWrapper.value.pop()
  isAnswerDrop.value = false
}

const resolvedFileIds = computed(() =>
    (props.uploadedFileIds?.length ? props.uploadedFileIds : fileIds.value) || []
  )


// 전송
const suggestSendChat = (payload) => {
  let query = ''
  if (typeof payload === 'string') query = payload.trim()
  else if (payload?.message) query = payload.message.trim()
  if (!query) return;

  emit('queryProcess', true)
  store.commit('setNewChat', { flag: false, message: '' })
  send(query, {
    req_ai_response: false,
    startQuery: null,
    sbData: null,
    msgObj: null,
    flowType: 'searchAssist',
    fileList: fileList.value,
    fileIds: resolvedFileIds.value
  })
  // emit('answerEnd');

  // QueryInputer 인풋창 비우기
  if (queryInputer.value && queryInputer.value.clearInput) {
    queryInputer.value.clearInput();
  }
}

function onFileUploadError(payload) {
  // 자식에서 온 에러를 상위로 그대로 전달
  emit('fileUploadError', payload)
}

function clearAllFiles() {
  // 자식이 실패 시 전체 파일 초기화가 필요하다고 알림
  emit('clearFiles')
}

function onFileProcessed({ file }) {
  // 성공 후 파일 상태 변경 필요 알림
  emit('fileProcessed', { file })
}

watch(session, (newSession) => {
  if (newSession) initChatPage(newSession)
}, { deep: true, immediate: true })

onMounted(() => {
  const s = session.value
  answerWrapper.value = s.answerList
  if (s.isInit && s.initValue) {
    send(s.initValue, { flowType: 'searchAssist', isInit: true })
    store.commit('setSession', { ...s, isInit: false })
  }
})

defineExpose({
  onGoAnswer: (ans) => {
    nextTick(() => {
      const el = document.getElementById(`answer-${ans.id}`)
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' })
    })
  },
  sendFromParent: (value) => {
    nextTick(() => { suggestSendChat(value) })
  }
})
</script>
