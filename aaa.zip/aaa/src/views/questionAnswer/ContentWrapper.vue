<template>
  <div
    class="body-wrapper"
    id="scrollContainer"
    @dragover.prevent="handleDragOver"
    @dragleave="handleDragLeave"
    @drop.prevent="handleDrop"
  >
    <!-- 문서 답변 화면: 부모의 파일/파일ID 바인딩 + 업로드 이벤트 연동 Rag랑 연동-->
    <DocumentAnswerWrapper
      v-if="showDocsAnswer === 'docs'"
      :fileList="fileListArray"
      :uploadedFileIds="fileIds"
      @answerEnd="handleAnswerEnd"
      :isQueryLoading="isQueryLoading"
      @fileUpload="handleFileUpload"
      @fileIds="(ids) => { fileIds.value = ids || [] }"
      @deleteFile="deleteFile"
      @newSessionCreated="handleNewSessionCreated"
    />
    <DocumentDriveWrapper
      v-if="showDocsAnswer === 'docsRepository'"
    />

    <ConversationHistoryWrapper
      v-if="showDocsAnswer === 'convHistory'"
    />
    <!-- 웰컴 화면( 초기화면임) -->
    <WelcomeWrapper
      v-if="showWelcome && !isLoading && showDocsAnswer === ''"
      ref="welcomeRef"
      :fileListArray="fileListArray"
      :isDragging="isDragging"
      :showFileList="showFileList"
      :isQueryLoading="isQueryLoading"
      @answerEnd="handleAnswerEnd"
      @welcomeMessgeSendAnswerWrapper="welcomeMessageSendAnswerWrapper"      
      @deleteFile="deleteFile"
      @fileUpload="handleFileUpload"
      @fileIds="setUploadedFileIds"
      @fileUploadError="onFileUploadError"
      @clearFiles="clearAllFiles"
      @fileProcessed="onFileProcessed"
    />
    <!-- 질문 했을경우 답변주는 화면(시나리오 빌드랑 연동)   -->
    <AnswerWrapper
      v-if="!showWelcome && !isLoading && showDocsAnswer === ''"
      ref="answerRef"
      :fileList="fileListArray"
      :uploadedFileIds="fileIds.value"
      :isDragging="isDragging"
      :showFileList="showFileList"
      :isQueryLoading="isQueryLoading"
      :conversation="currConversation"
      :isMultiAnswer="isMultiAnswer"
      @answerEnd="handleAnswerEnd"
      @queryProcess="handleQueryProcess"
      @deleteConversation="deleteConversation"
      @deleteFile="deleteFile"
      @fileUpload="handleFileUpload"
      @fileIds="setUploadedFileIds"
      @fileUploadError="onFileUploadError"
      @clearFiles="clearAllFiles"
      @fileProcessed="onFileProcessed"
    />

    <AnswerProgressWrapper
      v-if="isLoading"
    />

    <!-- Blur message when dragging -->
    <DragMessage       
      v-if="isDragging && imageUploadEnabled" 
    />
    <!-- <KeepAlive include="DragMessage">
    </KeepAlive> -->

  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch, defineProps, defineEmits, nextTick } from 'vue'
import { useStore } from 'vuex'
import WelcomeWrapper from './WelcomeWrapper.vue'
import AnswerWrapper from './AnswerWrapper.vue'
import AnswerProgressWrapper from './AnswerProgressWrapper.vue'
import ConversationHistoryWrapper from '@/views/convHistory/ConversationHistoryWrapper.vue'
import DragMessage from '@/component/DragMessage.vue'

import { v1 as uuidv1 } from 'uuid'
import { fetchCustomUI } from '@/domains/chat/infrastructure/liveChatApi'
import { getDomainInfo } from '@/domains/chat/infrastructure/chatApi'
import DocumentAnswerWrapper from '@/views/docsAnswer/DocumentAnswerWrapper.vue';
import { useToast } from 'vue-toastification';

// Props & Emits
const props = defineProps({
  isLoading: { type: Boolean, default: false }
})
const emit = defineEmits([
  'file-dropped',
  'deleteConversation',
  'submit',
  'newSessionCreated',
])

const fileListArray = ref([]);
const fileIds = ref([]); // 서버 업로드가 완료된 파일 id들 (QueryInputer가 뱉는 값)
const store = useStore()
const isDragging = ref(false)
const showFileList = ref(false)
const currConversation = ref({})
const isQueryLoading = ref(props.isLoading)
const answerRef = ref(null)
const toast = useToast();

// Computed
const showWelcome = computed(() => store.getters.showWelcome)
const imageUploadEnabled = computed(() => store.state.userChatbot.imageUpload)
const isFileLoading = computed(() => store.getters.getIsFileLoading);
const showDocsAnswer = computed(() => store.getters.getShowDocsAnswer);
import { getFileIconName } from '@/composables/chatUtils';
import DocumentDriveWrapper from '@/views/docsAnswer/DocumentDriveWrapper.vue';

watch(
  () => props.isLoading,
  newVal => { isQueryLoading.value = newVal }
)

// Lifecycle
onMounted(init)

// Methods
function handleDragOver() {
  if (!imageUploadEnabled.value) return
  isDragging.value = true
}

function handleDragLeave() {
  if (!imageUploadEnabled.value) return
  isDragging.value = false
}

function handleDrop(event) {
  console.log('handleDrop', event)
  if (!imageUploadEnabled.value) return
  console.log('handleDrop 시작', event)
  isDragging.value = false
  const newFiles = Array.from(event.dataTransfer.files).map(file => ({
    id: uuidv1(),
    name: file.name,
    size: file.size,
    type: file.type,
    file,
    status: 'ready',
    fileType: getFileIconName(file.type)
  }))
  fileListArray.value = [newFiles.at(-1)]
  showFileList.value = true
  emit('file-dropped', fileListArray.value)
}

// ===== 파일 이벤트 핸들러 =====
function handleFileUpload(newFiles) {
  fileListArray.value = [...fileListArray.value, ...newFiles]
  showFileList.value = true
}
function deleteFile(fileId) {
  fileListArray.value = fileListArray.value.filter(f => f.id !== fileId)
  if (fileListArray.value.length === 0) showFileList.value = false
}

//  업로드 성공 IDs 갱신 (자식 → 이 컴포넌트)
function setUploadedFileIds(ids = []) {
  fileIds.value = Array.isArray(ids) ? ids : []
}

//  자식에서 실패 통지 → 여기서 상태 동기화(필요 시 토스트)
function onFileUploadError(failedFile) {
  // 필요시 토스트/로그 처리 가능
// 2) 토스트 알림
  const msg = (failedFile?.name ? `[${failedFile.name}] ` : '') +
    ('파일 업로드에 실패했습니다. 다시 시도해 주세요.');
  toast.error(msg);

  // 3) 전역 로딩 플래그 복구
  if (store.getters.getIsFileLoading) {
    store.commit('setIsFileLoading', false);
  }

}

//  자식이 실패 시 전체 파일 비우기
function clearAllFiles() {
  fileListArray.value = []
  fileIds.value = []
  showFileList.value = false
}

//  성공 후 재트리거 방지용 상태 변경
function onFileProcessed({ file }) {
  if (!file) return
  fileListArray.value = fileListArray.value.map(f =>
    (f?.name === file.name && f?.size === file.size)
      ? { ...f, status: 'uploaded' }
      : f
  )
}

function deleteConversation(convItem) {
  emit('deleteConversation', convItem)
}

function handleNewSessionCreated(newSession) {
  emit('newSessionCreated', newSession)
}


// 웰컴페이지에서 받은 부분을 앤서래퍼 측으로 전달 send 함수를 실행
const welcomeMessageSendAnswerWrapper = async (value) => {
    //  업로드 진행 중이면 끝날 때까지 대기
      if (isFileLoading.value) {
        await new Promise(resolve => {
            const stop = watch(isFileLoading, v => {
                if (!v) { stop(); resolve(); }
              });
          });
     }


  store.commit('setShowWelcome', false);
  await nextTick(); // AnswerWrapper가 실제로 마운트될 때까지 대기
  // 이제 전송
  answerRef.value?.sendFromParent(value);
}

function handleQueryProcess(value) {
  isQueryLoading.value = value
}

function handleAnswerEnd() {
  console.log('answerEnd')
  fileListArray.value = []
  fileIds.value = []
  isQueryLoading.value = false
}


async function init() {
  try {
    const userChatbot = await fetchCustomUI({ chatbotCode: getDomainInfo().chatbotCode })
    store.commit('setUserChatbot', userChatbot)
    if (store.state.userChatbot.chatbotName) {
      document.title = store.state.userChatbot.chatbotName
    }
  } catch {
    // silent
  }
}
</script>
