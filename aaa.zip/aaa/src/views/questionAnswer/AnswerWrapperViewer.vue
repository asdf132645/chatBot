<template>
    <div class="answer-page-wrapper answer-page-wrapper-viewer">
      <div class="answer-page-box">
        <div class="answer-item">
            <div class="answer-right-wrapper">
                <h2 class="answer-title answer-box">
                {{ title }}
                </h2>
                <!-- 이미지 -->
                <div class="answer-image-wrapper answer-box">
                <div class="answer-image-group">
                    <div class="image-item">
                        <img :src="imageUrl" />
                    </div>
                    <div class="image-item">
                        <img :src="imageUrl" />
                    </div>
                    <div class="image-item">
                        <img :src="imageUrl" />
                    </div>
                    <div class="image-item">
                        <img :src="imageUrl" />
                    </div>
                    <div class="image-item">
                        <img :src="imageUrl" />
                    </div>
                    <div class="image-item">
                        <img :src="imageUrl" />
                    </div>
                </div>
                </div>
                <div class="answer-text-wrapper answer-box genai-answer-text" v-html="statement"></div>
                <RecommendList class="answer-box"
                    title="관련 질문"
                    :recommendList="recomList"
                />
            </div>
            
            <div class="answer-left-wrapper">
                <ReferenceList
                />
            </div>
        </div>
        <div class="answer-query-wrapper">
            <QueryInputer
            ref="queryInputer"
            id="answerQueryInputer"
            class="mt6"
            :placeholder="t('answerwrapper.answerwrapper_key4')"
            />
        </div>
      </div>
    </div>
  </template>
  
<script setup>
import RecommendList from '@/component/RecommendList.vue';
import QueryInputer from '@/component/QueryInputer.vue'
import { useRoute } from 'vue-router'
import { onMounted, ref } from 'vue'
import { useI18n } from 'vue-i18n';
const { t } = useI18n();
const route = useRoute()
const title = ref('')
const desc = ref('')
const imageUrl = ref('')
const statement = "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc. <br/><br/>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc. <br/><br/>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc. <br/><br/>"
const recomList = [
    {
        title: 'There are many variations of passages of Lorem Ipsum available',
        seq: 1
    },
    {
        title: 'but the majority have suffered alteration in some form',
        seq: 1
    },
    {
        title: 'by injected humour, or randomised words',
        seq: 1
    },
    {
        title: 'If you are going to use a passage of Lorem Ipsum',
        seq: 1
    },
    {
        title: 'anything embarrassing hidden in the middle of text',
        seq: 1
    }
]
onMounted(() => {
  title.value = route.query.title || ''
  desc.value  = route.query.desc  || ''
  imageUrl.value = route.query.imageUrl  || ''
})

</script>

<style lang="css">
.answer-page-wrapper-viewer{
    overflow: scroll;
}
</style>