<template>
    <div class="custom-radio" :class="{ disabled: disabled }">   
        <input type="radio" 
            @change="onChangeInputValue"
            :id="id"
            :value="value"
            :name="radioName"
            :checked="id == value"
            class="custom-input custom-radio-input" />
        <label class="custom-radio-label" :for="id">{{label}}</label>   
    </div>
</template>

<script>
export default {
    name: "CustomRadio",
    components: {},
    props: {
        value: String,
        id: String, 
        label: String, 
        radioName: String, 
        disabled: Boolean,
    },
    data() {
        return {
        };
    },
    methods: {
        onChangeInputValue() { 
            this.$emit('input', this.id); 
        }
    }
};
</script>