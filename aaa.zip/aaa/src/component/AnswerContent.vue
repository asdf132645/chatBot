<template>
  <div>
    <div :class="{'answer-item':true,'last-answer':lastAnswer}" v-if="answer.isLoading" :id="'answer-' + answer.id">
      <div class="answer-right-wrapper">
        <h2 class="answer-title answer-box">
          <img class="blinking" :src="require('@/assets/images/title_paragraph_light.svg')" />
        </h2>
        <!-- 과정분석 -->
        <div class="answer-procedure-wrapper answer-box blinking"></div>
        <!-- 이미지 -->
        <div class="answer-image-wrapper answer-box">
          <div class="answer-image-group">
            <div class="image-item blinking"></div>
            <div class="image-item blinking"></div>
            <div class="image-item blinking"></div>
            <div class="image-item blinking"></div>
            <div class="image-item blinking"></div>
            <div class="image-item blinking"></div>
          </div>
        </div>
        <!-- 답변 -->
        <div class="answer-text-wrapper answer-box">
          <img class="blinking" :src="require('@/assets/images/long_paragraph_light.svg')" />
        </div>
      </div>
      <div class="answer-left-wrapper">
        <ReferenceList
          :isLoading="answer.isLoading"
        />
      </div>
    </div>

    <div :class="{'answer-item':true,'last-answer':lastAnswer}" :id="`answer-${answer.id}`" v-if="!answer.isLoading">
      <div class="answer-right-wrapper">
        <h2 class="answer-title answer-box">
          {{ answer.title }}
        </h2>
        <!-- 과정분석 -->
        <div class="answer-procedure-wrapper answer-box">
          <div class="state-head">
            <div class="state-base state-title">
              <img class="" :src="require('@/assets/images/topology-star-3.svg')" />
              <span class="state-title-text">{{ $t('answercontent.answercontent_key1') }}</span>
            </div>
            <div class="state-base state-fold" @click="toggleState()">
              <BaseIcon name="ArrowTailUp" :size="20" v-if="!isStateOpen" />
              <BaseIcon name="ArrowTailDown" :size="20" v-if="isStateOpen" />
            </div>
          </div>
          <transition name="slide">
            <div class="state-body" ref="stateBody" v-if="isStateOpen">
              <transition-group name="fade-list" tag="div">
                <div class="state-base state-detail" v-for="searchItem in searchList" :key="searchItem.id">
                  <img class="blinking" :src="require('@/assets/images/search.svg')"
                       v-if="searchItem.status === 'search'" />
                  <img class="blinking" :src="require('@/assets/images/loading.svg')"
                       v-if="searchItem.status === 'loading'" />
                  <img class="blinking" :src="require('@/assets/images/check.svg')"
                       v-if="searchItem.status === 'check'" />
                  <span class="state-detail-target-info text-truncate">{{ searchItem.keyword }}</span>
                  <span class="state-detail-target-title">{{ searchItem.statusDetail }}</span>
                </div>
              </transition-group>
              <!-- 검색 결과 상태-->
              <div class="state-base state-detail state-result">
                <img class="blinking" :src="require('@/assets/images/loading.svg')" v-if="queryLoading" />
                <img class="blinking" :src="require('@/assets/images/check.svg')" v-if="!queryLoading" />
                <span class="state-detail-target-title state-last">
                    <span v-if="queryLoading">{{ $t('answercontent.answercontent_key2') }}</span>
                    <span v-if="!queryLoading">{{ $t('answercontent.answercontent_key3') }}</span>
                  </span>
              </div>
            </div>
          </transition>
        </div>

        <AnswerImageSlider
          class="answer-box"
          v-if="answer?.ragDocuments?.length > 0"
          :related_images="combinedDocImgData.images"
          :pdfUrl="combinedDocImgData.docUrls"
          @openModal="openImageModal"
        />

        <div class="answer-text-wrapper answer-box genai-answer-text" v-html="changeMarkDown(answer.answer)"></div>

        <!-- <div class="multi-answer-text-wrapper">
          <div class="answer-text-wrapper answer-box genai-answer-text multi-answer-text multi-answer-text-1" v-html="changeMarkDown(answer.answer)"></div>
          <div class="answer-text-wrapper answer-box genai-answer-text multi-answer-text multi-answer-text-2" v-html="changeMarkDown(answer.answer)"></div>
        </div> -->

        <div class="answer-text-wrapper answer-box" v-if="!answer.answer && answer.queryLoading">
          <img class="blinking" :src="require('@/assets/images/long_paragraph_light.svg')" />
        </div>

        <div class="answer-evaluation-wrapper answer-box" v-if="!answerLoading">
          <button class="btn btn-refresh mr-2 chipMsg" v-for="(chip, idx) in suggestionMessages" :key="idx"
                  @click="suggestReq(chip)">
            {{ chip.message }}
          </button>
          <button class="btn btn-refresh" @click.stop="regenerateAnswer">
            <BaseIcon :size="18" :mr="6" :mt="-1" name="Refresh" />
            {{ checkError ? 'Yes' : '다시 생성하기' }}
          </button>
          <div class="btn-group">
            <button class="btn evaluation-btn" @click.stop="copyAnswer(answer)">
              <BaseIcon :size="20" name="Copy" />
            </button>
            <button class="btn evaluation-btn" @click.stop="evaluationAnswer('up', answer)">
              <BaseIcon :size="20" name="ThumbUp" />
            </button>
            <button class="btn evaluation-btn" @click.stop="evaluationAnswer('down', answer)">
              <BaseIcon :size="20" name="ThumbDown" />
            </button>
          </div>
        </div>

        <RecommendList class="answer-box" v-if="answer.recomList.length > 0 && !answerLoading"
                       title="관련 질문"
                       :recommendList="answer.recomList"
                       @submit="submitQuery"
        />

        <RecommendList class="answer-box" v-if="answer.recomList.length > 0 && answerLoading"
                       title="관련 질문"
                       :recommendList="answer.recomList"
        />

        <div class="answer-text-wrapper answer-box" v-if="answer.recomLoading">
          <img class="blinking" :src="require('@/assets/images/long_paragraph_light.svg')" />
        </div> 

        <ReferenceList
          class="answer-box"
          :answerHeight=answerHeight
          :answer="answer"
          :fileList="answer.fewshots  || []"
          :attachList="answer.attachments  || []"
          :isLoading="answer.referenceLoading"
        />
      </div>
      <!-- <div class="answer-left-wrapper">
        
      </div> -->

      <MyModal
        width="650"
        :isOpenModal="isEvaluateModal"
        :title="$t('answercontent.answercontent_key4')"
        :okBtnName="$t('answercontent.answercontent_key6')"
        @sendData="evaluationAnswerDown"
        @close="evaluationAnswerCancel"
      >
        <template #content>
          <div class="evaluation-btn-group">
            <div v-for="evaluationItem in evaluationList" :key="evaluationItem.label"
                 :class="{
                'active': evaluationItem.selected
              }"
                 @click.stop="toggleEvaluationLabel(evaluationItem.id)"
                 class="evaluation-btn">{{ evaluationItem.label }}
              <BaseIcon :ml="16" :size="20" name="Check" v-if="evaluationItem.selected" />
            </div>
          </div>
          <form class="form-wrapper evaluation-form">
            <div class="form-textarea">
              <textarea :placeholder="$t('answercontent.answercontent_key5')"
                        :userReasonOpinionMaxLength="userReasonOpinionMaxLength"
                        v-model="userReasonOpinion">
              </textarea>
            </div>
          </form>
        </template>
      </MyModal>

    </div>
  </div>
</template>

<script setup>
import { ref, watch, onMounted, nextTick, defineProps, defineEmits, computed } from 'vue';
import { useToast } from 'vue-toastification';
import { useI18n } from 'vue-i18n';
import ReferenceList from '@/views/questionAnswer/ReferenceWrapper.vue';
import RecommendList from '@/component/RecommendList.vue';
import MyModal from '@/component/MyModal.vue';
import BaseIcon from '@/component/BaseIcon.vue';
import { getDomainInfo, saveFeedback } from '@/domains/chat/infrastructure/chatApi';
import { callEvaluationList } from '@/domains/chat/domain/factory/chatFactory';

import _isEmpty from 'lodash/isEmpty';
import AnswerImageSlider from '@/component/AnswerImageSlider.vue';
// import DocsEditor from '@/component/DocsEditor.vue';

const props = defineProps({
  response: Object,
  answer: { type: Object, required: true },
  searchList: { type: Array, default: () => [] },
  queryLoading: Boolean,
  answerLoading: Boolean,
  lastAnswer: Boolean,
  isStateOpen: Boolean,
  currIndex: Number,
});

const emit = defineEmits(['toggleState', 'openImageModal', 'submitQuery', 'deleteConversation']);
const { t } = useI18n();
const toast = useToast();
const marked = require('marked');

const answerHeight = ref(900);
const isEvaluateModal = ref(false);
const userReasonOpinion = ref('');
const userReasonOpinionMaxLength = 500;
const evaluationList = ref([]);
const currAnswer = ref(null);
const localAnswer = ref({});

// const contentEditor = ref(`
//   <h1>문서 편집기 예시</h1>
//   <p>이곳은 <strong>부모 컴포넌트</strong>에서 내려주는 초기 값입니다.</p>
//   <p>QuillEditor는 <em>HTML</em>을 그대로 반영할 수 있어요.</p>
//
//   <h2>회의 메모</h2>
//   <ul>
//     <li>프로젝트 목표: Q3 기능 출시</li>
//     <li>담당자: 프론트엔드 깅 졍</li>
//   </ul>
//
//   <h2>할 일 체크리스트</h2>
//   <ol>
//     <li><input type="checkbox" /> 강지영 유지보수 1</li>
//     <li><input type="checkbox" /> 강지영 유지보수 2</li>
//   </ol>
//
//   <p style="color:#2a9d8f;">
//     HTML 태그를 자유롭게 넣어서 사용이 가능합니다 ㅎㅎ
//   </p>
// `)

watch(() => props.answer.answer, async (newVal) => {
  if (newVal) {
    await nextTick();
    const el = document.querySelector('.answer-item');
    if (el) {
      requestAnimationFrame(() => {
        answerHeight.value = el.offsetHeight;
      });
    }
  }
}, { immediate: true });

onMounted(() => {
  evaluationList.value = callEvaluationList().map((item, idx) => ({ ...item, id: `eval-${idx + 1}`, selected: false }));
  localAnswer.value = { ...props.answer };
});

// 모든 ragDocuments의 related_images, doc_urls를 하나의 배열로 합쳐주는 computed
const combinedDocImgData = computed(() => {
  const images = []
  const docUrls = []
  props.answer.ragDocuments?.forEach(doc => {
    const url = doc.doc_url || ''
    // doc.related_images가 배열일 때만
    Array.isArray(doc.related_images) &&
    doc.related_images.forEach(img => {
      images.push(img)
      docUrls.push(url)
    })
  })
  return { images, docUrls }
})



function toggleState() {
  emit('toggleState', props.currIndex);
}

const checkError = computed(() => {
  return props.answer && props.answer.answer === t('answercontent.answercontent_key8');
});

function openImageModal(recomImage, imageId) {
  emit('openImageModal', { recomImage, imageId })
}

// suggestion_chips 타입의 메시지만 골라내는 computed
const suggestionMessages = computed(() => {
  //  answer.messages 우선
  const direct = props.answer?.messages;
  if (Array.isArray(direct)) {
    const chips = direct.filter(({ type }) => type === 'suggestion_chips');
    if (chips.length) return chips;
  }

  // raw → parsed
  const raw = props.response?.sbData?.messages;
  if (!raw) return [];

  try {
    const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
    return Array.isArray(parsed)
      ? parsed.filter(({ type }) => type === 'suggestion_chips')
      : [];
  } catch (e) {
    console.warn('파싱 실패:', e);
    return [];
  }
});

function changeMarkDown(letters) {
  if (!letters) return;
  const renderer = new marked.Renderer();
  renderer.link = (href, title, text) => `<a href=${href} target="_blank" style="text-decoration: underline;">${text}</a>`;
  renderer.code = (code, language) => `<pre class="custom-code-block"><code class="language">${language}<br/>${code}</code></pre>`;
  marked.setOptions({
    renderer,
    gfm: true,
    headerIds: false,
    tables: true,
    breaks: true,
    pedantic: false,
    smartLists: true,
    smartypants: false,
  });
  letters = letters.replace(/\|\n\n\|/g, '|\n|');
  return marked(letters);
}

// 답변복사 이벤트 복사처리 함수
function copyAnswer(answer) {
  const textarea = document.createElement('textarea');
  document.body.appendChild(textarea);
  textarea.value = answer.answer;
  textarea.select();
  try {
    toast.info(t('answercontent.answercontent_key9'));
    document.execCommand('copy');
  } catch (err) {
    console.error('AnswerWrapper.methods.copyAnswer(err) : ', err);
  } finally {
    document.body.removeChild(textarea);
  }
}

// 답변평가 이벤트 서버요청 함수
function evaluationAnswer(thumbs, answer) {
  currAnswer.value = answer;
  const chatbotCode = getDomainInfo().chatbotCode;
  validationEvaluationAnswer(thumbs, answer);
  const id = answer?.query_id || answer?.log_id || null;
  const payload = {
    session_id: answer.session_id,
    answer_id: id,
    agent_id: chatbotCode,
    thumb: thumbs,
    reason: [],
    comment: '',
  };
  if (thumbs === 'up') {
    saveFeedback(payload, chatbotCode);
    toast.info(t('answercontent.answercontent_key10'));
  } else if (thumbs === 'down') {
    isEvaluateModal.value = true;
  }
}

/** * 답변평가 유효성검증*/
function validationEvaluationAnswer(thumbs, answer) {
  if (_isEmpty(answer) && _isEmpty(answer.id)) return;
  if (_isEmpty(thumbs)) return;
  if (thumbs !== 'up' && thumbs !== 'down') return;
}

function evaluationAnswerDown() {
  const selectedReasons = evaluationList.value
    .filter(item => item.selected)
    .map(item => ({ id: item.id, reason_info: item.label }));
  const id = currAnswer.value?.query_id || currAnswer.value?.log_id || null;
  const payload = {
    session_id: currAnswer.value.session_id,
    answer_id: id,
    agent_id: getDomainInfo().chatbotCode,
    thumb: 'down',
    reason: selectedReasons,
    comment: userReasonOpinion.value,
  };
  saveFeedback(payload, currAnswer.value.agent_code).then(() => {
    isEvaluateModal.value = false;
    userReasonOpinion.value = '';
    evaluationList.value.forEach(e => (e.selected = false));
    toast.info(t('answercontent.answercontent_key10'));
  });
}

/**
 * 평가 취소 처리한 경우 모달 숨김 처리 및 요소 초기화 함수
 */
function evaluationAnswerCancel() {
  isEvaluateModal.value = false;
  userReasonOpinion.value = '';
  evaluationList.value.forEach(e => (e.selected = false));
}

// 평가 라벨을 클릭한 경우 선택값을 변경
function toggleEvaluationLabel(id) {
  evaluationList.value = evaluationList.value.map(item => ({
    ...item,
    selected: item.id === id ? !item.selected : item.selected,
  }));
}

/*기존 질의문을 활용하여 재질의, 기존 화면 엘리먼트를 유지하고 추가로 랜더링한다.*/
function regenerateAnswer() {
  emit('submitQuery', props.answer.title);
}

function submitQuery(query) {
  emit('submitQuery', query);
}

function suggestReq(chip) {
  emit('submitQuery', chip)
}
</script>

