<template>
   <div class="search-type-wrapper">
    <div class="search-type-item" 
      v-for="searchType in searchTypeList" :key="searchType.id"
      @click="changeSearchType(searchType.id)"
      :class="{
        'active': currSearchType === searchType.id
      }">
      <BaseIcon name="Check" :size="16" :mr="4" v-if="currSearchType === searchType.id"/>
      {{ searchType.name }}
    </div>
  </div>
</template>

<script>
export default {
    name: "SearchTypeList",
    
    data() {
        return {
          currSearchType: "", 
          searchTypeList: [], 
        };
    },
    created() {
      this.searchTypeList = [
        {
          id: 'basic', 
          name: this.$t("searchtypelist.searchtypelist_key1"), 
          desc: this.$t("searchtypelist.searchtypelist_key2"),
        },
        {
          id: 'searchDoc', 
          name: this.$t("searchtypelist.searchtypelist_key3"), 
          desc: this.$t("searchtypelist.searchtypelist_key4"),
        },
        {
          id: 'report', 
          name: this.$t("searchtypelist.searchtypelist_key5"), 
          desc: this.$t("searchtypelist.searchtypelist_key6"),
        },
        {
          id: 'summary', 
          name: this.$t("searchtypelist.searchtypelist_key7"), 
          desc: this.$t("searchtypelist.searchtypelist_key8"),
        },
        {
          id: 'inference', 
          name: this.$t("searchtypelist.searchtypelist_key9"), 
          desc: this.$t("searchtypelist.searchtypelist_key10"),
        },
      ]; 

      this.changeSearchType('basic');
    },
    methods: {
      changeSearchType(id) { 
        this.currSearchType = id; 
      }
    }
};
</script>
