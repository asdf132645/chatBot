<template>
  <div class="answer-recom-wrapper">
      <div class="answer-recom-title mb8">
          <span class="title-icon mr8">                
            <BaseIcon name="BookMark" v-if="isWelcomePage" />
            <BaseIcon name="Send" v-else/>
          </span>
          <h4 class="title-text">{{ title }}</h4>
      </div>
      <div class="answer-recom-group">
          <div class="recom-item" v-for="recomItem in sortedRecommendList" :key="recomItem.seq" @click.stop="submitQuery(recomItem.title)">
              <template v-if="isWelcomePage">
                <BaseIcon class="star-icon" name="Star" :size="12" :mr="8" />
                {{ recomItem.title }}                
              </template>
              <template v-else>
                {{ recomItem.title }}
                <BaseIcon class="bubble-icon ml-auto" name="ChatBubble" :size="20"/>
              </template>
          </div>
      </div>
  </div>
</template>

<script>
export default {
  name: "RecommendList",
  components: {
  },
  props: {
      recommendList: Array,
      title: String,
      page: String
  },
  computed: {
    isWelcomePage() {
      return this.page === 'welcome' ? true : false; 
    },
    sortedRecommendList() {
      // Sort by seq if recommendList items have seq property
      if (this.recommendList && this.recommendList.length > 0 && this.recommendList[0].seq !== undefined) {
        return [...this.recommendList].sort((a, b) => a.seq - b.seq);
      }
      // If items are strings or don't have seq, return as is
      return this.recommendList;
    }
  },
  data() {
      return {
      };
  },
  methods: {
    submitQuery(recomItem) {
      if (!recomItem || !recomItem.trim()) {
        return;
      }
      this.$emit('submit', recomItem.trimEnd()); 
    },
  }
};
</script>
