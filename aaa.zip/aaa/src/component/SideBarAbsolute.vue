<template>
  <Teleport to="#right-sidebar-destination">
    <div v-if="isOpenSidebar" 
      ref="sidebar"
      v-teleport-click-outside:right-sidebar-destination="closeSidebarDown"
      :class="['sidebar-wrapper', sidebarName]"
      :style="{
        'width': width + 'px', 
        'top': top + 'px', 
        'left': left + 'px',
        'right': right + 'px'
      }">
      <slot name="content"></slot>
    </div>
  </Teleport>
</template>

<script>
export default { 
  name: 'SideBar', 
  props: {
    isOpenSidebar: Boolean,  
    width: Number, 
    top: Number, 
    left: Number,
    right: Number,
    sidebarName: String
  },
  mounted() {
  },
  emits: ['close'],
  data() { 
    return { 
    }
  }, 
  methods: {
    closeSidebar(event) {
      const exclude = event.target.classList.contains('excluded'); 
      if(exclude) return;
      this.$emit('close'); 
    }
  },
}
</script>

