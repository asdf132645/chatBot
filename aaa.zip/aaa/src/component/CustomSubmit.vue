<template>
    <div class="custom-control custom-submit">
        <button type="submit" :id="id" class="btn primary" @click="onSubmit">{{ label }}</button>
    </div>
</template>

<script>
export default {
    name: "CustomSubmit",
    components: {},
    props: {
        id: String, 
        label: String, 
    },
    data() {
        return {
        };
    },
    methods: {
        onSubmit() { 
            this.$emit('submit'); 
        }
    }
};
</script>