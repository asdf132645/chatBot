<template>
   <div class="footer-option">
      <div class="source-info">
        <div class="source-info-icon">
          <span class="source-icon" v-for="i in 3" :key="i"></span>          
        </div>
        출처      
      </div>

      <div class="btn-group">
        <button class="btn">
          <BaseIcon name="ThumbUp" :size="18" />
        </button>
        <button class="btn-icon">
          <BaseIcon name="DotsHorizontal" :size="18" />
        </button>
      </div>
    </div>
</template>

<script>
import BaseIcon from '@/component/BaseIcon.vue';
export default {
  name: 'FooterOption',
  components: {
    BaseIcon
  },
  props: {
    
  },
  mounted() {
  },
  
  data() {
    return {
    }
  },
  methods: {
   
  },
}
</script>

