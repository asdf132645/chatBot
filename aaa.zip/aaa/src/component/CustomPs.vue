<template>
    <div class="custom-control custom-ps">   
        <label class="custom-label" :for="id">{{ label }}</label>
        <div class="custom-input">
            <input type="password" 
                :id="id"
                :value="value"
                :name="name"
                :placeholder="placeholder"
                @keydown="onChangeInputValue($event)"
                />       
            <button class="btn-view">
                <template v-if="!isPsShow"><BaseIcon name="EyeShow"/></template>
                <template v-else><BaseIcon name="EyeHide"/></template>
            </button>
        </div>
    </div>
</template>

<script>
export default {
    name: "CustomPs",
    components: {},
    props: {
        value: String,
        id: String, 
        label: String, 
        name: String, 
        placeholder: String
    },
    data() {
        return {
            isPsShow: false
        };
    },
    methods: {
        onChangeInputValue(event) { 
            this.$emit('input', event.target.value); 
        }
    }
};
</script>