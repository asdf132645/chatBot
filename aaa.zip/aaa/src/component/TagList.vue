<template>
    <div class="tag-wrapper-wrapper">
        <CustomInput
            label="태그 설정"
            id="tagInput"
            placeholder="태그를 입력해주세요."
            name="tagInput"
            v-model="inputDocTagValue"
            @enter="handleInputDocTagValue"
            :disabled="true"
        />

        <div class="tag-wrapper" v-if="tagList.length">
            <div class="tag-item" v-for="tag in tagList" :key="tag">
            {{ tag }}
            <button class="tag-item-remove" @click="deleteTag(tag)">
                <BaseIcon name="Close" :size="16" />
            </button>
            </div>
        </div>
    </div>
</template>

<script setup>
import CustomInput from '@/component/CustomInput.vue';
import BaseIcon from '@/component/BaseIcon.vue';

import { defineProps, ref, defineEmits } from 'vue';

const inputDocTagValue = ref('')

defineProps({
    tagList: Array, 
})

const emit = defineEmits(['onEnter', 'onDelete']);

/** ===== TAG 핸들링 ===== */
function handleInputDocTagValue(value) {
    if(value && value.trim()) {
        emit('onEnter', value); 
    }  
}

function deleteTag(tag) {
    emit('onDelete', tag); 
}

</script>
