<template>
  <div class="answer-image-slider-container">
    <div class="answer-image-slider" :style="{ '--visible-count': visibleCount }" v-if="images.length">
      <button
        v-show="current > 0"
        class="nav-arrow left"
        @click="prevImage"
      >
        <BaseIcon name="ArrowLeft" />
      </button>

      <div class="slider-main">
        <div class="slider-track" :style="trackStyle">
          <div
            v-for="(img, idx) in images"
            :key="idx"
            class="slide-item"
            :class="{ active: idx === current }"
            @click="selectImage(idx)"
          >
            <img :src="`${getGenaiIndexerSandboxImgUrl(img.src)}`"  />
            <div class="slide-caption">
              <span class="caption-text">{{ img.title }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- next는 항상 보이되 마지막엔 disabled -->
      <button
        class="nav-arrow right"
        @click="nextImage"
        :disabled="current >= maxIndex"
      >
        <BaseIcon name="ArrowRight" />
      </button>
    </div>

    <ImageModal
      width="950"
      height="800"
      :isOpenModal="isModalOpen"
      title="관련이미지"
      @close="isModalOpen = false"
    >
      <template #content>
        <div class="image-modal-content">
          <div class="image-left-wrapper">
            <div class="image-selected">
              <img class="selected-image" :src="getGenaiIndexerSandboxImgUrl(currentImage.src)" :alt="currentImage.title" />
            </div>
            <div class="image-details">
              <!-- pdfUrl이 있을 때 제목 클릭하면 새창으로 PDF 열기 -->
              <a
                v-if="pdfUrl"
                class="image-title"
                :href="pdfUrl"
                target="_blank"
                rel="noopener noreferrer"
              >
                {{ currentImage.title }}
              </a>
              <div v-else class="image-title">
                {{ currentImage.title }}
              </div>
            </div>
          </div>
          <div class="image-right-wrapper">
            <div class="image-gallery">
              <div
                v-for="(img, idx) in images"
                :key="idx"
                :class="{ selected: idx === current }"
                class="gallery-item"
                @click="selectImage(idx)"
              >
                <img class="gallery-image" :src="`${getGenaiIndexerSandboxImgUrl(img.src)}`" :alt="img.title" />
                <div class="gallery-title">{{ img.title }}</div>
              </div>
            </div>
          </div>
        </div>
      </template>
    </ImageModal>
  </div>
</template>

<script setup>
import { ref, computed, defineProps } from 'vue'
import BaseIcon from '@/component/BaseIcon.vue'
import ImageModal from '@/component/ImageModal.vue'
import {  getGenaiIndexerSandboxImgUrl } from '../shared/config/endpoints';

const props = defineProps({
  related_images: { type: Array, default: () => [] },
  visibleCount:   { type: Number, default: 3 },
  pdfUrl:         { type: String, default: '' },
})

// 이미지 접두어 붙여 매핑
const images = computed(() =>
  props.related_images.map(src => {
    const path = src.split('?')[0]
    const fileWithExt = path.slice(path.lastIndexOf('/') + 1)
    const filename = decodeURIComponent(fileWithExt)
    return { src, title: `${filename}`, filename }
  })
)

const current = ref(0)
const isModalOpen = ref(false)

const itemWidth = 215
const gap       = 16

const maxIndex = computed(() => Math.max(0, images.value.length - props.visibleCount))
const trackStyle = computed(() => {
  const offset = current.value * (itemWidth + gap)
  return { transform: `translateX(-${offset}px)` }
})

function prevImage() {
  if (current.value > 0) current.value--
}

function nextImage() {
  if (current.value < maxIndex.value) current.value++
}

function selectImage(idx) {
  current.value = idx
  isModalOpen.value = true
}

// 현재 선택된 이미지 객체
const currentImage = computed(() => images.value[current.value] || {})
</script>
