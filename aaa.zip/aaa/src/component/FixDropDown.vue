<template>
    <div v-if="isOpenDrop"
         ref="dropdown"
         v-teleport-click-outside:dropdown-destination="closeDropDown"
         :class="['dropdown-wrapper-fix dropdownFix', dropdownName]"
         :style="{
        'width': width + 'px',
        'bottom': '20px',
        'left': left + 'px',
      }">
      <slot name="content"></slot>
    </div>
</template>

<script>
export default {
  name: 'DropDown',
  props: {
    isOpenDrop: Boolean,
    width: Number,
    top: Number,
    left: Number,
    dropdownName: String
  },
  mounted() {
  },
  emits: ['close'],
  data() {
    return {
    }
  },
  methods: {
    closeDropDown(event) {
      const exclude = event.target.classList.contains('excluded');
      if(exclude) return;
      this.$emit('close');
    }
  },
}
</script>

