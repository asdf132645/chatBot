<template>
    <div class="custom-search">   
        <BaseIcon class="custom-search-icon" name="InputSearch" :size="17" />
        <input type="input" 
            class="custom-search-input"
            :id="id"
            :value="modelValue"
            :name="name"
            :placeholder="placeholder"
            @input="$emit('update:modelValue', $event.target.value)"
            @keyup.enter="$emit('enter', modelValue)"
            autocomplete="off"
        />
    </div>
</template>

<script setup>
import { defineProps, defineEmits } from 'vue';

defineProps({
    modelValue: String,
    id: String, 
    label: String, 
    name: String, 
    placeholder: String
})

defineEmits(['update:modelValue', 'enter']);

</script>
