<template>
    <span class="base-icon" :data-name="iconName" :style="{
        'margin': `${mt}px ${mr}px ${mb}px ${ml}px`
    }">
        <component :is="iconName" :size="size" />
    </span>
</template>
<script>
import AddChatIcon from '@/assets/icon/AddChat.vue'
import AddPlusIcon from '@/assets/icon/AddPlus.vue'
import AddUserIcon from '@/assets/icon/AddUser.vue'
import AiDocTypeIcon from '@/assets/icon/AiDocType.vue'
import ArrowDownIcon from '@/assets/icon/ArrowDown.vue'
import ArrowFullDownIcon from '@/assets/icon/ArrowFullDown.vue'
import ArrowFullUpIcon from '@/assets/icon/ArrowFullUp.vue';
import ArrowLeftIcon from '@/assets/icon/ArrowLeft.vue'
import ArrowRightIcon from '@/assets/icon/ArrowRight.vue'
import ArrowTailLeftIcon from '@/assets/icon/ArrowTailLeft.vue'
import ArrowTailDownIcon from '@/assets/icon/ArrowTailDown.vue'
import ArrowTailUpIcon from '@/assets/icon/ArrowTailUp.vue'
import BagIcon from '@/assets/icon/BagIcon.vue'
import BookMarkIcon from '@/assets/icon/BookMark.vue'
import BulbIdeaIcon from '@/assets/icon/BulbIdea.vue'
import BulbIdeaOffIcon from '@/assets/icon/BulbIdeaOff.vue'
import CalendarIcon from '@/assets/icon/CalendarIcon.vue';
import CategoryIcon from '@/assets/icon/CategoryIcon.vue'
import ChartIcon from '@/assets/icon/ChartIcon.vue'
import ChatBubbleIcon from '@/assets/icon/ChatBubble.vue'
import CheckIcon from '@/assets/icon/CheckIcon.vue'
import CircleIcon from '@/assets/icon/CircleIcon.vue';
import CloudIcon from '@/assets/icon/CloudIcon.vue';
import ClipIcon from '@/assets/icon/ClipIcon.vue'
import CloseIcon from '@/assets/icon/CloseIcon.vue'
import ClockIcon from '@/assets/icon/ClockIcon.vue'
import ColorBagIcon from '@/assets/icon/ColorBagIcon.vue';
import ContrastIcon from '@/assets/icon/ContrastIcon.vue'
import CopyIcon from '@/assets/icon/CopyIcon.vue'
import CsvIcon from '@/assets/icon/CsvIcon.vue'
import CsvTypeIcon from '@/assets/icon/CsvTypeIcon.vue'
import DeleteIcon from '@/assets/icon/DeleteIcon.vue'
import DeleteOutlineIcon from '@/assets/icon/DeleteOutlineIcon.vue'
import DocTypeIcon from '@/assets/icon/DocType.vue'
import DotsHorizontalIcon from '@/assets/icon/DotsHorizontal.vue'
import DotsVerticalIcon from '@/assets/icon/DotsVertical.vue'
import DoubleArrowLeftIcon from '@/assets/icon/DoubleArrowLeft.vue'
import DoubleArrowRightIcon from '@/assets/icon/DoubleArrowRight.vue'
import DownloadIcon from '@/assets/icon/DownloadIcon.vue'
import DriveIcon from '@/assets/icon/DriveIcon.vue';
import DriveRedIcon from '@/assets/icon/DriveRedIcon.vue';
import DriveGreenIcon from '@/assets/icon/DriveGreenIcon.vue';
import EditFullIcon from '@/assets/icon/EditFull.vue'
import EyeHideIcon from '@/assets/icon/EyeHide.vue'
import EyeShowIcon from '@/assets/icon/EyeShow.vue'
import FileIcon from '@/assets/icon/FileIcon.vue'
import FilterIcon from '@/assets/icon/FilterIcon.vue'
import FavoriteIcon from '@/assets/icon/FavoriteIcon.vue'
import FoldLeftIcon from '@/assets/icon/FoldLeft.vue'
import FoldRightIcon from '@/assets/icon/FoldRight.vue'
import FolderIcon from '@/assets/icon/FolderIcon.vue'
import FolderOffIcon from '@/assets/icon/FolderOff.vue'
import HwpTypeIcon from '@/assets/icon/HwpTypeIcon.vue'
import FolderOnIcon from '@/assets/icon/FolderOn.vue'
import HomeIcon from '@/assets/icon/HomeIcon.vue';
import InfoCircleIcon from '@/assets/icon/InfoCircle.vue'
import InputSearchIcon from '@/assets/icon/InputSearch.vue'
import InputSendIcon from '@/assets/icon/InputSend.vue'
import JpgIcon from '@/assets/icon/JpgIcon.vue';
import LinkGraphIcon from '@/assets/icon/LinkGraphIcon.vue';
import LinkIcon from '@/assets/icon/LinkIcon.vue';
import ListIcon from '@/assets/icon/ListIcon.vue'
import LocationIcon from '@/assets/icon/LocationIcon.vue'
import LogosGoogleIcon from '@/assets/icon/LogosGoogle.vue'
import LogoutIcon from '@/assets/icon/LogoutIcon.vue'
import MailIcon from '@/assets/icon/MailIcon.vue'
import MoonIcon from '@/assets/icon/MoonIcon.vue'
import PaperIcon from '@/assets/icon/PaperIcon.vue'
import PdfIcon from '@/assets/icon/PdfIcon.vue'
import PdfTypeIcon from '@/assets/icon/PdfTypeIcon.vue'
import PinIcon from '@/assets/icon/PinIcon.vue'
import PinVanIcon from '@/assets/icon/PinVanIcon.vue'
import PlayCircleIcon from '@/assets/icon/PlayCircleIcon.vue'
import QueryInputerIcon from '@/component/QueryInputer.vue'
import ReferenceWrapperIcon from '@/views/questionAnswer/ReferenceWrapper.vue';
import RefreshIcon from '@/assets/icon/RefreshIcon.vue'
import ReportDocTypeIcon from '@/assets/icon/ReportDocType.vue'
import SearchArrowDownIcon from '@/assets/icon/SearchArrowDownIcon.vue'
import SearchArrowUpIcon from '@/assets/icon/SearchArrowUpIcon.vue'
import SearchDocTypeIcon from '@/assets/icon/SearchDocType.vue'
import SearchIcon from '@/assets/icon/SearchIcon.vue'
import SendIcon from '@/assets/icon/SendIcon.vue'
import SendLineIcon from '@/assets/icon/SendLineIcon.vue';
import SettingIcon from '@/assets/icon/SettingIcon.vue'
import SharingIcon from '@/assets/icon/SharingIcon.vue'
import StarIcon from '@/assets/icon/StarIcon.vue'
import SummaryDocTypeIcon from '@/assets/icon/SummaryDocType.vue'
import SunIcon from '@/assets/icon/SunIcon.vue'
import TimeCircleIcon from '@/assets/icon/TimeCircle.vue'
import ThumbDownIcon from '@/assets/icon/ThumbDown.vue'
import ThumbUpIcon from '@/assets/icon/ThumbUp.vue'
import UploadStatusAlertIcon from '@/assets/icon/UploadStatusAlertIcon.vue'
import UploadStatusCheckIcon from '@/assets/icon/UploadStatusCheckIcon.vue'
import UploadStatusCircleIcon from '@/assets/icon/UploadStatusCircleIcon.vue'
import UploadStatusCloseIcon from '@/assets/icon/UploadStatusCloseIcon.vue'
import UploadStatusRefreshIcon from '@/assets/icon/UploadStatusRefreshIcon.vue'
import UserGroupIcon from '@/assets/icon/UserGroupIcon.vue';
import UserIcon from '@/assets/icon/UserIcon.vue';
import UserOctagonIcon from '@/assets/icon/UserOctagon.vue'
import UserPlusIcon from '@/assets/icon/UserPlusIcon.vue';  
import UsersIcon from '@/assets/icon/UsersIcon.vue'
import VoiceIcon from '@/assets/icon/VoiceIcon.vue';
import WordIcon from '@/assets/icon/WordIcon.vue'
import WordTypeIcon from '@/assets/icon/WordTypeIcon.vue'


export default {
    name: "BaseIcon",
    components: {
        AddChatIcon,
        AddPlusIcon,
        AddUserIcon,
        AiDocTypeIcon,
        ArrowDownIcon,
        ArrowFullDownIcon,
        ArrowFullUpIcon,
        ArrowLeftIcon,
        ArrowRightIcon,
        ArrowTailLeftIcon,
        ArrowTailDownIcon,
        ArrowTailUpIcon,
        BagIcon,
        BookMarkIcon,
        BulbIdeaIcon,
        BulbIdeaOffIcon,
        CalendarIcon,
        CategoryIcon,
        ChartIcon,
        ChatBubbleIcon,
        CheckIcon,
        CircleIcon, 
        ClockIcon,
        CloudIcon,
        ClipIcon,  
        CloseIcon,
        ColorBagIcon,
        ContrastIcon,
        CopyIcon,
        CsvIcon,
        CsvTypeIcon,
        DeleteIcon,
        DeleteOutlineIcon,
        DocTypeIcon,
        DownloadIcon,
        DotsHorizontalIcon,
        DotsVerticalIcon,
        DoubleArrowLeftIcon,
        DoubleArrowRightIcon,
        DriveIcon,
        DriveRedIcon,
        DriveGreenIcon,
        EditFullIcon,
        EyeHideIcon,
        EyeShowIcon,
        FileIcon,
        FilterIcon,
        FavoriteIcon,
        FoldLeftIcon,
        FoldRightIcon,
        FolderIcon,
        FolderOffIcon,
        HwpTypeIcon,
        FolderOnIcon,
        HomeIcon,
        InfoCircleIcon,
        InputSearchIcon,
        InputSendIcon,
        JpgIcon,
        LinkGraphIcon,
        LinkIcon,
        ListIcon,
        LocationIcon,
        LogosGoogleIcon,
        LogoutIcon,
        MailIcon,
        MoonIcon,
        PaperIcon,
        PdfIcon,
        PdfTypeIcon,
        PinIcon,
        PinVanIcon,
        PlayCircleIcon,
        QueryInputerIcon,
        RefreshIcon,
        ReferenceWrapperIcon,
        ReportDocTypeIcon,
        SearchArrowDownIcon,
        SearchArrowUpIcon,
        SearchDocTypeIcon,
        SearchIcon,
        SendIcon,
        SendLineIcon,
        SettingIcon,
        SharingIcon,
        StarIcon,
        SummaryDocTypeIcon,
        SunIcon,
        TimeCircleIcon,
        ThumbDownIcon,
        ThumbUpIcon,
        UploadStatusAlertIcon,
        UploadStatusCheckIcon,
        UploadStatusCircleIcon,
        UploadStatusCloseIcon,
        UploadStatusRefreshIcon,
        UserGroupIcon,
        UserIcon,
        UserOctagonIcon,
        UserPlusIcon,
        UsersIcon,
        VoiceIcon,
        WordIcon,
        WordTypeIcon,
    },
    props: {
        name: String,
        size: {
            type: Number,
            default: 24
        },
        mt: {
            type: Number,
            default: 0
        },
        mr: {
            type: Number,
            default: 0
        },
        mb: {
            type: Number,
            default: 0
        },
        ml: {
            type: Number,
            default: 0
        }
    },
    computed: {
        iconName() {
            return this.name + 'Icon'
        },
        changeSizeNumber() {
            let basicSize = this.size / 24;
            let truncatedNumber = Math.floor(basicSize * 10000) / 10000;
            return truncatedNumber;
        }
    },
    data() {
        return {
        };
    },
    methods: {
    }
}
</script>
<style lang="scss" scoped>
.base-icon {
    flex-shrink: 0;
}
</style>
