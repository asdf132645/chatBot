<template>
  <Teleport to="#dragging-message-destination">
    <div class="dragging-message-wrapper">
      <div class="dragging-message-box">
        <div class="file-upload-img-wrapper">
          <img class="file-upload-img" :src="require('@/assets/images/FileUpload.svg')" />
        </div>
        <div class="file-upload-title">{{ $t('contentwrapper.contentwrapper_key1') }}</div>
        <div class="file-upload-desc">Click to upload or drag and drop</div>        
      </div>
    </div>
  </Teleport>
</template>

<script>
export default { 
  name: 'DragMessage', 
  props: {
  },
  mounted() {
  },
  data() { 
    return { 
    }
  }, 
  methods: {
  },
}
</script>

