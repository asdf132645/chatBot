<template>
  <div class="toggle-state-demo">
    <h3>ToggleState Composable 데모</h3>
    
    <div class="controls">
      <button @click="openAllStates" class="btn">모든 상태 열기</button>
      <button @click="closeAllStates" class="btn">모든 상태 닫기</button>
      <button @click="addNewState" class="btn">새 상태 추가</button>
    </div>

    <div class="stats">
      <p>열린 상태: {{ openStatesCount }}개</p>
      <p>닫힌 상태: {{ closedStatesCount }}개</p>
      <p>전체 열림: {{ isAllOpen ? '예' : '아니오' }}</p>
      <p>전체 닫힘: {{ isAllClosed ? '예' : '아니오' }}</p>
    </div>

    <div class="state-list">
      <div 
        v-for="(state, index) in states" 
        :key="state.id" 
        class="state-item"
        :class="{ 'open': state.isStateOpen }"
      >
        <div class="state-header" @click="toggleState(index)">
          <span class="state-title">{{ state.title }}</span>
          <span class="toggle-icon">{{ state.isStateOpen ? '▼' : '▶' }}</span>
        </div>
        <div v-if="state.isStateOpen" class="state-content">
          <p>{{ state.content }}</p>
          <button @click="removeState(index)" class="remove-btn">삭제</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useToggleState } from '@/composables/useToggleState'

// 초기 상태 설정
const initialState = [
  { id: 1, title: '상태 1', content: '첫 번째 상태의 내용입니다.', isStateOpen: false },
  { id: 2, title: '상태 2', content: '두 번째 상태의 내용입니다.', isStateOpen: true },
  { id: 3, title: '상태 3', content: '세 번째 상태의 내용입니다.', isStateOpen: false }
]

const {
  states,
  toggleState,
  openAllStates,
  closeAllStates,
  addState,
  removeState,
  openStatesCount,
  closedStatesCount,
  isAllOpen,
  isAllClosed
} = useToggleState(initialState)

// 새 상태 추가
const addNewState = () => {
  const newId = Math.max(...states.value.map(s => s.id)) + 1
  addState({
    id: newId,
    title: `상태 ${newId}`,
    content: `새로 추가된 ${newId}번째 상태의 내용입니다.`,
    isStateOpen: false
  })
}
</script>

<style scoped>
.toggle-state-demo {
  padding: 20px;
  max-width: 600px;
  margin: 0 auto;
}

.controls {
  margin-bottom: 20px;
}

.btn {
  margin-right: 10px;
  padding: 8px 16px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.btn:hover {
  background-color: #0056b3;
}

.stats {
  background-color: #f8f9fa;
  padding: 15px;
  border-radius: 4px;
  margin-bottom: 20px;
}

.stats p {
  margin: 5px 0;
  font-size: 14px;
}

.state-list {
  border: 1px solid #ddd;
  border-radius: 4px;
}

.state-item {
  border-bottom: 1px solid #eee;
}

.state-item:last-child {
  border-bottom: none;
}

.state-header {
  padding: 15px;
  cursor: pointer;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #f8f9fa;
}

.state-header:hover {
  background-color: #e9ecef;
}

.state-title {
  font-weight: 500;
}

.toggle-icon {
  font-size: 12px;
  color: #666;
}

.state-content {
  padding: 15px;
  background-color: white;
}

.state-content p {
  margin: 0 0 10px 0;
}

.remove-btn {
  padding: 4px 8px;
  background-color: #dc3545;
  color: white;
  border: none;
  border-radius: 3px;
  cursor: pointer;
  font-size: 12px;
}

.remove-btn:hover {
  background-color: #c82333;
}

.state-item.open .state-header {
  background-color: #e3f2fd;
}
</style>
