<template>
    <div class="custom-control">   
        <label class="custom-label" :for="id" v-if="label">{{ label }}</label>
        <div class="custom-textarea" :style="{ height: heightFull ? '100%' : height + 'px' }">
            <textarea                
                :id="id"
                :value="modelValue"
                :name="name"
                :placeholder="placeholder"                
                @input="onChangeInputValue($event)"
                @keydown="onEnterInputValue($event)"
            />        
        </div>
    </div>
</template>

<script setup>
import { defineProps, defineEmits } from 'vue';

defineProps({
    modelValue: String,
    id: String, 
    label: String, 
    name: String, 
    placeholder: String,
    height: Number, 
    heightFull: Boolean
})

const emit = defineEmits(['update:modelValue', 'enter']);

function onChangeInputValue(event) { 
    emit('update:modelValue', event.target.value); 
}

function onEnterInputValue(event) {
    if (event.key === 'Enter') {
        emit('enter', event.target.value);
    }
}

</script>
