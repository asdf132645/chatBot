<template>
  <div class="sidebar-wrapper">
    <slot name="content">

    </slot>
  </div>
</template>

<script>
export default { 
  name: 'SideBar', 
  props: {
    
  },
  mounted() {
  },
  emits: ['close'],
  data() { 
    return { 
    }
  }, 
  methods: {
    closeSidebar(event) {
      const exclude = event.target.classList.contains('excluded'); 
      if(exclude) return;
      this.$emit('close'); 
    }
  },
}
</script>

