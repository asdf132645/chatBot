<template>
    <div class="custom-check" :class="{ disabled: disabled }">
        <template v-if="label">
            <input type="checkbox"
                @change="onChangeInputValue(id)"
                :id="id"
                :value="modelValue"
                :name="checkName"
                :checked="id == modelValue"
                class="custom-input" />
            <label class="custom-check-label"
                :for="id">{{label}}</label>
        </template>
        <template v-else>
            <input type="checkbox"
                @change="onChangeInputValue(id)"
                :id="id"
                :name="checkName"
                :checked="modelValue"
                class="custom-input" />
            <label class="custom-check-label"
                :class="{
                    'label-none': !label
                }"
                :for="id"></label>
        </template>
    </div>
</template>

<script setup>
import { defineProps, defineEmits } from 'vue';

defineProps({
    modelValue: [String, Boolean, Array],
    id: String, 
    label: String, 
    checkName: String, 
    disabled: Boolean,
})

const emit = defineEmits(['update:modelValue']);

function onChangeInputValue(id) {
    emit('update:modelValue', id);
}

</script>