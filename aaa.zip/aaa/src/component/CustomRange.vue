<template>
    <div class="custom-range">
        <div class="range-slider">
            <div
                :style="{
                    background: `linear-gradient(to right, #00bbff 0%, #00bbff ${computedValue}%, #dddddd ${computedValue}%, #dddddd 100%)`
                }"
                class="slider-track"></div>
            <div class="form-range">
                <span class="count min-count">{{ minNum }}</span>
                <span class="count max-count">{{ maxNum }}</span>
                <input type="range"
                    :value="modelValue"
                    @input="onRangeInput"
                    :min="minNum" :max="maxNum" :step="step">
            </div>
        </div>

        <div class="range-input">
            <input type="text"
                :value="modelValue"
                @input="onTextInput"
                @blur="onTextBlur"
                :min="minNum" :max="maxNum" :step="step">
        </div>
    </div>
</template>

<script setup>
import { defineProps, defineEmits, computed } from 'vue';

const props = defineProps({
    modelValue: {
        type: [String, Number],
        required: true
    },
    minNum: {
        type: Number,
        default: 0
    },
    maxNum: {
        type: Number,
        default: 100
    },
    step: {
        type: Number,
        default: 1
    },
});

const emit = defineEmits(['update:modelValue']);

const computedValue = computed(() => {
    const range = props.maxNum - props.minNum;
    const currentValue = Number(props.modelValue) - props.minNum;
    return (currentValue / range) * 100;
});

function onRangeInput(event) {
    const value = Number(event.target.value);
    emit('update:modelValue', value);
}

function onTextInput(event) {
    const value = event.target.value;
    emit('update:modelValue', value);
}

function onTextBlur(event) {
    const inputValue = event.target.value;
    
    // 빈값이면 최솟값으로 설정
    if (!inputValue || inputValue.trim() === '') {
        emit('update:modelValue', props.minNum);
        return;
    }
    
    let numValue = parseFloat(inputValue);
    
    // 숫자가 아닌 경우 최솟값으로 설정
    if (isNaN(numValue)) {
        emit('update:modelValue', props.minNum);
        return;
    }
    
    // 최솟값보다 작으면 최솟값으로 설정
    if (numValue < props.minNum) {
        emit('update:modelValue', props.minNum);
        return;
    }
    
    // 최댓값을 초과하면 최댓값으로 설정
    if (numValue > props.maxNum) {
        emit('update:modelValue', props.maxNum);
        return;
    }
    
    // 유효한 값이면 그대로 설정
    emit('update:modelValue', numValue);
}
</script>