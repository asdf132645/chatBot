<template>
  <Teleport to="#modal-destination">
    <Transition>
      <div v-if="isOpenModal" class="modal-container">
        <div
          class="modal-box image-upload-modal remove-padding-modal"
          :style="{
            width: `${width}px`,
            height: `${height}px`,
          }"
        >
          <div class="modal-header">
            <h3 class="modal-title">{{ title }}</h3>
            <button class="close-button" @click="$emit('close')">
              <BaseIcon :size="24" name="Close" />
            </button>
          </div>
          <div class="modal-body">
            <slot name="content"></slot>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script>
export default { 
  name: 'ImageModal', 
  props: {
    isOpenModal: Boolean, 
    title: String,
    height: String,
    width: String, 
    okBtnName: String, 
  },
  emits: ['close'],
  components: {
  }, 
  data() { 
    return { 

    }
  }, 
  methods: {
    close(){
      
    }
  },
}
</script>
