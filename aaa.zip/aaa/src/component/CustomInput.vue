<template>
    <div class="custom-control">   
        <label class="custom-label" :for="id" v-if="label">{{ label }}</label>
        <div class="custom-input"
            :class="{ disabled: disabled }"
        >
            <input type="input" 
                autocomplete="off"
                :id="id"
                :value="modelValue"
                :name="name"
                :placeholder="placeholder"
                @input="onChangeInputValue($event)"
                @keydown="onEnterInputValue($event)"
            />        
        </div>
    </div>
</template>

<script setup>

import { defineProps, defineEmits } from 'vue';
defineProps({
    modelValue: String,
    id: String, 
    label: String, 
    name: String, 
    placeholder: String, 
    disabled: Boolean
})

const emit = defineEmits(['update:modelValue', 'enter'])

function onChangeInputValue(event) { 
    emit('update:modelValue', event.target.value); 
}

function onEnterInputValue(event) {
    if (event.key === 'Enter') {
        emit('enter', event.target.value);
    }
}

</script>


