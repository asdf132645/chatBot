<template>
  <div>
    <div class="answer-item">
      <div class="answer-right-wrapper">
        <h2 class="answer-title answer-box">
          {{ title }}
        </h2>
        <!-- 과정분석 -->
        <div class="answer-procedure-wrapper answer-box blinking"></div>
        <!-- 이미지 -->
        <div class="answer-image-wrapper answer-box">
          <div class="answer-image-group">
            <div class="image-item blinking"></div>
            <div class="image-item blinking"></div>
            <div class="image-item blinking"></div>
            <div class="image-item blinking"></div>
            <div class="image-item blinking"></div>
            <div class="image-item blinking"></div>
          </div>
        </div>
        <div class="answer-text-wrapper answer-box genai-answer-text" v-html="changeMarkDown(desc)"></div>
      </div>
      <div class="answer-left-wrapper">
        <ReferenceList
          :isLoading="answer.isLoading"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRoute } from 'vue-router'
import { onMounted, ref } from 'vue'
const marked = require('marked');
const route = useRoute()
const title = ref('')
const desc = ref('')
onMounted(() => {
  title.value = route.query.title || ''
  desc.value  = route.query.desc  || ''
})


function changeMarkDown(letters) {
  if (!letters) return;
  const renderer = new marked.Renderer();
  renderer.link = (href, title, text) => `<a href=${href} target="_blank" style="text-decoration: underline;">${text}</a>`;
  renderer.code = (code, language) => `<pre class="custom-code-block"><code class="language">${language}<br/>${code}</code></pre>`;
  marked.setOptions({
    renderer,
    gfm: true,
    headerIds: false,
    tables: true,
    breaks: true,
    pedantic: false,
    smartLists: true,
    smartypants: false,
  });
  letters = letters.replace(/\|\n\n\|/g, '|\n|');
  return marked(letters);
}
</script>
