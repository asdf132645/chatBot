<template>
    <div class="custom-list-wrapper" :style="{ 
        maxHeight: maxHeight + 'px', 
        overflowY: 'auto',
        paddingBlock: removePadding ? '0' : '.5rem'
        }"        
        >
        <div class="list-item" v-for="listItem in lists" :key="listItem.id" @click="handleUserClick(listItem)" 
        :class="{ 'clickable': isClickable, 'selected': listItem.selected, 'border': border }">
            <div class="list-item-avatar" v-if="isAvatar">
                {{ listItem.name.charAt(0) }}
            </div>
            <div class="list-item-content"> 
                <div class="list-item-name">{{ listItem.name }}</div>
                <div class="list-item-sub-desc" v-if="listItem.userEmail">{{ listItem.userEmail }}</div>
                <div class="list-item-sub-desc" v-if="listItem.desc">{{ listItem.desc }}</div>
            </div>
            <div class="list-item-selected" v-if="listItem.selected">
                <BaseIcon name="Check" :size="16" />
            </div>
    
            <slot :listItem="listItem"></slot>
        </div>
    </div>
</template>

<script setup>
import { defineProps, defineEmits } from 'vue';

defineProps({
    lists: Array, 
    maxHeight: Number,
    isClickable: Boolean, 
    isAvatar: {
        type: Boolean,
        default: true
    }, 
    removePadding: {
        type: Boolean,
        default: false
    }, 
    border: {
        type: Boolean,
        default: false
    }
})

const emit = defineEmits(['listClick'])

function handleUserClick(user) {
    emit('listClick', user);
}

</script>
