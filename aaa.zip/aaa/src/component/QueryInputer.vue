<template>
  <div class="query-wrapper" :style="{ maxWidth: `${maxWidth}px` }" :class="{ disabled: isInteractionDisabled, 'no-shadow': noShadow }">
    <div class="query-box">
      <div class="query-search">
        <div class="query-search-outer">
          <div class="query-search-inner">
            <div class="query-search-box">
              <div
                class="query-search-input"
                :id="id"
                :placeholder="placeholder"
                ref="querySearch"
                :contenteditable="!isInteractionDisabled"
                @keyup="inputQuery"
                @paste="handlePaste"
                :tabindex="isInteractionDisabled ? -1 : 0"
                :class="{ disabled: isInteractionDisabled }"
              />
            </div>
          </div>
        </div>
        <!-- 업로드 아이콘 그룹 -->
        <div class="query-icon-group" v-if="isUploadDisabled || isInteractionDisabled || isSelectedModel || isMultiAnswer">

          <template v-if="isSelectedModel">
            <button class="btn change-model-btn" @click="toggleDropDown($event)">
              <BaseIcon name="ArrowFullDown" :size="20" :mr="8"/>
              {{ currentModelName }}
            </button>

            <button class="btn change-model-option-btn" @click="toggleModal('aiModel')">
              <BaseIcon name="List" :size="20"/>
            </button>
          </template>

          <template v-if="$store.state.userChatbot.imageUpload">
            <input
              type="file"
              ref="fileInput"
              @change="handleFileUpload"
              style="display: none"
              :disabled="isUploadDisabled"
              :accept="accept"
              :multiple="allowMultiple"
            />
            <button
              class="upload-btn"
              @click.stop="triggerFileUpload"
              :disabled="isUploadDisabled"
              :class="{ 
                disabled: isUploadDisabled, 
                hidden: isUploadHidden }"
            >
              <BaseIcon name="Clip" :size="20" />
            </button>
          </template>

          <button
            class="open-gallery-btn"
            @click.stop="toggleModal('prompt')"
            :disabled="isInteractionDisabled"
            :class="{ 
              disabled: isInteractionDisabled, 
              hidden: isInteractionHidden }"
          >
            <BaseIcon name="ChatBubble" :size="20" />
          </button>

          <CustomCheck
            v-if="isMultiAnswer"
            class="ml-auto"
            id="isMultiAnswer"
            label="다중답변"
            :isBoolean="true"
            :modelValue="checkedMultiAnswer"
            @change="handleMultiAnswer"
          />
        </div>
      </div>
      <div class="query-reset" v-if="enableReset">
        <button
          class="query-reset-btn"
          @click="resetResult"
          :disabled="isQueryLoading"
          :class="{ disabled: isInteractionDisabled }"
        >
          <BaseIcon name="Close" :size="20"/>
        </button>
      </div>
      <div class="query-send">
        <button
          class="query-send-btn btn primary"
          @click="submitQuery"
          :disabled="isQueryLoading"
          :class="{ disabled: isInteractionDisabled }"
        >
          <BaseIcon :name="isSearch ? 'Search' : 'InputSend'" />
        </button>
      </div>
    </div>

    <MyModal
      :width="currentModalType === 'aiModel' ? '500' : '1000'"
      :title="currentModalType === 'aiModel' ? 'AI 답변 조정' : '프롬프트 갤러리'"
      :isOpenModal="isOpenModal"
      :okBtnName="'확인'"
      :cancelBtnName="'취소'"
      @close="isOpenModal = false"
      @sendData="handleSendDataModal"
    >
      <template #content>
        <template v-if="currentModalType === 'aiModel'">
          <div class="form-wrapper">
            <div class="custom-control">
              <div class="custom-label">
                Temperature
  
                <div class="custom-label-desc">
                  답변의 창의성 또는 예측 불가능성을 조절합니다.
                </div>
              </div>      
              
              <CustomRange 
                :minNum="0"
                :maxNum="2"
                :step="0.01"
                v-model="model.temperature"
              />
            </div>
    
            <div class="custom-control">
              <div class="custom-label">
                Top P
                <div class="custom-label-desc">
                  답변의 다양성을 조절합니다.
                </div>
              </div>      
              
              <CustomRange 
                :minNum="0"
                :maxNum="1"
                :step="0.01"
                v-model="model.topP"
              />
            </div>
          </div>
        </template>
        <template v-if="currentModalType === 'prompt'">
          <UserPromptGallery
            v-if="session"
            :chatbotCode="session.chatbotCode"
            @select="applyPrompt"
          />
        </template>
      </template>
    </MyModal>

    <DropDown
      :width="200"
      :top="dropPosition.y"
      :left="dropPosition.x"
      :isOpenDrop="isOpenDrop"
      @close="isOpenDrop = false"
      dropdownName="drive-menu-wrapper"
    >
      <template #content>
        <CustomList
          :isAvatar="false"
          :lists="modelList"
          :maxHeight="300"
          :removePadding="true"
          :isClickable="true"
          @listClick="handleModelClick"
        />
      </template>
    </DropDown>
  </div>
</template>

<script>
import { nextTick } from 'vue';
import { useToast } from 'vue-toastification';
import BaseIcon from '@/component/BaseIcon.vue';
import { uploadFileMgr, checkFileMgr } from '@/domains/chat/infrastructure/fileUpload/fileMgrApi';
import CustomList from '@/component/CustomList.vue';
import DropDown from '@/component/DropDown.vue';
import CustomRange from '@/component/CustomRange.vue';
import MyModal from '@/component/MyModal.vue';
import UserPromptGallery from '@/domains/prompt/presentation/UserPromptGallery.vue';
import CustomCheck from '@/component/CustomCheck.vue';
export default {
  name: 'QueryInputer',
  components: { BaseIcon, CustomList, DropDown, CustomRange, MyModal, UserPromptGallery, CustomCheck },

  props: {
    genAiYn: Boolean,
    newSession: String,
    sessionId: String,
    id: String,
    isQueryLoading: { type: Boolean, default: false },
    maxWidth: { type: Number, default: 800 },

    // 부모가 넘겨주는 파일 리스트(업로드 트리거)
    fileList: { type: Array, default: () => [] },
    // 새로 추가: 업로드 제어용
    maxFiles: { type: Number, default: 0 },      // 0 = 무제한, 1 = 단일, N = 그 외 제한
    disableUpload: { type: Boolean, default: false }, // 강제 비활성화 플래그
    accept: { type: String, default: '' },       // 필요 시 허용 확장자 제어 (ex. 'image/*,.pdf')
    placeholder: { type: String, default: '' },
    abortSignal: { type: Object, default: null }, // AbortSignal
    isUploadHidden: { type: Boolean, default: false },
    isInteractionHidden: { type: Boolean, default: false },
    noShadow: { type: Boolean, default: false },
    isSelectedModel: { type: Boolean, default: false },
    isSearch: { type: Boolean, default: false },
    isMultiAnswer: { type: Boolean, default: false },
    enableReset: { type: Boolean, default: false },
  },

  data() {
    return { 
      query: '',
      modelList: [ 
        { name: '예시모델 1', id: 'model1', desc: '예시모델 1 설명', selected: false }, 
        { name: '예시모델 2', id: 'model2', desc: '예시모델 2 설명', selected: false }, 
        { name: '예시모델 3', id: 'model3', desc: '예시모델 3 설명', selected: false } 
      ],
      isOpenDrop: false,
      isOpenModal: false, 
      dropPosition: { x: 0, y: 0 },
      toast: useToast(),
      currentModelName: '모델 선택',
      model: { 
        temperature: 0.25,
        topP: 0.45,
      },
      currentModalType: "", 
      checkedMultiAnswer: false,
    };
  },

  computed: {
    // 입력/전송/갤러리 비활성 종합 플래그
    isInteractionDisabled() {
      const uploading = this.$store.state.isFileLoading;
      return uploading || this.isQueryLoading || this.disableUpload;
   },
    // 현재 보유 파일 개수
    currentCount() {
      return Array.isArray(this.fileList) ? this.fileList.length : 0;
    },
    // 단일 업로드 제한 여부
    reachedLimit() {
      if (this.maxFiles > 0) {
        return this.currentCount >= this.maxFiles;
      }
      return false;
    },
    // input/button 비활성화 종합 판단
    isUploadDisabled() {
      const uploading = this.$store.state.isFileLoading;
      // 업로드 중이거나, 쿼리 전송 로딩이거나, 강제 비활성화거나, 개수 제한 도달 → 비활성화
      return uploading || this.isQueryLoading || this.disableUpload || this.reachedLimit;
    },
    // 다중 선택 허용 여부 (기본은 기존과 동일하게 multiple 미사용)
    allowMultiple() {
      return !(this.maxFiles === 1);
    },
    session() {
      return this.$store.state.session;
    }
  },

  watch: {
    newSession() {
      this.resetQuery();
    },
    fileList(newVal) {
      // 이미 업로드 중이거나 전역 로딩 중이면 재호출 방지
      if (this._isUploading || this.$store.state.isFileLoading) return;

      const targets = (Array.isArray(newVal) ? newVal : []).filter(f => {
        const file = f?.file ?? f;
        return !!file && (f?.status === 'ready' || !f?.status); // ready만 처리
      });
      if (targets.length > 0) {
        this.uploadFile(targets);
      }
    },
  },

  methods: {
    handleSendDataModal() {
      this.currentModalType = '';
      this.isOpenModal = false;
    },

    toggleModal(type) {
      console.log(type)
      this.currentModalType = type;
      if(type !== 'aiModel') {
        this.isOpenModal = true;
      }else{
        this.toast.info('본 기능은 현재 개발 중입니다. 추후 업데이트를 통해 제공될 예정입니다.');
      }
      //
    },

    toggleDropDown(event) {
      this.toast.info('본 기능은 현재 개발 중입니다. 추후 업데이트를 통해 제공될 예정입니다.');
      this.dropPosition.x = event.clientX;
      this.dropPosition.y = event.clientY - 20;
      this.isOpenDrop = !this.isOpenDrop;
    },

    handleModelClick(item) {
      this.isOpenDrop = false;
      this.currentModelName = item.name;
      this.modelList.forEach(model => {
        model.selected = model.id === item.id;
      });
    },

    handleMultiAnswer() {
      this.checkedMultiAnswer = !this.checkedMultiAnswer;
    },

    setQuery(text) {
      this.query = text;
      if (this.$refs.querySearch) {
        this.$refs.querySearch.innerText = text;
      }
    },

    applyPrompt(text) { 
      this.handleSendDataModal();
      this.setQuery(text);
      
      // QueryInputer 내부로 포커스 이동
      //    ref로 잡힌 컴포넌트 인스턴스의 focusInput() 메서드 호출

      this.focusInput();

      // 클립보드 복사 (지원 시)
      navigator?.clipboard?.writeText?.(text).catch(() => {
      });      
    }, 

    inputQuery(event) {
      if (this.isInteractionDisabled) {
        event.preventDefault();
        return;
      }
      if (event.keyCode === 13 && !event.shiftKey) {
        event.preventDefault();
        // 개행 문자 제거하고 query 업데이트
        const cleanText = event.target.innerText.replace(/\n/g, '').trim();
        this.query = cleanText;
        // DOM 요소도 개행 제거된 텍스트로 업데이트
        event.target.innerText = cleanText;
        this.submitQuery();
      } else {
        this.query = event.target.innerText;
      }
    },

    submitQuery() {
      if (this.isInteractionDisabled || !this.query || !this.query.trim()){
        return;
      }

      // this.$store.commit('setMultiAnswer', this.isMultiAnswer);
      this.$emit('submit', this.query.trimEnd(), this.checkedMultiAnswer);
    },

    wait(ms) {
      return new Promise(res => setTimeout(res, ms));
    },

    async uploadFile(fileList) {
      // 재진입 방지
      if (this._isUploading) return;
      this._isUploading = true;
      this.$store.commit('setIsFileLoading', true);

      const fileData = fileList?.[0];
      const file = fileData?.file ?? fileData;
      if (!file) {
        this.$emit('fileError', { code: 'no-file' });
        this.$emit('clearFiles');
        this.$store.commit('setIsFileLoading', false);
        this._isUploading = false;
        return;
      }

      const onAbort = () => {
        reader?.cancel?.();
        this.$emit('fileError', { code: 'aborted' });
        this.$emit('clearFiles');
        this.$store.commit('setIsFileLoading', false);
        this._isUploading = false;
      };

      if (this.abortSignal) {
        if (this.abortSignal.aborted) return onAbort();
        this.abortSignal.addEventListener('abort', onAbort, { once: true });
      }

      let reader = null;

      try {
        // 1) 업로드 호출
        const uploadOk = await this.uploadFileRequest(file, this.sessionId, this.abortSignal);
        if (!uploadOk) {
          this.$emit('fileError', { code: 'upload-failed', file });
          this.$emit('clearFiles');
          return;
        }

        // 2) 업로드 상태 스트림 확인 (SSE)
        const response = await checkFileMgr(this.sessionId, this.abortSignal);
        const stream = response?.body?.pipeThrough?.(new TextDecoderStream());
        if (!stream) {
          this.$emit('fileError', { code: 'no-stream', file });
          this.$emit('clearFiles');
          return;
        }

        reader = stream.getReader();

        let buffer = '';
        let lastStatus = null;

        // eslint-disable-next-line
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += String(value);
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';

          for (const raw of lines) {
            const line = raw.trim();
            if (!line) continue;

            // event 라인은 정보용이므로 무시
            if (line.startsWith('event:')) continue;

            if (!line.startsWith('data:')) continue;
            // "data:" 뒤 공백 유무 모두 대응
            const jsonStr = line.replace(/^data:\s*/, '');

            let data;
            try {
              data = JSON.parse(jsonStr);
            } catch {
              continue;
            }

            const status = data?.status;
            lastStatus = status;

            // 성공
            if (status === 'completed') {
              // failedCnt가 1 이상이면 실패 처리
              if (data.failedCnt && data.failedCnt > 0) {
                this.$emit('fileError', { code: 'failed', meta: data, file });
                this.$emit('clearFiles');
                return;
              }
              
              const ids = Array.isArray(data.successFiles) ? data.successFiles : [];
              if (ids.length) this.$emit('fileIds', ids);
              this.$emit('fileProcessed', { file }); // 성공 시 목록 유지
              return;
            }

            // 실패 상태 즉시 종료
            if (status === 'limited' || status === 'error' || status === 'failed') {
              this.$emit('fileError', { code: status, meta: data, file });
              this.$emit('clearFiles');
              return;
            }

            // pending/proceeding 등은 계속 대기
          }
        }

        // completed 못 받고 스트림 종료 → 실패 처리
        this.$emit('fileError', { code: 'no-completed', lastStatus, file });
        this.$emit('clearFiles');
      } catch (e) {
        console.error('uploadFile error:', e);
        this.$emit('fileError', { code: 'exception', error: e?.message, file });
        this.$emit('clearFiles');
      } finally {
        this.$store.commit('setIsFileLoading', false);
        this._isUploading = false;
      }
    },

    async uploadFileRequest(file, sessionId, signal) {
      try {
        const resp = await uploadFileMgr(file, this.$store.state.loginUser.userEmail, sessionId, { signal });
        if (resp && typeof resp === 'object' && 'ok' in resp) return !!resp.ok;     // fetch Response
        if (resp && typeof resp === 'object' && 'success' in resp) return !!resp.success;
        return !!resp; // 그 외 truthy면 성공 처리
      } catch (error) {
        console.error('Error uploading file:', error);
        return false;
      }
    },

    resetQuery() {
      this.query = '';
      const el = document.getElementById(this.id);
      if (el) el.innerText = '';
    },

    focusInput() {
      if (this.isInteractionDisabled) return;
      nextTick(() => {
        const el = document.getElementById(this.id);
        if (el) el.focus();
        else console.warn(this.$t('queryinputer.queryinputer_key3'), this.id);
      });
    },

    handlePaste(event) {
      event.preventDefault();
      const pastedData = event.clipboardData || window.clipboardData;
      const textData = pastedData.getData('Text');
      window.document.execCommand('insertHTML', false, textData);
      this.inputQuery({ target: this.$refs.querySearch });
    },

    triggerFileUpload() {
      // 업로드 비활성화 상태면 아무 동작 X
      if (this.isUploadDisabled) return;
      this.$refs.fileInput?.click();
    },

    handleFileUpload(event) {
      // 업로드 비활성화 상태면 무시
      if (this.isUploadDisabled) {
        // 필요 시 토스트 안내 가능
        // this.$toast?.info?.('이 컴포넌트에서는 파일을 더 이상 올릴 수 없습니다.')
        event.target.value = '';
        return;
      }

      let files = Array.from(event.target.files || []);
      if (files.length === 0) return;

      // maxFiles==1 인 경우 첫 번째만 허용
      if (this.maxFiles === 1) files = files.slice(0, 1);

      this.$emit('fileUpload', files);

      // 같은 파일 다시 선택 가능하도록 초기화
      event.target.value = '';
    },

    resetResult() {
      this.resetQuery();
      this.$emit('resetResult');
    },

    clearInput() {
      if (this.$refs.querySearch) {
        this.$refs.querySearch.innerHTML = '';
        this.query = '';
      }
    },
  },
};
</script>

<style lang="scss">

.custom-tooltip {
  position: absolute;
  background-color: #333;
  color: #fff;
  padding: 6px 10px;
  font-size: 12px;
  border-radius: 4px;
  white-space: nowrap;
  z-index: 1000;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.2s ease-in-out;
}

.custom-tooltip.show {
  opacity: 1;
  pointer-events: auto;
}

.query-search-input:focus { outline: none; }
.query-search-input.disabled {
  caret-color: transparent;
  user-select: none;
}

</style>
