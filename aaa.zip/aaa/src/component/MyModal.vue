<template>
  <Teleport to="#modal-destination">
    <div v-if="isOpenModal" class="modal-container">
      <div class="modal-box" :style="{ width: `${width}px` }">
        <div class="modal-header">
          <h3 class="modal-title">
            {{ title }}

            <div class="modal-desc" v-if="desc">{{ desc }}</div>
          </h3>          
          <button class="btn btn-icon" @click="emit('close')">
            <BaseIcon name="Close" :size="24" />
          </button>
        </div>
        
        <div class="modal-body">
          <slot name="content"></slot>
        </div>
        <div class="modal-footer">
          <slot name="footer"></slot>

          <div class="btn-group ml-auto">
            <button class="btn outline-primary" v-if="isLinkCopy" @click="emit('linkCopy')"><BaseIcon name="Clip" :size="18" :mr="4" /> {{ $t('mymodal.mymodal_key1') }}</button>
            <button class="btn ml-auto" @click="emit('close')">{{ cancelBtnName || (okBtnName ? "취소" : "닫기") }}</button>
            <button class="btn primary" v-if="okBtnName" @click="emit('sendData')">{{ okBtnName }}</button>
          </div>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup>
import { defineProps, defineEmits } from 'vue'
import BaseIcon from '@/component/BaseIcon.vue'

defineProps({
  isOpenModal: Boolean,
  title: String,
  width: String,
  okBtnName: String,
  cancelBtnName: String,
  isLinkCopy: Boolean,
  desc: String,
})

const emit = defineEmits(['close', 'sendData', 'linkCopy'])
</script>
