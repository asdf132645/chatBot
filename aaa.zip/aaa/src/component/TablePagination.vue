<template>
  <div class="pagination">
    <div class="arrow page-btn" @click="goToFirst"><BaseIcon :size="20" name="DoubleArrowLeft" /></div>
    <div class="arrow page-btn" @click="goToPrev"><BaseIcon :size="20" name="ArrowLeft" /></div>

    <div class="pagination-number">
      <div
        v-for="pageNumber in pageNumbers"
        :key="pageNumber"
        class="page-btn"
        :class="{ active: pageNumber === currentPage }"
        @click="changePage(pageNumber)"
      >
        {{ pageNumber }}
      </div>
    </div>

    <div class="arrow page-btn" @click="goToNext"><BaseIcon :size="20" name="ArrowRight" /></div>
    <div class="arrow page-btn" @click="goToLast"><BaseIcon :size="20" name="DoubleArrowRight" /></div>

    <div class="pagination-perpage">
      <span class="label">{{ $t('tablepagination.tablepagination_key1') }}</span>
      <div class="select-input">
        <select v-model="perPageNumber">
          <option v-for="per in perPageOptions" :key="per" :value="per">
            {{ per }}개
          </option>
        </select>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch , defineProps, defineEmits} from 'vue'
import BaseIcon from '@/component/BaseIcon.vue'

const props = defineProps({
  page: {
    type: Number,
    default: 1
  },
  perPage: {
    type: Number,
    default: 20
  },
  totalCount: {
    type: Number,
    required: true
  },
  perPageOptions: {
    type: Array,
    default: () => [20, 30, 40, 50]
  }
})

const emit = defineEmits(['changePage', 'changePerPage'])

const currentPage = ref(props.page)
const perPageNumber = ref(props.perPage)

const pageCount = computed(() => Math.ceil(props.totalCount / perPageNumber.value))

const pageNumbers = computed(() => {
  const numbers = []
  for (let i = 1; i <= pageCount.value; i++) {
    numbers.push(i)
  }
  return numbers
})

function changePage(page) {
  currentPage.value = page
  emit('changePage', page)
}
function goToPrev() {
  if (currentPage.value > 1) changePage(currentPage.value - 1)
}
function goToNext() {
  if (currentPage.value < pageCount.value) changePage(currentPage.value + 1)
}
function goToFirst() {
  changePage(1)
}
function goToLast() {
  changePage(pageCount.value)
}

watch(perPageNumber, (newVal) => {
  emit('changePerPage', newVal)
})
</script>
