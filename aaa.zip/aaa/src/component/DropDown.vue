<template>
  <Teleport to="#dropdown-destination">
    <div v-if="isOpenDrop" 
      ref="dropdown"
      v-teleport-click-outside:dropdown-destination="closeDropDown"
      :class="['dropdown-wrapper', dropdownName]"
      :style="{
        'width': width + 'px', 
        'top': top + 'px', 
        'left': left + 'px',
        'right': right + 'px'
      }">
      <slot name="content"></slot>
    </div>
  </Teleport>
</template>

<script>
export default { 
  name: 'DropDown', 
  props: {
    isOpenDrop: Boolean,  
    width: Number, 
    top: Number, 
    left: Number,
    right: Number,
    dropdownName: String
  },
  mounted() {
  },
  emits: ['close'],
  data() { 
    return { 
    }
  }, 
  methods: {
    closeDropDown(event) {
      const exclude = event.target.classList.contains('excluded'); 
      if(exclude) return;
      this.$emit('close'); 
    }
  },
}
</script>

