<template>
  <div class="discover-wrapper">
    <div class="discover-answer-content">
      <div class="discover-wrapper-header">
        <div class="discover-wrapper-header-icon">
          <img :src="require('@/assets/images/detectIcon.png')" />
        </div>
        <div class="discover-wrapper-header-menu">
          <button class="menu-item">
            Recommended for You
          </button>
          <button class="menu-item">
            Popular
          </button>
          <button class="menu-item">
            Internal
          </button>
          <button class="menu-item">
            Headquarters
          </button>
        </div>
      </div>
  
      <div class="discover-wrapper-content">
  
        <div class="discover-wrapper-content-wrapper" v-for="discoverItem in discoverList" :key="discoverItem.id">
          <div class="discover-item image-right" @click.stop="routeAnswerViewer(discoverItem.rightImageType.title, discoverItem.rightImageType.desc, discoverItem.rightImageType.imageUrl)">
            <div class="discover-item-script">
              <div class="discover-item-title">{{ discoverItem.rightImageType.title }}</div>
              <div class="discover-item-desc">{{ discoverItem.rightImageType.desc }}</div>
              <div class="discover-item-time">
                <BaseIcon name="Clock" :size="16" />
                <span>2025-08-12</span>
              </div>
              <FooterOption />
            </div>
            
            <div class="discover-item-image"><img :src="discoverItem.rightImageType.imageUrl" /></div>
          </div>
  
          <div class="discover-item card-list">
            <div class="discover-card-item" v-for="cardItem in discoverItem.cardListType" :key="cardItem.id" @click.stop="routeAnswerViewer(cardItem.title, cardItem.desc, cardItem.imageUrl)">
              <div class="card-item-image"><img :src="cardItem.imageUrl" /></div>
              <div class="card-item-content">
                <div class="card-item-title">{{ cardItem.title }}</div>
                <div class="discover-item-time">
                  <BaseIcon name="Clock" :size="18" />
                  <span>2025-08-12</span>
                </div>
                <FooterOption />
              </div>
            </div>
          </div>
  
          <div class="discover-item image-left" @click.stop="routeAnswerViewer(discoverItem.leftImageType.title, discoverItem.leftImageType.desc, discoverItem.leftImageType.imageUrl)">
            <div class="discover-item-script">
              <div class="discover-item-title">{{ discoverItem.leftImageType.title }}</div>
              <div class="discover-item-desc">{{ discoverItem.leftImageType.desc }}</div>
              <div class="discover-item-time">
                <BaseIcon name="Clock" :size="16" />
                <span>2025-08-12</span>
              </div>
              <FooterOption />
            </div>
            <div class="discover-item-image"><img :src="discoverItem.leftImageType.imageUrl" /></div>
          </div>
        </div>
      </div>      
    </div>
    <div class="discover-sidebar-wrapper">
      <div class="discover-sidebar">
        <div class="discover-sidebar-header">
          Favorite Info
          <span>This is the most read article right now.</span>
        </div>
        <div class="discover-sidebar-content">
          <div class="discover-sidebar-content-item" v-for="(favoriteItem, index) in favoriteList" :key="index" @click.stop="routeAnswerViewer(favoriteItem.title, favoriteItem.desc, favoriteItem.imageUrl)">
            <div class="item-content">
              {{ favoriteItem.desc }}
              <span class="item-time">2025-08-12</span>
            </div>
            <div class="item-image"><img :src="favoriteItem.imageUrl" /></div>
          </div>
        </div>        
      </div>

      <div class="discover-sidebar">
        <div class="discover-sidebar-header">
          Hot & Recent News
          <span>Stay updated with the latest trending news.</span>
        </div>
        <div class="discover-sidebar-content">
          <div class="discover-sidebar-content-item" v-for="(favoriteItem, index) in favoriteList" :key="index" @click.stop="routeAnswerViewer(favoriteItem.title, favoriteItem.desc, favoriteItem.imageUrl)">
            <div class="item-content">
              {{ favoriteItem.desc }}              
            </div>            
          </div>
        </div>        
      </div>

      <div class="discover-sidebar">
        <div class="discover-sidebar-header">
          News by Category
          <span>This is the most read article right now.</span>
        </div>
        <div class="discover-sidebar-content">
          <div class="discover-sidebar-content-item" v-for="(favoriteItem, index) in favoriteList" :key="index" @click.stop="routeAnswerViewer(favoriteItem.title, favoriteItem.desc, favoriteItem.imageUrl)">
            <div class="item-image"><img :src="favoriteItem.imageUrl" /></div>
            <div class="item-content">
              {{ favoriteItem.desc }}
              <span class="item-time">2025-08-12</span>
            </div>
            
          </div>
        </div>        
      </div>
    </div>
  </div>
</template>

<script>
import FooterOption from '@/component/FooterOption.vue';
import BaseIcon from '@/component/BaseIcon.vue';
export default {
  name: 'DiscoverWrapper',
  components: {
    FooterOption,
    BaseIcon
  },
  props: {
  },
  
  data() {
    return {
      discoverList: [
        {
          rightImageType: { 
            imageUrl: require('@/assets/images/example_1.png'), 
            title: "Hydroelectric, thermal and nuclear generation", 
            desc: "they had to sell their energy at the spot losing revenues and reducing their investment capacity.", 
          }, 
          leftImageType: {
            imageUrl: require('@/assets/images/example_2.png'), 
            title: "The implementation of the new model and the energy auctions", 
            desc: "I include myself among the advocates of attributing a lower price to that energy.", 
          },
          cardListType: [
            {
              imageUrl: require('@/assets/images/example_card_1.png'), 
              title: "Technological perspectives of nuclear electricity generation", 
            }, 
            {
              imageUrl: require('@/assets/images/example_card_2.png'), 
              title: "Figure 5 shows that in the last few years the nuclear reactors", 
            }, 
            {
              imageUrl: require('@/assets/images/example_card_3.png'), 
              title: "there is a probability for the neutron to join the proton.", 
            }
          ]
        }, 
        {
          rightImageType: { 
            imageUrl: require('@/assets/images/example_1.png'), 
            title: "Hydroelectric, thermal and nuclear generation", 
            desc: "they had to sell their energy at the spot losing revenues and reducing their investment capacity.", 
          }, 
          leftImageType: {
            imageUrl: require('@/assets/images/example_2.png'), 
            title: "The implementation of the new model and the energy auctions", 
            desc: "I include myself among the advocates of attributing a lower price to that energy.", 
          },
          cardListType: [
            {
              imageUrl: require('@/assets/images/example_card_1.png'), 
              title: "Technological perspectives of nuclear electricity generation", 
              desc: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc."
            }, 
            {
              imageUrl: require('@/assets/images/example_card_2.png'), 
              title: "Figure 5 shows that in the last few years the nuclear reactors", 
              desc: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc."
            }, 
            {
              imageUrl: require('@/assets/images/example_card_3.png'), 
              title: "there is a probability for the neutron to join the proton.", 
              desc: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc."
            }
          ]
        }
      ], 
      favoriteList: [
        {
          imageUrl: require('@/assets/images/example_card_2.png'),
          title: "Hydroelectric, thermal and nuclear generation" ,
          desc: "Hydroelectric, thermal and nuclear generation"
        }, 
        {
          imageUrl: require('@/assets/images/example_2.png'),
          title: "Figure 5 shows that in the last few years the nuclear reactors", 
          desc: "Figure 5 shows that in the last few years the nuclear reactors"
        }, 
        {
          imageUrl: require('@/assets/images/example_1.png'),
          title: "the advocates of attributing a lower price to that energy",
          desc: "the advocates of attributing a lower price to that energy"
        }, 
      ]
    };
  },
  computed: {
    
  },

  watch: {
    
  },
  methods: {
    async routeAnswerViewer(title, desc, imageUrl){
      this.$router.push({ path: '/AnswerWrapperViewer', query: { title, desc, imageUrl } });
    }
  }
};
</script>

<style lang="scss" scoped>

</style>
