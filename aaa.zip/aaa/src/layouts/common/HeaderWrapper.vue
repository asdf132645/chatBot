<template>
  <div class="header-wrapper">
    <template v-if="false">
      <div class="one-depth-header">
        <!-- <div class="chat-type-wrapper">
          <div v-for="(type, index) in filteredSearchTypes" :key="index" class="chat-type" >
            <BaseIcon :name="type.component" :size="18" :mr="4"/> {{ type.label }}
          </div>
        </div> -->

        <!-- 채팅답변 타이틀 리스트 -->
        <div class="chat-list-wrapper" v-if="session.answerList.length > 0">
          <button class="btn chat-curr-btn" :title="currentTitle" @click.stop="answerListDrop()"> <span class="chat-curr-text">{{currentTitle}}</span> <BaseIcon :ml="8" :size="18" name="ArrowDown" /></button>

          <DropDown
            :top="chatDropPosition.y"
            :left="chatDropPosition.x"
            :isOpenDrop="isChatDrop"
            @close="isChatDrop = false"
            dropdownName="answer-menu-wrapper">
            <template #content>
              <div class="answer-menu">
                <div class="answer-menu-item" v-for="answerItem in session.answerList" :key="answerItem.id">
                  <button class="nav-btn" ref="answerTitle" @click.stop="scrollAnswer(answerItem)">{{answerItem.title}}</button>
                </div>
              </div>
            </template>
          </DropDown>
        </div>

        <button class="btn primary btn-share"
          @click.stop="callShareModal()"
          v-if="session.answerList.length > 0"
        >
          <BaseIcon name="Sharing" :mr="8" :size="16"/>공유
        </button>
      </div>
    </template>

    <template v-if="true">
      <div class="one-depth-header">
        <div class="page-title">
          <h3>{{ $t('headerwrapper.headerwrapper_key1') }}</h3>
          <div class="arrow"><BaseIcon name="ArrowRight" :size="16" /></div>
        </div>
        <div class="nav-list">
          <div
            class="nav-item"
            :class="{ active: isGroupActive('corp') }"
            @click="selectGroup('corp')"
          >{{ $t('headerwrapper.headerwrapper_key2') }}</div>
          <div
            class="nav-item"
            :class="{ active: isGroupActive('dept') }"
            @click="selectGroup('dept')"
          >{{ $t('headerwrapper.headerwrapper_key3') }}</div>
        </div>
      </div>

      <div class="second-depth-header">
        <div class="nav-list">
          <div class="nav-item" :class="{ active: isActiveTab('FileTabMangeWrapper') }" @click.stop="goPage('FileTabMangeWrapper')">{{ $t('headerwrapper.headerwrapper_key4') }}</div>
          <div class="nav-item"  :class="{ active: isActiveTab('FileUploadRequest') }" @click.stop="goPage('FileUploadRequest')">{{ $t('headerwrapper.headerwrapper_key5') }}</div>
          <div class="nav-item" :class="{ active: isActiveTab('FileApproval') }" @click.stop="goPage('FileApproval')">{{ $t('headerwrapper.headerwrapper_key6') }}</div>
        </div>
      </div>
    </template>

    <MyModal
      width="580"
      :isOpenModal="isShareModal"
      :isLinkCopy="shareType !== 'oneShare'"
      :title="$t('headerwrapper.headerwrapper_key10')"
      :okBtnName="$t('headerwrapper.headerwrapper_key15')"
      @close="isShareModal = false"
      @sendData="shareConversation"
      @linkCopy="onLinkCopy"
    >
      <template #content>
        <form class="form-wrapper share-form-wrapper">
          <div class="share-radio">
            <CustomRadio
              id="oneShare"
              :label="$t('headerwrapper.headerwrapper_key11')"
              radioName="shareTypeRadio"
              :value="convShareType"
              @change="radioActive"
            />
            <div class="divider"></div>
            <p class="radio-desc">{{ $t('headerwrapper.headerwrapper_key7') }}</p>
          </div>
          <div class="share-radio">
            <CustomRadio
              id="allShare"
              :label="$t('headerwrapper.headerwrapper_key12')"
              radioName="shareTypeRadio"
              :value="convShareType"
              @change="radioActive"
            />
            <div class="divider"></div>
            <p class="radio-desc">{{ $t('headerwrapper.headerwrapper_key8') }}</p>
          </div>
          <div class="share-radio">
            <CustomRadio
              id="someShare"
              :label="$t('headerwrapper.headerwrapper_key13')"
              radioName="shareTypeRadio"
              :value="convShareType"
              @change="radioActive"
            />
            <div class="divider"></div>
            <p class="radio-desc">{{ $t('headerwrapper.headerwrapper_key9') }}</p>
          </div>
        </form>

        <div class="user-group-wrapper" v-if="shareType === 'someShare'">
          <div class="user-info" v-for="user in userList" :key="user.email">
            <div class="user-profile"></div>
            <div class="user-email">{{ user.email }}</div>
            <button class="btn" @click.stop="deleteShareEmail(user)">
              <BaseIcon name="Close" :size="16"/>
            </button>
          </div>
          <CustomInput
            id="shareEmailId"
            :placeholder="$t('headerwrapper.headerwrapper_key14')"
            name="shareEmailName"
            @input="shareEmailValue = $event"
          />
        </div>
      </template>
    </MyModal>
  </div>
</template>

<script>
import MyModal from '@/component/MyModal.vue'
import CustomRadio from '@/component/CustomRadio.vue'
import CustomInput from '@/component/CustomInput.vue'
import DropDown from '@/component/DropDown.vue'
import BaseIcon from '@/component/BaseIcon.vue'
import { useToast } from "vue-toastification";
import { mapMutations, mapState, mapGetters  } from 'vuex';

export default {
  name: 'HeaderWrapper',
  components: {
    CustomRadio,
    CustomInput,
    MyModal,
    DropDown,
    BaseIcon
  },
  props: {
  },
  setup() {
    const toast = useToast();

    return { toast }
  },
  data() {
    return {
      realm: window.opsbotFrontProfile?.realm || '',
      curranswerItem: "",
      isShareModal: false,
      shareType: null,
      userList: [],
      chatDropPosition: {
        x: 0,
        y: 60
      },
      isChatDrop: false,
      searchTypes: [
        { value: 'basic', component: 'DocType', label: this.$t("headerwrapper.headerwrapper_key16") },
        { value: 'searchDoc', component: 'SearchDocType', label: this.$t("headerwrapper.headerwrapper_key17") },
        { value: 'report', component: 'ReportDocType', label: this.$t("headerwrapper.headerwrapper_key18") },
        { value: 'summary', component: 'SummaryDocType', label: this.$t("headerwrapper.headerwrapper_key19") },
        { value: 'inference', component: 'AiDocType', label: this.$t("headerwrapper.headerwrapper_key20") }
      ],
      convShareType: null,
      requestShareId: null,
      requestFromMain: false,
      shareEmailValue: null,
      currentAnswerId: null,
      currentTitle: "",
    };
  },
  computed: {
    ...mapGetters({
      session: 'session'
    }),
    ...mapState(['selectedTab', 'fileGroupType']),
    filteredSearchTypes() {
      return this.searchTypes.filter(type => type.value === this.session.searchType);
    }
  },

  watch: {
    'session.answerList': {
      immediate: true,
      handler(newList) {
        if (newList && newList.length > 0) {
          this.currentAnswerId = newList[0].id;
          this.currentTitle = newList[0].title;
          this.$nextTick(() => {
            this.updateHeaderWidth();
            this.updateDropdownPosition();
          });
        }
      }
    },

    currentTitle: {
      handler() {
        this.$nextTick(() => {
          this.updateHeaderWidth();
          this.updateDropdownPosition();
        });
      }
    }
  },
  methods: {
    ...mapMutations(['setSelectedTab', 'setFileGroupType']),
    isActiveTab(tabName) {
      return this.$store.state.selectedTab === tabName;
    },
    isGroupActive(type) {
      return this.fileGroupType === type;
    },
    selectGroup(type) {
      this.setFileGroupType(type);
      this.$router.push({ path: '/FileTabMangeWrapper', query: { type } });
    },
    goPage(pageNm) {
      this.$store.commit('setSelectedTab', pageNm);
    },
    answerListDrop() {
      this.updateDropdownPosition();
      this.isChatDrop = !this.isChatDrop;
    },
    callShareModal(){
      this.shareType = this.session.shareType;
      this.convShareType = this.session.shareType;
      this.userList = this.session.convList[0].userList;
      // TO-BE : 채팅 공유 기능 활성화
      this.toast.info(this.$t("headerwrapper.headerwrapper_key21"));
      // this.isShareModal = true;
    },
    shareConversation(){
      this.isShareModal = false;
      let payload = {
          shareType: this.shareType
        }
      if(this.requestFromMain){
        payload.convId = this.requestShareId;
      }else{
        payload.convId = this.session.convId;
      }

      if(this.shareType === 'someShare'){
        payload.user = this.userList;
      }
      // server request 이후 현재 대화방 정보 새로고침
      this.requestFromMain = false;
      this.requestShareId = null;
      // TO-BE : 다국어 처리 값
      let shareConversationStatement = this.$t("headerwrapper.headerwrapper_key22");
      this.toast.info(shareConversationStatement);
    },
    radioActive(event){
      this.shareType = event.target.id;
    },
    // shareFromRequestModal(convItem){
    //   // TO-BE : 채팅 공유 기능 활성화
    //   this.toast.info(this.$t("headerwrapper.headerwrapper_key21"));
    //   // this.shareType = convItem.shareType;
    //   // this.convShareType = convItem.shareType;
    //   // this.isShareModal = true;
    //   // this.requestShareId = convItem.id;
    //   // this.requestFromMain = true;
    // },
    onLinkCopy(){

      // 임시 엘리먼트 생성
      const textarea = document.createElement('textarea');
      document.body.appendChild(textarea);

      // 복사값 선택
      textarea.value = window.location.href;
      textarea.select();

      try {
        // 다국어 처리 값
        let copyAnswerStatement = this.$t("headerwrapper.headerwrapper_key23");
        this.toast.info(copyAnswerStatement);
        // 사용자 클립보드 복사
        document.execCommand('copy');
      } catch (err) {
        console.error('HeaderWrapper.methods.linkCopy(err) : ', err);
      } finally {
        // 임시 엘리먼트 삭제
        document.body.removeChild(textarea);
      }
    },
    addShareEmail(emailValue){
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if(emailRegex.test(emailValue)){
        this.userList.push({email: emailValue})
        this.shareEmailValue = "";
      }else{
        // TO-BE : 다국어 처리 값
        let validationStatement = this.$t("headerwrapper.headerwrapper_key24");
        this.toast.info(validationStatement);
      }
    },

    deleteShareEmail(user){
      this.userList = this.userList.filter( e => e.email !== user.email );
    },

    calculateTextWidth(text) {
      const canvas = document.createElement('canvas');
      const context = canvas.getContext('2d');
      if(document.querySelector('.title-text')) {
        const style = window.getComputedStyle(document.querySelector('.title-text'));
        context.font = `${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;
        const metrics = context.measureText(text);
        // Add padding for icon and spacing
        return metrics.width + 50; // 50px for icon and padding
      }
      return 50;
    },

    updateHeaderWidth() {
      const titleText = this.currentTitle;
      const textWidth = this.calculateTextWidth(titleText);

      // Update header button width
      // const headerButton = document.querySelector('.chat-curr-text');
      // if (headerButton) {
      //   headerButton.style.width = `${textWidth}px`;
      // }

      return textWidth;
    },

    updateDropdownPosition() {
      const button = document.querySelector('.chat-curr-btn');
      if (button) {
        const rect = button.getBoundingClientRect();

        this.chatDropPosition = {
          x: rect.left - ((600 - rect.width) / 2),
          y: rect.bottom
        };

        // Update dropdown width to match current header width
        const dropdownElement = document.querySelector('.answer-menu-wrapper');
        if (dropdownElement) {
          dropdownElement.style.setProperty('--dropdown-width', `${rect.width}px`);
        }
      }
    },

    scrollAnswer(answerItem) {
      this.isChatDrop = false;
      this.currentAnswerId = answerItem.id;
      this.currentTitle = answerItem.title;

      // Update widths after title change
      this.$nextTick(() => {
        this.updateHeaderWidth();
        this.updateDropdownPosition();
      });

      const element = document.getElementById(`answer-${answerItem.id}`);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }

      this.$emit('selectedAnswer', answerItem);
    },

    handleScroll() {
      if (!this.session.answerList.length) return;

      const answers = this.session.answerList;
      const headerHeight = 100;
      let currentAnswer = null;
      let minDistance = Infinity;

      for (let i = 0; i < answers.length; i++) {
        const element = document.getElementById(`answer-${answers[i].id}`);
        if (element) {
          const rect = element.getBoundingClientRect();
          const distance = Math.abs(rect.top - headerHeight);

          if (distance < minDistance) {
            minDistance = distance;
            currentAnswer = answers[i];
          }
        }
      }

      if (currentAnswer && this.currentAnswerId !== currentAnswer.id) {
        this.currentAnswerId = currentAnswer.id;
        this.currentTitle = currentAnswer.title;

        // Update widths after title change
        this.$nextTick(() => {
          this.updateHeaderWidth();
          this.updateDropdownPosition();
        });
      }
    },
    // Add window resize handler
    handleResize() {
      if (this.isChatDrop) {
        this.updateDropdownPosition();
      }
    },
    updateConversationTitle(newTitle) {
      // 대화 목록에서 현재 세션의 타이틀 업데이트
      const sessionIndex = this.sessionList.findIndex(s => s.convId === this.session.convId);
      if (sessionIndex !== -1) {
        this.sessionList[sessionIndex].title = newTitle;
      }
    },
  },
  created() {
  },
  mounted() {
    window.addEventListener('scroll', this.handleScroll);
    window.addEventListener('resize', this.handleResize);
    this.$nextTick(() => {
        this.updateDropdownPosition();
    });
    const type = this.$route.query.type;
    if (type === 'corp' || type === 'dept') {
      this.setFileGroupType(type);
    } else {
      this.selectGroup('corp');
    }
  },
  beforeDestroy() {
    window.removeEventListener('scroll', this.handleScroll);
    window.removeEventListener('resize', this.handleResize);
  }
};
</script>

