<template>
  <nav :class="{
    'wide': isOpenNav
  }">
    <template v-if="!isOpenNav">
      <div class="nav-header">
        <div class="logo">
          <img class="logoImg" :src="logoImg" v-if="logoImg !== ''" />
          <img v-else-if="realm === 'plex' || realm === 'nhn'" :src="require('@/assets/images/hpnAI_CI.svg')" title="logo" />
          <img v-else :src="require('@/assets/images/gyonggi_CI.svg')" title="logo" class="logo-img" />
        </div>
      </div>
      <div class="nav-body">
        <ul class="nav-btn-group">
          <li>
            <button class="nav-btn" @click="toggleNav(true)">
              <BaseIcon name="FoldLeft" :size="20"/>
            </button>
          </li>
          <li v-if="loginUser.userEmail" @click.stop="addConversation()">
            <button class="nav-btn">
              <BaseIcon name="AddChat" :size="20"/>
            </button>
          </li>
          <li v-if="loginUser.userEmail" @click.stop="focusSearchInput()">
            <button class="nav-btn">
              <BaseIcon name="Search" :size="20"/>
            </button>
          </li>
        </ul>
      </div>
      <div class="nav-footer">
        <div class="profile-wrapper">
          <div class="profile-info">
            <div class="image" @click.stop="toggleProfileItem($event)">
              <BaseIcon :size="20" name="UserOctagon" v-if="!loginUser.userEmail" />
              {{ loginUser.lastName.charAt(0) }}
            </div>
          </div>
        </div>
      </div>
    </template>

    <template v-else>
      <div class="nav-header">
        <div class="logo">
          <img class="logo-img main"  :src="logoImg" v-if="logoImg !== ''" />
          <img class="logo-img main" v-else-if="realm === 'plex' || realm === 'nhn'" :src="require('@/assets/images/hpnAI_BI.svg')" title="logo" />
          <span v-else class="logo-text">{{ $t('lnbwrapper.lnbwrapper_key5') }}</span>
          <!-- <img :src="require('@/assets/images/gyonggi_CI.svg')" title="logo" class="logo-img-long"/>  -->

        </div>
        <button class="btn btn-fold" @click="toggleNav(false)">
          <BaseIcon name="FoldRight" :size="18" />
        </button>
      </div>
      <div class="nav-body">
        <!-- v-if="loginUser.userEmail" -->
        <div class="nav-input-group-wrapper nav-body-item" v-if="loginUser.userEmail">
          <!-- 새 채팅 -->
          <button
            class="nav-input-item btn"
            :class="{ 'text-primary': currentRouteName === 'main' }"
            @click.stop="addConversation()"
          >
            <BaseIcon name="EditFull" :size="20"/>새 채팅
          </button>

          <!-- 에이전트 채팅 -->
          <button
            class="nav-input-item btn"
            :class="{ 'text-primary': currentRouteName === 'AgentChatWrapper' }"
            @click.stop="goToAgentChat()"
          >
            <BaseIcon name="LinkGraph" :size="20"/>에이전트 채팅 <span class="beta-text">Beta</span>
            <div class="check-icon">
              <BaseIcon name="Check" :size="19" v-if="currentRouteName === 'AgentChatWrapper'" />
            </div>
          </button>

          <!-- 공유 채팅 -->
          <!-- <button
            class="chat-add-btn nav-input-item btn"
            :class="{ primary: currentRouteName === 'ShareWrapper' }"
            @click.stop="goToShareManager()"
            v-if="isPlexRealm">
            <span class="icon"><BaseIcon name="Users" /></span>{{ $t('lnbwrapper.lnbwrapper_key2') }}
          </button> -->

          <!-- 파일 관리 -->
          <!-- <button
            class="chat-add-btn nav-input-item btn"
            :class="{ primary: currentRouteName === 'FileMangeWrapper' }"
            @click.stop="goToFileManager()"
            v-if="isPlexRealm"
          >
            <span class="icon"><BaseIcon name="Paper" /></span>{{ $t('lnbwrapper.lnbwrapper_key3') }}
          </button> -->

          <!-- 추천 페이지 -->
          <button
            class="nav-input-item btn"
            :class="{ 'text-primary': currentRouteName === 'DiscoverWrapper' }"
            @click.stop="goToDiscoverManager()"
            v-if="false"
          >
          <BaseIcon name="Paper" :size="18"/> 추천
          </button>

          <!-- 문서생성 -->
          <button
            class="nav-input-item btn"
            :class="{ 'text-primary': session.chatMode === 'docs' }"
            @click.stop="goToDocumentManager()"
          >
            <BaseIcon name="Paper" :size="19"/> AI 문서 스튜디오
            <div class="check-icon">
              <BaseIcon name="Check" :size="19" v-if="session.chatMode === 'docs'" />
            </div>
          </button>

          <!-- 문서저장소 -->
          <button
            class="nav-input-item btn"
            :class="{ 'text-primary': session.chatMode === 'docsRepository' }"
            @click.stop="goToDocumentAnswerManager()"
          >
            <BaseIcon name="Cloud" :size="19"/> AI 드라이브
            <div class="check-icon">
              <BaseIcon name="Check" :size="19" v-if="session.chatMode === 'docsRepository'" />
            </div>
            <!-- <BaseIcon name="Check" :size="19" v-if="currentRouteName === 'DocumentWrapper'" /> -->
          </button>

<!--          <button-->
<!--            class="nav-input-item btn disabled"-->
<!--            :class="{ 'text-primary': session.chatMode === 'convHistory' }"-->
<!--            @click.stop="goToConversationHistoryManager()"-->
<!--          >-->
<!--            <BaseIcon name="TimeCircle" :size="19"/> 대화 이력 관리-->
<!--            <div class="check-icon">-->
<!--              <BaseIcon name="Check" :size="19" v-if="session.chatMode === 'convHistory'" />-->
<!--            </div>-->
<!--            &lt;!&ndash; <BaseIcon name="Check" :size="19" v-if="currentRouteName === 'DocumentWrapper'" /> &ndash;&gt;-->
<!--          </button>-->

          <!-- 검색 -->
          <div class="search-input nav-input-item" v-if="false">
            <input
              type="text"
              id="searchInput"
              :placeholder="$t('lnbwrapper.lnbwrapper_key21')"
              @input="onSearchText($event)"
            />
            <button class="search-icon icon">
              <BaseIcon name="InputSearch" />
            </button>
          </div>
        </div>
        <div class="conversation-group-wrapper nav-body-item" v-if="!loginUser.userEmail">
          <div class="conversation-title wrapper-title login-request-title" @click.stop="login()">
            <h4 class="title-text">{{ $t('lnbwrapper.lnbwrapper_key6') }}</h4>
          </div>
        </div>

        <div class="conversation-group-wrapper nav-body-item" v-if="conversationList.length === 0 && loginUser.userEmail">
          <div class="conversation-title wrapper-title login-request-title">
            <h4 class="title-text">{{ $t('lnbwrapper.lnbwrapper_key7') }}</h4>
          </div>
        </div>

        <div class="conversation-group-wrapper nav-body-item" v-if="pinnedConversationList.length > 0 && showConversationHistory">
          <div class="conversation-title wrapper-title">
            <h4 class="title-text">{{ $t('lnbwrapper.lnbwrapper_key8') }}</h4>
          </div>
          <div class="conversation-group">
            <div class="conversation-item"
                 v-for="convItem in pinnedConversationList"
                 :key="convItem.convId"
                 ref="convs"
                 @click.stop="onSelectedConversation(convItem)"
                 :data-id="convItem.convId"
                 :class="{
                'active-conversation': currConversation && (convItem.session_id === currConversation.session_id)
              }">
              <p ref="convsTitle" :data-id="convItem.convId" @keyup.enter="$event.target.blur()"
                 @keydown.enter.prevent @blur="blurConvTitle">
                {{ convItem.title }}
              </p>
              <button ref="convsNav" :data-id="convItem.convId" class="btn-icon excluded"
                      @click.stop="toggleConvItem($event, convItem)">
                <BaseIcon name="DotsHorizontal" :size="18" />
              </button>
            </div>
          </div>
        </div>
        <div class="conversation-group-wrapper" v-if="conversationList.length > 0 && showConversationHistory"
             @blur="blurConvTitle">
          <div class="conversation-title wrapper-title nav-body-item">
            <BaseIcon name="ArrowFullDown" :size="20" :mr="8"/>
            <h4 class="title-text">{{ $t('lnbwrapper.lnbwrapper_key9') }}</h4>
          </div>
          <div class="conversation-group nav-body-item">
            <div class="conversation-item"
                 v-for="convItem in normalConversationList"
                 :key="convItem.convId"
                 ref="convs"
                 @click.stop="onSelectedConversation(convItem)"
                 :data-id="convItem.convId"
                 :class="{
                'new-item': convItem.isNew,
                'active-conversation': currConversation && (convItem.session_id === currConversation.session_id)
              }">
              <p ref="convsTitle" :data-id="convItem.convId" @keyup.enter="$event.target.blur()"
                 @keydown.enter.prevent @blur="blurConvTitle">
                {{ convItem.title }}
              </p>
              <button ref="convsNav" :data-id="convItem.convId" class="btn-icon excluded"
                      @click.stop="toggleConvItem($event, convItem)">
                <BaseIcon name="DotsHorizontal" :size="18" />
              </button>
            </div>
          </div>
        </div>
      </div>
      <div class="nav-footer">
        <div class="profile-wrapper">
          <div class="profile-info">
            <template v-if="loginUser.userEmail">
              <!-- <div class="image mr8">{{ loginUser.lastName[0] || '' }}</div> -->
              <div class="image mr8">{{ 'A' || '' }}</div>
              <div class="profile-label">
                 <h4 class="id">{{ loginUser.userEmail }}</h4>
<!--                <h4 class="id">ai-chatbot@aichatbot.com</h4>-->
              </div>
            </template>
            <template v-else>
              <button class="login-btn" @click="login()">
                <BaseIcon name="UserOctagon" :mr="8" />
                {{ $t('lnbwrapper.lnbwrapper_key13') }}
              </button>
            </template>
          </div>
          <button class="profile-btn btn excluded" @click.stop="toggleProfileItem">
            <BaseIcon name="Setting" />
          </button>
          <FixDropDown
            :width="260"
            :top="profileDropPosition.y"
            :left="profileDropPosition.x"
            :isOpenDrop="isProfileDrop"
            @close="closeEve"
            dropdownName="profile-menu-wrapper">
            <template #content>
              <div class="profile-menu">
                <div class="profile-menu-item profile-theme" @click.stop="toggleMenu('ThemeList')">
                  <BaseIcon name="ArrowFullUp" :mr="8" />
                  <!--                  <BaseIcon :name="showThemeList ? 'ArrowFullUp' : 'ArrowFullDown'" :mr="8" />-->
                  {{ $t('lnbwrapper.lnbwrapper_key19') }}
                </div>
                <ul class="profile-menu-item profile-theme-list">
                  <li @click.stop="setTheme('SYSTEM')">
                    <button class="nav-btn">{{ $t('lnbwrapper.lnbwrapper_key10') }}
                      <BaseIcon class="ml-auto" :size="20" name="Contrast" />
                    </button>
                  </li>
                  <li @click.stop="setTheme('LIGHT')">
                    <button class="nav-btn">{{ $t('lnbwrapper.lnbwrapper_key11') }}
                      <BaseIcon class="ml-auto" :size="20" name="Sun" />
                    </button>
                  </li>
                  <!-- <li @click.stop="setTheme('DARK')"> -->
                  <li>
                    <button class="nav-btn disabled">{{ $t('lnbwrapper.lnbwrapper_key12') }}
                      <BaseIcon class="ml-auto" :size="20" name="Moon" />
                    </button>
                  </li>
                </ul>
                <!-- 언어 설정 -->
                <div class="profile-menu-item profile-theme" @click.stop="toggleMenu('LangList')" v-if="false">
                  <BaseIcon name="ArrowFullUp" :mr="8" />
                  {{ $t('lnbwrapper.lnbwrapper_key35') }}
                </div>
                <ul class="profile-menu-item profile-theme-list" v-if="false">
                  <li @click.stop="changeLang('ko')">
                    <button class="nav-btn">{{ $t('lnbwrapper.lnbwrapper_key36') }}</button>
                  </li>
                  <li @click.stop="changeLang('en')">
                    <button class="nav-btn">English</button>
                  </li>
                  <li @click.stop="changeLang('indo')">
                    <button class="nav-btn">Bahasa Indonesia</button>
                  </li>
                </ul>
                <div class="profile-menu-item profile-logout" >
                  <button class="nav-btn" @click="adminPageGo()">
<!--                    <BaseIcon name="Logout" :size="20" :mr="8" />-->
                    관리자
                  </button>
                </div>
                <div class="profile-menu-item profile-logout" v-if="loginUser.userEmail">
                  <button class="nav-btn" @click="logout()">
                    <BaseIcon name="Logout" :size="20" :mr="8" />
                    {{ $t('lnbwrapper.lnbwrapper_key20') }}
                  </button>
                </div>
                <div class="profile-menu-item profile-logout" v-if="!loginUser.userEmail && !isOpenNav">
                  <button class="nav-btn" @click="login()">
                    <BaseIcon name="UserOctagon" :mr="8" />
                    {{ $t('lnbwrapper.lnbwrapper_key13') }}
                  </button>
                </div>

              </div>
            </template>
          </FixDropDown>

        </div>

      </div>
    </template>

    <DropDown
      :width="154"
      :top="convDropPosition.y"
      :left="convDropPosition.x"
      :isOpenDrop="isConvDrop"
      @close="isConvDrop = false"
      dropdownName="conversation-menu-wrapper">
      <template #content>
        <ul>
          <li v-if="realm !== 'plex'">
            <button class="nav-btn" @click.stop="shareConversation()">
              <BaseIcon name="Sharing" :size="20" :mr="8" />
              {{ $t('lnbwrapper.lnbwrapper_key14') }}
            </button>
          </li>
          <li>
            <button class="nav-btn" @click.stop="editTitleConversation()">
              <BaseIcon name="AddChat" :size="20" :mr="8" />
              {{ $t('lnbwrapper.lnbwrapper_key15') }}
            </button>
          </li>
          <li v-if="!toggleConversationTarget.pin">
            <button class="nav-btn" @click.stop="pinConversation(true)">
              <BaseIcon name="Pin" :size="20" :mr="8" />
              {{ $t('lnbwrapper.lnbwrapper_key16') }}
            </button>
          </li>
          <li v-if="toggleConversationTarget.pin">
            <button class="nav-btn" @click.stop="pinConversation(false)">
              <BaseIcon name="PinVan" :size="20" :mr="8" />
              {{ $t('lnbwrapper.lnbwrapper_key17') }}
            </button>
          </li>
          <li>
            <button class="nav-btn" @click.stop="deleteConversationModal()">
              <BaseIcon name="Delete" :size="20" :mr="8" />
              {{ $t('lnbwrapper.lnbwrapper_key18') }}
            </button>
          </li>
        </ul>
      </template>
    </DropDown>


    <MyModal
      width="385"
      :isOpenModal="isDeleteModal"
      :okBtnName="$t('lnbwrapper.lnbwrapper_key18')"
      :title="$t('lnbwrapper.lnbwrapper_key22')"
      @close="isDeleteModal = false"
      @sendData="deleteConversation"
    >
      <template #content>
        <p class="desc" v-html="$t('lnbwrapper.lnbwrapper_key4')"></p>
      </template>
    </MyModal>
    <MyModal
      width="400"
      :isOpenModal="isChatSendingModal"
      okBtnName="이동"
      cancelBtnName="취소"
      title="진행 중인 대화가 있습니다"
      @close="handleStay"
      @sendData="handleConfirmLeave"
    >
      <template #content>
        <p>현재 작성 중인 대화가 진행 중입니다. 다른 대화로 이동하면 입력하신 내용이 모두 삭제됩니다.<br/>정말 이동하시겠습니까?</p>
      </template>
    </MyModal>
  </nav>
</template>

<script setup>
import {
  ref,
  reactive,
  computed,
  watch,
  onMounted,
  nextTick,
  defineEmits,
  defineExpose,
  defineProps,
  onBeforeMount,
} from 'vue';
import { useStore } from 'vuex';
import { useRouter, useRoute } from 'vue-router';
import { useToast } from 'vue-toastification';
import { useI18n } from 'vue-i18n';
import BaseIcon from '@/component/BaseIcon.vue';
import DropDown from '@/component/DropDown.vue';
import FixDropDown from '@/component/FixDropDown.vue';
import MyModal from '@/component/MyModal.vue';
import { v1 as uuidv1 } from 'uuid';
import _ from 'lodash';
import _isEmpty from 'lodash/isEmpty';
import ssoService from '@/domains/sso/keycloakService.js';
import {
  deleteFileMgr
} from '@/domains/chat/infrastructure/fileUpload/fileMgrApi';

import {
  callConversationListAnswer,
  getDomainInfo,
  callConversationList,
  updateSessionTitle,
  updateSessionPinned,
  deleteSession, saveSession,
} from '@/domains/chat/infrastructure/chatApi';


// --- emits 정의 ---
const emit = defineEmits([
  'selectedConversation',
  'onShareConversation',
  'openBoard',
  'openBoardSession',
  'changeLoding',
]);

//  ---- props 정의 ---

defineProps({
  logoImg: { type: String, default: '' },
})

// --- composables ---
const store = useStore();
const router = useRouter();
const route = useRoute();
const toast = useToast();
const { t, locale: i18nLocale } = useI18n();

// --- 반응형 상태 ---
const isPlexRealm = ref(false);
const realm = ref('');

const conversationList = ref([]);
const pinnedConversationList = ref([]);
const normalConversationList = ref([]);
const newChat = computed(() => store.getters.newChat);
//챗 진행 중 여부
const isChatSending = computed(() => store.state.isChatSending);
// 사용자가 새 채팅 또는 다른 대화로 이동 시도할 때
const isChatSendingModal = ref(false);
const clickMenuType = ref('');
const clickConvItem = ref(null);
const isOpenNav = ref(true);
const isDeleteModal = ref(false);
const isConvDrop = ref(false);
const isProfileDrop = ref(false);
const convDropPosition = reactive({ x: 0, y: 0 });
const profileDropPosition = reactive({ x: 0, y: 0 });

// template refs
const convsTitle = ref([]);
const convsNav = ref([]);

const currConversation = ref(null);
const toggleConversationTarget = ref(null);

const showThemeList = ref(false);
const showLangList = ref(false);
const showProfileDrop = ref(false);

// --- 상태 변수 ---
const searchInputId = 'searchInput';

// --- computed ---
const loginUser = computed(() => store.getters.loginUser);
const currentRouteName = computed(() => route.name);
const session = computed(() => store.getters.session);
// 대화 기록을 보여줄지 여부 (간단한 조건)
const showConversationHistory = computed(() => {
  return loginUser.value.userEmail &&
         session.value.chatMode !== 'docsRepository' &&
         currentRouteName.value !== 'AgentChatWrapper';
});

onBeforeMount(() => {
  initConversation();
})


onMounted(() => {
  isPlexRealm.value = window.opsbotFrontProfile?.realm === 'plex';
  realm.value = window.opsbotFrontProfile?.realm || '';
});

// 웰컴페이지에서 첫 대화를 입력 시 첫 채팅일 경우 세션 저장 + 타이틀 변경
watch(newChat, (val) => {
  if (!val || !val.flag) return;
  const current = session.value;
  if (!current?.convId) return;
  // 기존 리스트에 이미 존재하면 중복 추가 방지
  const exists = conversationList.value.find(e => e.convId === current.convId);
  if (exists) return;
  // lnb 내용 추가
  normalConversationList.value.unshift(current);
  conversationList.value.unshift(current);

  // 인덱스 재정렬
  conversationList.value.forEach((e, i) => e.index = i);
  updateConversationTitle(current.convId, val.message);
  // 세션 호출 객체
  const sessionPayload = {
    agent_id: getDomainInfo().chatbotCode,
    email: store.state.loginUser.userEmail,
    title: val.message,
    session_id: current.session_id,
    chatMode: current.chatMode,
  };
  // 세션 저장
  saveSession(sessionPayload)
    .catch(error => {
      console.error('Error saving session and query:', error);
    });
}, { immediate: false });



function closeEve() {
  isProfileDrop.value = false;
  showThemeList.value = false;
  showLangList.value = false;
}

// function goToFileManager() {
//   router.push({ name: 'FileMangeWrapper' });
// }

/**
 * 공유 페이지 진입 함수
 */
//  function goToShareManager() {
//   router.push({ name: 'ShareWrapper' });
// }

/**
 * 추천 페이지 진입 함수
 */
function goToDiscoverManager() {
  router.push({ name: 'DiscoverWrapper' });
}
function goToDocumentManager() {
  docsGoPageCommon('docs', 'DocumentWrapper')
}

/**
 * 에이전트 채팅 페이지 진입 함수
 */
function goToAgentChat() {
  docsGoPageCommon('AgentChat', 'AgentChatWrapper')
}

function goToDocumentAnswerManager() {
  store.commit('setShowDocsAnswer', 'docsRepository');
  docsGoPageCommon('docsRepository', 'Main')
}

// function goToConversationHistoryManager() {
//   store.commit('setShowDocsAnswer', 'convHistory');
//   docsGoPageCommon('convHistory', 'Main')
// }

const docsGoPageCommon = (chatMode, pageNm) => {
  currConversation.value = null;
  const convId = uuidv1();
  const objConversation = {
    id: store.state.loginUser.userEmail,
    agent_code: getDomainInfo().chatbotCode,
    chatbotCode: getDomainInfo().chatbotCode,
    user_email: store.state.loginUser.userEmail,
    session_id: convId,
    convId: convId,
    query: '',
    title: '',
    created_at: new Date().toISOString(),
    conversationDate: new Date().toISOString(),
    isNew: true,
    chatMode: chatMode,
  }
  store.commit('setSession', objConversation)
  router.push({
    name: pageNm,
    params: route.params,
    query: route.query,
  });
}



function toggleNav(booelan) {
  isOpenNav.value = booelan;
}

function toggleConvItem(event, convItem) {
  toggleConversationTarget.value = convItem;
  isConvDrop.value = true;
  convDropPosition.x = event.clientX;
  convDropPosition.y = event.clientY - 100;
}

function toggleProfileItem(event) {
  isProfileDrop.value = true;
  profileDropPosition.x = event.clientX;
  profileDropPosition.y = event.clientY - 100;
}

function logout(force) {
  store.commit('setLoginUser', {});
  ssoService.logout({ redirectUri: '' });
  if (force) ssoService.logoutAllSession();
}


function login() {
  ssoService.login();
}

function adminPageGo() {
  window.location.href = `https://bb8-plex-adminfront-${process.env.VUE_APP_AGW_URL_SUB}.dev.helpnow.ai/login?chatbotCode=${getDomainInfo().chatbotCode}`;
}

async function initConversation() {
  // 로그인 유저 이메일 없으면 새 대화 생성
  const email = store.state.loginUser.userEmail;
  // 서버에서 대화 리스트 받아오기
  const response = await callConversationList({
    email,
    agent_id: getDomainInfo().chatbotCode,
  });

  // deep clone & 날짜순 정렬
  const list = _.cloneDeep(response);
  list.sort((a, b) => new Date(a.created_at) - new Date(b.created_at))
    .forEach((e, i) => {
      e.index = i;
    });

  // 상태 업데이트
  conversationList.value = list;
  pinnedConversationList.value = list.filter(e => e.pin);
  normalConversationList.value = list.filter(e => !e.pin);
  currConversation.value = list[0] || null;

  // 새 대화 생성 플래그 판단
  if (list.length !== 0) {
    const firstTitle = list[0].title;
    if (firstTitle === t('lnbwrapper.lnbwrapper_key1')) {
      // 첫 세션이 웰컴 메시지면 선택 콜백
      onSelectedConversation(currConversation.value);
    }
  }
  addConversation();
}


function onSelectedConversation(convItem) {
  store.commit('setShowDocsAnswer', '');

  if(convItem.chatMode === 'docs'){
    store.commit('setShowDocsAnswer', 'docs');
    router.push({
      name: 'Main',
      params: route.params,
      query: { ...route.query, accessLevel: session.value.accessLevel },
    });

    currConversation.value = convItem;
    isConvDrop.value = false;
    //
  }else if(convItem.chatMode === 'docsRepository'){
    store.commit('setShowDocsAnswer', 'docsRepository');
    router.push({
      name: 'Main',
      params: route.params,
      query: { ...route.query, accessLevel: session.value.accessLevel },
    });

    currConversation.value = convItem;
    isConvDrop.value = false;
  }
  else{
  store.commit('setShowDocsAnswer', '');
  router.push({
    name: 'Main',
    params: route.params,
    query: route.query,
  });

  if(isChatSending.value === true){
    isChatSendingModal.value = true;
    clickMenuType.value = 'old';
    clickConvItem.value = convItem;
    return;
  }
  currConversation.value = convItem;
  isConvDrop.value = false;

  // 부모 컴포넌트로 이벤트 방출
  // (템플릿에서 @selectedConversation="..." 로 처리)
  }
  emit('selectedConversation', convItem);

}

function shareConversation() {
  emit('onShareConversation', toggleConversationTarget.value);
}

function toggleMenu(menuType) {
  if (menuType === 'ThemeList') {
    showThemeList.value = !showThemeList.value;
    showLangList.value = false;
  } else {
    showLangList.value = !showLangList.value;
    showThemeList.value = false;
  }
}

function changeLang(locale) {
  i18nLocale.value = locale;
  localStorage.setItem('locale', locale);
  toast.info(t('lnbwrapper.lnbwrapper_key37'));
  showLangList.value = false;
  showThemeList.value = false;
  isProfileDrop.value = false;
}


// 편집 모드 진입
function editTitleConversation() {
  isConvDrop.value = false;

  // 해당 요소 찾기
  const titleEl = convsTitle.value.find(
    el => el.dataset.id === toggleConversationTarget.value.convId,
  );
  const navEl = convsNav.value.find(
    el => el.dataset.id === toggleConversationTarget.value.convId,
  );
  if (!titleEl || !navEl) return;

  // 편집 스타일 적용
  titleEl.classList.add('conversation-edit');
  titleEl.setAttribute('contenteditable', 'true');
  navEl.classList.add('display-none');
  titleEl.focus();
}

// 제목 저장
async function renameConversation() {
  const titleEl = convsTitle.value.find(
    el => el.dataset.id === toggleConversationTarget.value.convId,
  );
  const navEl = convsNav.value.find(
    el => el.dataset.id === toggleConversationTarget.value.convId,
  );
  if (!titleEl || !navEl) return;

  // 비어있으면 포커스
  const raw = titleEl.innerHTML.replaceAll('<br>', '').trim();
  if (raw.length === 0) {
    titleEl.focus();
    toast.error(t('lnbwrapper.lnbwrapper_key23'));
    return;
  }

  const payload = {
    collection: 'sessions',
    uuid: toggleConversationTarget.value.convId,
    update: { title: raw },
  };

  try {
    await updateSessionTitle(payload);

    // 로컬 리스트 업데이트
    conversationList.value = conversationList.value.map(conv =>
      conv.convId === toggleConversationTarget.value.convId
        ? { ...conv, title: raw }
        : conv,
    );
    pinnedConversationList.value = conversationList.value.filter(e => e.pin);
    normalConversationList.value = conversationList.value.filter(e => !e.pin);

    // 알림
    toast.info(t('lnbwrapper.lnbwrapper_key24'));

    // 편집 모드 해제
    titleEl.classList.remove('conversation-edit');
    titleEl.removeAttribute('contenteditable');
    navEl.classList.remove('display-none');
  } catch (err) {
    console.error(t('lnbwrapper.lnbwrapper_key25'), err);
    toast.error(t('lnbwrapper.lnbwrapper_key26'));
  }
}

function blurConvTitle(event) {
  event.preventDefault();
  renameConversation();
}

// --- 대화 고정/해제 ---
const pinConversation = async (isPinned) => {
  try {
    //  대화 내용 조회
    const answers = await callConversationListAnswer({
      email: store.state.loginUser.userEmail,
      session_id: toggleConversationTarget.value.convId,
    });

    //  고정 불가 조건 ( 일반채팅 docs 제외)
    if (isPinned && (!answers || answers.length === 0) && session.value.chatMode !== 'docs' && session.value.chatMode === 'docsRepository') {
      toast.error(t('lnbwrapper.lnbwrapper_key27'));
      isConvDrop.value = false;
      return;
    }

    //  서버에 고정/해제 요청 (await 잊지 마세요)
    await updateSessionPinned({
      collection: 'sessions',
      uuid: toggleConversationTarget.value.convId,
      pin: isPinned,
    });

    //  로컬 상태 업데이트
    toggleConversationTarget.value.pin = isPinned;
    toggleConversationTarget.value.pinnedDate = isPinned ? new Date() : null;

    arrangeConversation(toggleConversationTarget.value, isPinned);

    //  성공 토스트
    toast.info(
      isPinned
        ? t('lnbwrapper.lnbwrapper_key28')
        : t('lnbwrapper.lnbwrapper_key29'),
    );
    isConvDrop.value = false;

  } catch (err) {
    console.error(t('lnbwrapper.lnbwrapper_key30'), err);
    toast.error(t('lnbwrapper.lnbwrapper_key31'));
  }
};

// --- 목록 재정렬 ---
const arrangeConversation = (target, isPinned) => {
  conversationList.value = conversationList.value.map(e => {
    if (e.convId === target.convId) {
      return {
        ...e,
        pin: isPinned,
        pinnedDate: isPinned ? (e.pinnedDate || new Date()) : null,
      };
    }
    return e;
  });

  // 전체 대화(created_at 기준 오름차순) 정렬 & 인덱스 갱신
  conversationList.value.sort((a, b) =>
    new Date(a.created_at) - new Date(b.created_at),
  );
  conversationList.value.forEach((e, i) => {
    e.index = i;
  });

  // pinned 목록: pinnedDate 오름차순 + 인덱스 갱신
  pinnedConversationList.value = conversationList.value
    .filter(e => e.pin)
    .sort((a, b) => a.pinnedDate - b.pinnedDate)
    .map((e, i) => ({ ...e, index: i }));

  // normal 목록: pin=false + 인덱스 갱신
  normalConversationList.value = conversationList.value
    .filter(e => !e.pin)
    .map((e, i) => ({ ...e, index: i }));
};

/**
 *  대화 제목 업데이트 App.vue 에서 요청시 해당 함수 발동
 */
function updateConversationTitle(convId, newTitle) {
  const conv = conversationList.value.find(c => c.convId === convId);
  if (!conv) return;
  conv.title = newTitle;
  // 고정/일반 목록도 갱신
  pinnedConversationList.value = conversationList.value.filter(e => e.pin);
  normalConversationList.value = conversationList.value.filter(e => !e.pin);
}

// --- 삭제 모달 열기/닫기 ---
function deleteConversationModal() {
  isDeleteModal.value = true;
  isConvDrop.value = false;
}

async function deleteConversation() {
  // 모달 닫기
  isDeleteModal.value = false;

  try {
    // API payload 준비
    const payload = {
      collection: 'sessions',
      agent_id: session.value.chatbotCode,
      session_id: toggleConversationTarget.value.convId,
    };

    // 세션 삭제 요청
    deleteSession(payload);

    // 연관 파일 삭제 요청
    deleteFileMgr(toggleConversationTarget.value.convId);

    // 로컬 리스트에서 제거
    conversationList.value = conversationList.value
      .filter(e => e.convId !== toggleConversationTarget.value.convId);

    // 인덱스 재정렬
    conversationList.value
      .sort((a, b) => new Date(a.created_at) - new Date(b.created_at))
      .forEach((e, i) => e.index = i);

    // 고정/일반 목록 업데이트
    pinnedConversationList.value = conversationList.value.filter(e => e.pin);
    normalConversationList.value = conversationList.value.filter(e => !e.pin);

    //선택 세션 초기화
    // onSelectedConversation(session.value);
    isChatSendingModal.value = false;
    // 성공 토스트
    toast.info(t('lnbwrapper.lnbwrapper_key32'));
    addConversation();

  } catch (error) {
    console.error(t('lnbwrapper.lnbwrapper_key33'), error);
    toast.error(t('lnbwrapper.lnbwrapper_key34'));
  }
}


/**
 * 새 채팅 버튼 이벤트
 */
function addConversation() {
  store.commit('setShowDocsAnswer', '');
  if(isChatSending.value === true){
    isChatSendingModal.value = true;
    clickMenuType.value = 'new';
    return;
  }
  // 웰컴 화면 표시
  store.commit('setShowWelcome', true);
  emit('changeLoding', false);
  // 기본 타이틀 & convId 생성
  const tempTitle = t('lnbwrapper.lnbwrapper_key1');
  const convId = uuidv1();
  // 새 대화 세션 객체 (임시)
  const objConversation = {
    id: store.state.loginUser.userEmail,
    agent_code: getDomainInfo().chatbotCode,
    chatbotCode: getDomainInfo().chatbotCode,
    user_email: store.state.loginUser.userEmail,
    session_id: convId ,
    isInit: true,
    convId: convId,
    recommend_enabled: false,
    recom_list: [],
    nodes: {
      domain_node: { id: 'root', name: 'root' },
      subcategory_node: { id: '', name: '' },
    },
    prompt: {
      id: store.getters.session.promptId,
      prompt_name: store.getters.session.promptName,
    },
    engine: 'azure',
    query: '',
    linked_intent: 'Default Welcome Intent',
    query_date: '',
    title: tempTitle,
    chatMode: '',
    searchType: 'basic',
    shareType: 'oneShare',
    userList: [],
    pin: false,
    pinnedDate: '',
    created_at: new Date().toISOString(),
    conversationDate: new Date().toISOString(),
    promptId: store.getters.session.promptId,
    domainNode: {},
    subcategoryNode: {},
    index: normalConversationList.value.length,
    isNew: true,
  };
  // Vuex 세션만 변경 → 화면 초기화
  store.commit('setSession', objConversation);
  // 현재 세션 선택만 업데이트
  currConversation.value = objConversation;

  // 화면 라우팅(Main으로 이동)
  router.push({
    name: 'Main',
    params: route.params,
    query: route.query,
  });
}




// 검색어 입력 처리
function onSearchText(event) {
  const txt = event.target.value.toUpperCase();
  if (_isEmpty(txt)) {
    pinnedConversationList.value = conversationList.value.filter(e => e.pin);
    normalConversationList.value = conversationList.value.filter(e => !e.pin);
  } else {
    pinnedConversationList.value = conversationList.value
      .filter(e => e.pin)
      .filter(e => e.title.toUpperCase().includes(txt));
    normalConversationList.value = conversationList.value
      .filter(e => !e.pin)
      .filter(e => e.title.toUpperCase().includes(txt));
  }
}

// 검색 인풋 포커스
function focusSearchInput() {
  isOpenNav.value = true;
  nextTick(() => {
    const inp = document.getElementById(searchInputId);
    if (inp) setTimeout(() => inp.focus(), 100);
  });
}

//  테마 설정
function setTheme(theme) {
  const body = document.body;
  localStorage.setItem('theme', theme);
  if (theme === 'SYSTEM') {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
    body.setAttribute('data-theme', prefersDark.matches ? 'dark' : 'root');
    prefersDark.addEventListener('change', e => {
      body.setAttribute('data-theme', e.matches ? 'dark' : 'root');
    });
  } else if (theme === 'DARK') {
    body.setAttribute('data-theme', 'dark');
  } else {
    body.setAttribute('data-theme', 'root');
  }
  // 드롭다운 닫기
  showProfileDrop.value = false;
  showThemeList.value = false;
  showLangList.value = false;
  isProfileDrop.value = false;
}


// 모달 ok 클릭
function handleConfirmLeave() {
  // 채팅 전송 상태 초기화
  store.commit('setIsChatSending', false);
  if(clickMenuType.value === 'new') {
    addConversation();
  } else{
    onSelectedConversation(clickConvItem.value);
  }
  isChatSendingModal.value = false;
}

// 모달 닫기 클릭
function handleStay() {
  isChatSendingModal.value = false;
}


// 외부(부모 컴포넌트)에서 호출 가능하도록 노출
defineExpose({
  updateConversationTitle,
  addNewConversation,
});

// 새로운 세션을 대화 목록에 추가하고 현재 세션으로 설정
function addNewConversation(newSession) {

  // 기존 리스트에 이미 존재하는지 확인 (session_id로 비교)
  const exists = conversationList.value.find(e => e.session_id === newSession.session_id);

  if (exists) {
    // 이미 존재하더라도 현재 세션으로 설정
    currConversation.value = newSession;

    // 고정/일반 목록도 업데이트
    pinnedConversationList.value = conversationList.value.filter(e => e.pin);
    normalConversationList.value = conversationList.value.filter(e => !e.pin);

    return;
  }

  // 새 세션을 리스트 맨 앞에 추가
  conversationList.value.unshift(newSession);

  // 인덱스 재정렬
  conversationList.value.forEach((e, i) => e.index = i);

  // 고정/일반 목록 업데이트
  pinnedConversationList.value = conversationList.value.filter(e => e.pin);
  normalConversationList.value = conversationList.value.filter(e => !e.pin);

  // 현재 세션으로 설정
  currConversation.value = newSession;

}

</script>