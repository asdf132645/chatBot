import { ref } from 'vue'
import { getFileIconName } from './chatUtils'
import { useToast } from 'vue-toastification'

/** 파일 첨부 공용 로직 (중복 방지 + 상태 일원화) */
export function useFileAttachments() {
  const fileList = ref([])            // [{id,name,size,type,file,status,fileType}]
  const uploadedFileIds = ref([])     // 서버 업로드 완료된 파일 id 배열
  const toast = useToast()

  // 파일 중복 판정 키(이름+사이즈+lastModified)
  const keyOf = f => `${f?.name}::${f?.size}::${f?.lastModified ?? 'na'}`

  function handleFileUpload(files) {
    if (!files || !files.length) return
    const exists = new Set(fileList.value.map(f => keyOf(f.file || f)))
    const appended = []

    for (const f of files) {
      const k = keyOf(f)
      if (exists.has(k)) continue // 중복 방지
      appended.push({
        id: crypto?.randomUUID?.() || String(Date.now() + Math.random()),
        name: f.name,
        size: f.size,
        type: f.type,
        file: f,
        status: 'ready',                 // ready | uploaded | error
        fileType: getFileIconName(f.type),
      })
      exists.add(k)
    }

    if (appended.length) fileList.value = [...fileList.value, ...appended]
  }

  function handleFileIds(ids) {
    uploadedFileIds.value = Array.isArray(ids) ? ids : []
  }

  function onFileUploadError(failedFile) {
    if (!failedFile) return
    
    // failedCnt가 있는 경우 토스트 메시지 표시
    if (failedFile.meta && failedFile.meta.failedCnt && failedFile.meta.failedCnt > 0) {
      toast.error(`파일 업로드 실패: ${failedFile.meta.failedCnt}개 파일 처리 중 오류가 발생했습니다. 다시 시도해주세요.`);
    } else {
      toast.error('파일 업로드 중 오류가 발생했습니다. 다시 시도해주세요.');
    }
    
    fileList.value = fileList.value.map(f =>
      (f.name === failedFile.name && f.size === failedFile.size)
        ? { ...f, status: 'error' }
        : f
    )
    // 3초 뒤 에러 항목 제거
    setTimeout(() => {
      fileList.value = fileList.value.filter(f => f.status !== 'error')
    }, 3000)
  }

  function clearAllFiles() {
    fileList.value = []
    uploadedFileIds.value = []
  }

  function onFileProcessed({ file }) {
    if (!file) return
    fileList.value = fileList.value.map(f =>
      (f.name === file.name && f.size === file.size)
        ? (f.status === 'uploaded' ? f : { ...f, status: 'uploaded' }) // 중복 이벤트 가드
        : f
    )
  }

  function deleteFile(fileId) {
    fileList.value = fileList.value.filter(f => f.id !== fileId)
    if (!fileList.value.length) uploadedFileIds.value = []
  }

  return {
    fileList,
    uploadedFileIds,
    handleFileUpload,
    handleFileIds,
    onFileUploadError,
    clearAllFiles,
    onFileProcessed,
    deleteFile,
  }
}
