// HTML → TXT 변환 컴포저블

export type HtmlToTextOptions = {
  linkStyle?: 'inline' | 'remove' | 'footnote'; // 기본: inline → "텍스트 (URL)"
  imageStyle?: 'alt' | 'remove' | 'keep';       // 기본: alt  → "[IMG: alt]"
  tableStyle?: 'tsv' | 'markdown' | 'lines';    // 기본: tsv  → 탭 구분
  headingUppercase?: boolean;                   // 기본: false
  maxConsecutiveBlankLines?: number;            // 기본: 2
};

type RequiredOpts = Required<HtmlToTextOptions>;

function _convertHtmlToText(html: string, opts: HtmlToTextOptions = {}): string {
  const options: RequiredOpts = {
    linkStyle: 'inline',
    imageStyle: 'alt',
    tableStyle: 'tsv',
    headingUppercase: false,
    maxConsecutiveBlankLines: 2,
    ...opts,
  };

  // SSR/비브라우저 안전 가드
  const hasDOM = typeof window !== 'undefined' && typeof DOMParser !== 'undefined';
  if (!hasDOM) {
    // 아주 단순 폴백: 태그 제거만
    return (html || '')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<\/p>/gi, '\n\n')
      .replace(/<[^>]+>/g, '')
      .replace(/\u00a0/g, ' ')
      .trim();
  }

  const parser = new DOMParser();
  const doc = parser.parseFromString(`<div id="root">${html || ''}</div>`, 'text/html');
  const root = doc.getElementById('root')!;

  const decode = (s: string) => {
    if (!s) return '';
    const div = doc.createElement('div');
    div.innerHTML = s;
    return div.textContent || '';
  };

  const trimLines = (s: string) =>
    s.split('\n').map(line => line.replace(/[ \t]+\n?$/g, '')).join('\n');

  const collapseBlank = (s: string) => {
    const max = Math.max(0, options.maxConsecutiveBlankLines);
    if (max === 0) return s.replace(/\n+/g, '\n');
    const re = new RegExp(`(?:\\n\\s*){${max + 1},}`, 'g');
    return s.replace(re, '\n'.repeat(max));
  };

  const ctx = {
    olDepthCounters: [] as number[],
    footnotes: [] as string[],
    indent: 0,
  };

  const BLOCKS = new Set([
    'address','article','aside','blockquote','canvas','dd','div','dl','dt','fieldset',
    'figcaption','figure','footer','form','h1','h2','h3','h4','h5','h6','header',
    'hgroup','hr','li','main','nav','noscript','ol','p','pre','section','table','tfoot','ul','tr'
  ]);

  const indentPrefix = () => '  '.repeat(ctx.indent);

  function serialize(node: Node): string {
    if (node.nodeType === Node.TEXT_NODE) {
      return decode((node as Text).data.replace(/\u00a0/g, ' ')).replace(/\s+/g, ' ');
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return '';

    const el = node as HTMLElement;
    const tag = el.tagName.toLowerCase();

    if (tag === 'br') return '\n';
    if (tag === 'hr') return '\n' + '-'.repeat(40) + '\n';

    if (tag === 'code') {
      if (el.parentElement?.tagName.toLowerCase() === 'pre') {
        return el.textContent || '';
      }
      return '`' + (el.textContent || '').replace(/\s+/g, ' ').trim() + '`';
    }

    if (tag === 'pre') {
      const txt = el.textContent || '';
      return '\n' + txt.replace(/\r\n?/g, '\n') + '\n';
    }

    if (tag === 'blockquote') {
      const inner = Array.from(el.childNodes).map(serialize).join('');
      const clean = trimLines(inner.trim());
      const quoted = clean.split('\n').map(l => `> ${l}`).join('\n');
      return '\n' + quoted + '\n';
    }

    if (tag === 'a') {
      const text = (el.textContent || '').trim();
      const href = (el.getAttribute('href') || '').trim();
      if (options.linkStyle === 'remove' || !href) return text;
      if (options.linkStyle === 'footnote') {
        const idx = ctx.footnotes.push(href);
        return text ? `${text} [${idx}]` : `[${idx}]`;
      }
      if (!text) return href;
      return text === href ? href : `${text} (${href})`;
    }

    if (tag === 'img') {
      if (options.imageStyle === 'remove') return '';
      const alt = (el.getAttribute('alt') || '').trim();
      if (options.imageStyle === 'keep') {
        const src = (el.getAttribute('src') || '').trim();
        return `[IMG${alt ? `: ${alt}` : ''}${src ? ` | ${src}` : ''}]`;
      }
      return alt ? `[IMG: ${alt}]` : '[IMG]';
    }

    if (tag === 'ul' || tag === 'ol') {
      ctx.indent++;
      if (tag === 'ol') ctx.olDepthCounters[ctx.indent] = 1;

      const items = Array.from(el.children)
        .filter(c => c.tagName?.toLowerCase() === 'li')
        .map(li => {
          let prefix: string;
          if (tag === 'ul') prefix = '• ';
          else {
            const n = ctx.olDepthCounters[ctx.indent]++;
            prefix = `${n}. `;
          }
          const content = Array.from(li.childNodes).map(serialize).join('').trim();
          return indentPrefix() + prefix + content.replace(/\n/g, '\n' + indentPrefix() + '   ');
        });

      ctx.indent--;
      return '\n' + items.join('\n') + '\n';
    }

    if (tag === 'table') {
      const rows = Array.from(el.querySelectorAll('tr')).map(tr =>
        Array.from(tr.children).map(td =>
          trimLines(serialize(td).trim().replace(/\n+/g, ' '))
        )
      );

      if (options.tableStyle === 'markdown') {
        if (!rows.length) return '\n';
        const header = rows[0];
        const sep = header.map(() => '---');
        const md = [header.join(' | '), sep.join(' | ')]
          .concat(rows.slice(1).map(r => r.join(' | ')))
          .join('\n');
        return '\n' + md + '\n';
      }

      if (options.tableStyle === 'lines') {
        const lines = rows.map(r => r.join(' | ')).join('\n');
        return '\n' + lines + '\n';
      }

      const tsv = rows.map(r => r.join('\t')).join('\n');
      return '\n' + tsv + '\n';
    }

    if (/^h[1-6]$/.test(tag)) {
      let txt = Array.from(el.childNodes).map(serialize).join('').trim();
      if (options.headingUppercase) txt = txt.toUpperCase();
      return '\n' + txt + '\n';
    }

    if (tag === 'p' || tag === 'div') {
      const inner = Array.from(el.childNodes).map(serialize).join('');
      const text = inner.trim();
      if (!text) return '\n';
      return '\n' + text + '\n';
    }

    const content = Array.from(el.childNodes).map(serialize).join('');
    if (BLOCKS.has(tag)) return '\n' + content.trim() + '\n';
    return content;
  }

  let out = Array.from(root.childNodes).map(serialize).join('');
  out = out.replace(/\r\n?/g, '\n');
  out = trimLines(out);
  out = collapseBlank(out);
  out = out.trim();

  if (options.linkStyle === 'footnote' && ctx.footnotes.length) {
    const notes = ctx.footnotes.map((href, i) => `[${i + 1}] ${href}`).join('\n');
    out += `\n\n${notes}`;
  }

  return out;
}

/** 컴포저블: 기본 옵션 주입해 두고 호출할 수 있게 반환 */
export function useHtmlToText(defaults: HtmlToTextOptions = {}) {
  const htmlToText = (html: string, opts?: HtmlToTextOptions) =>
    _convertHtmlToText(html, { ...defaults, ...opts });
  return { htmlToText };
}

export const convertHtmlToText = _convertHtmlToText;
