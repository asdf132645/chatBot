
export const nowIso = () => new Date().toISOString();

export const stripExt = (name = '') => name.replace(/\.[^.]+$/, '');

export const getFileIconName = (fileType) => {
  const typeMap = {
    'application/pdf': 'PDF',
    'image/jpeg': 'Image',
    'image/png': 'Image',
    'text/plain': 'Text',
    'application/msword': 'Doc',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'Doc',
    'application/vnd.ms-excel': 'Excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'Excel',
  };
  return typeMap[fileType] || 'File';
};

export function formatDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}
