export function usePromptClipboard({ t, queryInputerRef } = {}) {
  async function copyToClipboard(text = '') {
    try {
      if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch (err) {
      console.warn(t ? t('answerwrapper.answerwrapper_key16') : '클립보드 복사 실패', err);
    }

    try {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.style.position = 'fixed';
      textarea.style.left = '-9999px';
      document.body.appendChild(textarea);
      textarea.focus();
      textarea.select();
      const ok = document.execCommand('copy');
      document.body.removeChild(textarea);
      return ok;
    } catch (err) {
      console.warn(t ? t('answerwrapper.answerwrapper_key17') : '클립보드 복사(대체 경로) 실패', err);
      return false;
    }
  }

  async function applyPrompt(text = '', { close } = {}) {
    if (queryInputerRef?.value?.setQuery) {
      queryInputerRef.value.setQuery(text);
    }
    await copyToClipboard(text);
    if (typeof close === 'function') close();
  }

  return { copyToClipboard, applyPrompt };
}
