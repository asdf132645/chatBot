import { ref } from 'vue'
import { v4 as uuidv4 } from 'uuid'
import { getFileIconName } from './chatUtils'

export function useFileDragUpload() {
  const isDragging = ref(false)
  const showFileList = ref(false)
  const fileListArray = ref<any[]>([])

  const handleDragOver = () => {
    isDragging.value = true
  }

  const handleDragLeave = () => {
    isDragging.value = false
  }

  const handleDrop = (event: DragEvent) => {
    isDragging.value = false
    const files = Array.from(event.dataTransfer?.files || []).map(file => ({
      id: uuidv4(),
      name: file.name,
      size: file.size,
      type: file.type,
      file,
      status: 'ready',
      fileType: getFileIconName(file.type)
    }))
    fileListArray.value = [files[files.length - 1]]
    showFileList.value = true
  }

  const handleFileUpload = (newFiles: any[]) => {
    fileListArray.value = [newFiles[newFiles.length - 1]]
    showFileList.value = true
  }

  const deleteFile = (fileId: string) => {
    fileListArray.value = fileListArray.value.filter(file => file.id !== fileId)
    if (fileListArray.value.length === 0) showFileList.value = false
  }

  return {
    isDragging,
    showFileList,
    fileListArray,
    handleDragOver,
    handleDragLeave,
    handleDrop,
    handleFileUpload,
    deleteFile,
  }
}
