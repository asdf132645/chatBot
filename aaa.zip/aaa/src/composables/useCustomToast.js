import { ref } from 'vue'

// 전역 토스트 상태 관리
const toasts = ref([])
let toastId = 0

export function useCustomToast() {
  const showToast = (message, options = {}) => {
    const id = ++toastId
    const toast = {
      id,
      message,
      type: options.type || 'info',
      showCloseButton: options.showCloseButton !== false,
      autoClose: options.autoClose || true,
      duration: options.duration || 2000
    }
    
    toasts.value.push(toast)
    
    // autoClose가 true인 경우 자동으로 제거
    if (toast.autoClose) {
      setTimeout(() => {
        removeToast(id)
      }, toast.duration)
    }
    
    return id
  }
  
  const removeToast = (id) => {
    const index = toasts.value.findIndex(toast => toast.id === id)
    if (index > -1) {
      toasts.value.splice(index, 1)
    }
  }
  
  const clearAllToasts = () => {
    toasts.value = []
  }
  
  // 편의 메서드들
  const success = (message, options = {}) => {
    return showToast(message, { ...options, type: 'success' })
  }
  
  const error = (message, options = {}) => {
    return showToast(message, { ...options, type: 'error' })
  }
  
  const warning = (message, options = {}) => {
    return showToast(message, { ...options, type: 'warning' })
  }
  
  const info = (message, options = {}) => {
    return showToast(message, { ...options, type: 'info' })
  }
  
  return {
    toasts,
    showToast,
    removeToast,
    clearAllToasts,
    success,
    error,
    warning,
    info
  }
}
