import { ref, computed } from 'vue'

/**
 * toggleState 기능을 위한 독립적인 composable
 * 상태 토글 기능을 재사용 가능하게 분리
 */
export function useToggleState(initialStates = [], externalStateRef = null) {
  // 상태 배열 관리
  const states = ref(initialStates.map(state => ({
    ...state,
    isStateOpen: state.isStateOpen || false
  })))

  // 특정 인덱스의 상태 토글 (외부 상태 참조 우선)
  const toggleState = (index) => {
    if (externalStateRef && externalStateRef.value && externalStateRef.value[index]) {
      // 외부 상태 직접 수정
      externalStateRef.value[index].isStateOpen = !externalStateRef.value[index].isStateOpen
    } else if (states.value[index]) {
      // 내부 상태 수정
      states.value[index].isStateOpen = !states.value[index].isStateOpen
    }
  }

  // 특정 인덱스의 상태 설정
  const setState = (index, isOpen) => {
    if (states.value[index]) {
      states.value[index].isStateOpen = isOpen
    }
  }

  // 모든 상태를 열기
  const openAllStates = () => {
    states.value.forEach(state => {
      state.isStateOpen = true
    })
  }

  // 모든 상태를 닫기
  const closeAllStates = () => {
    states.value.forEach(state => {
      state.isStateOpen = false
    })
  }

  // 특정 인덱스의 상태 가져오기
  const getState = (index) => {
    return states.value[index]?.isStateOpen || false
  }

  // 상태 배열 업데이트
  const updateStates = (newStates) => {
    states.value = newStates.map(state => ({
      ...state,
      isStateOpen: state.isStateOpen || false
    }))
  }

  // 상태 추가
  const addState = (state) => {
    states.value.push({
      ...state,
      isStateOpen: state.isStateOpen || false
    })
  }

  // 상태 제거
  const removeState = (index) => {
    if (index >= 0 && index < states.value.length) {
      states.value.splice(index, 1)
    }
  }

  // 열린 상태 개수
  const openStatesCount = computed(() => 
    states.value.filter(state => state.isStateOpen).length
  )

  // 닫힌 상태 개수
  const closedStatesCount = computed(() => 
    states.value.filter(state => !state.isStateOpen).length
  )

  // 모든 상태가 열려있는지 확인
  const isAllOpen = computed(() => 
    states.value.length > 0 && states.value.every(state => state.isStateOpen)
  )

  // 모든 상태가 닫혀있는지 확인
  const isAllClosed = computed(() => 
    states.value.length > 0 && states.value.every(state => !state.isStateOpen)
  )

  return {
    // 상태
    states,
    
    // 메서드
    toggleState,
    setState,
    openAllStates,
    closeAllStates,
    getState,
    updateStates,
    addState,
    removeState,
    
    // computed
    openStatesCount,
    closedStatesCount,
    isAllOpen,
    isAllClosed
  }
}
