// 에디터 전용 마크다운 재정의
import * as mk from 'marked';

const marked = mk.marked || mk; // v5+ (ESM) 또는 구버전(CJS) 모두 커버용으로 변경함
const RendererCtor = mk.Renderer || (marked && marked.Renderer) || null;

/** 서버가 따옴표/이스케이프 형태로 오는 경우 복원 */
export function decodeMaybeEscaped(s) {
  if (typeof s !== 'string') return '';
  let t = s.trim();
  try {
    // 양끝 따옴표 + 이스케이프 흔적이 보이면 JSON.parse 로 복원
    if ((t.startsWith('"') && t.endsWith('"')) || /\\[nrt"\\]/.test(t)) {
      t = JSON.parse(t);
    }
  } catch { /* noop */
  }
  // 혼재 개행 보정
  return t.replace(/\\r\\n/g, '\n').replace(/\\n/g, '\n').replace(/\r\n/g, '\n');
}

/** 간단한 HTML 판별 */
export function isHtml(str) {
  if (!str) return false;
  return /^\s*<\/?[a-z][\s\S]*>/i.test(str);
}

/** 리스트/헤딩 사이 간격 보정 */
function ensureListAndHeadingSpacing(src) {
  let s = src.replace(/\r\n?/g, '\n');

  // 리스트 앞에 문단이 붙은 경우만 빈 줄 추가
  s = s.replace(/([^\n])\n(?=(- |\* |\+ |\d+\. ))/g, '$1\n\n');

  // 헤딩 앞에 문단이 붙은 경우만 빈 줄 추가
  s = s.replace(/([^\n])\n(#{1,6}\s)/g, '$1\n\n$2');

  return s;
}


/** 코드펜스 짝수 보정 */
function balanceCodeFences(src) {
  const count = (src.match(/```/g) || []).length;
  return (count % 2 === 1) ? (src + '\n```') : src;
}

/** MD 본문 정규화(코드펜스 제외 구간만 보정) */
export function normalizeMd(md) {
  const FENCE = '```';
  const chunks = String(md).split(FENCE);
  for (let i = 0; i < chunks.length; i += 2) {
    chunks[i] = ensureListAndHeadingSpacing(chunks[i]);
  }
  return balanceCodeFences(chunks.join(FENCE));
}

/** 안전하게 Markdown→HTML */
export function renderMdToHtml(mdOrMaybeEscaped) {
  const raw = decodeMaybeEscaped(mdOrMaybeEscaped);

  // 이미 HTML이면 그대로 통과
  if (isHtml(raw)) return raw;

  const prepped = normalizeMd(raw);

  //  Renderer가 없는 환경도 허용 (옵셔널)
  const renderer = RendererCtor ? new RendererCtor() : undefined;

  // 기본 옵션
  if (marked.setOptions) {
    marked.setOptions({
      ...(renderer ? { renderer } : {}),
      gfm: true,
      breaks: false,
      headerIds: false,
      smartLists: true,
      smartypants: false,
      mangle: false,
      tables: true,
      pedantic: false,
    });
  }

  // v5+: marked.parse, 구버전: 함수 호출 둘 다 케이스 커버
  const parse = marked.parse || marked;
  return parse(prepped);
}

function flattenReferenceListPattern(body) {
  const isInlineTag = (el) => {
    if (!el || el.nodeType !== 1) return false;
    return /^(A|ABBR|B|BDI|BDO|BR|CITE|CODE|DATA|DFN|EM|I|IMG|KBD|LABEL|MARK|Q|RB|RP|RT|RTC|RUBY|S|SAMP|SMALL|SPAN|STRONG|SUB|SUP|TIME|U|VAR|WBR)$/i.test(el.tagName);
  };
  const isMeaningfulText = (n) => n && n.nodeType === 3 && !!(n.nodeValue || '').trim();

  const listNodes = Array.from(body.querySelectorAll('ul, ol'));
  listNodes.forEach((list) => {
    const liItems = Array.from(list.children).filter((el) => el.tagName === 'LI');

    liItems.forEach((li) => {
      const kids = Array.from(li.childNodes); // 텍스트 노드 포함
      if (!kids.length) return;

      // li 직계에서 첫 서브리스트 위치 찾기
      const subIdx = kids.findIndex((n) => n.nodeType === 1 && (/^(UL|OL)$/i).test(n.tagName || ''));
      if (subIdx === -1) return;
      const sub = kids[subIdx];

      // 서브리스트 앞의 리드 노드들 (텍스트/인라인만 허용)
      const leadNodes = kids.slice(0, subIdx);
      if (!leadNodes.length) return;

      // 리드 노드가 모두 "의미 있는 텍스트 또는 인라인 엘리먼트" 인지 검사
      const invalidLead = leadNodes.some((n) => {
        if (n.nodeType === 3) return false; // 텍스트는 허용(공백은 아래에서 걸러짐)
        if (n.nodeType === 1) return !(isInlineTag(n)); // 블록 엘리먼트면 실패
        return true; // 코멘트 등은 실패로 간주
      });
      if (invalidLead) return;

      // 리드 노드에 의미있는 내용이 하나도 없으면 스킵
      const hasMeaning = leadNodes.some((n) => (n.nodeType === 3 ? isMeaningfulText(n) : true));
      if (!hasMeaning) return;

      const parent = list.parentNode;
      if (!parent) return;

      // 리드 노드를 <p>로 감싸서 리스트 바깥으로 승격
      const p = body.ownerDocument.createElement('p');
      leadNodes.forEach((n) => p.appendChild(n)); // 원본 이동
      parent.insertBefore(p, list);

      // 이 리스트에 LI가 하나뿐이면 바깥 리스트를 서브리스트로 교체
      if (liItems.length === 1) {
        parent.replaceChild(sub, list); // 서브리스트를 리스트 자리로 올림 (원본 이동)
        return;
      }

      // 여러 LI가 있으면: 서브리스트의 LI들을 부모 리스트로 끌어올리고 현재 LI 제거
      const subLis = Array.from(sub.children).filter((el) => el.tagName === 'LI');
      subLis.forEach((subLi) => list.insertBefore(subLi, li));
      sub.remove();
      li.remove();
    });
  });
}