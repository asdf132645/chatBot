// 파일 다운로드 공용 컴포저블 (UTF-8 BOM/개행 옵션 지원)
export function useDownloader() {
  function downloadBlob(filename: string, blob: Blob) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  /** text → .txt 파일 다운로드
   *  - bom: true면 UTF-8 BOM 붙여서 메모장(Windows) 한글 깨짐 방지
   *  - eol: 'LF' | 'CRLF' (윈도우 호환이면 'CRLF' 추천)
   */
  function downloadTextFile(
    filename: string,
    text: string,
    { bom = true, eol = 'CRLF' as 'LF' | 'CRLF' } = {}
  ) {
    let payload = text ?? '';
    if (eol === 'CRLF') payload = payload.replace(/\r?\n/g, '\r\n');

    const utf8 = new TextEncoder().encode(payload);
    let data = utf8;

    if (bom) {
      const BOM = new Uint8Array([0xef, 0xbb, 0xbf]);
      const merged = new Uint8Array(BOM.length + utf8.length);
      merged.set(BOM, 0);
      merged.set(utf8, BOM.length);
      data = merged;
    }

    const blob = new Blob([data], { type: 'text/plain;charset=utf-8' });
    downloadBlob(filename, blob);
  }

  return { downloadBlob, downloadTextFile };
}
