<template>
  <div class="restricted-access">
    <div class="card">
<!--      <img class="limit-icon" :src="require('@/assets/images/LimitsIcon.png')" />-->
      <h1 class="title">서비스 이용 권한이 필요합니다.</h1>
      <p class="message">
        <span class="gray-text-access" >
          접근이 제한된 URL입니다. 요청하신 URL에 대한 접근 권한이 없습니다.<br>
          해당 서비스를 이용하시려면 ________ 에서 사용 설정을 해주셔야 합니다.<br>
          자세한 내용은 관리자에게 문의하시기 바랍니다.</span>
      </p>
      <!-- <button class="access-btn" @click="currentOrigin()">바로가기</button> -->
    </div>
  </div>
</template>
<script setup>
// const currentOrigin = () => {
//   const { protocol, hostname } = window.location
//   const base = protocol + '//'
//   const map = {
//     'local.opsnow.com': `${base}local.opsnow.com:8091`,
//     'bb8-plex-front-dev.dev.helpnow.ai': `${base}krdev.helpnow.ai`,
//     'bb8-plex-front-sandbox.dev.helpnow.ai': `${base}bb8-front-sandbox.dev.helpnow.ai`,
//     'plex-front.helpnow.ai': `${base}poc.helpnow.ai`
//   }
//   // 이동
//   window.location.href = map[hostname] || `${base}kr.helpnow.ai`
// }
</script>
<style scoped>


.card {
  padding: 2rem;
  border-radius: 8px;
  max-width: 500px;
  text-align: center;
}

.title {
  font-size: 1.5rem;
  margin-bottom: 1rem;
  font-weight: bold;
  color: #333333;
}

.message {
  font-size: 0.9rem;
  color: #6961f2;
  line-height: 1.5;
}

</style>
