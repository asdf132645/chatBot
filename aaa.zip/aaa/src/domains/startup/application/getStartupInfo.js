import { startupApi } from '../infrastructure/startupApi'

/**
 * 가공 해야하는 API 들은 해당 파일처럼 분리해서 작업 진행 컴포넌트에는 UI 직접 조작 하는 부분만 생성
 * */

export function usePlexInfo() {

  const plexInfo = async (agentCode) => {
    try {
      const res = await startupApi.getPlexInfo(agentCode);
      return res.data;
    } catch (err) {
      console.error('플렉스 인포 불러오기 실패:', err)
    }
  }

  return {
    plexInfo
  }
}
