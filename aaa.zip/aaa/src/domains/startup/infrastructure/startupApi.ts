// src/domains/prompt/infrastructure/promptApi.ts
import { httpClient } from '@/shared/http/httpClient'
import { SERVER_URL } from '@/shared/config/endpoints'

export const startupApi = {

  // 헬프나우 콘솔 외부 채널 연동에서 셋팅한 값 가지고 오는 API
  async getPlexInfo(agentCode: string) {
    return httpClient.get(`${SERVER_URL}plex-info/${agentCode}`, { excludeToken: true })
  },
  // 헬프나우 콘솔 외부 채널 연동에서 셋팅한 값 가지고 오는 API 에서 받은 이미지 로고 응답값을 이미지 전환 시키는 API
  async getPlexImg(chatbotCode: string, imageName: string) {
    return `${SERVER_URL}plex-img/${chatbotCode}/${encodeURIComponent(imageName)}`
  }
}
