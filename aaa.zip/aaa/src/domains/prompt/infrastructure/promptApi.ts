import { httpClient } from '@/shared/http/httpClient'
import { GENAI_SERVER_URL } from '@/shared/config/endpoints'

export const promptApi = {
  // 헬프나우 콘솔에서 지식센터 -> gen ai 테스트 메뉴 -> 사용자 프롬프트 관리에서 등록한 프롬프트 리스트를 가지고오는 함수입니다. 동작 하는 부분은 usePrompt 쪽에서 하고있습니다  -> 전체 검색 usePrompt 하면 나옵니다.
  async getUserPrompts(agentCode: string, page: number = 1, category?: string) {
    return httpClient.get(`${GENAI_SERVER_URL}/agent-code/${agentCode}/prompt`, {
      params: {
        prompt_type: 'user',
        page, // API는 1부터 시작
        per_page: 9,
        ...(category ? { category } : {})
      }
    })
  },
  // 프롬프트 갤러리 팝업창에서 카테고리 부분을 호출해오는 함수 입니다. 동작은 usePrompt 쪽에서 하고있습니다 -> 전체 검색 usePrompt 하면 나옵니다.
  async getUserCategories(agentCode: string) {
    return httpClient.get(`${GENAI_SERVER_URL}/agent-code/${agentCode}/prompt/categories`)
  }
}
