<template>
  <div class="prompt-gallery-wrapper" ref="scrollBox">
    
    <!-- 카테고리 필터 -->
    <div class="custom-control row-inline-style" v-if="categories.length">
      <div class="custom-label">{{ $t('userpromptgallery.userpromptgallery_key2') }}</div>
      <button class="btn btn-select border" @click.stop="toggleCategoryDrop($event)">
        {{ selectedCategory || '전체' }}
        <BaseIcon name="ArrowFullDown" :size="16" />
      </button>      
    </div>

    <!-- 프롬프트 리스트 -->
    <div class="prompt-gallery-card-wrapper" v-if="prompts.length">
      <div class="prompt-gallery-card-list custom-card-list">
        <div
          v-for="item in prompts"
          :key="item.id"
          class="prompt-gallery-card card-item"
          @click="handleSelectedPrompt(item.prompt_name)"
        >
          <div class="card-header">
            <div class="card-icon">
              <div class="card-icon-badge-wrapper">
                <div class="card-pin-badge" v-if="item.is_pinned">
                  <BaseIcon :size="14" name="Pin" />
                </div>
              </div>
              <BaseIcon :size="20" name="Paper" />
            </div>
          </div>
          <div class="card-body">
            <h3 class="card-title">{{ item.prompt_name }}</h3>
            <div class="card-desc">{{ item.prompt }}</div>
          </div>
        </div>
      </div>
      <div v-if="loading" class="loading-indicator">{{ $t('userpromptgallery.userpromptgallery_key4') }}</div>
      <div class="dumi"></div>
      <div ref="bottomRef" style="height: 40px;" />
    </div>

    <div v-if="!prompts.length && !loading" class="empty-state">
      {{ $t('userpromptgallery.userpromptgallery_key5') }}
    </div>

    <DropDown
      :width="154"
      :isOpenDrop="isOpenDrop"
      :top="driveDropPosition.y + 20"
      :left="driveDropPosition.x - 50"
      @close="isOpenDrop = false"
      dropdownName="prompt-gallery-menu-wrapper"
    >
      <template #content>
        <ul>
          <li v-for="category in categories" :key="category">
            <button class="nav-btn" @click.stop="handleCategoryChange(category)">
              {{ category }}
            </button>
          </li>
        </ul>
      </template>
    </DropDown>
  </div>      
    
</template>

<script setup>
import DropDown from '@/component/DropDown.vue';
import BaseIcon from '@/component/BaseIcon.vue';

import {
  ref,
  nextTick,
  onBeforeUnmount,
  defineProps,
  defineEmits,
  onMounted
} from 'vue'
import { usePrompt } from '@/domains/prompt/application/usePrompt';

const props = defineProps({
  chatbotCode: { type: String, required: true }
})
const emit = defineEmits(['select'])

const { prompts, pageInfo, fetchUserPrompts, getUserCategories } = usePrompt()

const scrollBox = ref(null)
const bottomRef = ref(null)
const currentPage = ref(1)
const loading = ref(false)
const categories = ref([])
const selectedCategory = ref('')
const isOpenDrop = ref(false)
const driveDropPosition = ref({ x: 0, y: 0 })
let observer = null

function toggleCategoryDrop(event) {
  driveDropPosition.value.x = event.clientX;
  driveDropPosition.value.y = event.clientY - 20;
  isOpenDrop.value = !isOpenDrop.value;
}


async function loadPrompts(page = currentPage.value) {
  if (loading.value) return
  loading.value = true
  await fetchUserPrompts(props.chatbotCode, page, selectedCategory.value || undefined)
  loading.value = false
}

function handleSelectedPrompt(prompt) {
  emit('select', prompt)
}

/**
 * 카테고리 변경 시 체인지 이벤트
 * **/
async function handleCategoryChange(category) {
  isOpenDrop.value = false; 
  selectedCategory.value = category === '전체' ? '' : category
  currentPage.value = 1;
  prompts.value = [];
  observer?.disconnect();
  scrollBox.value?.scrollTo(0, 0);

  await loadPrompts();
  await nextTick();
  setupObserver();
}

/**
 * IntersectionObserver 생성 후 bottomRef에 스크롤이 감지 될 경우 프롬프트 내용 재 호출
 * **/
function setupObserver() {
  if (!scrollBox.value || !bottomRef.value) return

  if (observer) observer.disconnect()

  observer = new IntersectionObserver(async ([entry]) => {
    if (entry.isIntersecting && pageInfo.value?.has_next && !loading.value) {
      const nextPage = currentPage.value + 1
      currentPage.value = nextPage
      await loadPrompts(nextPage)
    }
  }, {
    root: scrollBox.value,
    threshold: 0.1
  })
  observer.observe(bottomRef.value)
}


// // 첫 진입 시 호출 하는 부분
// watch(() => isOpenDrop.value, async (val) => {
//   if (!val) {
//     if (observer) observer.disconnect()
//     return
//   }

//   currentPage.value = 1
//   prompts.value = []
//   selectedCategory.value = ''
//   categories.value = (await getUserCategories(props.chatbotCode)) || []
//   categories.value.unshift('전체'); 
//   await loadPrompts()
//   await nextTick()
//   setupObserver()
// })



onMounted(async () => {
  if (!props.chatbotCode) {
    if (observer) observer.disconnect()
    return
  }

  currentPage.value = 1
  prompts.value = []
  selectedCategory.value = ''
  categories.value = (await getUserCategories(props.chatbotCode)) || []
  categories.value.unshift('전체'); 
  await loadPrompts()
  await nextTick()
  setupObserver()
})

onBeforeUnmount(() => {
  if (observer) observer.disconnect()
})
</script>
