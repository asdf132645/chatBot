import { ref } from 'vue'
import { promptApi } from '../infrastructure/promptApi'

const prompts = ref([])
const pageInfo = ref({
  current_page: 1,
  total_pages: 0,
  has_next: false,
  has_prev: false
})

export function usePrompt() {
  const fetchUserPrompts = async (agentCode, page, category) => {
    try {
      const res = await promptApi.getUserPrompts(agentCode, page, category)

      if (page === 1) {
        prompts.value = res.data.prompts
      } else {
        prompts.value = [...prompts.value, ...res.data.prompts]
      }

      pageInfo.value = res.data.page_info
      return res.data
    } catch (err) {
      console.error('프롬프트 목록 불러오기 실패:', err)
    }
  }

  const getUserCategories = async (agentCode) => {
    try {
      const res = await promptApi.getUserCategories(agentCode)
      return res.data.categories
    } catch (err) {
      console.error('카테고리 불러오기 실패:', err)
    }
  }

  return {
    prompts,
    pageInfo,
    fetchUserPrompts,
    getUserCategories
  }
}
