export function toNFC(s) {
  return (s || '').normalize('NFC');
}

// 업로드 직전
// const normalizedName = toNFC(file.name);
// payload.filename = normalizedName
