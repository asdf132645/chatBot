import axios from 'axios';

import {
  // ragEditorSseUrl,
  // ragRouterUrl
} from '../../../shared/config/endpoints'

import { CHATBOT_PLEX_SERVER_URL, RAG_SERVER_URL } from '../../../shared/config/endpoints';
// const CHATBOT_PLEX_SERVER_URL = 'http://localhost:8888';

/**
 * TXT 업로드 (FormData)
 * - 서버 엔드포인트는 상황에 맞게 교체 (예: //docs/upload-txt)
 * - 서버에서 session_id/agent_id 받아서 문서 저장하도록 구현되어 있어야 함
 */
export async function uploadDocTxt({ sessionId, filename, content, agentCode, email, userNm }) {
  const form = new FormData();
  const blob = new Blob([content || ''], { type: 'text/plain;charset=utf-8' });

  form.append('file', blob, filename);
  form.append('session_id', sessionId);
  form.append('category', 'myDrive');
  if (agentCode) form.append('agent_id', agentCode);
  if (email) form.append('author_id', email);
  if (userNm) form.append('author_name', userNm);
  // 필요 시 추가 메타데이터
  // form.append('doc_type', 'txt');
  
  const url = '/documents/upload';

  const { data } = await axios.post(`${CHATBOT_PLEX_SERVER_URL}${url}`, form, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return data;
}

/**
 * 문서 목록 조회
 * @param {Object} params - 조회 파라미터
 * @param {number} params.page - 페이지 번호 (0부터 시작, 기본값: 0)
 * @param {number} params.size - 페이지 크기 (기본값: 10)
 * @param {string} params.extension - 파일 확장자로 검색
 * @param {string} params.authorName - 작성자 이름으로 검색
 * @param {string} params.title - 제목으로 검색
 * @returns {Promise<Object>} 문서 목록 페이지 정보
 */
export async function getDocumentsList({ 
  page = 0, 
  size = 100, 
  extension, 
  authorName, 
  title,
  keyword,
  category,
  deleted,
  searchType,
  searchValue,
}) {
  
  const url = deleted ? '/documents/deleted' : '/documents/active';
  
  // URL 파라미터 구성
  const params = new URLSearchParams();
  params.append('page', page.toString());
  params.append('size', size.toString());
  
  // 검색 조건이 있는 경우 추가
  if (extension) params.append('extension', extension);
  if (authorName) params.append('author_name', authorName);
  if (title) params.append('title', title);
  if (keyword) params.append('keyword', keyword);
  if (category) params.append('category', category);

  // searchType 은 file, date, author 중 하나, searchValue 는 검색 값
  if (searchType) {
    if (searchType === 'file') {
      params.append('extension', searchValue);
    } else if (searchType === 'date') {
      if (searchValue === 'today') {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        params.append('updated_at', today.toISOString());
      } else if (searchValue === '7days') {
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        sevenDaysAgo.setHours(0, 0, 0, 0);
        params.append('updated_at', sevenDaysAgo.toISOString());
      } else if (searchValue === '30days') {
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        thirtyDaysAgo.setHours(0, 0, 0, 0);
        params.append('updated_at', thirtyDaysAgo.toISOString());
      }
    } else if (searchType === 'author') {
      // category 기준으로 
      // myDrive, companyDrive, departmentDrive 중 하나
      // if (searchValue === 'me') {
      //   params.append('category', 'myDrive');
      // } else if (searchValue === 'department') {
      //   params.append('category', 'departmentDrive');
      // } else if (searchValue === 'company') {
      //   params.append('category', 'companyDrive');
      // }

      params.append('author', searchValue);
    }
  }
  const fullUrl = `${CHATBOT_PLEX_SERVER_URL}${url}?${params.toString()}`;

  try {
    const { data } = await axios.get(fullUrl);
    return data;
  } catch (error) {
    console.error('문서 목록 조회 중 오류 발생:', error);
    throw error;
  }
}

export async function getIntegratedDocumentsList({
  keyword,
  category,
  agentCode,
  directoryId,
  documentStatus,
  directoryStatus,
  searchType,
  searchValue,
  sortBy,
  sortDirection,
}) {

  const url = `/integrated`;
  
  // 기본 파라미터 설정 - null 값은 undefined로 설정
  const params = {
    keyword: keyword || undefined,
    title: undefined,
    author: undefined,
    authorId: undefined,
    category: category === 'home' ? 'myDrive' : category,
    agentCode: agentCode,
    directoryId: directoryId || undefined,
    documentStatus: documentStatus || 'ACTIVE',
    directoryStatus: directoryStatus || 'ACTIVE',
    documentExtension: undefined,
    directoryExtension: undefined,
    createdAtFrom: undefined,
    createdAtTo: undefined,
    updatedAtFrom: undefined,
    updatedAtTo: undefined,
    sortBy: sortBy || 'createdAt',
    sortDirection: sortDirection || 'DESC',
    searchType: searchType || 'ALL',
    searchValue: searchValue || undefined,
  };

  // searchType과 searchValue에 따른 파라미터 전처리
  if (searchType && searchValue) {
    if (searchType === 'file') {
      // 파일 확장자 검색은 문서에만 적용
      params.documentExtension = searchValue;
      // 디렉토리는 확장자가 없으므로 제거
      params.directoryExtension = searchValue;
    } else if (searchType === 'date') {
      if (searchValue === 'today') {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        params.updatedAtFrom = today.toISOString();
        params.updatedAtTo = new Date().toISOString();
      } else if (searchValue === '7days') {
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        sevenDaysAgo.setHours(0, 0, 0, 0);
        params.updatedAtFrom = sevenDaysAgo.toISOString();
        params.updatedAtTo = new Date().toISOString();
      } else if (searchValue === '30days') {
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        thirtyDaysAgo.setHours(0, 0, 0, 0);
        params.updatedAtFrom = thirtyDaysAgo.toISOString();
        params.updatedAtTo = new Date().toISOString();
      }
    } else if (searchType === 'author') {
      if (searchValue === 'me') {
        params.category = 'myDrive';
      } else if (searchValue === 'department') {
        params.category = 'departmentDrive';
      } else if (searchValue === 'company') {
        params.category = 'companyDrive';
      }
    }
  }

  // undefined 값들을 제거하여 실제 값이 있는 파라미터만 전송
  const cleanParams = Object.fromEntries(
    Object.entries(params).filter(([, value]) => value !== undefined)
  );

  try {
    const { data } = await axios.post(`${CHATBOT_PLEX_SERVER_URL}${url}`, cleanParams);
    return data;
  } catch (error) {
    console.error('문서 및 디렉토리 통합 조회 중 오류 발생:', error);
    throw error;
  }
}


/**
 * 문서 정보 업데이트 (타이틀 수정)
 * @param {string} documentKey - 업데이트할 문서 키값
 * @param {Object} document - 업데이트할 문서 정보
 * @param {string} document.title - 문서 제목
 * @returns {Promise<Object>} 업데이트된 문서 정보
 */
export async function updateDocument(documentKey, document) {
  const url = `/documents/${documentKey}`;
  
  try {
    const { data } = await axios.put(`${CHATBOT_PLEX_SERVER_URL}${url}`, document, {
      headers: { 'Content-Type': 'application/json' },
    });
    return data;
  } catch (error) {
    console.error('문서 정보 업데이트 중 오류 발생:', error);
    throw error;
  }
}

/**
 * 단일 문서 삭제
 * @param {string} documentKey - 삭제할 문서 키값
 * @returns {Promise<void>} 삭제 결과
 */
export async function deleteDocument(documentKey) {
  const url = `/documents/${documentKey}/soft-delete`;
  
  try {
    await axios.put(`${CHATBOT_PLEX_SERVER_URL}${url}`);
  } catch (error) {
    console.error('문서 삭제 중 오류 발생:', error);
    throw error;
  }
}

/**
 * 단일 문서 삭제 (물리적 삭제)
 * @param {string} documentKey - 삭제할 문서 키값 hardDeleteDocument('key1');
 * @returns {Promise<void>} 삭제 결과
 */
export async function hardDeleteDocument(documentKey) {
  const url = `/documents/${documentKey}`;
  try {
    const response = await axios.delete(`${CHATBOT_PLEX_SERVER_URL}${url}`);
    return response;
  } catch (error) {
    console.error('문서 완전 삭제 중 오류 발생:', error);
    throw error;
  }
}

/**
 * 다중 문서 삭제 (물리적 삭제)
 * @param {Array<string>} documentKeys - 삭제할 문서 키값 배열 hardDeleteDocumentsBatch(['key1', 'key2', 'key3']); 배열로 삭제할 문서 키값 전달
 * @returns {Promise<void>} 삭제 결과
 */
export async function hardDeleteDocumentsBatch(documentKeys) {
  const url = `/documents/batch`;
  try {
    const response = await axios.delete(`${CHATBOT_PLEX_SERVER_URL}${url}`, {
      data: {
        documentKeys: documentKeys
      }
    });
    return response;
  } catch (error) {
    console.error('다중 문서 완전 삭제 중 오류 발생:', error);
    throw error;
  }
}

/**
 * 파일 업로드 (원본 파일)
 * @param {Object} params - 업로드 파라미터
 * @param {string} params.sessionId - 세션 ID
 * @param {File} params.file - 업로드할 파일
 * @param {string} params.agentCode - 에이전트 코드
 * @param {string} params.email - 사용자 이메일
 * @param {string} params.userNm - 사용자 이름
 * @returns {Promise<Object>} 업로드 결과
 */
export async function uploadDocFile({ sessionId, file, filename, agentCode, email, userNm, category, directoryId }) {
  const form = new FormData();

  form.append('file', file);
  form.append('session_id', sessionId);
  form.append('filename', filename);
  if (agentCode) form.append('agent_id', agentCode);
  if (email) form.append('author_id', email);
  if (userNm) form.append('author_name', userNm);
  if (category) form.append('category', category);
  if (directoryId) form.append('directory_id', directoryId);
  const url = '/documents/upload';

  try {
    console.log('업로드 요청 데이터:', {
      url: `${CHATBOT_PLEX_SERVER_URL}${url}`,
      formData: Object.fromEntries(form.entries())
    });
    
    const { data } = await axios.post(`${CHATBOT_PLEX_SERVER_URL}${url}`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return data;
  } catch (error) {
    console.error('파일 업로드 중 오류 발생:', error);
    console.error('오류 응답:', error.response?.data);
    console.error('오류 상태:', error.response?.status);
    throw error;
  }
}

/**
 * 다중 파일 업로드
 * @param {Object} params - 업로드 파라미터
 * @param {string} params.sessionId - 세션 ID
 * @param {File[]} params.files - 업로드할 파일 배열
 * @param {string} params.agentCode - 에이전트 코드
 * @param {string} params.email - 사용자 이메일
 * @param {string} params.userNm - 사용자 이름
 * @param {string} params.category - 카테고리
 * @param {string} params.directoryId - 디렉토리 ID (선택사항)
 * @returns {Promise<Object>} 업로드 결과
 */
export async function uploadMultipleDocFiles({ sessionId, files, agentCode, email, userNm, category, directoryId }) {
  const form = new FormData();

  // 모든 파일을 files 배열로 추가
  Array.from(files).forEach(file => {
    form.append('files', file);
  });

  form.append('session_id', sessionId);
  if (agentCode) form.append('agent_id', agentCode);
  if (email) form.append('author_id', email);
  if (userNm) form.append('author_name', userNm);
  if (category) form.append('category', category);
  if (directoryId) form.append('directory_id', directoryId);

  const url = '/documents/upload-multiple';

  try {
    console.log('다중 파일 업로드 요청 데이터:', {
      url: `${CHATBOT_PLEX_SERVER_URL}${url}`,
      fileCount: files.length,
      formData: Object.fromEntries(form.entries())
    });
    
    const { data } = await axios.post(`${CHATBOT_PLEX_SERVER_URL}${url}`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return data;
  } catch (error) {
    console.error('다중 파일 업로드 중 오류 발생:', error);
    console.error('오류 응답:', error.response?.data);
    console.error('오류 상태:', error.response?.status);
    throw error;
  }
}

/**
 * 문서 다운로드
 * @param {string} documentKey - 다운로드할 문서 키값
 * @returns {Promise<Object>} 다운로드 결과
 */
export async function downloadDocument(documentKey, filename) {
  const url = `/documents/${documentKey}/download`;
  try {
    const response = await axios.get(`${CHATBOT_PLEX_SERVER_URL}${url}`, {
      responseType: 'blob', // 파일 다운로드를 위해 blob으로 설정
    });
    
    // Blob URL 생성 및 다운로드
    const blob = new Blob([response.data]);
    const downloadUrl = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(downloadUrl);
    
    return { success: true, filename };
  } catch (error) {
    console.error('문서 다운로드 중 오류 발생:', error);
    throw error;
  }
}

/**
 * 논리적 디렉토리를 생성한다.
 */
export async function createDocumentDirectory(directoryName, category, parentId, agentCode, email, userNm) {
  const url = `/directories`;
  const requestData = {
    name: directoryName,
    category: category,
    parentId: parentId,
    agentCode: agentCode,
    creatorEmail: email,
    creatorName: userNm,
  };
  try {
    const { data } = await axios.post(`${CHATBOT_PLEX_SERVER_URL}${url}`, requestData, {
      headers: { 'Content-Type': 'application/json' },
    });
    return data;
  } catch (error) {
    console.error('디렉토리 생성 중 오류 발생:', error);
    throw error;
  }
}

/**
 * 디렉토리 정보 수정
 * @param {string} directoryId - 수정할 디렉토리 ID
 * @param {Object} directoryData - 수정할 디렉토리 정보
 * @param {string} directoryData.name - 디렉토리 이름
 * @param {string} directoryData.category - 디렉토리 카테고리
 * @param {string} directoryData.parentId - 부모 디렉토리 ID (null이면 루트)
 * @param {string} directoryData.agentCode - 에이전트 코드
 * @returns {Promise<Object>} 수정된 디렉토리 정보
 */
export async function updateDocumentDirectory(directoryId, directoryData) {
  const url = `/directories/${directoryId}`;
  
  try {
    const { data } = await axios.put(`${CHATBOT_PLEX_SERVER_URL}${url}`, directoryData, {
      headers: { 'Content-Type': 'application/json' },
    });
    return data;
  } catch (error) {
    console.error('디렉토리 수정 중 오류 발생:', error);
    throw error;
  }
}

/**
 * 디렉토리 물리적 삭제 (완전 삭제)
 * @param {string} directoryId - 삭제할 디렉토리 ID
 * @returns {Promise<void>} 삭제 결과
 * @throws {Error} 하위 디렉토리가 있으면 삭제 불가
 */
export async function deleteDocumentDirectory(directoryId) {
  const url = `/directories/${directoryId}`;
  
  try {
    await axios.delete(`${CHATBOT_PLEX_SERVER_URL}${url}`);
  } catch (error) {
    console.error('디렉토리 물리적 삭제 중 오류 발생:', error);
    throw error;
  }
}

/**
 * 디렉토리 논리적 삭제 (소프트 삭제)
 * @param {string} directoryId - 삭제할 디렉토리 ID
 * @returns {Promise<void>} 삭제 결과
 */
export async function softDeleteDocumentDirectory(directoryId) {
  const url = `/directories/${directoryId}/soft`;
  
  try {
    await axios.delete(`${CHATBOT_PLEX_SERVER_URL}${url}`);
  } catch (error) {
    console.error('디렉토리 논리적 삭제 중 오류 발생:', error);
    throw error;
  }
}

/**
 * 디렉토리 정렬 순서 수정
 * @param {string} directoryId - 수정할 디렉토리 ID
 * @param {number} newSortOrder - 새로운 정렬 순서
 * @returns {Promise<void>} 수정 결과
 */
export async function updateDirectorySortOrder(directoryId, newSortOrder) {
  const url = `/directories/${directoryId}/sort-order`;
  
  try {
    await axios.put(`${CHATBOT_PLEX_SERVER_URL}${url}`, null, {
      params: { newSortOrder },
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('디렉토리 정렬 순서 수정 중 오류 발생:', error);
    throw error;
  }
}

/**
 * 문서 검색 상태 스트림 시작
 * @param {string} chatbotCode - 챗봇 코드
 * @param {string} sessionId - 세션 ID
 * @returns {Promise<Response>} 스트림 응답
 */
export async function startDocsSearchStream(chatbotCode, sessionId) {
  try {
    const response = await fetch(`${RAG_SERVER_URL}/rag/agent-code/${chatbotCode}/stream/${sessionId}/status`);
    return response;
  } catch (error) {
    console.error('문서 검색 스트림 시작 중 오류 발생:', error);
    throw error;
  }
}

/**
 * 문서 검색 스트림 종료
 * @param {string} chatbotCode - 챗봇 코드
 * @param {string} sessionId - 세션 ID
 * @returns {Promise<Object>} 종료 결과
 */
// export async function endDocsSearchStream(chatbotCode, sessionId) {
export async function endDocsSearchStream() {
  // console.log('endDocsSearchStream', chatbotCode, sessionId);
  return { success: true, message: 'Stream ended' };
}

/**
 * 문서를 복사한다.
 */
export async function copyDocument(sourceDocumentKey, categoryId, parentId, newTitle, newAuthor, newAuthorId, newAgentCode) {
  const url = `/documents/copy`;
  const requestData = {
    sourceDocumentKey,
    categoryId,
    parentId,
    newTitle,
    newAuthor,
    newAuthorId,
    newAgentCode
  };
  try {
    const { data } = await axios.post(`${CHATBOT_PLEX_SERVER_URL}${url}`, requestData, {
      headers: { 'Content-Type': 'application/json' },
    });
    return data;
  } catch (error) {
    console.error('copyDocument error:', error);
    throw error;
  }
}