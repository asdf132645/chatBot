// RAG SSE 호출
export async function fetchRagStream(payload) {
  return fetch('/api/rag/stream', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'text/event-stream'
    },
    body: JSON.stringify(payload)
  });
}

// SSE 종료
export async function endRagStream(code, convId) {
  try {
    return fetch(`/api/rag/stream/end?code=${encodeURIComponent(code)}&convId=${encodeURIComponent(convId)}`, {
      method: 'POST'
    });
  } catch (_) {
    return null;
  }
}

// Mock SSE
export async function fetchGenAiStreamMock(request, options = {}) {
  const { chunkMs = 80 } = options;
  const q = (request?.q || '').trim();
  const sample = [
    `# ${q || '문서 제목 예시'}\n`,
    `요청하신 내용에 따라 **문서 개요**를 생성합니다.\n\n`,
    `1) 요구사항 정리\n- 항목 A\n- 항목 B\n\n`,
    `2) 세부 전략\n- 포인트 1\n- 포인트 2\n\n`,
    `> 실시간 스트리밍으로 들어오는 텍스트를 마크다운으로 변환하여 표시.\n`,
  ];

  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    start(controller) {
      let i = 0;
      const iv = setInterval(() => {
        if (i >= sample.length) {
          clearInterval(iv);
          controller.close();
          return;
        }
        const sse = `data: ${sample[i++]}\n\n`;
        controller.enqueue(encoder.encode(sse));
      }, chunkMs);
    },
  });

  return new Response(stream, {
    headers: { 'Content-Type': 'text/event-stream; charset=utf-8' },
  });
}
