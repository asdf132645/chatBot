// # SSE 스트림 처리 (분기/옵션 확장)
import { nextTick } from 'vue'
import { doRagReportGet } from './useReportFetch'
import { ragEditorSseUrl, ragRouterUrl } from '../../../shared/config/endpoints'
import { toNFC } from '../domain/filenameUtils'

/** 안전 스크롤 래퍼 */
function safeGoBottom(chatScrollRef, onGoBottomRef) {
  try {
    if (!chatScrollRef?.value) return
    if (typeof onGoBottomRef === 'function') onGoBottomRef(chatScrollRef)
  } catch (e) {
    console.warn('safeGoBottom error:', e)
  }
}

/** 리스트에서 내 아이템 위치 찾기 */
function findItemIndex(chatListRef, item, queryId) {
  if (!Array.isArray(chatListRef?.value)) return -1
  const arr = chatListRef.value
  let idx = arr.findIndex(c => c === item || c?.queryId === queryId)
  if (idx === -1 && item?._idx) {
    idx = arr.findIndex(c => c?._idx === item._idx)
  }
  return idx
}

export async function doSseChatCall({
                                      // 기존 파라미터
                                      query,
                                      session,
                                      localSessionId,        // ref
                                      fileList,              // ref
                                      currentTemplate,       // reactive { id, ... }
                                      chatListRef,           // ref
                                      chatScrollRef,         // ref(엘리먼트)
                                      onGoBottomRef,         // function
                                      t,                     // i18n t
                                      toast,                 // useToast()
                                      renderMarkdown,        // function (미사용 가능)
                                      isStreaming,           // ref: 스트리밍 상태
                                      editor,                // { contentRef, titleRef } for doRagReportGet
                                      queryId,
                                      signal,
                                      useRouter = false,        // false: ragEditorSseUrl, true: ragRouterUrl
                                      payloadBuilder,        // function(ctx): object  (기본 페이로드 대체)
                                      headers,               // object: 요청 헤더 오버라이드
                                      shouldFetchReport = true, // boolean: 리포트 조회 여부
                                      speedMs = 10,          // number: 타자 효과 속도(ms)
                                    } = {}) {
  const id = localSessionId.value
  const attachedNames = (fileList.value || []).map(f => f.name)
  // 스트림 루프 시작 - 스트리밍 상태 활성화
  if (isStreaming) {
    isStreaming.value = true
  }
  // 버블 추가 (pending)
  const item = {
    _idx: Date.now(),
    sessionId: id,
    query,
    queryId,
    answer: '',
    files: attachedNames,
    _status: 'pending',
    _progress: 1,
    state: '',
  }
  chatListRef.value.push(item)
  await nextTick()
  safeGoBottom(chatScrollRef, onGoBottomRef)

  // 진행률 애니메이션
  let timer = setInterval(() => {
    if (item._progress < 90) item._progress += 2
  }, 120)

  let reader
  try {
    const agentCode = session.value?.agentCode || session.value?.chatbotCode
    if (!agentCode) throw new Error('agent_code 없음')

    const url = (useRouter ? ragRouterUrl(agentCode) : ragEditorSseUrl(agentCode))
    const hasFiles = (fileList.value?.length || 0) > 0
    const fileMeta = hasFiles
      ? [{
        role: 'event',
        type: 'file_upload',
        metadata: {
          files: fileList.value.map(f => ({
            doc_title: toNFC(f.name),
            uploaded_at: new Date().toISOString(),
            doc_page: null,
          })),
        },
      }]
      : []

    // ★ 페이로드 빌더: 주입되면 사용, 없으면 기본
    const defaultPayload = {
      messages: [
        ...fileMeta,
        { role: 'user', content: query },
      ],
      stream: true,
      session_id: id,
      prompt_id: currentTemplate?.id,
      query_id: queryId,
    }
    const payload = typeof payloadBuilder === 'function'
      ? payloadBuilder({
        query,
        session,
        sessionId: id,
        fileList: fileList.value || [],
        template: currentTemplate,
        queryId,
        hasFiles,
        fileMeta,
        defaultPayload,
      })
      : defaultPayload

    // ★ 요청 헤더: 오버라이드 가능
    const reqHeaders = {
      'Content-Type': 'application/json',
      'Accept': 'text/event-stream',
      ...(headers || {}),
    }

    const resp = await fetch(url, {
      method: 'POST',
      headers: reqHeaders,
      body: JSON.stringify(payload),
      signal,
    })

    reader = resp.body.pipeThrough(new TextDecoderStream()).getReader()

    // abort 시 스트림 취소
    if (signal) {
      if (signal.aborted) throw new DOMException('Aborted', 'AbortError')
      signal.addEventListener(
        'abort',
        () => { reader?.cancel?.().catch(() => {}) },
        { once: true }
      )
    }

    let dot = 0
    let stopRequested = false


    
    // eslint-disable-next-line
    while (true) {

      const { done, value } = await reader.read()
      if (done) break

      const chunk = String(value);
      const lines = chunk.split('\n')
      
      let currentEvent = 'message'
      let piece = ''

      for (const line of lines) {
        if (line.startsWith('event:')) {
          currentEvent = line.slice(6).trim()
          if (currentEvent === 'stop') {
            stopRequested = true
            // stop 이벤트가 와도 현재까지의 piece는 처리해야 함
            if (piece.length > 0) {
              // 타자 효과 (speedMs가 0이면 즉시 처리)
              if (speedMs > 0) {
                await new Promise(r => setTimeout(r, speedMs))
              }

              // speedMs가 0이면 로딩 메시지 표시 안 함
              if (speedMs > 0 && t) {
                let statement = t('answerwrapper.answerwrapper_key24') || '답변 중'
                for (let i = 0; i < (dot % 4); i++) statement += '.'
                dot++
                item.state = statement
              }

              // piece에 개행 치환 로직 적용
              let processedPiece = piece
                .replace(/\n\n\n\n\n/g, '<<5개연속개행>>')
                .replace(/\n\n\n\n/g, '<<4개연속개행>>')
                .replace(/\n\n\n/g, '<<3개연속개행>>')
                .replace(/\n\n/g, '')
                .replace(/<<5개연속개행>>/g, '\n')
                .replace(/<<4개연속개행>>/g, '\n')
                .replace(/<<3개연속개행>>/g, '\n')
                .replace(/\.#/g, '.\n#')
                .replace(/\.-/g, '.\n-')
              
              // chatListRef에서 해당 아이템을 찾아서 직접 업데이트 (반응성 보장)
              const currentItem = chatListRef.value.find(chatItem => chatItem._idx === item._idx)
              if (currentItem) {
                currentItem.answer += processedPiece
              } else {
                item.answer += processedPiece
              }
              
              // Vue 반응성 시스템이 즉시 업데이트를 감지하도록 nextTick 사용
              await nextTick()
              safeGoBottom(chatScrollRef, onGoBottomRef)
              
              piece = '' // piece 초기화
            }
          }
          continue
        }
        if (line.startsWith('data:')) {
          // 스트리밍 상태 비활성화
          if (isStreaming) {
            isStreaming.value = false
          }
          const data = line.replace(/^data:\s?/, '')
          
          if (currentEvent === 'stop') {
            // stop 이벤트의 data를 에러 메시지로 처리
            if (data && data.trim()) {
              piece += data
            }
          } else {
            // 빈 data 라인을 감지해서 개행 추가
            if (data === '') {
              piece += '\n'
            } else {
              piece += data
            }
          }
          continue
        }
      }

      if (piece.length > 0) {
        // 타자 효과 (speedMs가 0이면 즉시 처리)
        if (speedMs > 0) {
          await new Promise(r => setTimeout(r, speedMs))
        }

        // speedMs가 0이면 로딩 메시지 표시 안 함
        if (speedMs > 0 && t) {
          let statement = t('answerwrapper.answerwrapper_key24') || '답변 중'
          for (let i = 0; i < (dot % 4); i++) statement += '.'
          dot++
          item.state = statement
        }

        // piece에 개행 치환 로직 적용
        // 특정 케이스 별도 치환 : 예) 나열합니다.- 특징 1 => 나열합니다.\n- 특징 1
        let processedPiece = piece
          .replace(/\n\n\n\n\n/g, '<<5개연속개행>>')
          .replace(/\n\n\n\n/g, '<<4개연속개행>>')
          .replace(/\n\n\n/g, '<<3개연속개행>>')
          .replace(/\n\n/g, '')
          .replace(/<<5개연속개행>>/g, '\n')
          .replace(/<<4개연속개행>>/g, '\n')
          .replace(/<<3개연속개행>>/g, '\n')
          .replace(/\.#/g, '.\n#')
          .replace(/\.-/g, '.\n-')
        // chatListRef에서 해당 아이템을 찾아서 직접 업데이트 (반응성 보장)
        const currentItem = chatListRef.value.find(chatItem => chatItem._idx === item._idx)
        if (currentItem) {
          currentItem.answer += processedPiece
        } else {
          item.answer += processedPiece
        }
        
        // Vue 반응성 시스템이 즉시 업데이트를 감지하도록 nextTick 사용
        await nextTick()
        safeGoBottom(chatScrollRef, onGoBottomRef)
      }

      if (stopRequested) break
    }



    // ★ 스트림 끝: 리포트 메타 조회는 옵션
    let report = null
    if (shouldFetchReport) {
      report = await new Promise(resolve => {
        setTimeout(async () => {
          const result = await doRagReportGet({
            session,
            localSessionId: id,
            toast,
            renderMarkdown,
            editor,
            queryId,
          });
          resolve(result);
        }, 0);
      });
    }

    if (timer) clearInterval(timer)
    if (typeof report !== 'undefined') {
      // console.log('원본 report', report)
    }

    // 리스트에서 내 아이템 위치 확인
    let idx = findItemIndex(chatListRef, item, queryId)
    if (idx === -1) {
      return {
        item,
        answer: item.answer,
        report,
        queryId,
        fileListArr: fileList.value
      }
    }

    const cur = chatListRef.value[idx]

    // stop 이벤트로 인한 에러 처리
    if (stopRequested && item.answer.includes('작업 중 내부 오류가 발생하였습니다')) {
      const updated = {
        ...cur,
        _progress: 100,
        _status: 'error',
        state: '',
        answer: item.answer,
        report: undefined,
      }
      chatListRef.value.splice(idx, 1, updated)
      toast?.error?.('작업 중 내부 오류가 발생하였습니다. 잠시 후 다시 시도해주세요.')
      await nextTick()
      safeGoBottom(chatScrollRef, onGoBottomRef)
      return {
        item: updated,
        answer: updated.answer,
        report: undefined,
        queryId,
        fileListArr: fileList.value
      }
    }

    // 서버 에러 케이스
    if (report && report.error) {
      const updated = {
        ...cur,
        _progress: 100,
        _status: 'error',
        state: '',
        answer: '문서 생성 실패',
        report: undefined,
      }
      chatListRef.value.splice(idx, 1, updated)
      toast?.error?.('문서 생성 실패')
      await nextTick()
      safeGoBottom(chatScrollRef, onGoBottomRef)
      return {
        item: updated,
        answer: updated.answer,
        report: undefined,
        queryId,
        fileListArr: fileList.value
      }
    }

    const reportData = shouldFetchReport ? (report ?? null) : null
    const displayState = reportData ? '' : (shouldFetchReport ? '리포트 없음(요약만 생성)' : '')

    const updated = {
      ...cur,
      _progress: 100,
      _status: 'ready',
      state: displayState,
      report: reportData,
    }
    chatListRef.value.splice(idx, 1, updated)
    await nextTick()
    safeGoBottom(chatScrollRef, onGoBottomRef)

    return {
      item: updated,
      answer: updated.answer,
      report: updated.report,
      queryId,
      fileListArr: fileList.value
    }
  } catch (err) {
    console.error('SSE error:', err)
    if (timer) clearInterval(timer)

    // 취소(Abort)
    if (err?.name === 'AbortError') {
      try {
        const idx = findItemIndex(chatListRef, item, queryId)
        if (idx !== -1) {
          const cur = chatListRef.value[idx]
          if (cur?._status === 'pending') {
            const updated = {
              ...cur,
              _progress: 100,
              _status: 'canceled',
              state: '취소됨',
            }
            chatListRef.value.splice(idx, 1, updated)
          }
        }
      } finally {
        await nextTick()
        safeGoBottom(chatScrollRef, onGoBottomRef)
      }
      return {
        item,
        answer: item.answer,
        report: item.report,
        queryId,
        fileListArr: fileList.value,
        aborted: true,
      }
    }

    // 기타 에러
    try {
      const idx = findItemIndex(chatListRef, item, queryId)
      if (idx === -1) {
        toast?.error?.('문서 생성 실패')
        return
      }
      const cur = chatListRef.value[idx]
      if (cur?._status && cur._status !== 'pending') return
      const updated = {
        ...cur,
        _progress: 100,
        _status: 'error',
        state: '',
        answer: '문서 생성 실패',
      }
      chatListRef.value.splice(idx, 1, updated)
    } finally {
      toast?.error?.('문서 생성 실패')
      await nextTick()
      safeGoBottom(chatScrollRef, onGoBottomRef)
    }
  }
}
