// 보고서 불러와서 에디터에 넣기 (심플 버전)

import { nowIso, stripExt } from '../../../composables/chatUtils';
import { ragReportFilesUrl } from '../../../shared/config/endpoints';

/** ref든 일반 값이든 알아서 세팅 */
function setValue(target, val) {
  if (!target) return;
  if (target && typeof target === 'object' && 'value' in target) target.value = val;
  else target = val;
}

/** 에디터에 제목/내용 반영 */
function applyEditor(editor, { html, title }) {
  if (!editor) return;
  if (editor.contentRef) setValue(editor.contentRef, html);
  if (editor.content) setValue(editor.content, html);
  if (editor.titleRef) setValue(editor.titleRef, title);
  if (editor.title) setValue(editor.title, title);
}

/** 서버가 "이스케이프된 문자열"로 줄 때 복원 (예: "<h2>..</h2>" 형태) */
function decodeMaybeEscaped(s) {
  if (typeof s !== 'string') return '';
  let t = s.trim();

  // 따옴표로 감싸진 JSON 문자열이면 먼저 풀기 (\\n → \n)
  try {
    if ((t.startsWith('"') && t.endsWith('"')) || /\\[nrt"\\]/.test(t)) {
      t = JSON.parse(t);
    }
  } catch { /* 무시 */
  }

  // 남아있는 이스케이프 개행도 실제 개행으로
  t = t.replace(/\\r\\n/g, '\n').replace(/\\n/g, '\n').replace(/\r\n/g, '\n');
  return t;
}


/** 매우 단순한 HTML 판별: 태그가 선두에 보이면 HTML로 간주 */
function isHtml(str) {
  if (!str) return false;
  return /^\s*<\/?[a-z][\s\S]*>/i.test(str);
}


/**
 * 보고서 파일 조회 → 에디터에 주입
 *  Markdown이면 renderMarkdown(md)로 HTML 변환 후 주입
 */
export async function doRagReportGet({
                                       session,
                                       localSessionId,
                                       toast,
                                       renderMarkdown,               // (md:string)=>html
                                       editor,                       // { contentRef|content, titleRef|title }
                                       queryId,
                                     }) {
  try {
    const agentCode = session.value?.agentCode || session.value?.chatbotCode;
    if (!agentCode) throw new Error('agent_code가 없습니다.');
    const url = ragReportFilesUrl(agentCode, localSessionId, queryId);
    const resp = await fetch(url, { method: 'GET', headers: { Accept: 'application/json' } });
    if (!resp.ok) throw new Error(`보고서 파일 조회 실패: ${resp.status}`);

    const data = await resp.json();
    const first = data?.report_files?.[0];
    if (!first?.content) return null;

    //  원문 확보 (이스케이프 풀기)
    const source = decodeMaybeEscaped(first.content);

    //  HTML/MD 처리
    let html = '';
    if (isHtml(source)) {
      html = source;
    } else {
      // 마크다운이면 변환
      html = renderMarkdown ? renderMarkdown(source) : source;
    }
    // console.log(JSON.stringify(html))
    //  Quill 친화 형태로 살짝 정리 후 에디터에 주입
    const finalHtml = html;
    const title = stripExt(first.doc_title || '문서명');
    applyEditor(editor, { html: finalHtml, title });

    // 디버깅용
    // console.log(finalHtml)

    return {
      fileName: first.doc_title || '문서',
      createdAt: first.created_at || nowIso(),
      // 참고: md 대신 화면에 실제 들어간 HTML을 반환 (팀원이 확인하기 쉬움)
      html: finalHtml,
      query_id: queryId
    };
  } catch (err) {
    console.error('doRagSend error:', err);
    toast?.error?.('문서 불러오기 실패');
    return null;
  }
}
