export default {
  namespaced: true,
  state: () => ({
    pending: null, // { message, fileList, uploadedFileIds, template }
  }),
  mutations: {
    setPending(state, payload) { state.pending = payload || null },
    consume(state) { state.pending = null },
  },
  getters: {
    getPending: (s) => s.pending,
  },
}
