<template>
  <div class="doc-answer-list-wrapper" ref="rootEl">
    <div
      class="bubble-wrapper"
      v-for="(chat, idx) in chatList"
      :key="chat.id || (chat.sessionId + ':' + chat._idx)"
    >
      <!-- 일반 유저 메시지 -->
      <div v-if="!chat._type && chat.query" class="user-chat-bubble bubble">
        {{ chat.query }}
      </div>

      <!-- AI 메시지 -->
      <div v-if="!chat._type" class="ai-chat-bubble bubble">
        <div class="user-meta" v-if="chat.query">
          <div class="ask-text">{{ chat.query }}</div>
        </div>
        <div class="answer-procedure-wrapper answer-box">
          <div class="state-head">
            <div class="state-base state-title">
              <img class="" :src="require('@/assets/images/topology-star-3.svg')" />
              <span class="state-title-text">{{ $t('answercontent.answercontent_key1') }}</span>
            </div>
            <div class="state-base state-fold" @click="toggleState(idx)">
              <BaseIcon name="ArrowTailUp" :size="20" v-if="!getChatState(idx)" />
              <BaseIcon name="ArrowTailDown" :size="20" v-if="getChatState(idx)" />
            </div>
          </div>
          <transition name="slide">
            <div class="state-body" ref="stateBody" v-if="getChatState(idx)">
              <transition-group name="fade-list" tag="div">
                <div class="state-base state-detail" v-for="searchItem in searchList" :key="searchItem.id">
                  <img class="blinking" :src="require('@/assets/images/search.svg')"
                      v-if="searchItem.status === 'search'" />
                  <img class="blinking" :src="require('@/assets/images/loading.svg')"
                      v-if="searchItem.status === 'loading'" />
                  <img class="blinking" :src="require('@/assets/images/check.svg')"
                      v-if="searchItem.status === 'check'" />
                  <span class="state-detail-target-info text-truncate">{{ searchItem.keyword }}</span>
                  <span class="state-detail-target-title">{{ searchItem.statusDetail }}</span>
                </div>
              </transition-group>
              <!-- 검색 결과 상태-->
              <div class="state-base state-detail state-result">
                <img class="blinking" :src="require('@/assets/images/loading.svg')" v-if="queryLoading" />
                <img class="blinking" :src="require('@/assets/images/check.svg')" v-if="!queryLoading" />
                <span class="state-detail-target-title state-last">
                    <span v-if="queryLoading">{{ $t('answercontent.answercontent_key2') }}</span>
                    <span v-if="!queryLoading">{{ $t('answercontent.answercontent_key3') }}</span>
                  </span>
              </div>
            </div>
          </transition>
        </div>
        
        <!-- 진행중 -->
        <template v-if="isStreaming">
          <div class="file-tags" v-if="chat.files && chat.files.length">
            <span class="file-tag" v-for="(fname, i) in chat.files" :key="i">
              <BaseIcon name="file" :size="14" />
              {{ fname }}
            </span>
          </div>

          <div class="genai-answer-text answer-box" v-html="renderMarkdownStream(chat.answer)"></div>

          <div class="doc-progress-card is-waiting" role="status" aria-live="polite">
            <div class="loading-spinner"></div>
            <div class="doc-progress-meta">
              <div class="title">답변 중 …</div>
            </div>
          </div>
        </template>

        <!-- 완료 -->
        <template v-else-if="chat._status === 'ready'">
          <div class="file-tags answer-box" v-if="chat.files && chat.files.length">
            <span class="file-tag" v-for="(fname, i) in chat.files" :key="i">
              <BaseIcon name="file" :size="14" />
              {{ fname }}
            </span>
          </div>
          <div class="genai-answer-text answer-box" v-html="renderMarkdownStream(chat.answer)"></div>
          <div
            class="doc-progress-card is-success"
            v-if="chat.report"
            :class="{ 'is-disabled': idx !== chatList.length - 1 }"
            @click.stop="onOpenEditor(idx, chat)"
          >
            <div class="doc-progress-ring" style="--p: 100">
              <div class="ring">
                <div class="hole">
                  <BaseIcon name="ReportDocType" :size="18" />
                </div>
              </div>
            </div>
            <div class="doc-progress-meta" v-if="chat.report && (chat.report.fileName || chat.report.createdAt)">
              <span v-if="chat.report.fileName" class="title">{{ chat.report.fileName }}</span>
              <span v-if="chat.report.createdAt" class="sub">{{ formatDate(chat.report.createdAt) }}</span>
            </div>

            <BaseIcon name="ArrowRight" :size="18" />
          </div>
        </template>

        <!-- 오류 -->
        <template v-else-if="chat._status === 'error'">
          <div class="doc-progress-card is-error" role="alert" aria-live="assertive">
            <div class="doc-progress-ring" style="--p: 100">
              <div class="ring">
                <div class="hole">
                  <BaseIcon name="Warning" :size="18" />
                </div>
              </div>
            </div>
            <div class="doc-progress-meta">
              <div class="title">생성 실패</div>
              <div class="sub">다시 시도해 주세요.</div>
            </div>
          </div>
        </template>

        <!-- 취소 -->
        <template v-else-if="chat._status === 'canceled'">
          <div class="user-meta">
            <div class="ask-text">{{ chat.query }}</div>
          </div>

          <div class="file-tags" v-if="chat.files && chat.files.length">
            <span class="file-tag" v-for="(fname, i) in chat.files" :key="i">
              <BaseIcon name="file" :size="14" />
              {{ fname }}
            </span>
          </div>

          <div class="doc-progress-card is-canceled" role="status" aria-live="polite">
            <div class="doc-progress-ring" style="--p: 100">
              <div class="ring">
                <div class="hole">
                  <BaseIcon name="Close" :size="18" />
                </div>
              </div>
            </div>
            <div class="doc-progress-meta">
              <div class="title">생성 취소됨</div>
              <div class="sub">요청이 중단되었습니다.</div>
            </div>
          </div>
        </template>

        <!-- 기타 상태 -->
        <template v-else>
          <div class="genai-answer-text answer-box" v-html="renderMarkdownStream(chat.answer)"></div>
        </template>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, defineProps, defineEmits, defineExpose, watch } from 'vue';
import BaseIcon from '@/component/BaseIcon.vue';
import { useChatView } from '@/domains/chat/application/useChatView';

const props = defineProps({
  chatList: { type: Array, default: () => [] },
  renderMarkdownStream: { type: Function, required: true },
  formatDate: { type: Function, required: true },
  searchList: { type: Array, default: () => [] },
  queryLoading: { type: Boolean, default: false },
  isStreaming: { type: Boolean, default: false },
});

const emit = defineEmits(['open-editor', 'mounted']);

const rootEl = ref(null);

// 각 채팅의 상태를 관리하는 ref
const chatStates = ref({});
const { onGoBottomRef } = useChatView();
// 특정 채팅의 상태를 가져오는 함수
function getChatState(idx) {
  return chatStates.value[idx] || false;
}

// 특정 채팅의 상태를 토글하는 함수
function toggleState(idx) {
  chatStates.value[idx] = !getChatState(idx);
}

// 특정 채팅의 상태를 열기
function openState(idx) {
  chatStates.value[idx] = true;
}

// 특정 채팅의 상태를 닫기
function closeState(idx) {
  chatStates.value[idx] = false;
}

function onOpenEditor(idx, chat) {
  const len = Array.isArray(props.chatList) ? props.chatList.length : 0;
  if (idx !== len - 1) return;

  setTimeout(() => {
    emit('open-editor', chat);
  }, 0);
}

//  chatList 변화를 감지해서 자동 스크롤
watch(
  () => props.chatList,
  () => {
    if (rootEl.value) {
      // 직접 스크롤 처리
      setTimeout(() => {
        rootEl.value.scrollTop = rootEl.value.scrollHeight;
      }, 50);
    }
  },
  { deep: true, immediate: true }
);

onMounted(() => {
  // 부모에게 실제 DOM 엘리먼트를 이벤트로 전달
  emit('mounted', rootEl.value);
  onGoBottomRef(rootEl, 'auto');
});

// 부모 컴포넌트에서 사용할 수 있도록 함수들을 노출
defineExpose({
  openState,
  closeState,
  toggleState,
  getChatState
});
</script>

<style scoped>
.doc-progress-card.is-disabled {
  pointer-events: none;
  opacity: 0.5;
  cursor: not-allowed;
}
</style>