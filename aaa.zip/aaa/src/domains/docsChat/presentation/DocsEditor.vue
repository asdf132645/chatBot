<template>
  <div class="editor-wrapper">
    <!-- ===== 헤더 ===== -->
    <div class="editor-header">
      <div class="editor-header-title">{{ editorTitle }}</div>

      <div class="doc-list-wrapper">
        <button class="editor-header-button disabled" disabled>맞춤법검사</button>
        <button class="editor-header-button disabled" disabled>명확성검사</button>
        <button class="editor-header-button disabled" disabled>어휘정제</button>
        <div class="divider"></div>
        <button class="editor-header-button disabled" disabled>연관 문서</button>
        <div class="divider"></div>

        <button
          class="editor-header-button"
          :disabled="showEditorOverlay"
          @click.stop="isOpenModal = true"
          title="저장"
        >
          저장
        </button>
<!--        <div class="divider"></div>-->

        <!--  복사 -->
<!--        <button class="editor-header-button" @click="onClickCopy">-->
<!--          복사-->
<!--        </button>-->

        <!-- 숨겨진 파일 입력 -->
        <input
          ref="fileInputRef"
          type="file"
          accept="image/*"
          @change="onPickImage"
          style="display:none"
        />

        <!-- 문서 리스트 드롭다운 -->
        <DropDown
          :width="280"
          :top="chatDropPosition.y"
          :left="chatDropPosition.x - 280"
          :isOpenDrop="isDocListDrop"
          @close="$emit('update:isDocListDrop', false)"
          dropdownName="doc-list-menu-wrapper"
        >
          <template #content>
            <div class="conversation-menu-wrapper">
              <ul>
                <li v-for="doc in docList" :key="doc.id">
                  <button class="nav-btn" @click.stop="$emit('select-doc', doc)">
                    <BaseIcon name="SummaryDocType" :size="20" :mr="8" />
                    <div class="doc-title">
                      {{ doc.title }}
                      <div class="doc-desc">{{ doc.desc }}</div>
                    </div>
                  </button>
                </li>
              </ul>
            </div>
          </template>
        </DropDown>

        <!-- 저장 모달 -->
        <MyModal
          width="500"
          :isOpenModal="isOpenModal"
          title="문서 저장"
          okBtnName="저장"
          desc="문서를 저장합니다."
          @close="isOpenModal = false"
          @sendData="handleSendData"
        >
          <template #content>
            <form class="form-wrapper">
              <!-- <CustomInput
                label="문서 제목"
                id="documentTitleInput"
                placeholder="문서 제목을 입력해주세요."
                name="documentTitleInput"
                v-model="documentInfo.title"
              /> -->
              
              <div class="custom-control">   
                <label class="custom-label">문서 제목</label>
                <div class="custom-input">
                  <input
                    id="documentTitleInput"
                    placeholder="문서 제목을 입력해주세요."
                    name="documentTitleInput"
                    v-model="documentInfo.title"
                  /> 
                </div>
            </div>

              <CustomInput
                label="암호 설정"
                :disabled="true"
                id="passwordInput"
                placeholder="암호를 입력해주세요."
                name="passwordInput"
                v-model="documentInfo.password"
              />

              <div class="radio-wrapper custom-control row-style row-center">
                <div class="custom-label">문서 타입</div>
                <CustomRadio
                  :disabled="true"
                  id="pdf"
                  label=".PDF"
                  radioName="shareTypeRadio"
                  :value="makedDocType"
                  @change="radioActive"
                />
                <CustomRadio
                  :disabled="true"
                  id="csv"
                  label=".CSV"
                  radioName="shareTypeRadio"
                  :value="makedDocType"
                  @change="radioActive"
                />
                <CustomRadio
                  :disabled="true"
                  id="txt"
                  label=".TXT"
                  radioName="shareTypeRadio"
                  :value="makedDocType"
                  @change="radioActive"
                />
                <CustomRadio
                  id="md"
                  label=".MD"
                  radioName="shareTypeRadio"
                  :value="makedDocType"
                  @change="radioActive"
                />
              </div>

              <div class="custom-control row-style row-center">
                <div class="custom-label">중요 문서 여부</div>
                <CustomCheck
                  :disabled="true"
                  id="favorite"
                  label="확인"
                  checkName="favoriteCheck"
                  :value="documentInfo.favorite"
                  @change="() => { documentInfo.favorite = !documentInfo.favorite }"
                />
              </div>

              <div class="custom-control row-style row-center">
                <div class="custom-label">파일 복사/저장 가능 여부</div>
                <CustomCheck
                  :disabled="true"
                  id="isSaved"
                  label="확인"
                  checkName="favoriteCheck"
                  :value="documentInfo.isSaved"
                  @change="() => { documentInfo.isSaved = !documentInfo.isSaved }"
                />
              </div>

              <TagList 
                :tagList="documentInfo.tags" 
                @onEnter="handleAddTag" 
                @onDelete="handleDeleteTag" />
              
            </form>
          </template>
        </MyModal>
      </div>
    </div>

    <!-- ===== 본문 ===== -->
    <div class="editor-content">
      <button class="related-document-list-btn" @click="$emit('toggle-related')">
        <BaseIcon name="file" :size="18" :mr="4" />
        참고자료
      </button>

      <div class="docs-editor-wrapper">
        <!-- 오버레이 -->
        <div
          class="editor-loading-overlay"
          :class="{ 'is-visible': showEditorOverlay }"
          aria-hidden="true"
        >
          <div class="editor-skeleton">
            <div class="skeleton-line" style="width: 40%"></div>
            <div class="skeleton-line" style="width: 90%"></div>
            <div class="skeleton-line" style="width: 80%"></div>
            <div class="skeleton-line" style="width: 70%"></div>
          </div>
        </div>

        <!-- Toast UI Editor mount -->
        <div ref="editorRoot" class="scrollable-tui"></div>
      </div>
    </div>
  </div>
</template>

<script setup>
import BaseIcon from '@/component/BaseIcon.vue'
import DropDown from '@/component/DropDown.vue'
import CustomRadio from '@/component/CustomRadio.vue'
import CustomInput from '@/component/CustomInput.vue'
import CustomCheck from '@/component/CustomCheck.vue'
import MyModal from '@/component/MyModal.vue'
import TagList from '@/component/TagList.vue'
import { defineProps, defineEmits, ref, computed, onMounted, onBeforeUnmount, watch } from 'vue'

/* TOAST UI Editor */
import Editor from '@toast-ui/editor'
import '@toast-ui/editor/dist/toastui-editor.css'
// import { useToast } from 'vue-toastification';

const props = defineProps({
  editorTitle: { type: String, default: '문서명' },
  contentEditor: { type: String, default: '' },
  quillFormats: { type: Array, default: () => [] }, // 호환용
  showEditorOverlay: { type: Boolean, default: false },
  isDocListDrop: { type: Boolean, default: false },
  chatDropPosition: { type: Object, required: true },
  docList: { type: Array, default: () => [] },
})
// const toast = useToast();

const emit = defineEmits([
  'update:isDocListDrop',
  'toggle-related',
  'select-doc',
  'editor-ready',
  'toggleDropItem',
  'save-txt',
])

/** ===== 상태 ===== */
const makedDocType = ref('md')
const isOpenModal = ref(false)

const documentInfo = ref({
  title: '',
  password: '',
  favorite: '',
  isSaved: false,
  type: 'txt',
  tags: [],
})

const radioActive = (event) => {
  documentInfo.value.type = event?.target?.id || 'txt'
}

/** Editor 인스턴스 */
const editorRoot = ref(null)
let editor = null

const safeHtml = computed(() => (typeof props.contentEditor === 'string' ? props.contentEditor : ''))

/** 파일 input */
const fileInputRef = ref(null)

/** 마운트 */
onMounted(async () => {
  try {
    editor = new Editor({
      el: editorRoot.value,
      height: '520px',
      initialEditType: 'wysiwyg',
      previewStyle: 'vertical',
      usageStatistics: false,
      initialValue: '',
      toolbarItems: [
        ['heading', 'bold', 'italic', 'strike'],
        ['hr', 'quote'],
        ['ul', 'ol', 'task'],
        ['table', 'link', 'image'], // image 버튼
        ['code', 'codeblock'],
        ['scrollSync'],
      ],
      hooks: {
        // 업로드 없이 DataURL로 바로 삽입
        async addImageBlobHook(blob, callback) {
          try {
            const dataUrl = await fileToDataURL(blob)
            callback(dataUrl, blob?.name || 'image')
          } catch (err) {
            console.error('이미지 처리 실패:', err)
            alert('이미지를 삽입할 수 없습니다.')
          }
        },
      },
    })

    // 클립보드 이미지 붙여넣기 지원 (Ctrl+V)
    enablePasteImageFromClipboard()

    // 초기 콘텐츠
    if (safeHtml.value) {
      try { editor.setHTML(safeHtml.value) }
      catch (err) { console.warn('setHTML 실패 → markdown 폴백:', err); editor.setMarkdown(safeHtml.value || '') }
    }

    emit('editor-ready', { getHTML, getMarkdown, setHTML, setMarkdown, clear })
  } catch (err) {
    console.error('Toast UI Editor 초기화 실패:', err)
  }
})

/** Blob -> DataURL */
function fileToDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result)
    reader.onerror = (e) => reject(e)
    reader.readAsDataURL(file)
  })
}

/** 붙여넣기 이미지 처리 */
function enablePasteImageFromClipboard() {
  const root = editorRoot.value
  if (!root) return
  root.addEventListener('paste', async (evt) => {
    try {
      const items = evt.clipboardData?.items || []
      for (const it of items) {
        if (it.kind === 'file') {
          const file = it.getAsFile()
          if (file && file.type?.startsWith('image/')) {
            evt.preventDefault()
            const dataUrl = await fileToDataURL(file)
            editor?.exec('addImage', { imageUrl: dataUrl, altText: file.name || 'image' })
            break
          }
        }
      }
    } catch (err) {
      console.error('클립보드 이미지 붙여넣기 실패:', err)
    }
  })
}


/** 파일 선택 처리(DataURL 삽입) */
async function onPickImage(e) {
  const file = e?.target?.files?.[0]
  if (!file) return
  try {
    const dataUrl = await fileToDataURL(file)
    // 커서 위치 문제 방지용(경우에 따라 필요)
    editor?.insertText && editor.insertText(' ')
    editor?.exec('addImage', { altText: file.name || 'image', imageUrl: dataUrl })
  } catch (err) {
    console.error('이미지 선택 처리 실패:', err)
    alert('이미지를 삽입할 수 없습니다.')
  } finally {
    if (fileInputRef.value) fileInputRef.value.value = ''
  }
}

/** contentEditor 변경 → 동기화 */
watch(() => props.contentEditor, (v) => {
  if (!editor) return
  const next = typeof v === 'string' ? v : ''
  try { editor.setHTML(next) }
  catch (err) { console.warn('setHTML 실패, markdown 폴백:', err); editor.setMarkdown(next || '') }
})

/** 오버레이 시 읽기전용 */
watch(() => props.showEditorOverlay, (v) => {
  if (!editor) return
  try {
    if (typeof editor.setReadOnly === 'function') editor.setReadOnly(!!v)
  } catch (err) {
    console.warn('읽기전용 전환 실패:', err)
  }
}, { immediate: true })

/** 저장 */
const handleSendData = () => {
  try {
    emit('save-txt', {
      ...documentInfo.value,
      html: getHTML(),
      markdown: getMarkdown(),
    })
    isOpenModal.value = false
  } catch (err) {
    console.error('저장 처리 중 오류:', err)
  }
}

/** ===== 복사===== */
// function onClickCopy() {
//   try {
//     const html = getHTML()
//     const txt = htmlToPlain(html)
//     copyTextViaTextarea(txt)   // ↓ 2) 함수 사용
//     toast.info('텍스트가 클립보드에 복사되었습니다.');
//
//   } catch (err) {
//     console.error('복사 실패:', err)
//     toast.info('복사에 실패했습니다.');
//
//   }
// }
/** 클립보드 복사: textarea 방식(HTTP에서도 동작) */
// function copyTextViaTextarea(text) {
//   const ta = document.createElement('textarea')
//   ta.value = String(text ?? '')
//   ta.setAttribute('readonly', '')
//   ta.style.position = 'fixed'
//   ta.style.top = '-1000px'
//   ta.style.left = '-1000px'
//   document.body.appendChild(ta)
//
//   // iOS 대응: 선택 범위 보장
//   if (/ipad|iphone|ipod/i.test(navigator.userAgent)) {
//     const range = document.createRange()
//     range.selectNodeContents(ta)
//     const sel = window.getSelection()
//     sel.removeAllRanges()
//     sel.addRange(range)
//     ta.setSelectionRange(0, 999999)
//   } else {
//     ta.select()
//   }
//
//   try {
//     document.execCommand('copy')
//   } finally {
//     document.body.removeChild(ta)
//   }
// }

/** HTML → 텍스트 (간단 변환) */
// function htmlToPlain(html) {
//   const div = document.createElement('div')
//   div.innerHTML = String(html || '')
//
//   // 줄바꿈 보강
//   div.querySelectorAll('br').forEach(br => br.replaceWith('\n'))
//   div.querySelectorAll('p, li').forEach(el => el.append('\n'))
//   // 표는 탭/개행 간단 처리
//   div.querySelectorAll('tr').forEach(tr => tr.append('\n'))
//   div.querySelectorAll('td, th').forEach(cell => cell.append('\t'))
//
//   const text = div.textContent || ''
//   return text.replace(/\t+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim()
// }


/** ===== Helper ===== */
function getHTML() {
  try { return editor ? editor.getHTML() : '' }
  catch (err) { console.error('getHTML 실패:', err); return '' }
}
function getMarkdown() {
  try { return editor ? editor.getMarkdown() : '' }
  catch (err) { console.error('getMarkdown 실패:', err); return '' }
}
function setHTML(html) {
  try { if (editor) editor.setHTML(String(html || '')) }
  catch (err) { console.warn('setHTML 실패, markdown 폴백:', err); if (editor) editor.setMarkdown(String(html || '')) }
}
function setMarkdown(md) {
  try { if (editor) editor.setMarkdown(String(md || '')) }
  catch (err) { console.error('setMarkdown 실패:', err) }
}
function clear() {
  try { if (editor) editor.setHTML('') }
  catch (err) { console.warn('clear 실패, markdown 폴백:', err); if (editor) editor.setMarkdown('') }
}

// TAG 핸들링
function handleAddTag(tag) {
  documentInfo.value.tags.push(tag)
}
function handleDeleteTag(tag) {
  documentInfo.value.tags = documentInfo.value.tags.filter((t) => t !== tag)
}

onBeforeUnmount(() => {
  try {
    if (editor) {
      editor.destroy()
      editor = null
    }
  } catch (err) {
    console.error('Editor destroy 실패:', err)
  }
})
</script>
