import { ref } from 'vue'
import { fileManageApi } from '@/domains/fileMange/infrastructure/fileManageApi'

const files = ref<any[]>([])

export function useFileManage() {
  const usage = ref('')
  const loading = ref(false)
  const error = ref(null)
  const uploadStatus = ref(null)

  async function loadFiles({ group, page, pageSize, keyword }: { group: any; page: any; pageSize: any; keyword: any }) {
    const res = await fileManageApi.getFileList(group)
    files.value = res.items.map(item => ({ ...item, selected: false }))
    usage.value = res.usage
    return res
  }

  async function deleteFile(fileId: any) {
    await fileManageApi.fileManageDeleteFile(fileId)
    files.value = files.value.filter(f => f.id !== fileId)
  }

  async function downloadFile(fileId: any) {
    return  await fileManageApi.fileManageDownloadFile(fileId)
  }

  /**
   * S-Box 파일 업로드
   */
  async function uploadSBoxFiles(agentCode: string, documentKeys: string[], worker: { email: string; name: string }, folderName: string = 'sbox', sessionId: string) {
    loading.value = true
    error.value = null

    try {
      const result = await fileManageApi.uploadSBoxFiles(agentCode, documentKeys, worker, folderName, sessionId)
      
      if (result.success) {
        return { success: true, data: result.data }
      } else {
        // API에서 반환된 에러 메시지를 그대로 사용
        const errorMessage = result.error || 'S-Box 파일 업로드에 실패했습니다.'
        return { success: false, error: errorMessage }
      }
    } catch (err: any) {
      const errorMessage = err.message || 'S-Box 파일 업로드 중 오류가 발생했습니다.'
      return { success: false, error: errorMessage }
    } finally {
      loading.value = false
    }
  }

  /**
   * 업로드 상태 확인
   */
  async function checkUploadStatus(agentCode: string) {
    try {
      const result = await fileManageApi.checkUploadStatus(agentCode)
      
      if (result.success) {
        uploadStatus.value = result.data
        return { success: true, data: result.data }
      } else {
        return { success: false, error: result.error }
      }
    } catch (err: any) {
      const errorMessage = err.message || '업로드 상태 확인 중 오류가 발생했습니다.'
      return { success: false, error: errorMessage }
    }
  }

  /**
   * 최신 업로드 상태 확인 (SSE)
   */
  async function getLatestUploadStatus(agentCode: string, sessionId: string, onMessage?: (data: any) => void, onError?: (error: any) => void, onClose?: () => void) {
    try {
      const result = await fileManageApi.getLatestUploadStatus(agentCode, sessionId)
      
      // 에러가 반환된 경우
      if (result && typeof result === 'object' && 'success' in result && result.success === false) {
        return result
      }
      
      // EventSource가 반환된 경우
      const eventSource = result as EventSource
      
      // onMessage 콜백이 있으면 설정, 없으면 기본 처리
      if (onMessage) {
        eventSource.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data)
            uploadStatus.value = data
            onMessage(data)
          } catch (parseError) {
            console.warn('SSE 데이터 파싱 실패:', parseError)
          }
        }
      }

      if (onError) {
        eventSource.onerror = (error) => {
          console.error('SSE 에러:', error)
          onError(error)
        }
      }

      if (onClose) {
        eventSource.addEventListener('close', () => {
          eventSource.close()
          onClose()
        })
      }

      return eventSource
    } catch (err: any) {
      const errorMessage = err.message || 'SSE 연결 중 오류가 발생했습니다.'
      return { 
        success: false, 
        error: errorMessage 
      }
    }
  }

  return {
    files,
    usage,
    loading,
    error,
    uploadStatus,
    loadFiles,
    deleteFile,
    downloadFile,
    uploadSBoxFiles,
    checkUploadStatus,
    getLatestUploadStatus,
  }
}
