import { fileManageApi } from '../infrastructure/fileManageApi'

export async function uploadFileRequest(file: File) {
  return await fileManageApi.uploadFileRequest(file)
}
