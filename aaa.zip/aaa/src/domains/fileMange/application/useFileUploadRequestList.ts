import { fileManageApi } from '../infrastructure/fileManageApi'

export async function useFileUploadRequestList(params: {
  groupType: string
  page: number
  pageSize: number
  keyword?: string
}) {
  const res = await fileManageApi.getUploadRequestList(params)
  return {
    items: res.items ?? [],
    totalCount: res.totalCount ?? 0
  }
}
