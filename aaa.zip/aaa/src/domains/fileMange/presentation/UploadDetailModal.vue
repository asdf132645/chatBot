<template>
  <Teleport to="body">
    <div v-if="uploadedFiles.length > 0" class="modal-container">
      <div class="modal-box" :style="{ width: '400px' }">
        <div class="modal-header">
          <h3>{{ $t('uploaddetailmodal.uploaddetailmodal_key1') }}</h3>
        </div>

        <div class="modal-body">
          <div class="upload-summary">{{ uploadStatusMessage }}</div>

          <ul class="upload-file-list">
            <li
              v-for="file in uploadedFiles"
              :key="file.id"
              class="upload-file-item"
              :class="{
                cancelled: file.status === 'CANCELED',
                failed: file.status === 'FAILED'
              }"
            >
              <div class="file-info-wrapper">
                <span>
                  {{ file.fileName }}
                  <template v-if="file.status === 'CANCELED'">{{ $t('uploaddetailmodal.uploaddetailmodal_key2') }}</template>
                </span>

                <button
                  v-if="file.status === 'READY'"
                  class="cancel-btn"
                  @click.stop="cancelUpload(file.id)"
                >{{ $t('uploaddetailmodal.uploaddetailmodal_key3') }}</button>
              </div>
              <BaseIcon :name="statusIcon(file.status)" :size="14" />
            </li>
          </ul>
        </div>

        <div class="modal-footer" v-if="!uploading">
          <button class="btn" @click="clearUploads">{{ $t('uploaddetailmodal.uploaddetailmodal_key4') }}</button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup>
import { computed, defineProps } from 'vue'
import BaseIcon from '@/component/BaseIcon.vue'

const props = defineProps({
  uploadedFiles: Array,
  uploading: Boolean,
  cancelUpload: Function,
  clearUploads: Function,
})

const statusIcon = (status) => {
  switch (status) {
    case 'READY': return 'UploadStatusCircle'
    case 'UPLOADING': return 'UploadStatusRefresh'
    case 'COMPLETED': return 'UploadStatusCheck'
    case 'REJECTED': return 'UploadStatusAlert'
    case 'FAILED': return 'UploadStatusAlert'
    case 'CANCELED': return 'UploadStatusClose'
    default: return 'Help'
  }
}

const uploadStatusMessage = computed(() => {
  const total = props.uploadedFiles.length
  const failed = props.uploadedFiles.filter(f => f.status === 'FAILED').length

  if (props.uploading) {
    return `${total}개 파일 업로드 중`
  }

  if (failed > 0) {
    return `${total}개 중 ${total - failed}개 파일 업로드 완료`
  }

  return `${total}개 파일 업로드 완료`
})
</script>

