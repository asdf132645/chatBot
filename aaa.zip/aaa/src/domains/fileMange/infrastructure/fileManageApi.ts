import { httpClient } from '@/shared/http/httpClient'
import { CHATBOT_FILE_MGR_URL, GENAI_SERVER_URL } from '@/shared/config/endpoints';
import { resolveAgwUrlGenAiServer } from '@/shared/config/env'


export const fileManageApi = {

  // 문서 크기 조회 API
  async getDocsSize(agentCode: string) {
    return await httpClient.get(`${CHATBOT_FILE_MGR_URL}/knowledge-docs/agents/${agentCode}/docs/size`)
  },

  // 인덱스 크기 재계산 API
  async recalculateIndexSize(agentCode: string) {
    return await httpClient.post(`${CHATBOT_FILE_MGR_URL}/knowledge-docs/agents/index-size/recalculate`, {
      agentCode
    })
  },

  // 도메인 노드 삭제 API
  async deleteDomainNode(agentCode: string, domainId: string) {
    return await httpClient.delete(`${GENAI_SERVER_URL}/agent-code/${agentCode}/node/domain/${domainId}?domain_id=${domainId}`)
  },

  // 파일 업로드 취소 하는 API ( 해당 부분은 따로 테스트 할 필요가 없어서 주석 처리 안 함 url 만 변경해서 사용 하시면 됩니다. )
  async cancelUploadRequest (fileId: any) {
    return await httpClient.get(`${GENAI_SERVER_URL}/fake/file-manage/cancel/${fileId}`)
  },

  // 반려 하는 API ( 해당 부분은 따로 테스트 할 필요가 없어서 주석 처리 안 함 url 만 변경해서 사용 하시면 됩니다. )
  async rejectFilesApi({ ids, reason }: { ids: string[], reason: string }) {
    return await httpClient.post(`${GENAI_SERVER_URL}/fake/file-manage/cancel`, {
      ids,
      reason,
    })
  },


  // 임시 가짜 api 목업
  async getFileList(groupType: 'corp' | 'dept') {

    const corpItems = [
      {
        id: '1',
        fileName: '파일1.pdf',
        fileSize: '2MB',
        userName: '강지영',
        userId: 'kjy1',
        updateDate: '2025.05.30',
      },
      {
        id: '2',
        fileName: '파일2.hwp',
        fileSize: '1MB',
        userName: '강',
        userId: 'ㅏㅓㅛ2',
        updateDate: '2025.05.31',
      },
      {
        id: '3',
        fileName: '파일3.pptx',
        fileSize: '5MB',
        userName: '지영',
        userId: 'kjy3',
        updateDate: '2025.06.01',
      },
    ]

    const deptItems = [
      {
        id: '1',
        fileName: '파일1deptData.pdf',
        fileSize: '2MB',
        userName: '강지영',
        userId: 'kjy1',
        updateDate: '2025.05.30',
      },
      {
        id: '2',
        fileName: '파일2deptData.hwp',
        fileSize: '1MB',
        userName: '강',
        userId: 'ㅏㅓㅛ2',
        updateDate: '2025.05.31',
      },
      {
        id: '3',
        fileName: '파일3deptData.pptx',
        fileSize: '5MB',
        userName: '지영',
        userId: 'kjy3',
        updateDate: '2025.06.01',
      },
    ]

    const data = groupType === 'corp' ? corpItems : deptItems

    return Promise.resolve({
      usage: groupType === 'corp' ? '1.2GB / 30GB' : '820MB / 30GB',
      totalCount: data.length,
      page: 1,
      pageSize: 10,
      items: data,
    })
  },
  // 승인 API 목업
   async  approveFilesApi(fileIds: string[]): Promise<{ success: boolean }> {
    return Promise.resolve({ success: true })
  },

  async fileManageDownloadFile(fileId: string) {
    return Promise.resolve({ success: true, message: '다운로드 성공' })
  },

  async fileManageDeleteFile(fileId: string) {
    return Promise.resolve({ success: true, message: '삭제 성공' })
  },



  // 가짜 목업 데이터 리스트 (업로드 신청 용)
  async getUploadRequestList(params: {
    groupType: string
    page: number
    pageSize: number
    keyword?: string
    approvalStatus: string
  }) {
    const total = 6
    const success = 4
    const fail = 2

    return {
      items: [
        {
          id: '1',
          fileName: '업로드문서1.pdf',
          fileSize: '2.3MB',
          proposeDate: '2024-05-30',
          status: 'COMPLETED',
          approvalDate: '2024-06-01',
          approver: 'kang',
          approverId: 'ji',
          rejectReason: '',
          uploadGroupMeta: { total, success, fail }
        },
        {
          id: '2',
          fileName: '통계자료.csv',
          fileSize: '1.2MB',
          proposeDate: '2024-05-28',
          status: 'REJECTED',
          approvalDate: '2024-05-29',
          approver: 'kjy',
          approverId: 'kjy111',
          rejectReason: '형식 오류',
          uploadGroupMeta: { total, success, fail }
        },
        {
          id: '3',
          fileName: '진행중파일.docx',
          fileSize: '3.0MB',
          proposeDate: '2024-06-01',
          status: 'UPLOADING',
          approvalDate: '-',
          approver: '-',
          approverId: '-',
          rejectReason: '',
          uploadGroupMeta: { total, success, fail }
        },
        {
          id: '4',
          fileName: '검토중파일.pptx',
          fileSize: '4.7MB',
          proposeDate: '2024-06-01',
          status: 'READY',
          approvalDate: '-',
          approver: '-',
          approverId: '-',
          rejectReason: '',
          uploadGroupMeta: { total, success, fail }
        },
        {
          id: '5',
          fileName: '실패한파일.xls',
          fileSize: '1.9MB',
          proposeDate: '2024-06-01',
          status: 'FAILED',
          approvalDate: '-',
          approver: '-',
          approverId: '-',
          rejectReason: '네트워크 오류',
          uploadGroupMeta: { total, success, fail }
        },
        {
          id: '6',
          fileName: '사용자취소.hwp',
          fileSize: '2.1MB',
          proposeDate: '2024-06-01',
          status: 'CANCELED',
          approvalDate: '-',
          approver: '-',
          approverId: '-',
          rejectReason: '',
          uploadGroupMeta: { total, success, fail }
        }
      ],
      totalCount: 6
    }
  },
  // 업로드 신청 파일 전송 부분 가짜 데이터
  async uploadFileRequest(file: any, uploadGroupMeta: any) {
    const formData = new FormData()
    formData.append('file', file)

    const initialData = {
      id: String(Date.now()),
      fileName: file.name,
      fileSize: (file.size / 1024 / 1024).toFixed(1) + 'MB',
      proposeDate: new Date().toISOString().slice(0, 10),
      status: 'UPLOADING',
      approvalDate: '-',
      approver: '-',
      approverId: '-',
      rejectReason: '',
      uploadGroupMeta // 전체 파일의 대한 정보
    }

    await new Promise((resolve) => setTimeout(resolve, 1000))

    return {
      success: true,
      message: '업로드 완료',
      data: {
        ...initialData,
        status: 'COMPLETED'
      }
    }
  },

  // S-Box 관련 API
  /**
   * S-Box 파일 업로드
   */
  async uploadSBoxFiles(agentCode: string, documentKeys: string[],  worker: { email: string; name: string }, folderName: string = 'sbox', sessionId: string ) {
    const baseUrl = resolveAgwUrlGenAiServer('https://bb8-filemgr-dev.dev.helpnow.ai');
    const url = `${baseUrl}/knowledge-docs/docs/sbox/upload`;
    
    const payload = {
      metainfo: {
        agentCode,
        domainNode: folderName,
        subcategoryNode: '',
        worker,
        desc: '',
        tags: [],
        sessionId: sessionId
      },
      documentKeys
    };

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      // API 응답에서 status가 failure인 경우 처리
      if (data.status === 'failure') {
        return { 
          success: false, 
          error: data.message || 'S-Box 파일 업로드에 실패했습니다.' 
        };
      }
      
      return { success: true, data };
    } catch (error: any) {
      console.error('S-Box 파일 업로드 실패:', error);
      return { 
        success: false, 
        error: error.message || 'S-Box 파일 업로드 중 오류가 발생했습니다.' 
      };
    }
  },

  /**
   * 업로드 상태 확인 (일반 HTTP)
   */
  async checkUploadStatus(agentCode: string) {
    const baseUrl = resolveAgwUrlGenAiServer('https://bb8-filemgr-dev.dev.helpnow.ai');
    const url = `${baseUrl}/knowledge-docs/docs/upload/${agentCode}/status/check`;
    
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return { success: true, data };
    } catch (error: any) {
      console.error('업로드 상태 확인 실패:', error);
      return { 
        success: false, 
        error: error.message || '업로드 상태 확인 중 오류가 발생했습니다.' 
      };
    }
  },

  /**
   * 최신 업로드 상태 확인 (SSE)
   */
  async getLatestUploadStatus(agentCode: string, sessionId: string): Promise<EventSource | { success: false; error: string }> {
    const baseUrl = resolveAgwUrlGenAiServer('https://bb8-filemgr-dev.dev.helpnow.ai');
    const url = `${baseUrl}/knowledge-docs/docs/upload/${agentCode}/status/latest?sessionId=${sessionId}`;
    
    try {
      const eventSource = new EventSource(url);

      return eventSource;
    } catch (error: any) {
      console.error('SSE 연결 실패:', error);
      return { 
        success: false, 
        error: error.message || 'SSE 연결 중 오류가 발생했습니다.' 
      };
    }
  }

}
