// src/domains/report/domain/reportTemplateModel.js

// API 응답 -> 뷰 모델 매핑 (선언형, 간결)
export function toReportTemplate(entity) {
  return {
    id: entity?.id || '',
    title: entity?.title || '',
    description: entity?.description || '',
    content: entity?.content || '',
    isPinned: !!entity?.is_pinned,
    icon: entity?.icon || '',
    createdAt: entity?.created_at || '',
  }
}

export function toReportTemplates(list) {
  return Array.isArray(list) ? list.map(toReportTemplate) : []
}

export function toPageInfo(meta) {
  return {
    currentPage: meta?.current_page ?? 1,
    perPage: meta?.per_page ?? 8,
    totalCount: meta?.total_count ?? 0,
    totalPages: meta?.total_pages ?? 0,
    hasNext: !!meta?.has_next,
    hasPrev: !!meta?.has_prev,
    isFirstPage: !!meta?.is_first_page,
    isLastPage: !!meta?.is_last_page,
  }
}
