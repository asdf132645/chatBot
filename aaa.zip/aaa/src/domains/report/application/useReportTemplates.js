// src/domains/report/application/useReportTemplates.js
import { ref } from 'vue'
import { reportApi } from '../infrastructure/reportApi'
import { toReportTemplates, toPageInfo } from '../domain/reportTemplateModel'

export function useReportTemplates() {
  const loading = ref(false)
  const templates = ref([])
  const pageInfo = ref({
    currentPage: 1, perPage: 8, totalCount: 0, totalPages: 0,
    hasNext: false, hasPrev: false, isFirstPage: true, isLastPage: true,
  })

  async function load(agentCode, { accessLevel = 'public', page = 1, perPage = 8, keyword } = {}) {
    loading.value = true
    try {
      const { data } = await reportApi.getReportTemplates(agentCode, {
        access_level: accessLevel, page, per_page: perPage, keyword,
      })
      templates.value = toReportTemplates(data?.templates || []);
      // console.log(templates.value)
      pageInfo.value = toPageInfo(data?.page_info || {})
    } finally {
      loading.value = false
    }
  }

  async function create(agentCode, payload) {
    return reportApi.createReportTemplate(agentCode, payload)
  }

  async function update(agentCode, templateId, payload) {
    return reportApi.updateReportTemplate(agentCode, templateId, payload)
  }

  async function remove(agentCode, templateId) {
    return reportApi.deleteReportTemplate(agentCode, templateId)
  }

  return { loading, templates, pageInfo, load, create, update, remove }
}
