// src/domains/report/infrastructure/reportApi.ts
import { httpClient } from '@/shared/http/httpClient'
import { GENAI_SERVER_URL } from '@/shared/config/endpoints'

export type AccessLevel = 'private' | 'public'

export interface GetReportTemplatesParams {
  access_level?: AccessLevel
  page?: number
  per_page?: number
  keyword?: string
}

export interface UpsertReportTemplateBody {
  title?: string | null
  description?: string | null
  content?: string | null
  is_pinned?: boolean | null
}

// 안전 변환: API가 요구하는 타입으로 강제
function normalizeBody(body: UpsertReportTemplateBody): Required<UpsertReportTemplateBody> {
  return {
    title: typeof body?.title === 'string' ? body.title : '',
    description: typeof body?.description === 'string' ? body.description : '',
    content: typeof body?.content === 'string' ? body.content : '',
    is_pinned: typeof body?.is_pinned === 'boolean' ? body.is_pinned : false,
  }
}

export const reportApi = {
  async getReportTemplates(agentCode: string, params: GetReportTemplatesParams = {}) {
    const { access_level = 'public', page = 1, per_page = 8, keyword } = params
    return httpClient.get(
      `${GENAI_SERVER_URL}/agent-code/${agentCode}/report`,
      { params: { access_level, page, per_page, keyword } }
    )
  },

  async createReportTemplate(agentCode: string, body: UpsertReportTemplateBody) {
    const payload = normalizeBody(body)
    return httpClient.post(
      `${GENAI_SERVER_URL}/agent-code/${agentCode}/report`,
      payload
    )
  },

  async updateReportTemplate(agentCode: string, templateId: string, body: UpsertReportTemplateBody) {
    const payload = normalizeBody(body)
    return httpClient.put(
      `${GENAI_SERVER_URL}/agent-code/${agentCode}/report/${templateId}`,
      payload
    )
  },

  async deleteReportTemplate(agentCode: string, templateId: string) {
    return httpClient.delete(
      `${GENAI_SERVER_URL}/agent-code/${agentCode}/report/${templateId}`
    )
  },
}
