// Agent API 기본 설정
import { AGENT_SERVER_URL, AGENT_CHAT_STREAM_PATH } from '@/shared/config/endpoints';
import { getAccessToken } from '@/shared/http/tokens'

/**
 * Agent Retrieve API - 컨텍스트 데이터를 가져오는 API (사용하지 않음)
 * 새로운 API는 retrieve와 generate가 통합됨
 */
export async function retrieveAgentContext() {
  // 새로운 API에서는 retrieve 단계가 없으므로 빈 결과 반환
  return {
    documents: [],
    concat_context: '',
    contexts: []
  };
}

/**
 * Agent Stream API - CrewAI 실행 결과를 SSE로 스트리밍하는 API
 * @param {Object} params - 파라미터
 * @param {string} params.query - 사용자 쿼리
 * @param {string} params.sessionId - 세션 ID
 * @param {string} params.agentCode - 에이전트 코드 (선택사항)
 * @param {string} params.language - 언어 코드 (기본값: "ko")
 * @returns {Promise<Response>} SSE 스트림 응답
 */
export async function generateAgentResponse({ query, sessionId, agentCode = null, language = "ko", config = {} }) {
  const url = `${AGENT_SERVER_URL}${AGENT_CHAT_STREAM_PATH}`;
  
  const requestData = {
    query: query,
    session_id: sessionId,
    agent_code: agentCode,
    language: language
  };

  try {
    const token = getAccessToken();
    const excludeToken = config?.excludeToken ?? false;

    // fetch 헤더 구성
    const headers = new Headers({
      'Content-Type': 'application/json'
    });

    // 토큰 자동 부착
    if (token && !excludeToken) {
      headers.set('Authorization', `Bearer ${token}`);
    }

    const response = await fetch(url, {
      method: 'POST',
      headers, // new Headers() 객체 그대로 전달
      body: JSON.stringify(requestData)
    });

    if (!response.ok) {
      const errorMessage = await response.text().catch(() => '');
      const error = new Error(`HTTP error! status: ${response.status}`);
      error.status = response.status;
      error.message = errorMessage || `HTTP error! status: ${response.status}`;
      throw error;
    }

    return response;
  } catch (error) {
    console.error('Agent Stream 오류:', error);
    throw error;
  }
}

/**
 * Agent 채팅을 위한 통합 함수
 * @param {Object} params - 파라미터
 * @param {string} params.query - 사용자 쿼리
 * @param {string} params.sessionId - 세션 ID
 * @param {string} params.agentCode - 에이전트 코드 (선택사항)
 * @param {string} params.language - 언어 코드 (기본값: "ko")
 * @param {Function} params.onStream - 스트림 데이터 콜백
 * @returns {Promise<Object>} 결과
 */
export async function agentChat({ query, sessionId, agentCode = null, language = "ko", onStream, config = {} }) {
  try {
    // 1. Agent Stream API 호출
    const response = await generateAgentResponse({
      query,
      sessionId,
      agentCode,
      language,
      config
    });

    // 2. SSE 스트림 처리
    if (onStream && response.body) {
      const reader = response.body.getReader();
      const decoder = new TextDecoder();

      try {
        // eslint-disable-next-line no-constant-condition
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');
          
          let currentEvent = 'message';
          let currentData = '';

          for (const line of lines) {
            if (line.startsWith('event:')) {
              currentEvent = line.slice(6).trim();
              continue;
            }
            
            if (line.startsWith('data:')) {
              currentData = line.replace(/^data:\s?/, '');
              
              // 완료 신호 처리
              if (currentEvent === 'message_stop' || currentData === '[DONE]') {
                console.log('Agent Stream 완료 신호 수신');
                onStream({ done: true });
                return;
              }
              
              // 각 이벤트 타입별 처리
              if (currentEvent === 'thinking_delta') {
                // thinking_delta: AI가 생각하는 과정
                onStream({
                  data: {
                    type: 'thinking',
                    content: currentData
                  }
                });
              } else if (currentEvent === 'input_json_delta') {
                // input_json_delta: 입력 처리 상태
                onStream({
                  data: {
                    type: 'input_status',
                    content: currentData
                  }
                });
              } else if (currentEvent === 'text_delta') {
                // text_delta: 실제 답변 텍스트
                onStream({
                  data: {
                    type: 'text',
                    content: currentData
                  }
                });
              } else if (currentEvent === 'message_stop') {
                // message_stop: 응답 끝 알림
                console.log('Agent Stream 완료 신호 수신 (message_stop)');
                onStream({ done: true });
                return;
              }
              
              continue;
            }
          }
        }
      } finally {
        reader.releaseLock();
        // 스트림이 정상적으로 종료된 경우 완료 신호 전달
        if (onStream) {
          console.log('Agent Stream 정상 종료');
          onStream({ done: true });
        }
      }
    }

    return {
      success: true,
      response: response
    };

  } catch (error) {
    console.error('Agent 채팅 오류:', error);
    throw error;
  }
}
