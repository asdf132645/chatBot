<template>
  <div class="agent-answer-wrapper">
    <!-- Agent 답변 목록 -->
    
    
  </div>
</template>

<script setup>
import { ref, defineProps, defineEmits, defineExpose } from 'vue';
import AgentAnswerContent from './AgentAnswerContent.vue';
import { useAgentChat } from '../application/useAgentChat';

// Props
const props = defineProps({
  sessionId: {
    type: String,
    required: true
  },
  multiDomainIds: {
    type: Array,
    default: () => []
  },
  insightPromptId: {
    type: String,
    default: '4bd9cbed-9346-4dd3-b5e5-ff4c2a5514eb'
  }
});

// Emits
const emit = defineEmits([]);

// Agent 채팅 훅 사용
const {
  chatList,
  isStreaming,
  searchList,
  referenceList,
  queryLoading,
  startAgentChat,
  toggleAnswerState,
  clearChatList,
  updateConfig
} = useAgentChat();

// Refs
const agentQueryInputer = ref(null);



/**
 * 쿼리 제출 처리
 * @param {string} query - 사용자 쿼리
 */
async function handleSubmitQuery(query) {
  if (!query || !query.trim()) {
    console.warn('빈 쿼리입니다.');
    return;
  }

  if (isStreaming.value) {
    console.warn('이미 처리 중입니다.');
    return;
  }

  try {
    emit('queryProcess', true);
    
    await startAgentChat({
      query: query.trim(),
      sessionId: props.sessionId,
      multiDomainIds: props.multiDomainIds,
      insightPromptId: props.insightPromptId
    });

    emit('answerComplete', {
      query: query.trim(),
      answer: chatList.value[chatList.value.length - 1]?.answer || ''
    });

  } catch (error) {
    console.error('Agent 쿼리 처리 오류:', error);
  } finally {
    emit('queryProcess', false);
  }
}

/**
 * 답변 상태 토글 처리
 * @param {Object} params - 토글 파라미터
 */


/**
 * 부모에서 호출할 수 있는 메서드들
 */
defineExpose({
  /**
   * 부모에서 쿼리 전송
   * @param {string} query - 쿼리
   */
  
});
</script>

<style scoped>

</style>
