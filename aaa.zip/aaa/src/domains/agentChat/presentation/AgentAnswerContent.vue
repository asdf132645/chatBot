<template>
  <div :class="{'agent-chat-answer-item':true,'last-answer':lastAnswer}" :id="`answer-${answer.id}`">
    <div class="agent-chat-answer-right-wrapper">
      <!-- 제목 -->
      <h2 class="agent-chat-answer-title agent-chat-answer-box">
        <div v-if="!answer.title" class="agent-chat-skeleton">
          <div class="agent-chat-skeleton-line" style="width: 60%"></div>
        </div>
        <span v-else>{{ answer.title }}</span>
      </h2>
      
      <!-- 과정분석 -->
      <div class="agent-chat-answer-procedure-wrapper">
        <div v-if="!answer.searchList || !answer.searchList.length" class="agent-chat-skeleton">
          <div class="agent-chat-skeleton-line" style="width: 50%"></div>
          <div class="agent-chat-skeleton-line" style="width: 70%"></div>
        </div>
        <div class="agent-chat-answer-box-div" v-else>
          <div class="state-head">
            <div class="state-base state-title">
              <img class="" :src="require('@/assets/images/topology-star-3.svg')" />
              <span class="state-title-text">처리 과정</span>
            </div>
            <div class="state-base state-fold" @click="toggleState()">
              <BaseIcon name="ArrowTailUp" :size="20" v-if="!isStateOpen" />
              <BaseIcon name="ArrowTailDown" :size="20" v-if="isStateOpen" />
            </div>
          </div>
          <transition name="slide">
            <div class="state-body" ref="stateBody" v-if="isStateOpen">
              <transition-group name="fade-list" tag="div">
                <div class="state-base state-detail" v-for="searchItem in answer.searchList" :key="searchItem.id">
                  <img class="blinking" :src="require('@/assets/images/search.svg')"
                       v-if="searchItem.status === 'search'" />
                  <img class="blinking" :src="require('@/assets/images/loading.svg')"
                       v-if="searchItem.status === 'loading'" />
                  <img class="blinking" :src="require('@/assets/images/check.svg')"
                       v-if="searchItem.status === 'check'" />
                  <span class="state-detail-target-info text-truncate">{{ searchItem.keyword }}</span>
                  <span class="state-detail-target-title">{{ searchItem.statusDetail }}</span>
                </div>
              </transition-group>
              <div class="state-base state-detail state-result">
                <img class="blinking" :src="require('@/assets/images/loading.svg')" v-if="queryLoading" />
                <img class="blinking" :src="require('@/assets/images/check.svg')" v-if="!queryLoading" />
                <span class="state-detail-target-title state-last">
                    <span v-if="queryLoading">{{ t('answercontent.answercontent_key2') }}</span>
                    <span v-if="!queryLoading">{{ t('answercontent.answercontent_key3') }}</span>
                  </span>
              </div>
            </div>
          </transition>
        </div>
      </div>

      <!-- 답변 텍스트 -->
      <template v-if="answer.isMultiAnswer">
        <div class="agent-chat-multi-answer-text-wrapper agent-chat-answer-box">
          <div class="agent-chat-multi-answer-text genai-answer-text">
            <div v-if="answer.isLoading" class="agent-chat-skeleton">
              <div class="agent-chat-skeleton-line" style="width: 40%"></div>
              <div class="agent-chat-skeleton-line" style="width: 90%"></div>
              <div class="agent-chat-skeleton-line" style="width: 80%"></div>
              <div class="agent-chat-skeleton-line" style="width: 70%"></div>
              <div class="agent-chat-skeleton-line" style="width: 85%"></div>
              <div class="agent-chat-skeleton-line" style="width: 60%"></div>
            </div>
            <div v-else v-html="getDisplayContent(answer)"></div>
          </div>          
          <div class="agent-chat-multi-answer-text genai-answer-text">
            <div v-if="answer.isLoading1" class="agent-chat-skeleton">
              <div class="agent-chat-skeleton-line" style="width: 40%"></div>
              <div class="agent-chat-skeleton-line" style="width: 90%"></div>
              <div class="agent-chat-skeleton-line" style="width: 80%"></div>
              <div class="agent-chat-skeleton-line" style="width: 70%"></div>
              <div class="agent-chat-skeleton-line" style="width: 85%"></div>
              <div class="agent-chat-skeleton-line" style="width: 60%"></div>
            </div>
            <div v-else v-html="getDisplayContent1(answer)"></div>
          </div>          
        </div>
      </template>

      <template v-else>
        <div class="agent-chat-answer-text-wrapper agent-chat-answer-box">
          <div v-if="answer.isLoading" class="agent-chat-skeleton">
            <div class="agent-chat-skeleton-line" style="width: 40%"></div>
            <div class="agent-chat-skeleton-line" style="width: 90%"></div>
            <div class="agent-chat-skeleton-line" style="width: 80%"></div>
            <div class="agent-chat-skeleton-line" style="width: 70%"></div>
            <div class="agent-chat-skeleton-line" style="width: 85%"></div>
            <div class="agent-chat-skeleton-line" style="width: 60%"></div>
          </div>
          <div v-else class="genai-answer-text" v-html="getDisplayContent(answer)"></div>
        </div>
      </template>


    </div>
    
    <!-- <div class="answer-left-wrapper">
      
    </div> -->
  </div>
</template>

<script setup>
import { ref, defineProps, defineEmits } from 'vue';
import { useI18n } from 'vue-i18n';
import BaseIcon from '@/component/BaseIcon.vue';

// Props
const props = defineProps({
  answer: {
    type: Object,
    required: true,
    default: () => ({
      id: '',
      query: '',
      answer: '',
      isLoading: false,
      isStateOpen: false,
      searchList: [],
      referenceList: [], 
      isMultiAnswer: false
    })
  },
  searchList: {
    type: Array,
    default: () => []
  },
  lastAnswer: {
    type: Boolean,
    default: false
  },
  queryLoading: {
    type: Boolean,
    default: false
  }
});

// Emits
const emit = defineEmits(['toggleState']);

// i18n
const { t } = useI18n();

// Store
// const store = useStore();
// const isMultiAnswer = computed(() => store.getters.multiAnswer || false );

// 상태
const isStateOpen = ref(props.answer.isStateOpen || false);
const __mdCache = { last: '', html: '' };

function renderMdStreaming(mdText) {
  const md = frontNormalizeForRender(mdText || '');
  if (md === __mdCache.last) return __mdCache.html;
  __mdCache.last = md;
  __mdCache.html = changeMarkDown(md); // 네가 가진 changeMarkDown 사용
  return __mdCache.html;
}

// 첫번째 답변용
function getDisplayContent(answer) {
  return renderMdStreaming(answer?.answer || '');
}


// 두 번째 답변용 디스플레이 컨텐츠 결정 함수
function getDisplayContent1(answer) {
  return renderMdStreaming(answer?.answer1 || '');
}


function frontNormalizeForRender(md='') {
  // 공백 토큰 처리 연속 공백 2개는 단락바꿈, 단일 공백은 그대로 유지 함
  let normalized = md
    .replace(/\s{2,}/g, '\n\n')  // 연속 공백 2개 이상을 단락바꿈으로
    .replace(/\n{3,}/g, '\n\n'); // 연속된 줄바꿈 3개 이상을 2개로 정리

  // 헤더 토큰 앞에 빈 줄 추가 (문장 중간에 나온 경우)
  normalized = normalized.replace(/([^\n])\s*(#{1,6}\s+)/g, '$1\n\n$2');

  return normalized;
}

// 마크다운 렌더링 함수 (기존 renderMarkdownStream과 동일)
function changeMarkDown(letters) {
  if (!letters) return '';
  const marked = require('marked');

  const renderer = new marked.Renderer();
  renderer.link = (href, title, text) =>
    `<a href=${href} target="_blank" style="text-decoration: underline;">${text}</a>`;
  renderer.code = (code, language) =>
    `<pre class="custom-code-block"><code class="language">${language || ''}<br/>${code}</code></pre>`;
  renderer.del = (text) => text; // ~취소선 무력화 유지할 거면 그대로

  marked.setOptions({
    renderer,
    gfm: true,
    breaks: true,     // 단일 \n → <br> (서버의 '공백토큰 1회'가 줄바꿈으로 보이게)
    headerIds: false,
    tables: true,
    smartLists: true,
    smartypants: false,
  });

  return marked(letters);
}

// 상태 토글 함수
function toggleState() {
  isStateOpen.value = !isStateOpen.value;
  emit('toggleState', { answerId: props.answer.id, isOpen: isStateOpen.value });
}
</script>
