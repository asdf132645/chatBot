import { nextTick } from 'vue';

const wait = (ms) => new Promise(res => setTimeout(res, ms));

export function useChatView() {
  // selector 기반
  const onGoBottom = async (selector = '.body-wrapper', behavior = 'smooth') => {
    await nextTick();
    await wait(100);
    const container = document.querySelector(selector);
    if (container) {
      container.scrollTo({ top: container.scrollHeight, behavior });
    }
  };

  // ref 기반
  const onGoBottomRef = async (elRef, behavior = 'smooth') => {
    await nextTick();
    const el = elRef?.value;
    if (el) {
      el.scrollTo({ top: el.scrollHeight, behavior });
    }
  };

  return { onGoBottom, onGoBottomRef, wait };
}
