let sendFunction = null;

export function initChatService(sendFunc) {
  if (typeof sendFunc !== 'function') {
    throw new Error('초기화하려면 함수를 제공해야 합니다.');
  }
  sendFunction = sendFunc;
}

export function sendChatMessage(payload, options = {}) {
  if (!sendFunction) {
    return Promise.reject('Chat service not initialized');
  }
  return sendFunction(payload, options);
}