// src/domains/chat/application/chatHelpers.js

/**
 * 멀티턴 컨텍스트 메시지 생성
 * - 최근 3턴(유저→봇)을 기준으로 쌓고, 마지막에 현재 유저 메시지를 붙임
 */
export function buildMultiturnMessages(value, answerWrapperRef) {

  const arr = (answerWrapperRef && answerWrapperRef.value) || [];
  const isValid = item =>
    item &&
    item.answers?.length > 0 &&
    typeof item.query === 'string';


  let msgs = [];

  // 최대 3턴의 히스토리(유저→봇)를 가져오기
  const history = [];
  for (let i = Math.max(0, arr.length - 3); i < arr.length; i++) {
    if (!isValid(arr[i])) continue;
    history.push(arr[i]);
  }

  history.forEach(item => {
    msgs.push({ role: 'user', content: item.query });
    const lastAns = item.answers[item.answers.length - 1].answer;
    msgs.push({ role: 'assistant', content: lastAns });
  });

  // 마지막에 지금 턴 유저 질의 추가
  msgs.push({ role: 'user', content: value || '' });
  return msgs;
}
