import { ref, computed, reactive } from 'vue';
import { useStore } from 'vuex';
import { useI18n } from 'vue-i18n';
import { useToast } from 'vue-toastification';
import { v1 as uuidv1 } from 'uuid';
import marked from 'marked';
import { usePrompt } from '../../prompt/application/usePrompt';
import * as chatApi from '../../chat/infrastructure/chatApi';
import { initChatService } from './chatService';
import { useChatView } from './useChatView';
import { callEvaluationList, createDefaultAnswer, createNewChat } from '../domain/factory/chatFactory';

const fileListArray = ref([]);

export function useChat(emit) {
  const store = useStore();
  const session = computed(() => store.getters.session);
  const userChatbot = computed(() => store.getters.userChatbot);
  const isFileLoading = computed(() => store.getters.getIsFileLoading);
  const { t } = useI18n();
  const toast = useToast();

  // --- 모든 상태 ---
  const answerWrapper = ref([]);
  const messages = ref([]);
  const isWaiting = ref(false);
  const isGenAiWaiting = ref(false);
  const welcomeMessage = ref([]);
  const defaultWelcomeMessage = ref([t('welcomewrapper.welcomewrapper_key9')]);
  const { prompts: promptList, fetchUserPrompts } = usePrompt();
  const makeSBResponseParameter = ref('');
  const genAiWaitMessages = ref([]);
  const classMode = ref(false);
  const live = ref(false);
  const transition_info = reactive({ transition: {} });
  const feedback = ref({});
  const formComponents = ref([]);
  const genAiOption = ref({ vendor: 'azure' });
  const currChatMsgId = ref('');
  const feedbackView = ref(false);
  const selectedLanguage = ref('');
  const translateOn = ref(false);
  const askedTime = ref(new Date());


  // 평가 관련 상태
  const isEvaluateModal = ref(false);
  const userReasonOpinion = ref('');
  const userReasonOpinionMaxLength = 500;
  const evaluationList = ref([]);
  const currAnswerForEval = ref(null);

  // --- Computed ---
  const pinnedRecommendList = computed(() => (promptList.value || []).filter(p => p.is_pinned).map((item, index) => ({
    title: item.prompt,
    seq: item.seq || index + 1,
  })));
  const showAnswers = computed(() => (answerWrapper.value || []).filter(item => item.title));

  const { onGoBottom, wait } = useChatView();

  // 질문 마무리 하는 함수 NodeJs 몽고디비에 저장하는 로직
  const answerEnd = (currentChat) => {
    if (currentChat.q === '') return;
    isWaiting.value = false;
    isGenAiWaiting.value = false;
    currentChat.queryLoading = false;
    let answerWrapperLength = 0;
    if (answerWrapper.value?.length > 0) {
      answerWrapper.value.at(-1).isStateOpen = false;
      answerWrapperLength = answerWrapper.value.length;
    }
    endSearchListSSE(); // SSE 종료 로직
    const queryPayload = {
      agent_id: session.value.chatbotCode,
      query_id: currentChat.query_id,
      session_id: session.value.session_id,
      email: store.state.loginUser.userEmail,
      sub: store.state.loginUser.userId,
      seq_no: answerWrapperLength,
      query: currentChat.query,
      keywords: currentChat.keywords || [],
      images: currentChat.images || [],
      answer: currentChat.answer,
      attachments: currentChat.attachments || [],
      attachmentIds: currentChat.attachmentIds,
      references: currentChat.fewshots || [],
      questions: currentChat.recomList || [],
      searchList: currentChat.searchList || [],
      messages: currentChat.response?.sbData?.messages,
      ragDocuments: currentChat.response?.sbData?.ragDocuments
    };
    chatApi.saveQuery(queryPayload).catch(error => console.error('Error saving query:', error));
    store.commit('setIsChatSending', false); // 채팅이 끝난 상태를 알려주는 전역함수
    emit('answerEnd');
  };

  const endSearchListSSE = () => chatApi.endSearchStream(session.value.chatbotCode, session.value.convId);

  const getRecommendedQuestions = async (query, context, fewshot = '', promptId = '') => {
    // 마지막 Chat 객체 가져오기
    const currentChat = answerWrapper.value.at(-1);
    const searchItemId = 'recommended_question';

    //  추천 질문 생성 전 상태 표시
    currentChat.searchList.push({
      id: searchItemId,
      status: 'loading',
      keyword: query,
      statusDetail: t('answerwrapper.answerwrapper_key25'),
    });

    // 기본 질문 리스트 (API 실패 또는 빈 응답 시 사용)
    const defaultQuestions = [
      // t('answerwrapper.answerwrapper_key26'),
      // t('answerwrapper.answerwrapper_key27'),
      // t('answerwrapper.answerwrapper_key28'),
      // t('answerwrapper.answerwrapper_key29'),
      // t('answerwrapper.answerwrapper_key30'),
    ];

    try {
      // 스크롤 맨 아래로
      onGoBottom('smooth');

      // API 요청 헤더 구축
      const headers = await onGenerateHeaders();
      const payload = {
        messages: JSON.stringify([{ role: 'user', content: query }]),
        context,
        fewshot,
        prompt_id: promptId,
        multiturn_k: 1,
        session_id: session.value.session_id,
        code: session.value.chatbotCode,
      };

      // 추천 질문 호출
      const { data } = await chatApi.fetchRecommendedQuestion(payload, headers, session.value.chatbotCode);

      // 다시 스크롤
      onGoBottom('smooth');

      //  상태 업데이트
      const searchItem = currentChat.searchList.find(item => item.id === searchItemId);
      if (searchItem) {
        searchItem.status = 'check';
        searchItem.statusDetail = t('answerwrapper.answerwrapper_key20');
      }

      //  응답 처리
      if (data?.recommended_questions?.length) {
        return data.recommended_questions.map((title, i) => ({ title, seq: i + 1 }));
      } else {
        return defaultQuestions.map((title, i) => ({ title, seq: i + 1 }));
      }

    } catch (error) {
      console.error('추천 질문 가져오기 실패:', error);

      // 에러 시에도 상태 업데이트
      const searchItem = currentChat.searchList.find(item => item.id === searchItemId);
      if (searchItem) {
        searchItem.status = 'check';
        searchItem.statusDetail = t('answerwrapper.answerwrapper_key32');
      }

      // 폴백 질문 반환
      return defaultQuestions.map((title, i) => ({ title, seq: i + 1 }));
    }
  };


  const onGenerateHeaders = async () => {
    const response = await chatApi.fetchHeadersForGenAi(chatApi.getDomainInfo().chatbotCode);
    const headers = { ...response.data };
    if (genAiOption.value.vendor === 'AZURE') {
      headers.api_version = response.data.api_version || '2023-05-15';
    }
    return headers;
  };

  // 웰컴 페이지 로직
  const initializeWelcomePage = async () => {
    try {
      const response = await send('', { isWelcome: true });
      const messages = response?.sbData?.messages;
      if (messages) {
        const serverWelcomeMsg = JSON.parse(messages).flatMap(item => item.simpleResponse).filter(Boolean);
        if (serverWelcomeMsg.length > 0) welcomeMessage.value = serverWelcomeMsg;
        else welcomeMessage.value = defaultWelcomeMessage.value;
      }
    } catch (e) {
      console.error('welcomeEvent() 실패:', e);
    }
    await fetchUserPrompts(session.value.chatbotCode, 1);
  };


  const makeSBResponse = async (sbData, startQuery, request, confidence) => {
    if (sbData == null) return;

    transition_info.transition = {
      div: sbData.transitionDiv,
      transition_id: sbData.transitionId,
      transition_name: sbData.transitionName,
    };

    const response = {
      action: '',
      askedTime: askedTime.value,
      components: [],
      diagnosticInfo: null,
      intent: sbData.displayName,
      intentDetectionConfidence: sbData.displayName === '' ? '' : confidence,
      query: makeSBResponseParameter.value.aiResponse ? '' : sbData.query,
      responseId: sbData.responseId,
    };
    if (startQuery) response.query = '';

    const lastChat = answerWrapper.value.at(-1);
    const parsedMessages = JSON.parse(sbData.messages || '[]');

    //  carousel_card → fewshots 참고 자료에다가 넣는 부분 ( 어드민 페이지에서 피드백 관리에서 퓨샷으로 등록 한 부분, llm 이 지식문서에서 자료를 참고해서 던지는 부분 )
    const carousel = parsedMessages.find(m => m.type.toLowerCase() === 'carousel_card');
    if (carousel?.content) {
      // 스트리밍 중에는 fewshots에 추가하지 않고 임시 저장
      if (!lastChat.tempFewshots) {
        lastChat.tempFewshots = [];
      }
      carousel.content.forEach(item => {
        lastChat.tempFewshots.push({
          id: item.id,
          source_id: item.title,
          doc_title: item.title,
          content: item.description,
        });
      });
    }

    //  simple_response 만들어서 챗에다가 넣는 부분
    parsedMessages
      .filter(m => m.type.toUpperCase() === 'SIMPLE_RESPONSE')
      .forEach(m => {
        const txt = m.simpleResponse?.[0] || '';
        lastChat.answer += txt + '\n';
      });

    feedback.value = {
      'convId': sbData.sessionId,
      'query': sbData.eventName || sbData.origin_query || sbData.query,
      'messages': sbData.createdByAi ? sbData.ai_response_messages : sbData.messages,
      'ai_platform': sbData.genAI_kind || '',
      'live': live.value,
    };

    let formFlag = false;
    for (let i = 0; i < parsedMessages.length; i++) {
      const msg = parsedMessages[i];
      if (!msg || !msg.type) continue;

      // 각 메시지 타입에 대한 객체 초기화
      let simpleResponseObj = {};
      let cardResponseObj = {};
      let listResponseObj = {};
      let mediaResponseObj = {};
      let calendarResponseObj = {};
      let accordionResponseObj = {};
      let itemCardContent = [];
      let suggestionChipsObj = [];

      const type = msg.type.toUpperCase();

      if (type === 'SIMPLE_RESPONSE') {
        const idx = Math.floor(Math.random() * msg.simpleResponse.length);
        simpleResponseObj.textToSpeech = msg.simpleResponse[idx];
      } else if (type === 'BASIC_CARD') {
        cardResponseObj = {
          title: msg.title,
          subtitle: msg.subtitle,
          formattedText: msg.formattedText,
          description: msg.description,
          image: {
            accessibilityText: msg.imageAccessibilityText,
            url: msg.imageUrl,
            linkUrl: msg.imageLinkUrl,
          },
          buttons: (msg.buttonList || []).map(b => ({
            openTelAction: b.btnQuaAddress,
            type: b.btnType,
            openUriAction: b.btnOuaUrl,
            title: b.btnTitle,
            target: b.targetType || 'blank',
          })),
        };
      } else if (type === 'MEDIA_CONTENT') {
        mediaResponseObj = {
          imageUri: msg.imageUri,
          accessibilityText: msg.accessibilityText,
          contentUrl: msg.contentUrl,
          name: msg.name,
          description: msg.description,
          buttons: (msg.buttonList || []).map(b => ({ url: b.btnUrl, title: b.btnTitle })),
        };
      } else if (type === 'LIST') {
        listResponseObj = {
          title: msg.title,
          headerDescription: msg.headerDescription,
          headerimageUri: msg.headerimageUri,
          headerimageLinkUri: msg.headerimageLinkUri,
          items: (msg.items || []).map(item => ({
            imageUri: item.imageUri,
            itemTitle: item.itemTitle,
            description: item.description,
            linkUri: item.linkUri,
            info: { key: item.itemTitle },
          })),
        };
      } else if (type === 'ITEM_CARD') {
        itemCardContent = (msg.content || []).map(contentItem => ({
          title: contentItem.title,
          description: contentItem.description,
          fixedRatio: contentItem.fixedRatio,
          itemList: contentItem.itemList,
          image: {
            accessibilityText: contentItem.imageAccessibilityText,
            url: contentItem.imageUrl,
            linkUrl: contentItem.imageLinkUrl,
          },
          buttons: (contentItem.buttonList || []).map(b => ({
            openTelAction: b.btnQuaAddress,
            type: b.btnType,
            openUriAction: b.btnOuaUrl,
            title: b.btnTitle,
            target: b.targetType || 'blank',
          })),
        }));
      } else if (type === 'CALENDAR') {
        calendarResponseObj = msg;
      } else if (type === 'ACCORDION') {
        accordionResponseObj = msg;
      } else if (type === 'SUGGESTION_CHIPS') {
        suggestionChipsObj.push({
          name: msg.message,
          uri: msg.url,
          linkedIntent: msg.linkedIntent,
          linkedIntentNm: msg.linkedIntentNm,
        });
      } else if (type === 'FORM') {
        formFlag = true;
      }

      if (simpleResponseObj.textToSpeech) {
        response.components.push({ name: 'SIMPLE_RESPONSE', content: simpleResponseObj });
      }
      if (cardResponseObj.title) {
        response.components.push({ name: 'CARD', content: cardResponseObj });
      }
      if (mediaResponseObj.imageUri) {
        response.components.push({ name: 'MEDIA_CONTENT', content: mediaResponseObj });
      }
      if (listResponseObj.title) {
        response.components.push({ name: 'LIST', content: listResponseObj });
      }
      if (itemCardContent.length > 0) {
        response.components.push({ name: 'ITEM_CARD', content: itemCardContent });
      }
      if (calendarResponseObj.mode) {
        response.components.push({ name: 'CALENDAR', content: calendarResponseObj });
      }
      if (accordionResponseObj.accordion) {
        response.components.push({ name: 'ACCORDION', content: accordionResponseObj });
      }
      if (suggestionChipsObj.length > 0) {
        // 제안 칩은 이전 메시지도 제안 칩이었는지 확인하여 병합하는 로직
        const lastComponent = response.components.at(-1);
        if (lastComponent && lastComponent.name === 'SUGGESTION_CHIPS') {
          lastComponent.content.push(...suggestionChipsObj);
        } else {
          response.components.push({ name: 'SUGGESTION_CHIPS', content: suggestionChipsObj });
        }
      }
      if (formFlag) {
        response.components.push({ name: 'FORM', content: {} });
      }
    }

    if (formFlag) {
      emit('handleAgentForm', response);
      feedbackView.value = false;
      formComponents.value = response.components;
      classMode.value = true;
    } else {
      isWaiting.value = false;
    }
  };

  // --- 파일 업로드 대기 함수 ---
  const checkFileUploading = async () => {
    return new Promise(resolve => {
      const interval = setInterval(() => {
        // isFileLoading Vuex getter의 값이 false가 되면 대기 종료
        if (!isFileLoading.value) {
          clearInterval(interval);
          resolve();
        }
      }, 1000);
    });
  };

  // --- 파일 업로드 상태 UI 추가 함수 ---
  const searchListAddFileUpload = () => {
    // 파일 업로드가 진행 중이고, 파일 목록이 있을 때만 실행
    if (isFileLoading.value && fileListArray.value.length > 0) {
      const currentChat = answerWrapper.value.at(-1);
      if (!currentChat) return;

      const searchItemId = 'file_upload';
      currentChat.searchList.push({
        id: searchItemId,
        status: 'loading',
        keyword: fileListArray.value[0].name,
        statusDetail: t('answerwrapper.answerwrapper_key46'), // "파일 업로드 진행중"
      });
    }
  };

  /* SSE(Server-Sent Events)로 검색 진행 상태를 실시간 수신 */
  const startSearchListSSE = async () => {
    let responseText;
    try {
      // 스트림 요청
      responseText = await chatApi.streamSearchStatus(
        session.value.chatbotCode,
        session.value.convId,
      );
    } catch (err) {
      // 네트워크 에러나 타임아웃 발생 시
      console.warn('streamSearchStatus failed:', err);
      return;
    }
    const reader = responseText.body.pipeThrough(new TextDecoderStream()).getReader();

    let readable = true;
    while (readable) {
      const { done, value } = await reader.read();

      if (value && value.startsWith('data:')) {
        let eventData = value.slice(6).trim();
        let dataList = eventData.split('\n\ndata: ');

        dataList.forEach((d) => {
          try {
            let eventItem = JSON.parse(d);
            const currentChat = answerWrapper.value.at(-1);
            if (!currentChat) return;

            eventItem.data.forEach((e) => {
              const searchItemId = e.subTask;
              const searchItem = currentChat.searchList.find(item => item.id === searchItemId);

              if (searchItem) {
                searchItem.status = 'check';
                searchItem.statusDetail = e.desc;
              } else {
                currentChat.searchList.push({
                  id: searchItemId,
                  status: 'loading',
                  keyword: e.subTask,
                  statusDetail: e.desc,
                });
              }
            });
          } catch (error) {
            console.error('SSE JSON parsing error:', error, 'Received data:', d);
          }
        });
      }

      if (done) {
        readable = false;
      }

      // 폴링 간격
      await wait(100);
    }
  };

  async function handleStandardBotResponse(request, currentChat, q, options) {
    try {
      const { data: responseData } = await chatApi.sendChatRequest(request);
      currentChat.response = responseData;
      if (responseData.sbData?.req_ai_response) {
        // GenAI 전환
        const streamingReq = buildRequestObject(q, {
          ...options,
          req_ai_response: true,
          sbData: responseData.sbData,
          msgObj: responseData.sbData.messages,
        });
        return handleGenAiStreamingResponse(streamingReq, currentChat);

      }
      // 일반 질문 응답 처리 - tempFewshots를 fewshots로 이동
      if (currentChat.tempFewshots && currentChat.tempFewshots.length > 0) {
        currentChat.fewshots = [...(currentChat.fewshots || []), ...currentChat.tempFewshots];
        currentChat.tempFewshots = [];
      }
      
      // ReferenceList 표시를 위해 referenceLoading을 false로 설정
      currentChat.referenceLoading = false;
      answerEnd(currentChat);
    } catch (e) {
      console.error(e);
      const errMsg = t('answerwrapper.answerwrapper_key48');
      currentChat.answer += errMsg;
      
      // 에러 발생 시에도 tempFewshots를 fewshots로 이동
      if (currentChat.tempFewshots && currentChat.tempFewshots.length > 0) {
        currentChat.fewshots = [...(currentChat.fewshots || []), ...currentChat.tempFewshots];
        currentChat.tempFewshots = [];
      }
      
      currentChat.referenceLoading = false;
      currentChat.end = true;
      answerEnd(currentChat);
    }
  }


  // --- GenAI 스트리밍 처리 ---
  async function handleGenAiStreamingResponse(request, currentChat) {
    try {
      const resp = await chatApi.fetchGenAiStream(request); // genAi 스트림
      const reader = resp.body.pipeThrough(new TextDecoderStream()).getReader();

      isWaiting.value = false;
      isGenAiWaiting.value = false;

      let dotCounter = 0;
      const speed = 10;
      // eslint-disable-next-line
      while (true) {
        const { done, value } = await reader.read();
        if (done) {
          // 스트림 종료 후 추천 질문 조회
          currentChat.recomLoading = true;
          currentChat.recomList = await getRecommendedQuestions(
            currentChat.query,
            currentChat.answer,
          );
          currentChat.recomLoading = false;

          // 스트리밍 완료 후 tempFewshots를 fewshots로 이동
          if (currentChat.tempFewshots && currentChat.tempFewshots.length > 0) {
            currentChat.fewshots = [...(currentChat.fewshots || []), ...currentChat.tempFewshots];
            currentChat.tempFewshots = [];
          }

          // ReferenceList 표시를 위해 referenceLoading을 false로 설정
          currentChat.referenceLoading = false;

          answerEnd(currentChat);
          break;
        }

        // 데이터 전처리
        let text = value
          .replace(/event: none\s*/g, '')
          .replace(/event: stop\s*/g, '')
          .replace(/^data: /gm, '')
          .replace(/\n\n\n\n\n/g, '<<n5>>')
          .replace(/\n\n\n\n/g, '<<n4>>')
          .replace(/\n\n\n/g, '<<n3>>')
          .replace(/\n\n/g, '')
          .replace(/<<n5>>/g, '\n')
          .replace(/<<n4>>/g, '\n\n')
          .replace(/<<n3>>/g, '\n');

        // 한 글자씩 표시
        await wait(speed);

        // 로딩 애니메이션
        let statement = t('answerwrapper.answerwrapper_key24');
        for (let i = 0; i < dotCounter % 4; i++) statement += '.';
        dotCounter++;
        currentChat.state = statement;
        // console.log(text);
        // 실제 답변 추가
        currentChat.answer += text;
        onGoBottom('.body-wrapper');
      }
    } catch (error) {
      console.error('GenAI 스트리밍 처리 중 에러:', error);
      
      // 에러 발생 시에도 tempFewshots를 fewshots로 이동
      if (currentChat.tempFewshots && currentChat.tempFewshots.length > 0) {
        currentChat.fewshots = [...(currentChat.fewshots || []), ...currentChat.tempFewshots];
        currentChat.tempFewshots = [];
      }
      
      // 에러 발생 시에도 ReferenceList 표시를 위해 referenceLoading을 false로 설정
      currentChat.referenceLoading = false;
      // 에러 발생 시에도 자연스럽게 종료
      answerEnd(currentChat);
    }
  }


  const send = async (q, options = {}) => {
    const {
      flowType = 'standard',
    } = options;


    // GenAI 스트림 전환용 기본 파라미터 초기화
    makeSBResponseParameter.value = '';
    genAiWaitMessages.value = [];

    //
    askedTime.value = new Date();
    store.commit('setIsChatSending', true); // 채팅을 시작하면 true 로 다른 lnb 측에서 다른 페이지로 이동을 막는 임시 전역 변수

    if (flowType === 'searchAssist') { // 기존 send 함수 사용되는 페이지마다 분리해서 쓸 수 있도록 변경
      return handleSearchAssist(q, options);
    }
  };

  // --- 질문 시작 ---
  async function handleSearchAssist(q, options = {}) {
    if (Array.isArray(options.fileList)) fileListArray.value = options.fileList;
    isWaiting.value = true;
    isGenAiWaiting.value = false;
    makeSBResponseParameter.value = '';
    genAiWaitMessages.value = [];

    const { isInit = false, fileIds = [], linkedIntent, startQuery, calendarParameters, accordionParameters } = options;

    // query 및 타이밍 설정
    const query = startQuery || q;

    // SSE 시작
    startSearchListSSE();
    onGoBottom('.body-wrapper');

    // 채팅 객체 생성
    const currentChat = createAndDisplayQuery(query, { flowType: 'searchAssist', isInit });

    // 업로드한 파일 목록을 '표시용 메타데이터'로 먼저 세팅 (참고자료 패널에서 즉시 보이게)
    if (Array.isArray(fileListArray.value) && fileListArray.value.length > 0) {
      currentChat.attachments = fileListArray.value.map(f => ({
        // 표시용 메타데이터
        id: f.id,
        type: f.fileType || mapMimeToIcon(f.type),
        filename: f.name,
        sizeBytes: f.size,
      }));
      currentChat.attachmentIds = fileIds;
    }

    if (!options.req_ai_response) {
      //  기본 Answer 초기화
      const defaultAnswer = createDefaultAnswer();
      currentChat.answers = [defaultAnswer];
      currentChat.isStateOpen = true;

      // 파일 업로드 UI 초기화 (파일이 있을 때만)
      if (!isInit && fileListArray.value.length > 0) {
        searchListAddFileUpload(fileListArray.value);
      }
    }

    if (linkedIntent) {
      currentChat.linkedIntent = linkedIntent;
    }
    if (calendarParameters) {
      currentChat.calendarParameters = calendarParameters;
    }
    if (accordionParameters) {
      currentChat.accordionParameters = accordionParameters;
    }
    if (fileListArray.value.length > 0) {
      currentChat.referenceLoading = true;
      searchListAddFileUpload(fileListArray.value);
      await checkFileUploading();
      const searchItem = currentChat.searchList.find(item => item.id === 'file_upload');
      if (searchItem) {
        searchItem.status = 'check';
        searchItem.statusDetail = t('answerwrapper.answerwrapper_key47');
      }
    }

    // 요청 객체 생성
    const request = buildRequestObject(query, options);

    // API 호출
    try {
      const { data } = await chatApi.sendChatRequest(request);
      // 화면 표시 업데이트
      currentChat.referenceLoading = false;
      if (fileIds.length > 0) {
        currentChat.attachmentIds = fileIds; // 서버 전송/추적용
      }
      currentChat.messages = data.sbData.messages; // 추천 검색 내용이 담긴 응답값
      currentChat.ragDocuments = data.sbData.ragDocuments; // 관련 이미지 담는 곳
      await makeSBResponse(data.sbData, startQuery, request, data.intentDetectionConfidence);

      if (options.req_ai_response) {
        // GenAI 스트리밍으로 이어붙이기
        return handleGenAiStreamingResponse(
          buildRequestObject(query, {
            ...options,
            req_ai_response: true,
            sbData: data.sbData,
            msgObj: data.sbData.messages,
          }),
          currentChat,
        );
      } else {
        return await handleStandardBotResponse(request, currentChat, q, options);
      }

    } catch (error) {
      console.error('searchAssist 에러:', error);
      // 에러 핸들링: fallback 메시지 및 종료
      const errMsg = t('answerwrapper.answerwrapper_key48');
      currentChat.answer += errMsg;
      currentChat.end = true;
      
      // 에러 발생 시에도 tempFewshots를 fewshots로 이동
      if (currentChat.tempFewshots && currentChat.tempFewshots.length > 0) {
        currentChat.fewshots = [...(currentChat.fewshots || []), ...currentChat.tempFewshots];
        currentChat.tempFewshots = [];
      }
      
      currentChat.referenceLoading = false; // ReferenceList 표시를 위해 referenceLoading을 false로 설정
      isWaiting.value = false;
      isGenAiWaiting.value = false;
      answerEnd(currentChat);
    }
  }

  // 첫 화면에서 설명글 넣는 부분
  const initPageDataSet = async (options) => {
    try {
      const request = buildRequestObject('', options);
      const { data: responseData } = await chatApi.sendChatRequest(request);
      return responseData;
    } catch (e) {
      return null;
    }
  };

  const initChatPage = (newSession) => {
    answerWrapper.value = newSession.answerList || [];
    if (newSession.isInit && newSession.initValue) {
      send(newSession.initValue, { flowType: 'searchAssist' });
      store.commit('setSession', { ...newSession, isInit: false });
    }
  };

  // toggleAnswerState 함수는 useToggleState composable로 대체됨

  const toMarkdown = (text) => {
    if (!text) return '';
    const renderer = new marked.Renderer();
    renderer.link = (href, title, text) => `<a href="${href}" target="_blank" style="text-decoration: underline;">${text}</a>`;
    renderer.code = (code, language) => `<pre class="custom-code-block"><code class="language">${language}<br/>${code}</code></pre>`;
    marked.setOptions({ renderer, gfm: true, breaks: true });
    return marked(text.replace(/\|\n\n\|/g, '|\n|'));
  };

  function mapMimeToIcon(mime) {
    const map = {
      'application/pdf': 'PDF',
      'image/jpeg': 'Image',
      'image/png': 'Image',
      'text/plain': 'Text',
      'application/msword': 'Doc',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'Doc',
      'application/vnd.ms-excel': 'Excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'Excel',
    };
    return map[mime] || 'File';
  }

  const copyAnswer = (answer) => {
    navigator.clipboard.writeText(answer.answer).then(() => toast.info('복사되었습니다.'));
  };

  /** 공통 필드 세팅 함수 LLM 관련 플래그 다 넣는 곳 **/
  function buildRequestObject(q, options) {
    const { linkedIntent, req_ai_response = false, sbData = null, msgObj = null } = options;

    const {
      defaultLanguageCode = 'ko',
      platform = 'standard',
      aiResponseOption: ai_response_option,
      aiResponseSimple: ai_response_simple,
      aiResponseEnable: ai_response_enable,
      aiResponsePlatform: ai_response_platform,
      multiTurn,
    } = store.state.userChatbot;

    const threshold = userChatbot.value.threshold || '0.4';
    const trans_out = translateOn.value ? selectedLanguage.value : '';
    const { session_id, chatbotCode } = session.value;
    // console.log(session_id);
    const startParameters = { fields: {} };
    const baseFields = {
      sessionId: { kind: 'stringValue', stringValue: session_id },
      lang: { kind: 'stringValue', stringValue: defaultLanguageCode },
    };
    const userParameters = { fields: { ...baseFields } };
    let request = {
      session_id: session_id,
      lang: defaultLanguageCode,
      code: chatbotCode,
      live: live.value,
      trans_out,
      platform,
      threshold,
      ai_response_option,
      ai_response_simple,
      ai_response_enable,
      ai_response_platform,
      multiTurn,
      req_ai_response,
      linked_intent: linkedIntent || undefined,
      q: q || '',
      event: q ? undefined : 'WELCOME',
      start_parameters: JSON.stringify(startParameters),
      user_parameters: JSON.stringify(userParameters),
      sub: store.state.loginUser.userId,
    };

    if (req_ai_response && sbData && msgObj) {
      const parsed = JSON.parse(msgObj);
      const aiResp = parsed.find(i => i.type === 'ai_response');
      const insight = parsed.find(i => i.type === 'insight_ai_response');
      if (insight) {
        request.start_parameters = JSON.stringify(insight);
      }
      const { genAI_context, genAI_fewshots, genAI_logId, genAI_kind } = sbData;
      Object.assign(userParameters.fields, {
        genAI_context: { kind: 'stringValue', stringValue: genAI_context },
        genAI_fewshots: { kind: 'stringValue', stringValue: genAI_fewshots },
        genAI_logId: { kind: 'stringValue', stringValue: genAI_logId },
        prompt_id: { kind: 'stringValue', stringValue: aiResp?.prompt_id || '' },
        msgStr: { kind: 'stringValue', stringValue: msgObj },
        convId: { kind: 'stringValue', stringValue: session_id },
        genAI_kind: { kind: 'stringValue', stringValue: genAI_kind },
      });
    }

    request.user_parameters = JSON.stringify(userParameters);
    return request;
  }


  const createAndDisplayQuery = (q) => {
    if (!answerWrapper.value || !Array.isArray(answerWrapper.value)) {
      answerWrapper.value = [];
    }

    const { convId, chatbotCode, id: sessionId, promptId: sessionPromptId } = session.value;

    const chat = createNewChat({
      q,
      chatId: uuidv1(),
      sessionId,
      convId,
      chatbotCode,
      sessionPromptId,
    });

    chat.answers.push(createDefaultAnswer());

    answerWrapper.value.push(chat);
    return answerWrapper.value.at(-1);
  };


  const fetchEvaluationList = () => {
    evaluationList.value = callEvaluationList().map((item, idx) => ({
      ...item,
      id: `eval-${idx + 1}`,
      selected: false,
    }));
  };


  const submitNegativeEvaluation = () => {
    if (!currAnswerForEval.value) return;

    const selectedReasons = evaluationList.value
      .filter(i => i.selected)
      .map(i => ({ id: i.id, reason_info: i.label }));

    const chatbotCode = chatApi.getDomainInfo().chatbotCode;
    const answer = currAnswerForEval.value;

    const payload = {
      session_id: answer.session_id,
      answer_id: answer.query_id,
      agent_id: chatbotCode,
      thumb: 'down',
      reason: selectedReasons,
      comment: userReasonOpinion.value,
    };

    chatApi.saveFeedback(payload, chatbotCode).then(() => {
      toast.info(t('answercontent.answercontent_key10'));
      cancelEvaluation(); // 성공 후 모달 닫고 초기화
    }).catch(e => {
      console.error('피드백 저장 실패', e);
      toast.error('피드백 저장에 실패했습니다.');
    });
  };

  const cancelEvaluation = () => {
    isEvaluateModal.value = false;
    userReasonOpinion.value = '';
    evaluationList.value.forEach(e => e.selected = false);
    currAnswerForEval.value = null;
  };

  const regenerateAnswer = (answer) => {
    if (!answer || !answer.title) return;
    emit('submitQuery', answer.title);
  };

  const toggleEvaluationLabel = (id) => {
    const item = evaluationList.value.find(i => i.id === id);
    if (item) {
      item.selected = !item.selected;
    }
  };

  // 서비스 초기화
  initChatService(send);

  return {
    // State
    answerWrapper,
    pinnedRecommendList,
    currChatMsgId,
    userChatbot,
    session,
    welcomeMessage,
    defaultWelcomeMessage,
    isEvaluateModal,
    userReasonOpinion,
    userReasonOpinionMaxLength,
    evaluationList,
    messages,
    fileListArray,
    // Computed
    showAnswers,
    // Methods
    initializeWelcomePage,
    initPageDataSet,
    initChatPage,
    send,
    toMarkdown,
    copyAnswer,
    fetchEvaluationList,
    submitNegativeEvaluation,
    cancelEvaluation,
    regenerateAnswer,
    toggleEvaluationLabel,
  };
}