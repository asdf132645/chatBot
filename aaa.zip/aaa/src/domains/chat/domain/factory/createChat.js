export function createDefaultAnswer() {
  return {
    id: '',
    answer: '',
    documents: [],
    fewshots: [],
    engine: '',
    query_date: '',
    user_feedback: '',
    concat_context: '',
    concat_fewshots: '',
    end: false,
    state: '답변 준비',
  };
}

export function createNewChat({ q, chatId, sessionId, convId, chatbotCode, sessionPromptId }) {
  return {
    query_id: chatId,
    query: q,
    user_email: sessionId,
    session_id: convId,
    recommend_enabled: true,
    recomList: [],
    answers: [],
    query_date: '',
    title: q,
    id: chatId,
    answer: '',
    recomImage: [],
    documents: [],
    fewshots: [],
    answerDate: '',
    agent_code: chatbotCode,
    prompt: { id: sessionPromptId },
    searchList: [],
    queryLoading: true,
    referenceLoading: true,
    state: '답변 준비',
  };
}

export function createNewResAnswer() {
  return {
    logType: 'bot',
    askedTime: '',
    components: [],
    query: '',
    action: '',
    outputAudio: {},
    params: {},
  };
}

export function createSimpleResponseComponent({
                                                textToSpeech = ' ',
                                                ssml = '',
                                                displayText = '',
                                              } = {}) {
  return {
    name: 'SIMPLE_RESPONSE',
    content: {
      textToSpeech,
      ssml,
      displayText,
    },
  };
}
