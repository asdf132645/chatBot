import { v1 as uuidv1 } from 'uuid';

/**
 * 새로운 채팅 객체를 생성
 */
export const createNewChat = ({ q, chatId, sessionId, convId, chatbotCode, sessionPromptId }) => ({
  q,
  query: q,
  title: q,
  chatId,
  query_id: uuidv1(),
  sessionId,
  convId,
  chatbotCode,
  sessionPromptId,
  answers: [],
  answer: '',
  response: null,
  isStateOpen: true,
  queryLoading: true,
  recomLoading: false,
  referenceLoading: true, // ReferenceWrapper.vue -> 화면에서 보이고 안 보이게 하는 처리
  end: false,
  fewshots: [], // 푸샷데이터
  recomList: [],
  searchList: [],
  keywords: [],
  images: [],
  attachments: [],
  state: '', // '답변 생성중...' 상태 표시를 위함
});



/**
 * 기본 답변 객체를 생성
 */
export const createDefaultAnswer = () => ({
  answer: '',
  components: [],
  end: false,
  askedTime: new Date(),
});

/**
 * 새로운 응답 답변 객체를 생성 (주로 GenAI 스트리밍용)
 */
export const createNewResAnswer = () => ({
  askedTime: new Date(),
  components: [createSimpleResponseComponent()], // 초기 컴포넌트 포함
  end: false,
});

/**
 * 단순 응답 컴포넌트 객체 생성
 */
export const createSimpleResponseComponent = (text = '답변 생성중...') => ({
  name: 'SIMPLE_RESPONSE',
  content: {
    textToSpeech: text,
    ssml: '',
    displayText: '',
  },
});

/**
 * 파일 업로드 검색 항목 객체를 생성
 */
export const createFileUploadSearchItem = (file) => ({
  id: 'file_upload',
  status: 'loading',
  keyword: file.name,
  statusDetail: '파일 업로드 진행중',
});

// 피드백 관련 배열
export function callEvaluationList() {
  return [
    {id:'1', label:'유해하거나 불쾌한 답변', selected: false},
    {id:'2', label:'의도와 다른 답변', selected: false},
    {id:'3', label:'사실과 다른 답변', selected: false},
    {id:'4', label:'부족하거나 과한 답변', selected: false},
    {id:'5', label:'부적절한 사실이 아닌 답변', selected: false},
    {id:'6', label:'기타 답변', selected: false}
  ];
}