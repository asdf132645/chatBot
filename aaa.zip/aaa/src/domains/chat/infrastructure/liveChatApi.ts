// src/domains/chat/infrastructure/liveChatApi.ts

import { httpClient } from '@/shared/http/httpClient'
import { SERVER_URL } from '@/shared/config/endpoints'
import ENDPOINT from '@/shared/config/apiConstants';

// 사용자 정의 UI 가져오기
export async function fetchCustomUI(payload: { chatbotCode: string }) {
  const { data } = await httpClient.get<{
    chatbotImg?: string
    [key: string]: any
  }>(
    `${SERVER_URL}${ENDPOINT.ChATBOT.LIVE_CHAT.CUSTOM_UI}/get/${payload.chatbotCode}`,
    { excludeToken: true }
  )

  if (!data) {
    throw new Error('cannot get custom ui')
  }

  const imgFile = data.chatbotImg || 'chatImg.svg'
  data.chatbotImg = `${SERVER_URL}s3-image/${imgFile}`
  return data
}

// 로그인 상태 체크
export async function fetchLoginCheck(payload: { chatbotCode: string }) {
  return httpClient.get<any>(
    `${SERVER_URL}${ENDPOINT.ChATBOT.LIVE_CHAT.CHECK_LOGIN}/${payload.chatbotCode}`,
    { excludeToken: true }
  )
}
