
// File Upload API
import axios from 'axios';
import { CHATBOT_FILE_MGR_URL } from '../../../../shared/config/endpoints';
import { getDomainInfo } from '../chatApi';


export async function uploadFileMgr(file, userEmail, sessionId) {
  try {
    // FormData 객체 생성
    const formData = new FormData();

    // metainfo 객체 구성
    const metainfo = {
      agentCode: getDomainInfo().chatbotCode,
      sessionId: sessionId,
      domainNode: "",
      subcategoryNode: "",
      worker: {
        email: userEmail,
        name: userEmail
      },
      desc: "",
      tags: []
    };

    // FormData에 metainfo와 단일 파일 추가
    formData.append('metainfo', JSON.stringify(metainfo));
    formData.append('files', file);

    // API 요청 설정
    const config = {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    };

    // API 요청
    return await axios.post(
      CHATBOT_FILE_MGR_URL + '/knowledge-docs/docs/upload',
      formData,
      config
    );
  } catch (error) {
    console.error('Error in uploadFile:', error);
    throw error;
  }
}

// File Upload Check API
export function checkFileMgr(sessionId) {
  return fetch( CHATBOT_FILE_MGR_URL + `/knowledge-docs/docs/upload/${getDomainInfo().chatbotCode}/status/latest?sessionId=${sessionId}`)
}

// File Delete API
export function deleteFileMgr(sessionId) {
  return axios.delete(`${CHATBOT_FILE_MGR_URL}/knowledge-docs/docs/${getDomainInfo().chatbotCode}/${sessionId}`);
}

// File Delete API
export function deleteFileIds(docIds) {
  return axios.delete(`${CHATBOT_FILE_MGR_URL}/knowledge-docs/docs/${getDomainInfo().chatbotCode}?docIds=${docIds}`);
}