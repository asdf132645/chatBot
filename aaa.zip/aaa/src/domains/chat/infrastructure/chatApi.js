import {
  CHATBOT_ASSIST_URL,
  CHATBOT_PROXY_URL,
  CHATBOT_LOGGER_URL,
  getFullChatbotUrl,
  isFailResponse,
} from '../../../shared/config/endpoints';
import { httpClient } from '../../../shared/http/httpClient';
import moment from 'moment';

let assistBasic = 'api/agent-assist/agent-code';
const loggerBasic = 'api/logging/mongodb';

const chatbotCode = '566b2d71-1b40-4c0a-bc7a-790f0b4a13d5';
const promptId = '65ee4d971ffabdf2fde2a62d';

/*
* 도메인 url 에서 chatbotCode 가져오는 함수
* */
export function getDomainInfo() {
  // URL에서 chatbotCode 파라미터 확인
  const urlParams = new URLSearchParams(window.location.search);
  let urlChatbotCode = urlParams.get('chatbotCode');
  if(window.location.host == "plexfront.temptest.shop" && urlChatbotCode != chatbotCode){
    urlChatbotCode = chatbotCode
  }

  return {
    chatbotCode: urlChatbotCode || chatbotCode,
    promptId: promptId,
  };
}

// 채팅 세션 저장하는 함수 - LNB 함수에서 질문 후 저장하는 부분으로 변경 기존 - 새채팅 생성시 만들던 부분 리팩토링함
export function saveSession(payload) {
  const sessionData = {
    collection: 'sessions',
    agent_id: payload.agent_id,
    email: payload.email,
    title: payload.title,
    created_at: moment().format('YYYY-MM-DD HH:mm:ss'),
    updated_at: moment().format('YYYY-MM-DD HH:mm:ss'),
    uuid: payload.session_id,
    session_id: payload.session_id,
    pin: false,  // 기본값으로 false 설정
    searchType: payload.searchType,
    chatMode: payload.chatMode,
  };

  return httpClient.post(`${CHATBOT_LOGGER_URL}/${loggerBasic}/save`, sessionData);
}
// 채팅 타이틀 변경하는 함수
export function updateSessionTitle(payload) {
  return httpClient.patch(`${CHATBOT_LOGGER_URL}/${loggerBasic}`, {
    collection: payload.collection,
    uuid: payload.uuid,
    update: {
      title: payload.update.title,
    },
  });
}

export function updateSessionPinned(payload) {
  return httpClient.patch(`${CHATBOT_LOGGER_URL}/${loggerBasic}`, {
    collection: payload.collection,
    uuid: payload.uuid,
    update: {
      pin: payload.pin,
    },
  });
}

const parseMessages = (msgs) => {
  if (!msgs) return [];
  if (typeof msgs === 'string') {
    try {
      return JSON.parse(msgs);
    } catch {
      return [];
    }
  }
  return msgs;
};

const withSeq = (arr = []) =>
  Array.isArray(arr)
    ? arr.map((item, idx) => ({ ...item, seq: idx + 1 }))
    : [];

export const saveQuery = async (payload) => {
  const {
    agent_id,
    session_id,
    email,
    query_id,
    seq_no,
    query,
    answer,
    messages,
    searchList = [],
    keywords,
    images,
    attachments,
    references,
    questions,
    ragDocuments,
  } = payload;

  const queryData = {
    collection: 'querys',
    agent_id,
    session_id,
    email,
    date: moment().format('YYYY-MM-DD HH:mm:ss'),
    query_id,
    seq_no,
    query,
    contents: {
      keywords: withSeq(keywords),
      images: withSeq(images),
      answer: { content: answer },
    },
    attachments: withSeq(attachments),
    references: withSeq(references),
    questions: withSeq(questions),
    thumb: '',
    searchList,
    messages: parseMessages(messages),
    ragDocuments
  };

  return await httpClient.post(
    `${CHATBOT_LOGGER_URL}/${loggerBasic}/save`,
    queryData,
  );
};

export const saveDocsQuery = async (payload) => {
  const {
    agent_id,
    query_id,
    session_id,
    email,
    seq_no,
    query,
    report,
    StreamingAnswers,
    isDocsType,
    fileList
  } = payload;
  const queryData = {
    collection: 'querys',
    agent_id,
    session_id,
    email,
    date: moment().format('YYYY-MM-DD HH:mm:ss'),
    query_id,
    seq_no,
    query,
    thumb: '',
    report,
    StreamingAnswers,
    isDocsType,
    fileList
  };

  return await httpClient.post(
    `${CHATBOT_LOGGER_URL}/${loggerBasic}/save`,
    queryData,
  );
};


// --- CHATBOT PROXY ---
export const sendChatRequest = (requestPayload) => {
  return httpClient.post(`${CHATBOT_PROXY_URL}/web?format=true`, requestPayload, {
    headers: { 'content-type': 'application/json' },
    timeout: 340000,
    excludeToken: true,
  });
};

export const fetchGenAiStream = (requestPayload) => {
  return fetch(`${CHATBOT_PROXY_URL}/web?format=true`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(requestPayload),
  });
};

export const streamSearchStatus = (chatbotCode, convId) => {
  return fetch(`${CHATBOT_PROXY_URL}/search/status?code=${chatbotCode}&sessionId=${convId}`);
};

export const endSearchStream = (chatbotCode, convId) => {
  return httpClient.get(`${CHATBOT_PROXY_URL}/search/end?code=${chatbotCode}&sessionId=${convId}`);
};

export function fetchSearchAssistDocs(
  payload,
  headers,
  chatbotCode,
) {
  const url = `${CHATBOT_ASSIST_URL}/${assistBasic}/${chatbotCode}/genai/retrieve`;

  return httpClient.post(url, payload, {
    headers: {
      Token: 'acd3f4ebbaba7a9c1be2ceef33a609593666c5d3698d56827f011336cb1f0826',
      LLMServiceAuth: JSON.stringify(headers),
    },
    excludeToken: true,
  });
}

// --- AGENT ASSIST API ---
export function fetchGenAiAnswer(payload, chatbotCode) {
  return fetch(`${CHATBOT_ASSIST_URL}/${assistBasic}/${chatbotCode}/genai/generate`, payload);
}


export async function fetchRecommendedQuestion(payload) {
  const response = await httpClient.post(
    `${CHATBOT_PROXY_URL}/getSbRecommendedQuery`,
    payload,
    { headers: { "Content-Type": "application/json" } }
  );

  if (isFailResponse(response)) {
    throw new Error(response.data.error);
  }

  return response;
}


export const fetchHeadersForGenAi  = async (chatbotCode) => {
  try {
    const response = await httpClient.get(
      getFullChatbotUrl(`genai/headers/${chatbotCode}`),
      { excludeToken: true }
    );

    if (isFailResponse(response)) {
      throw new Error(response.data.error);
    }

    return response;
  } catch (err) {
    console.error(err);
  }
};


/**
 * 질문 정보에 대한 서버 질의 처리를 위한 인터페이스 함수
 * @param Object 대화 세션 목록을 호출하기 위한 대화방 객체
 * @returns 지정 대화에 해당하는 질의 배열
 * lnb 에서 이전 대화를 클릭시 해당 api 에서 몽고디비에 저장한 값을 받아서 대화 객체에다가 넣는 부분
 */
export async function callConversationListAnswer(payload) {
  try {
    // 몽고 디비에서 불러올 경우 여기서 데이터 넘기는 처리 -> app.vue 로 넘어감
    // 서버 요청
    const response = await getQueryList(payload);
    const queries = Array.isArray(response.data.result) ? response.data.result : [];

    if (queries.length === 0) {
      return [];
    }
    // 데이터 매핑
    return queries.map(query => ({
      id: query.query_id,
      title: query.query,
      messages: query.messages,
      answer: query.contents?.answer?.content || '',
      recomImage: query.contents?.images || [], // contents.images 배열 매핑
      recomList: query.questions || [], // questions 배열 매핑
      documents: query.attachments || [], // attachments 배열 매핑
      fewshots: query.references || [], // references 배열 매핑
      answerDate: query.date,
      agent_code: query.agent_id,
      log_id: query.query_id,
      session_id: query.session_id,
      keywords: query.contents?.keywords || [],
      images: query.contents?.images || [],
      attachments: query.attachments || [],
      questions: query.questions || [],
      loading: false,
      queryLoading: false,
      referenceLoading: false,
      searchList: query.searchList || [],
      ragDocuments: query.ragDocuments || [],
    }));
  } catch (error) {
    console.error('Error in callConversationListAnswer:', error);
    return [];
  }
}

// Querys Collection APIs
export function getQueryList(payload) {
  const headers = {
    'Content-Type': 'application/json',
  };

  return httpClient.post(`${CHATBOT_LOGGER_URL}/${loggerBasic}`, {
    collection: 'querys',
    agent_id: getDomainInfo().chatbotCode,
    session_id: payload.session_id,
    email: payload.email,
    sort: 'asc',
  }, { headers: headers });
}


/**
 * 채팅창 정보에 대한 서버 질의 처리를 위한 인터페이스 함수
 * @param Object 채팅창 세션 목록을 호출하기 위한 사용자 정보를 담은 객체
 * @returns 현재 사용자의 가용 채팅창 목록 배열
 */
export async function callConversationList(payload) {
  try {
    // 서버 요청
    const response = await getSessionList(payload);

    // 응답 데이터가 배열이 아닐 경우 처리
    const sessions = Array.isArray(response.data.result) ? response.data.result : [];

    if (sessions.length === 0) {
      return [];
    }

    // 데이터 매핑
    return sessions.map(session => ({
      id: session.email,
      convId: session.session_id,
      chatbotCode: session.agent_id,
      session_id: session.session_id, // LnbWrapper에서 사용하는 session_id 추가
      title: session.title,
      searchType: 'basic',
      shareType: 'oneShare',
      userList: [],
      pin: session.pin,
      pinnedDate: session.pinnedDate,
      conversationDate: session.date,
      promptId: session.promptId,
      domainNode: {},
      subcategoryNode: {},
      agent_code: session.agent_id,
      email: session.email,
      chatMode: session.chatMode,
    }));
  } catch (error) {
    console.error('Error in callConversationList:', error);
    return [];
  }
}

// Sessions Collection APIs
export function getSessionList(payload) {

  const headers = {
    'Content-Type': 'application/json',
  };

  return httpClient.post(`${CHATBOT_LOGGER_URL}/${loggerBasic}`, {
    collection: 'sessions',
    agent_id: payload.agent_id,
    email: payload.email,
    sort: 'asc',
  }, { headers: headers });
}


// Feedbacks Collection APIs
export async function saveFeedback(payload) {
  try {
    // 먼저 기존 피드백 삭제
    await httpClient.delete(`${CHATBOT_LOGGER_URL}/${loggerBasic}`, {
      params: {
        collection: 'feedbacks',
        session_id: payload.session_id,
        answer_id: payload.answer_id,
        agent_id: payload.agent_id,
      },
    });

    // 새 피드백 저장
    const feedbackData = {
      collection: 'feedbacks',
      session_id: payload.session_id,
      answer_id: payload.answer_id,
      agent_id: payload.agent_id,
      thumb: payload.thumb,
      reason: payload.reason || [],
      comment: payload.comment || '',
      created_at: moment().format('YYYY-MM-DD HH:mm:ss'),
    };

    return httpClient.post(`${CHATBOT_LOGGER_URL}/${loggerBasic}/save`, feedbackData);
  } catch (error) {
    console.error('Error in saveFeedback:', error);
    throw error;
  }
}

// 세션 삭제
export function deleteSession(payload) {
  return httpClient.delete(`${CHATBOT_LOGGER_URL}/${loggerBasic}`, {
    params: {
      collection: 'sessions',
      agent_id: payload.agent_id,
      session_id: payload.session_id,
    },
  });
}