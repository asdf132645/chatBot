import { resolveAgwUrlGenAiServer } from '@/shared/config/env';

class FileManagerApi {
  private baseUrl: string;

  constructor() {
    this.baseUrl = resolveAgwUrlGenAiServer('https://bb8-filemgr-dev.dev.helpnow.ai');
  }

  /**
   * 업로드 상태 확인 (일반 HTTP)
   */
  async checkUploadStatus(agentCode: string) {
    const url = `${this.baseUrl}/knowledge-docs/docs/upload/${agentCode}/status/check`;
    
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return { success: true, data };
    } catch (error: any) {
      console.error('업로드 상태 확인 실패:', error);
      return { 
        success: false, 
        error: error.message || '업로드 상태 확인 중 오류가 발생했습니다.' 
      };
    }
  }

  /**
   * 최신 업로드 상태 확인 (SSE)
   */
  async getLatestUploadStatus(agentCode: string): Promise<EventSource | { success: false; error: string }> {
    const url = `${this.baseUrl}/knowledge-docs/docs/upload/${agentCode}/status/latest`;
    
    try {
      const eventSource = new EventSource(url);

      return eventSource;
    } catch (error: any) {
      console.error('SSE 연결 실패:', error);
      return { 
        success: false, 
        error: error.message || 'SSE 연결 중 오류가 발생했습니다.' 
      };
    }
  }
}

export const fileManagerApi = new FileManagerApi();
