// src/domains/sBox/application/useSBox.js

import { ref } from 'vue'
import { SBoxEntity } from '../domain/sBoxEntity'
import { sBoxApi } from '../infrastructure/sBoxApi'
import { useToast } from 'vue-toastification'

/**
 * S-Box 애플리케이션 서비스
 */
export function useSBox() {
  const loading = ref(false)
  const error = ref(null)
  const sBoxNode = ref(null)
  const toast = useToast()

  /**
   * S-Box 노드 생성
   */
  async function createSBoxNode(agentCode, nodeName = 'sbox') {
    loading.value = true
    error.value = null

    try {
      const sBoxEntity = new SBoxEntity({
        agentCode,
        nodeName
      })

      if (!sBoxEntity.isValid()) {
        toast.error('유효하지 않은 S-Box 엔티티입니다.')
        return {
          success: false,
          error: '유효하지 않은 S-Box 엔티티입니다.'
        }
      }

      const result = await sBoxApi.createSBoxNode(agentCode, nodeName)

      if (result.success) {
        return {
          success: true,
          nodeId: result.data
        }
      } else {
        toast.error(result.error || 'S-Box 노드 생성에 실패했습니다.')
        return {
          success: false,
          error: result.error || 'S-Box 노드 생성에 실패했습니다.'
        }
      }
    } catch (err) {
      error.value = err.message
      console.error('S-Box 노드 생성 실패:', err)
      toast.error(err.message || 'S-Box 노드 생성 중 오류가 발생했습니다.')
      return {
        success: false,
        error: err.message
      }
    } finally {
      loading.value = false
    }
  }

  async function createSBoxNodeId(agentCode, nodeName = 'sbox') {
    return await createSBoxNode(agentCode, nodeName)
  }

  return {
    // 상태
    loading,
    error,
    sBoxNode,
    
    // 메서드
    createSBoxNode,
    createSBoxNodeId
  }
}
