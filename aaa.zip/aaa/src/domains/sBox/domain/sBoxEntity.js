// src/domains/sBox/domain/sBoxEntity.js

/**
 * S-Box 도메인 엔티티
 */
export class SBoxEntity {
  constructor({
    id = null,
    agentCode = '',
    nodeName = 'sbox',
    nodeId = null,
    createdAt = null,
    updatedAt = null
  } = {}) {
    this._id = id
    this._agentCode = agentCode
    this._nodeName = nodeName
    this._nodeId = nodeId
    this._createdAt = createdAt
    this._updatedAt = updatedAt
  }

  // Getters
  get id() { return this._id }
  get agentCode() { return this._agentCode }
  get nodeName() { return this._nodeName }
  get nodeId() { return this._nodeId }
  get createdAt() { return this._createdAt }
  get updatedAt() { return this._updatedAt }

  // Setters
  set nodeId(value) { this._nodeId = value }
  set updatedAt(value) { this._updatedAt = value }

  /**
   * S-Box 노드 생성 요청 데이터
   */
  toCreateRequest() {
    return {
      agent_code: this._agentCode,
      node_name: this._nodeName
    }
  }

  /**
   * S-Box 노드 응답 데이터로부터 엔티티 생성
   */
  static fromResponse(data) {
    return new SBoxEntity({
      id: data.id,
      agentCode: data.agent_code,
      nodeName: data.node_name,
      nodeId: data.node_id,
      createdAt: data.created_at,
      updatedAt: data.updated_at
    })
  }

  /**
   * 유효성 검사
   */
  isValid() {
    return !!(this._agentCode && this._nodeName)
  }
}
