// src/domains/sBox/infrastructure/sBoxApi.ts

import { GENAI_SERVER_URL } from '@/shared/config/endpoints'

/**
 * S-Box API 클라이언트
 */
export class SBoxApi {
  private baseUrl: string

  constructor() {
    this.baseUrl = GENAI_SERVER_URL
  }

  /**
   * S-Box 노드 생성
   */
  async createSBoxNode(agentCode: string, nodeName: string = 'sbox') {
    const url = `${this.baseUrl}/agent-code/${agentCode}/node/domain`
    
    const payload = {
      agent_code: agentCode,
      node_name: nodeName
    }

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()
      return {
        success: true,
        data: data.data // data 필드만 추출
      }
    } catch (error) {
      console.error('S-Box 노드 생성 실패:', error)
      return {
        success: false,
        error: error.message
      }
    }
  }

}

// 싱글톤 인스턴스
export const sBoxApi = new SBoxApi()
