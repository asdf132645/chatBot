<template>
  <div :class="{'answer-item':true,'last-answer':lastAnswer}" :id="`answer-${answer.id}`">
    <div class="answer-right-wrapper">
      <!-- 제목 -->
      <h2 class="answer-title answer-box">
        <img v-if="!answer.title" class="blinking" :src="require('@/assets/images/title_paragraph_light.svg')" />
        <span v-else>{{ answer.title }}</span>
      </h2>
      
      <!-- 과정분석 -->
      <div class="answer-procedure-wrapper answer-box">
        <div v-if="!answer.searchList || !answer.searchList.length" class="blinking"></div>
        <div v-else>
          <div class="state-head">
            <div class="state-base state-title">
              <img class="" :src="require('@/assets/images/topology-star-3.svg')" />
              <span class="state-title-text">처리 과정</span>
            </div>
            <div class="state-base state-fold" @click="toggleState()">
              <BaseIcon name="ArrowTailUp" :size="20" v-if="!isStateOpen" />
              <BaseIcon name="ArrowTailDown" :size="20" v-if="isStateOpen" />
            </div>
          </div>
          <transition name="slide">
            <div class="state-body" ref="stateBody" v-if="isStateOpen">
              <transition-group name="fade-list" tag="div">
                <div class="state-base state-detail" v-for="searchItem in answer.searchList" :key="searchItem.id">
                  <img class="blinking" :src="require('@/assets/images/search.svg')"
                       v-if="searchItem.status === 'search'" />
                  <img class="blinking" :src="require('@/assets/images/loading.svg')"
                       v-if="searchItem.status === 'loading'" />
                  <img class="blinking" :src="require('@/assets/images/check.svg')"
                       v-if="searchItem.status === 'check'" />
                  <span class="state-detail-target-info text-truncate">{{ searchItem.keyword }}</span>
                  <span class="state-detail-target-title">{{ searchItem.statusDetail }}</span>
                </div>
              </transition-group>
              <div class="state-base state-detail state-result">
                <img class="blinking" :src="require('@/assets/images/loading.svg')" v-if="queryLoading" />
                <img class="blinking" :src="require('@/assets/images/check.svg')" v-if="!queryLoading" />
                <span class="state-detail-target-title state-last">
                    <span v-if="queryLoading">{{ t('answercontent.answercontent_key2') }}</span>
                    <span v-if="!queryLoading">{{ t('answercontent.answercontent_key3') }}</span>
                  </span>
              </div>
            </div>
          </transition>
        </div>
      </div>

      <!-- 답변 텍스트 -->
      <template v-if="answer.isMultiAnswer">
        <div class="multi-answer-text-wrapper answer-box">
          <div class="multi-answer-text genai-answer-text">
            <img v-if="answer.isLoading" class="blinking" :src="require('@/assets/images/long_paragraph_light.svg')" />
            <div v-else v-html="changeMarkDown(answer.answer)"></div>
          </div>          
          <div class="multi-answer-text genai-answer-text">
            <img v-if="answer.isLoading1" class="blinking" :src="require('@/assets/images/long_paragraph_light.svg')" />
            <div v-else v-html="changeMarkDown(answer.answer1)"></div>
          </div>          
        </div>
      </template>

      <template v-else>
        <div class="answer-text-wrapper answer-box">
          <img v-if="!answer.answer" class="blinking" :src="require('@/assets/images/long_paragraph_light.svg')" />
          <div v-else class="genai-answer-text" v-html="changeMarkDown(answer.answer)"></div>
        </div>
      </template>


        <RagReferenceList 
          class="answer-box"
          :isLoading="answer.isLoading"
          :referenceList="answer.referenceList || []"
        />
    </div>
    
    <!-- <div class="answer-left-wrapper">
      
    </div> -->
  </div>
</template>

<script setup>
import { ref, defineProps, defineEmits } from 'vue';
import { useI18n } from 'vue-i18n';
import BaseIcon from '@/component/BaseIcon.vue';
import RagReferenceList from './RagReferenceList.vue';

// Props
const props = defineProps({
  answer: {
    type: Object,
    required: true,
    default: () => ({
      id: '',
      query: '',
      answer: '',
      isLoading: false,
      isStateOpen: false,
      searchList: [],
      referenceList: [], 
      isMultiAnswer: false
    })
  },
  searchList: {
    type: Array,
    default: () => []
  },
  lastAnswer: {
    type: Boolean,
    default: false
  },
  queryLoading: {
    type: Boolean,
    default: false
  }
});

// Emits
const emit = defineEmits(['toggleState']);

// i18n
const { t } = useI18n();

// Store
// const store = useStore();
// const isMultiAnswer = computed(() => store.getters.multiAnswer || false );

// 상태
const isStateOpen = ref(props.answer.isStateOpen || false);


// 마크다운 렌더링 함수
function changeMarkDown(letters) {
  if (!letters) return '';
  
  const marked = require('marked');
  const renderer = new marked.Renderer();
  renderer.link = (href, title, text) => 
    `<a href=${href} target="_blank" style="text-decoration: underline;">${text}</a>`;
  renderer.code = (code, language) => 
    `<pre class="custom-code-block"><code class="language">${language || ''}<br/>${code}</code></pre>`;
  
  marked.setOptions({
    renderer,
    gfm: true,
    headerIds: false,
    tables: true,
    breaks: true,
    pedantic: false,
    smartLists: true,
    smartypants: false,
  });
  
  // 데이터 전처리 - 표 렌더링을 위한 개행 처리
  
  // 표 시작 전에 빈 줄 추가 (마크다운 표 인식을 위해)
  letters = letters.replace(/([^\n])\n(\|)/g, '$1\n\n$2');  // 표 시작 전에 빈 줄 추가
  letters = letters.replace(/^(\|)/gm, '\n$1');              // 문서 시작이 표인 경우
  
  // 표 구분자 정리
  letters = letters.replace(/\|\n\n\|/g, '|\n|');           // 빈 줄이 있는 표 구분자 정리
  letters = letters.replace(/\|\s*\n\s*\|/g, '|\n|');       // 파이프 사이의 공백과 개행 정리
  letters = letters.replace(/\|\|/g, '|\n|');               // 연속된 파이프를 개행으로 분리
  
  // 표의 각 행이 제대로 구분되도록 처리
  letters = letters.replace(/(\|[^|\n]*\|)\s*\n\s*(\|[^|\n]*\|)/g, '$1\n$2');
  
  // 연속된 빈 줄 정리 (표는 보존)
  letters = letters.replace(/\n\n\n+/g, '\n\n');
  
  return marked(letters);
}

// 상태 토글 함수
function toggleState() {
  isStateOpen.value = !isStateOpen.value;
  emit('toggleState', { answerId: props.answer.id, isOpen: isStateOpen.value });
}
</script>
