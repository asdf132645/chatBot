<template>
  <aside>
    <!-- 로딩 상태 -->
    <div v-if="isLoading">
      <!-- <div class="reference-group">
        <div class="reference-item" style="padding: 0 !important">
          <img class="blinking" :src="require('@/assets/images/refer_paragraph_light.svg')" />
        </div>
        <div class="reference-item" style="padding: 0 !important">
          <img class="blinking" :src="require('@/assets/images/refer_paragraph_light.svg')" />
        </div>
        <div class="reference-item" style="padding: 0 !important">
          <img class="blinking" :src="require('@/assets/images/refer_paragraph_light.svg')" />
        </div>
      </div> -->
    </div>

    <!-- 참조 문서 목록 -->
    <transition name="fade">
      <div v-if="!isLoading && shouldShow">
        <div class="aside-title wrapper-title">
          <div class="ref-area" @click="activeReference()" v-if="hasReferenceList">
            <span class="title-icon" v-if="isRefOpen">
              <BaseIcon name="BulbIdea"/>
            </span>
            <span class="title-icon" v-if="!isRefOpen">
              <BaseIcon name="BulbIdeaOff"/>
            </span>
            <h4 class="title-text">참조 문서</h4>
          </div>
        </div>
        
        <div class="reference-group">
          <transition name="fade">
            <div v-if="isRefOpen && hasReferenceList" class="reference-group-wrapper">
              <div
                class="reference-item"
                v-for="item in pagedReferenceList"
                :key="item.id"
                @click="openUrl(item.url)"
                :title="item.title"
              >
                <h4 class="title">{{ item.title }}</h4>
                <p class="desc line-clamp">{{ item.content }}</p>
              </div>
            </div>
          </transition>
        </div>

        <!-- 페이지네이션 -->
        <div
          class="reference-group-control-wrapper"
          v-if="totalPage > 1 && hasReferenceList"
        >
          <div class="reference-group-control">
            <div class="pagination-status">
              <span class="current-page">{{ currentPage }}</span> /
              <span class="total-page">{{ totalPage }}</span>
            </div>
            <button
              class="pagination-btn left"
              :disabled="isFirstPage"
              @click="prevPage"
            >
              <BaseIcon name="ArrowLeft" :size="18" />
            </button>
            <button
              class="pagination-btn right"
              :disabled="isLastPage"
              @click="nextPage"
            >
              <BaseIcon name="ArrowRight" :size="18" />
            </button>
          </div>
        </div>
      </div>
    </transition>
  </aside>
</template>

<script setup>
import { ref, computed, defineProps } from 'vue';
import BaseIcon from '@/component/BaseIcon.vue';

// Props
const props = defineProps({
  isLoading: {
    type: Boolean,
    default: true
  },
  referenceList: {
    type: Array,
    default: () => []
  }
});

// 상태
const isRefOpen = ref(true);
const currentPage = ref(1);
const itemsPerPage = 3;

// 계산된 속성
const shouldShow = computed(() => props.referenceList && props.referenceList.length > 0);
const hasReferenceList = computed(() => props.referenceList && props.referenceList.length > 0);
const totalPage = computed(() => Math.ceil(props.referenceList.length / itemsPerPage));
const isFirstPage = computed(() => currentPage.value === 1);
const isLastPage = computed(() => currentPage.value === totalPage.value);

const pagedReferenceList = computed(() => {
  const start = (currentPage.value - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  return props.referenceList.slice(start, end);
});

// 메서드
function activeReference() {
  isRefOpen.value = !isRefOpen.value;
}

function openUrl(url) {
  if (url) {
    window.open(url, '_blank');
  }
}

function prevPage() {
  if (currentPage.value > 1) {
    currentPage.value--;
  }
}

function nextPage() {
  if (currentPage.value < totalPage.value) {
    currentPage.value++;
  }
}
</script>
