import axios from 'axios';
import { getDomainInfo } from '@/domains/chat/infrastructure/chatApi';

// RAG API 기본 설정
import { RAG_SERVER_URL } from '../../../shared/config/endpoints';
const AGENT_CODE = getDomainInfo().chatbotCode;

// LLM 서비스 인증 정보
const LLM_SERVICE_AUTH = {
  "engine_name": "huggingface/novita/openai/gpt-oss-120b",
  "llm_service_key_id": "541f4c20-8a1c-11f0-a363-93b57b039dfb",
  "service_vendor": "gpt oss",
  "engine_type": "oss",
  "credentials": "08BFCF388E6144F3CFE79CD631C28D32FD75F5CFE027919B0ADCF3E49EE07FD5CE22AE1DF0195552251A64262D2DAA1B15E6DA0100D10C1D5386BD98BBB4F96B23202E606F04A5C1B156662BCD948A87FC421D1EAACC3DC44E07405F63C648BA"
};

/**
 * RAG Retrieve API - 컨텍스트 데이터를 가져오는 API
 * @param {Object} params - 파라미터
 * @param {string} params.query - 검색 쿼리
 * @param {string} params.sessionId - 세션 ID
 * @param {Array} params.multiDomainIds - 도메인 ID 배열
 * @param {boolean} params.queryOptimize - 쿼리 최적화 여부
 * @returns {Promise<Object>} 검색 결과
 */
export async function retrieveContext({ query, sessionId, multiDomainIds, queryOptimize = true }) {
  const url = `${RAG_SERVER_URL}/api/rag/agent-code/${AGENT_CODE}/genai/retrieve`;
  
  const requestData = {
    messages: JSON.stringify([{ role: "user", content: query }]),
    session_id: sessionId,
    multi_domain_ids: multiDomainIds || [],
    query_optimize: queryOptimize,
    s_box_enabled: true
  };

  try {
    console.log('RAG Retrieve 요청:', { url, requestData });
    
    const response = await axios.post(url, requestData, {
      headers: {
        'Content-Type': 'application/json',
        'LLMServiceAuth': JSON.stringify(LLM_SERVICE_AUTH)
      }
    });

    console.log('RAG Retrieve 응답:', response.data);
    return response.data;
  } catch (error) {
    console.error('RAG Retrieve 오류:', error);
    // HTTP 에러 상태 코드 추가
    if (error.response && error.response.status) {
      error.status = error.response.status;
    }
    throw error;
  }
}

/**
 * RAG Generate API - 컨텍스트 데이터를 기반으로 스트림 SSE 응답을 생성하는 API
 * @param {Object} params - 파라미터
 * @param {string} params.insightPromptId - 인사이트 프롬프트 ID
 * @param {string} params.sessionId - 세션 ID
 * @param {Array} params.messages - 메시지 배열
 * @param {Array} params.dynamicVariables - 동적 변수 배열 (컨텍스트 포함)
 * @param {boolean} params.stream - 스트림 여부
 * @returns {Promise<Response>} SSE 스트림 응답
 */
export async function generateResponse({ insightPromptId, sessionId, messages, dynamicVariables, stream = true }) {
  const url = `${RAG_SERVER_URL}/api/rag/agent-code/${AGENT_CODE}/genai/generate`;
  
  const requestData = {
    insight_prompt_id: insightPromptId,
    log_id: "",
    stream: stream,
    messages: JSON.stringify(messages),
    session_id: sessionId,
    dynamic_variables: dynamicVariables || []
  };

  try {
    console.log('RAG Generate 요청:', { url, requestData });
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'LLMServiceAuth': JSON.stringify(LLM_SERVICE_AUTH)
      },
      body: JSON.stringify(requestData)
    });

    if (!response.ok) {
      const errorMessage = await response.text().catch(() => '');
      const error = new Error(`HTTP error! status: ${response.status}`);
      error.status = response.status;
      error.message = errorMessage || `HTTP error! status: ${response.status}`;
      throw error;
    }

    return response;
  } catch (error) {
    console.error('RAG Generate 오류:', error);
    throw error;
  }
}

/**
 * RAG 채팅을 위한 통합 함수
 * @param {Object} params - 파라미터
 * @param {string} params.query - 사용자 쿼리
 * @param {string} params.sessionId - 세션 ID
 * @param {Array} params.multiDomainIds - 도메인 ID 배열
 * @param {string} params.insightPromptId - 인사이트 프롬프트 ID
 * @param {Array} params.chatHistory - 채팅 히스토리
 * @param {Function} params.onStream - 스트림 데이터 콜백
 * @returns {Promise<Object>} 결과
 */
export async function ragChat({ query, sessionId, multiDomainIds, insightPromptId, chatHistory = [], onStream }) {
  try {
    // 1. Retrieve - 컨텍스트 검색
    const retrieveResult = await retrieveContext({
      query,
      sessionId,
      multiDomainIds,
      queryOptimize: true
    });

    // Retrieve 완료 상태 전달 (documents를 contexts로 변환)
    if (onStream) {
      const contexts = retrieveResult?.documents?.map((doc, index) => ({
        title: doc.doc_title || 'Unknown',
        content: doc.content || '',
        url: doc.doc_url || '',
        ranking: index + 1,
        page: doc.page || 1
      })) || [];
      
      onStream({ 
        data: { 
          status: 'retrieving',
          contexts: contexts
        } 
      });
    }

    // 2. 컨텍스트 데이터를 dynamic_variables로 변환
    const dynamicVariables = [];
    
    // concat_context를 search_context로 추가
    if (retrieveResult && retrieveResult.concat_context) {
      dynamicVariables.push({
        name: "search_context",
        value: retrieveResult.concat_context
      });
    }
    
    // 각 문서를 개별 context로 추가
    // if (retrieveResult && retrieveResult.documents && retrieveResult.documents.length > 0) {
    //   retrieveResult.documents.forEach((doc, index) => {
    //     const contextValue = `**Title: ${doc.doc_title || 'Unknown'}**\nRanking: ${index + 1}\nURL: ${doc.url || ''}\nContent: ${doc.content || ''}`;
        
    //     dynamicVariables.push({
    //       name: "context",
    //       value: contextValue
    //     });
    //   });
    // }

    // 3. 메시지 히스토리 구성
    const messages = [
      ...chatHistory,
      { role: "user", content: query }
    ];

    // 4. Generate - 응답 생성
    // Generate 시작 상태 전달
    if (onStream) {
      onStream({ 
        data: { 
          status: 'generating'
        } 
      });
    }

    const response = await generateResponse({
      insightPromptId,
      sessionId,
      messages,
      dynamicVariables,
      stream: true
    });

      // 5. SSE 스트림 처리
     if (onStream && response.body) {
       const reader = response.body.getReader();
       const decoder = new TextDecoder();

       try {
         // eslint-disable-next-line no-constant-condition
         while (true) {
           const { done, value } = await reader.read();
           if (done) break;

           const chunk = decoder.decode(value);
           const lines = chunk.split('\n');
           
           let currentEvent = 'message';
           let piece = '';

           for (const line of lines) {
             if (line.startsWith('event:')) {
               currentEvent = line.slice(6).trim();
               if (currentEvent === 'stop') {
                 console.log('RAG Generate 완료 신호 수신 (event: stop)');
                 onStream({ done: true });
                 return;
               }
               continue;
             }
             if (line.startsWith('data:')) {
                const data = line.replace(/^data:\s?/, '');
               
               if (data === '[DONE]') {
                 console.log('RAG Generate 완료 신호 수신 (data: [DONE])');
                 onStream({ done: true });
                 return;
               }
               
               if (currentEvent !== 'stop') {
                 // 빈 data 라인을 감지해서 개행 추가
                 if (data === '') {
                   piece += '\n';
                 } else {
                   piece += data;
                 }
               }
               continue;
             }
           }

           if (piece.length > 0) {
             // piece에 개행 치환 로직 적용
             let processedPiece = piece
               .replace(/\n\n\n\n\n/g, '<<5개연속개행>>')
               .replace(/\n\n\n\n/g, '<<4개연속개행>>')
               .replace(/\n\n\n/g, '<<3개연속개행>>')
               .replace(/\n\n/g, '')
               .replace(/<<5개연속개행>>/g, '\n')
               .replace(/<<4개연속개행>>/g, '\n')
               .replace(/<<3개연속개행>>/g, '\n')
               
             onStream({ 
               data: { 
                 content: processedPiece,
                 type: 'text'
               } 
             });
           }
         }
      } finally {
        reader.releaseLock();
        // 스트림이 정상적으로 종료된 경우 완료 신호 전달
        if (onStream) {
          console.log('RAG Generate 스트림 정상 종료');
          onStream({ done: true });
        }
      }
    }

    return {
      success: true,
      contexts: retrieveResult?.contexts || [],
      response: response
    };

  } catch (error) {
    console.error('RAG 채팅 오류:', error);
    throw error;
  }
}
