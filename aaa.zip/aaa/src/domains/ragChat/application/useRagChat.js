import { ref, reactive } from 'vue';
import { ragChat } from '../infrastructure/ragApi';

/**
 * RAG 채팅을 위한 컴포저블
 */
export function useRagChat() {
  // 상태 관리
  const chatList = ref([]);
  const isStreaming = ref(false);
  const currentAnswer = ref(null);
  const searchList = ref([]);
  const referenceList = ref([]);
  const queryLoading = ref(false);
  const insightPromptId = ref('4bd9cbed-9346-4dd3-b5e5-ff4c2a5514eb');

  // 설정
  const config = reactive({
    insightPromptId: insightPromptId.value, // 기본 프롬프트 ID
    multiDomainIds: [
      {
        // label: "서울시청 문서",
        // type: "domain",
        domainId: "68b911b31b88a11dcecaa6e1"
      }
    ]
  });

  /**
   * RAG 채팅 시작
   * @param {Object} params - 파라미터
   * @param {string} params.query - 사용자 쿼리
   * @param {string} params.sessionId - 세션 ID
   * @param {Array} params.multiDomainIds - 도메인 ID 배열 (선택사항)
   * @param {string} params.insightPromptId - 인사이트 프롬프트 ID (선택사항)
   * @param {boolean} params.isMultiAnswer - 다중 답변 여부 (선택사항)
   * @param {Function} params.onScroll - 스크롤 콜백 (선택사항)
   */
  async function startRagChat({ query, sessionId, multiDomainIds, insightPromptId, isMultiAnswer, onScroll }) {
    if (isStreaming.value) {
      console.warn('이미 스트리밍 중입니다.');
      return;
    }

    try {
      isStreaming.value = true;
      queryLoading.value = true;

      // 새로운 답변 객체 생성
      const answerId = Date.now().toString();
      const newAnswer = {
        id: answerId,
        query: query,
        title: query, // 쿼리를 제목으로 설정
        answer: '',
        answer1: '', // 멀티 답변을 위한 두 번째 답변
        isLoading: true,
        isLoading1: false, // 두 번째 답변 로딩 상태
        isStateOpen: true, // 처음에 열려있도록 설정
        searchList: [],
        referenceList: [],
        createdAt: new Date().toISOString(),
        isMultiAnswer: isMultiAnswer
      };

      currentAnswer.value = newAnswer;
      chatList.value.push(newAnswer);

      // 각 답변의 검색 상태 초기화
      newAnswer.searchList = [
        { id: `search-${answerId}-1`, keyword: '데이터 검색', status: 'loading', statusDetail: '데이터 검색중' }
      ];
      
      // 전역 searchList도 업데이트 (호환성을 위해 유지)
      searchList.value = newAnswer.searchList;

      // 멀티 답변인 경우 두 답변을 동시에 병렬로 실행
      if (isMultiAnswer && currentAnswer.value) {
        // 두 번째 답변 로딩 상태 즉시 시작
        currentAnswer.value.isLoading1 = true;
        
        // 두 답변을 동시에 병렬로 실행 (Promise.allSettled 사용으로 각각 독립적으로 처리)
        const [firstAnswerResult, secondAnswerResult] = await Promise.allSettled([
          ragChat({
            query,
            sessionId,
            multiDomainIds: multiDomainIds || config.multiDomainIds,
            insightPromptId: insightPromptId || config.insightPromptId,
            chatHistory: getChatHistory(),
            onStream: (streamData) => handleStreamData(streamData, onScroll)
          }),
          ragChat({
            query,
            sessionId,
            multiDomainIds: multiDomainIds || config.multiDomainIds,
            insightPromptId: insightPromptId || config.insightPromptId,
            chatHistory: getChatHistory(),
            onStream: (streamData) => handleSecondAnswerStreamData(streamData, onScroll)
          })
        ]);

        // 각 답변의 결과 처리
        if (firstAnswerResult.status === 'rejected') {
          console.error('첫 번째 답변 오류:', firstAnswerResult.reason);
          if (currentAnswer.value) {
            currentAnswer.value.answer = '첫 번째 답변 생성 중 오류가 발생했습니다.';
            currentAnswer.value.isLoading = false;
          }
        }

        if (secondAnswerResult.status === 'rejected') {
          console.error('두 번째 답변 오류:', secondAnswerResult.reason);
          if (currentAnswer.value) {
            currentAnswer.value.answer1 = '두 번째 답변 생성 중 오류가 발생했습니다.';
            currentAnswer.value.isLoading1 = false;
          }
        }
      } else {
        // 단일 답변인 경우 기존 로직
        await ragChat({
          query,
          sessionId,
          multiDomainIds: multiDomainIds || config.multiDomainIds,
          insightPromptId: insightPromptId || config.insightPromptId,
          chatHistory: getChatHistory(),
          onStream: (streamData) => handleStreamData(streamData, onScroll)
        });
      }

    } catch (error) {
      console.error('RAG 채팅 오류:', error);
      if (currentAnswer.value) {
        // HTTP 에러 상태 코드 체크
        if (error.status && (error.status >= 400 && error.status < 600)) {
          currentAnswer.value.answer = '<p>죄송합니다. 다시 시도해주세요.</p>';
        } else {
          currentAnswer.value.answer = '죄송합니다. 오류가 발생했습니다.';
        }
        currentAnswer.value.isLoading = false;
      }
      queryLoading.value = false;
    } finally {
      isStreaming.value = false;
    }
  }


  /**
   * 두 번째 답변 스트림 데이터 처리
   * @param {Object} streamData - 스트림 데이터
   * @param {Function} onScroll - 스크롤 콜백
   */
  function handleSecondAnswerStreamData(streamData, onScroll) {
    if (!currentAnswer.value) return;

    if (streamData.done) {
      // 두 번째 답변 스트리밍 완료
      currentAnswer.value.isLoading1 = false;
      return;
    }

    if (streamData.data) {
      const data = streamData.data;
      
      // 두 번째 응답 텍스트 누적
      if (data.content) {
        currentAnswer.value.answer1 += data.content;
        
        // 첫 번째 컨텐츠가 도착하면 로딩 상태 해제
        if (currentAnswer.value.isLoading1 && currentAnswer.value.answer1.trim()) {
          currentAnswer.value.isLoading1 = false;
        }
        
        // 스크롤 콜백 호출
        if (onScroll) {
          onScroll();
        }
      }
    }
  }

  /**
   * 스트림 데이터 처리
   * @param {Object} streamData - 스트림 데이터
   * @param {Function} onScroll - 스크롤 콜백
   */
  function handleStreamData(streamData, onScroll) {
    if (!currentAnswer.value) return;

    if (streamData.done) {
      // 스트리밍 완료
      currentAnswer.value.isLoading = false;
      queryLoading.value = false;
      // 분석 과정 닫기
      currentAnswer.value.isStateOpen = false;
      return;
    }

    if (streamData.data) {
      const data = streamData.data;
      
      // 응답 텍스트 누적
      if (data.content) {
        currentAnswer.value.answer += data.content;
        
        // 첫 번째 컨텐츠가 도착하면 로딩 상태 해제
        if (currentAnswer.value.isLoading && currentAnswer.value.answer.trim()) {
          currentAnswer.value.isLoading = false;
        }
        
        // 스크롤 콜백 호출
        if (onScroll) {
          onScroll();
        }
      }

      // JSON 형태의 메타데이터 처리
      if (data.type !== 'text' && data.contexts) {
        currentAnswer.value.referenceList = data.contexts.map((ctx, index) => ({
          id: `ref-${currentAnswer.value.id}-${index}`,
          title: ctx.title || 'Unknown',
          content: ctx.content || '',
          url: ctx.url || '',
          ranking: ctx.ranking || index + 1,
          page: ctx.page || 1
        }));
        // 전역 referenceList는 마지막 답변의 referenceList로 업데이트 (호환성을 위해 유지)
        referenceList.value = currentAnswer.value.referenceList;
      }

      // JSON 형태의 상태 정보 처리
      if (data.type !== 'text') {
        if (data.status === 'retrieving') {
          updateSearchStatus(`search-${currentAnswer.value.id}-1`, 'check', '검색 완료');
        }
      }

    }
  }

  /**
   * 검색 상태 업데이트
   * @param {string} searchId - 검색 ID
   * @param {string} status - 상태
   * @param {string} statusDetail - 상태 상세
   */
  function updateSearchStatus(searchId, status, statusDetail) {
    // 현재 답변의 searchList 업데이트
    if (currentAnswer.value && currentAnswer.value.searchList) {
      const searchItem = currentAnswer.value.searchList.find(item => item.id === searchId);
      if (searchItem) {
        searchItem.status = status;
        searchItem.statusDetail = statusDetail;
      }
    }
    
    // 전역 searchList도 업데이트 (호환성을 위해 유지)
    const globalSearchItem = searchList.value.find(item => item.id === searchId);
    if (globalSearchItem) {
      globalSearchItem.status = status;
      globalSearchItem.statusDetail = statusDetail;
    }
  }

  /**
   * 채팅 히스토리 가져오기
   * @returns {Array} 채팅 히스토리
   */
  function getChatHistory() {
    return chatList.value
      .filter(chat => !chat.isLoading && chat.answer)
      .map(chat => [
        { role: 'user', content: chat.query },
        { role: 'assistant', content: chat.answer }
      ])
      .flat();
  }

  /**
   * 답변 상태 토글
   * @param {string} answerId - 답변 ID
   */
  function toggleAnswerState(answerId) {
    const answer = chatList.value.find(item => item.id === answerId);
    if (answer) {
      answer.isStateOpen = !answer.isStateOpen;
    }
  }

  /**
   * 채팅 리스트 초기화
   */
  function clearChatList() {
    chatList.value = [];
    currentAnswer.value = null;
    searchList.value = [];
    referenceList.value = [];
  }

  /**
   * 설정 업데이트
   * @param {Object} newConfig - 새로운 설정
   */
  function updateConfig(newConfig) {
    Object.assign(config, newConfig);
  }

  return {
    // 상태
    chatList,
    isStreaming,
    currentAnswer,
    searchList,
    referenceList,
    queryLoading,
    config,

    // 메서드
    startRagChat,
    toggleAnswerState,
    clearChatList,
    updateConfig
  };
}
