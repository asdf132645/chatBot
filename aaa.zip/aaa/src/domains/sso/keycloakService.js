import VueCookies from "vue-cookies"
import BespinSso from "../sso/bespinsso"
const bespinsso = new BespinSso();
 
const ssoService = {
  init() {
    return bespinsso.init();
  },
 
  isLoggedIn() {
    return bespinsso.getKeycloak().authenticated;
  },
 
  getKeycloak() {
    return bespinsso.getKeycloak();
  },
 
  login(options = null) {
    return new Promise(() => {
      const locale = VueCookies.get('BSP_LangCode') || 'en';
      bespinsso.getKeycloak().login(Object.assign({}, locale, options));
    });
  },
 
  logout(options) {
    return new Promise(() => {
      bespinsso.getKeycloak().logout(options);
    });
  },
 
  getSessionCount() {
    return bespinsso.getSessionCount();
  },
 
  logoutAllSession(withoutCurrent = false) {
    return bespinsso.logoutAllSession(withoutCurrent);
  }
};
 
export default ssoService;