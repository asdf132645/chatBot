const Keycloak = require('keycloak-js');
const axios = require('axios');
import { SSO_PARAM, getServerUrl } from '../../shared/config/endpoints';
function BespinSso() {
  var that = this;

  this.init = function() {
    return new Promise(function (resolve, reject) {
      try {
        let params = {
          realm: SSO_PARAM.realm.toUpperCase(),
          clientId: SSO_PARAM.clientId
          // clientId: 'plex_front_local'
        };

        axios.get(getServerUrl('keycloak/get'), {
          params: params,
          excludeToken: true
        }).then(function(response) {
          // console.log('keycloak/get',response.data)
          const keycloakJson = response.data.json;

          that.keycloak = new Keycloak(JSON.parse(keycloakJson));

          that.keycloak.init({
            onLoad: 'check-sso',
            checkLoginIframe: true
          });

          resolve(that.keycloak);
        });
      } catch (e) {
        console.log("BespinSso init", e)
        reject(e);
      }
    });
  };

  this.getKeycloak = function() {
    return this.keycloak;
  };

  this.getSessionCount = function() {
    return new Promise(function (resolve, reject) {
      try {
        var authServerUrl = that.keycloak.authServerUrl;
        var realm = that.keycloak.realm;
        var clientId = that.keycloak.clientId;
        var token = that.keycloak.token;

        axios.get(authServerUrl + '/realms/' + realm + '/api/users/me/session-count', {
          headers: {
            Authorization: 'Bearer ' + token
          },
          params: {
            clientId: clientId
          }
        }).then(function (response) {
          resolve(response.data.count);
        });
      } catch (e) {
        reject(e);
      }
    });
  };

  this.logoutAllSession = function(withoutCurrent) {
    return new Promise(function (resolve, reject) {
      try {
        var authServerUrl = that.keycloak.authServerUrl;
        var realm = that.keycloak.realm;
        var clientId = that.keycloak.clientId;
        var token = that.keycloak.token;
 
        axios.get(authServerUrl + '/realms/' + realm + '/api/users/me/logout-allsession', {
          headers: {
            Authorization: 'Bearer ' + token
          },
          params: {
            clientId: clientId,
            // params 추가
            withoutCurrent: withoutCurrent
          }
        }).then(function () {
          resolve();
        });
      } catch (e) {
        reject(e);
      }
    });
  };

}

export default BespinSso;
