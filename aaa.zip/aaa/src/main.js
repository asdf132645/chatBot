import { createApp } from 'vue';
import { router } from '@/router';
import { store } from '@/store';
import eventBus from '@/util/eventBus';
import App from '@/App.vue';
import GlobalConstants from '@/constants';
import VueCookies from 'vue-cookies';
import { i18n } from '@/common/i18n';
import Toast from 'vue-toastification';
import { AgGridVue } from 'ag-grid-vue3';
import Profile from '@/common/profile';
import BaseIcon from '@/component/BaseIcon';
import vClickOutside from 'v-click-outside';
import teleportClickOutside from './directives/teleportClickOutside';
import tooltipDirective from './directives/tooltip'
import '@/assets/css/scss/global.scss';
import '@/assets/css/scss/AgentChatWrapper.scss';

import 'vue-toastification/dist/index.css';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';
import '@vuepic/vue-datepicker/dist/main.css';

// 저장된 locale 불러와서 초기 설정에 반영
const savedLocale = localStorage.getItem('locale');
if (savedLocale) {
  i18n.global.locale.value = savedLocale;
}

const app = createApp(App);

// 기본 플러그인들 등록
app.use(router);
app.use(store);
app.use(i18n);
app.use(VueCookies);
app.use(vClickOutside);

// Toast 옵션
const toastOptions = {
  transition: "Vue-Toastification__fade",
  maxToasts: 20,
  newestOnTop: true,
  position: "bottom-center",
  timeout: 1000,
  hideProgressBar: true,
  pauseOnFocusLoss: false,
  pauseOnHover: false,
  toastClassName: "plex-toast-class",
  bodyClassName: ["plex-toast-body-class"],
  closeButton: true,
  closeOnClick: false
};
app.use(Toast, toastOptions);

// 전역 컴포넌트 등록
app.component('BaseIcon', BaseIcon);
app.component('AgGridVue', AgGridVue);

// 전역 프로퍼티 등록
app.config.globalProperties.$emitter = eventBus;
app.config.globalProperties.constants = GlobalConstants;
app.config.globalProperties.profile = Profile;

// Intlify devtools 설정 (생략 가능)
if (process.env.NODE_ENV === 'production') {
  global.__INTLIFY_PROD_DEVTOOLS__ = false;
}

// 커스텀 디렉티브 등록
app.directive('teleport-click-outside', teleportClickOutside);
app.directive('tooltip', tooltipDirective);

// 앱 마운트
app.mount('#app');
