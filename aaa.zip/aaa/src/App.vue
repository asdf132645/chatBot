<template>
  <AccessDenied v-if="!plexUseYn"/>
  <main class="main-wrapper" v-else>
    <!-- 공통 배경 이미지 -->
    <div class="background-gradient" v-if="false">
      <img
        class="background-gradient-img"
        :src="require('@/assets/images/Gradient.svg')"
      />
    </div>
    <!-- 공통 왼쪽 LNB 영역 (라우터에 따라 숨기고 싶으면 조건 추가 가능) -->
    <LnbWrapper
      ref="lnbRef"
      v-if="pageStart"
      @changeLoding="_setLoadingPage"
      @selectedConversation="onSelectedConversation"
      @onShareConversation="onShareConversation"
      :logoImg="logoImg"
    />
    <!-- 라우터 뷰 자리 -->
    <section class="section-wrapper" v-if="pageStart">
      <HeaderWrapper
        v-if="showHeader"
        ref="headerRef"
        @selectedAnswer="onSelectedAnswer"
      />
      <router-view
        v-slot="{ Component }"
      >
        <component
          :is="Component"
          ref="contentRef"
          :isLoading="isLoading"
          @deleteConversation="deleteConversation"
          @submit="submitQuery"
          @newSessionCreated="handleNewSessionCreated"
        />
      </router-view>    
    </section>
  </main>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import { useRoute } from 'vue-router';
import { useStore } from 'vuex';
import { useCookies } from '@vueuse/integrations/useCookies'
import ssoService from '@/domains/sso/keycloakService.js';
import { getServerUrl } from '@/shared/config/endpoints';
import axios from 'axios';
import LnbWrapper from '@/layouts/common/LnbWrapper.vue';
import HeaderWrapper from '@/layouts/common/HeaderWrapper.vue';
import {callConversationListAnswer, getDomainInfo, callConversationList} from '@/domains/chat/infrastructure/chatApi';
import { usePlexInfo } from '@/domains/startup/application/getStartupInfo';
import AccessDenied from '@/domains/startup/presentation/accessDenied.vue';
import { startupApi } from '@/domains/startup/infrastructure/startupApi';
const { plexInfo } = usePlexInfo()

const route = useRoute();
const store = useStore();
const cookies = useCookies();

const lnbRef = ref();
const headerRef = ref();
const contentRef = ref();

const isLoading = ref(false);
const pageStart = ref(false);
const tokenKey = ref('');
const plexUseYn = ref(true);
const logoImg = ref('');

const currSession = computed({
  get: () => store.getters.session || {},
  set: v => store.commit('setSession', v),
});

const showHeader = computed(() => route.name === 'FileMangeWrapper');
onMounted(() => {
  // 첫 진입 시 플렉스 인포 내용 불러와서 접근 가능 여부 + 로고 변경을 위한 호출
  getPlexAgentInfo();

  _setLoadingPage(true);
  getApiByEnviroment();
});

/*
* 에이전트 정보는 헬프나우 콘솔에서 외부채널 연동 - plex 설정 값을 가지고오는 부분입니다.
* */
const getPlexAgentInfo = async () => {
  try {
    // 헬프나우 콘솔에서 외부 채널 정보 API ㅎ로출하기
    const res = await plexInfo(getDomainInfo().chatbotCode)
    if (!res) {
      console.warn('플렉스 정보 응답이 X')
      return
    }

    // 헬프나우 콘솔에서 외부 채널 플래그 담기
    plexUseYn.value = res.plexUseYn ?? false

    const info = res.plexInfo
    if (!info || !info.chatbotLoginLogoImg) {
      console.warn('chatbotLoginLogoImg 정보가 없음')
      return
    }

    // 이미지 로드 ( 헬프나우 콘솔에서 외부 채널 셋팅한 값chatbotLoginLogoImg -> 이미지 API 태워서 넣는 부분)
    try {
      logoImg.value = await startupApi.getPlexImg(
        getDomainInfo().chatbotCode,
        info.chatbotLoginLogoImg
      )

    } catch (imgErr) {
      console.log('로고 이미지 로드 실패:', imgErr)
    }
  } catch (err) {
    console.log('플렉스 인포 불러오기 실패:', err)
    plexUseYn.value = false
  }
}

// AnswerWrapper WelcomeWrapper 화면에서 표시하는 플래그 값
function _setLoadingPage(value) {
  isLoading.value = value;
}
/*
* 다른 채팅 선택 시 발동 하는 함수
* */
async function onSelectedConversation(sessionData) {
  // 세션 전체를 먼저 커밋
  store.commit('setSession', sessionData);
  _setLoadingPage(true);

  await _refreshConversationList(sessionData.session_id);
  await _refreshAnswerList(sessionData.session_id);

  _setLoadingPage(false);
}




async function _refreshConversationList(sessionId) {
  const payload = { email: store.state.loginUser.userEmail };
  const convArr = await callConversationList(payload);

  const currConv = convArr.find(e => e.session_id === sessionId) || {};

  // convList 포함해서 세션 통째로 교체
  store.commit('setSession', { ...currConv, convList: convArr });
}


async function _refreshAnswerList(sessionId) {
  const payload = { email: store.state.loginUser.userEmail, session_id: sessionId };
  const chatMsgArr = await callConversationListAnswer(payload);
  // 기존 세션에 answerList만 업데이트
  store.commit('setSession', { ...store.getters.session, answerList: chatMsgArr, isNew: false });
  // showWelcome 은 앤서래퍼, 웰컴래퍼 화면에 표시하는 부분 isLoading 이랑 같이 사용
  store.commit('setShowWelcome', !chatMsgArr.some(item => item.title));
}

function deleteConversation(convItem) {
  lnbRef.value?.deleteFromRequest(convItem);
}

function submitQuery(value) {
  currSession.value.isInit = true;
  currSession.value.initValue = value;
  store.commit('setSession', currSession.value);
  store.commit('setShowWelcome', false);
}

function onShareConversation(convItem) {
  headerRef.value?.shareFromRequestModal(convItem);
}

function handleNewSessionCreated(newSession) {
  // LnbWrapper에 새로운 세션 추가
  if (lnbRef.value && lnbRef.value.addNewConversation) {
    lnbRef.value.addNewConversation(newSession);
  }
}

function onSelectedAnswer(answerItem) {
  contentRef.value?.$refs?.answerRef?.onGoAnswer(answerItem);
}

function getQueryParams(param) {
  const result = window.location.search.match(new RegExp("(\\?|&)" + param + "(\\[\\])?=([^&]*)"));
  return result ? result[3] : false;
}

function parseJwt(token) {
  const base64Url = token.split('.')[1];
  const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
  const jsonPayload = decodeURIComponent(
    atob(base64)
      .split('')
      .map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
      .join('')
  );
  return JSON.parse(jsonPayload);
}

function getTokenInfo(sso_token) {
  const userInfo = parseJwt(sso_token);
  const loginUser = {
    userEmail: userInfo.email,
    lastName: userInfo.family_name,
    userNm: userInfo.family_name,
    userId: userInfo.sub,
  };
  store.commit('setLoginUser', loginUser);
}

function ssoStart() {
  tokenKey.value = 'ACCESS_TOKEN';
  store.commit('setSubDomain', '');
  cookies.remove(tokenKey.value);

  ssoService.init().then(keycloak => {
    keycloak.onReady = async (authenticated) => {
      if (!authenticated) {
        const uuid = getQueryParams('uuid');
        const token_url = getQueryParams('token_url');
        if (uuid && token_url) {
          const response = await axios.post(decodeURIComponent(token_url), JSON.stringify({ uuid }));
          const sso_token = response.data?.access_token;
          if (sso_token) {
            cookies.set(tokenKey.value, sso_token, '1y', '/');
            getTokenInfo(sso_token);
            return;
          }
        }
        store.commit('setCheckLogin', true);
        ssoService.login();

      }
      pageStart.value = true;
    };

    keycloak.onAuthSuccess = () => {
      getTokenInfo(keycloak.token);
      cookies.set(tokenKey.value, keycloak.token, '1y', '/');
    };

    keycloak.onTokenExpired = () => {
      keycloak.updateToken(60).then(refreshed => {
        if (refreshed) {
          cookies.set(tokenKey.value, keycloak.token, '1y', '/');
        } else {
          window.location.reload();
        }
      }).catch(e => {
        console.log('error login', e);
        window.location.reload();
      });
    };

    keycloak.onAuthError = (e) => {
      console.log('Auth Error', e);
    };
  });
}

function getApiByEnviroment() {
  axios.get(getServerUrl(`general/frontProfile`), { excludeToken: true })
    .then(res => res.data)
    .then(() => {
      store.commit('setTokenKey', 'ACCESS_TOKEN');
      ssoStart();
    })
    .catch(error => {
      console.log("general/frontProfile error", error);
    });
}
</script>


