import { createRouter, createWebHistory } from 'vue-router';
import ContentWrapper from '../views/questionAnswer/ContentWrapper';
import FileMangeWrapper from '../views/fileManage/fileMange.vue';
import DocumentWrapper from '@/views/docsAnswer/DocumentWrapper.vue';
import DocumentAnswerWrapper from '@/views/docsAnswer/DocumentAnswerWrapper.vue';
import DocumentDriveWrapper from '@/views/docsAnswer/DocumentDriveWrapper.vue';
import DiscoverWrapper from '@/layouts/common/DiscoverWrapper.vue';
import AnswerWrapperViewer from '@/views/questionAnswer/AnswerWrapperViewer.vue';
import ConversationHistoryWrapper from '@/views/convHistory/ConversationHistoryWrapper.vue';
import AgentChatWrapper from '@/views/agentChat/AgentChatWrapper.vue';

const routes = [
  {
    path: '/',
    name: 'Main',
    component: ContentWrapper,
    meta: { layout: false },
  },
  {
    path: '/FileTabMangeWrapper',
    name: 'FileMangeWrapper',
    component: FileMangeWrapper,
    meta: { layout: true },
  },
  {
    path: '/AnswerWrapperViewer',
    name: 'AnswerWrapperViewer',
    component: AnswerWrapperViewer,
    meta: { layout: true },
  },
  {
    path: '/ShareWrapper',
    name: 'ShareWrapper',
    component: FileMangeWrapper,
    meta: { layout: true },
  },
  {
    path: '/DiscoverWrapper',
    name: 'DiscoverWrapper',
    component: DiscoverWrapper,
    meta: { layout: true },
  },
  {
    path: '/DocumentWrapper',
    name: 'DocumentWrapper',
    component: DocumentWrapper,
    meta: { layout: true },
  },
  {
    path: '/DocumentAnswerWrapper',
    name: 'DocumentAnswerWrapper',
    component: DocumentAnswerWrapper,
    meta: { layout: true },
  },
  {
    path: '/DocumentDriveWrapper',
    name: 'DocumentDriveWrapper',
    component: DocumentDriveWrapper,
    meta: { layout: true },
  },
  {
    path: '/ConversationHistoryWrapper',
    name: 'ConversationHistoryWrapper',
    component: ConversationHistoryWrapper,
    meta: { layout: true },
  },
  {
    path: '/AgentChatWrapper',
    name: 'AgentChatWrapper',
    component: AgentChatWrapper,
    meta: { layout: true },
  }
];

// 라우터 생성
const router = createRouter({
  history: createWebHistory(),
  routes,
});

// 라우터 추출 (main.js에서 import)
export { router };
