import { createI18n } from 'vue-i18n';
import en from '@/lang/en.json';
import ko from '@/lang/ko.json';
import zh from '@/lang/zh.json';
import ja from '@/lang/ja.json';
import indo from '@/lang/indo.json';

export const i18n = createI18n({
  legacy: false,
  globalInjection: true,
  locale: 'ko',
  fallbackLocale: 'ko',
  messages: {
    en, ko, zh, ja, indo,
  },
});
