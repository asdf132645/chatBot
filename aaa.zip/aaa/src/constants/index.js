/**
 * Created by sungho.hong on 2019-03-06.
 */

export default Object.freeze({
  /* Language */
  ENGLISH: 'en',
  KOREAN: 'ko',
  CHINESE: 'zh',
  AUTH_TYPE: {
    EDIT: 'AUTH_TYPE_010',
    VIEW: 'AUTH_TYPE_020',
    NONE: 'AUTH_TYPE_030',
  },
  /* SSO 관련 */
  ACCESS_TOKEN: 'ACCESS_TOKEN', // 개발계 엑세스 토큰
  /* Environment */
  LOCAL: 'LOCAL', // 로컬
  DEV: 'DEV', // 개발
  STAGE: 'STAGE', // 개발
  PROD: 'PROD', // 운영
});
