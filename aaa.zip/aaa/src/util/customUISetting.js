import { SERVER_URL } from '@/constants/constants';

export class CustomUISetting {
  constructor(){
    this.chatbotImg = `${SERVER_URL}s3-image/chatImg.svg`;
    this.chatbotName ="AI Chatbot";
    this.headerName ="AI Chatbot";
    this.floating ="#0ACD7F";
    this.floatingCloseText ="";
    this.background ="#EAEAEA";
    this.userBubble ="#0ACD7F";
    this.chatbotBubble ="#FFFFFF";
    this.header ="#3C4455";
    this.headerFont ="#FFFFFF";
    this.userFont ="#FFFFFF";
    this.chatbotFont ="#000000";
    this.chatbotNameFont ="#000000";
    this.greetings ="#FFFFFF";
    this.greetingsFont ="#000000";
    this.borderBox = "#3C4455";
    this.btnBackground = "#f1f1f1";
    this.btnFont = "#000000";
    this.suggestionBorder = "#AAAAAA";
    this.arrowBtnBackground = "#B0B6BD";
    this.arrowBtnFont = "#FFFFFF";
    this.sendBtnBackground = "#3C4455";
    this.sendBtnFont = "#FFFFFF";
    this.isSubmitOnEnter = false;
    this.favoriteBtnFont = "#B0B6BD";
    this.suggestionFont = "#000000";
    this.timestampFont="#B7BCCE";
    this.focusRing="#000000";
    this.iconDeco = false;
    this.profileRoundRemove = false;
    this.imageUpload = false;
    this.floatingIconClose = false;
    this.chatbotImgChanged = false;
    this.userFontSize = 12;
    this.chatbotFontSize = 12;
    this.responseSpeed = 10;
    this.floatingIconSize = 45;
    this.conversationSettings = 'basic';
    this.suggestionType = 'basicStyle';
    this.headerStyleType = 'html'
    this.desc = "";
    this.fixedQuestions = [];
    this.chattingMsg = '궁금한 사항을 입력해 주세요';
    this.htmlWidgetOpen = 'inline';
    this.aiResponseEnable = false;
    this.aiResponsePlatform = false;
    this.recommendEnabled = false; 
    this.aiResponseOption = "hybrid"
    this.aiResponseSimple = false
    this.multiTurn = true;
    this.multiTurnTimes = 3;
    this.optimizedAiQuery = false, 
    this.optimizedLlmKeyId = "", 
    this.optimizedAiResponsePlatform = "", 
    this.greetingsUseYn = false;
    this.greetingsView = "basic";
    this.chatbotHeaderImageUrl = ''; 
    this.satisfactionUseYn = false; 
    this.satisfactionType = '';
    this.greetingsCloseCnt = 1;
    this.dialogFeedbackEnable = false; 
    this.dialogFeedbackSettings = {
      up:'',
      down: '',
      reasons: [],
      reasonsYn: false,
      opinionYn: false,
    };
    this.chatbotFloatingImageUrl = '';
  }
}