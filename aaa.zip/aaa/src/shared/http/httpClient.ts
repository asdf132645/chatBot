import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios'
import { getAccessToken } from './tokens'

/**
 *  사용 법 예시
 *  1. 기본 요청은 기존 코드 그대로 사용 가능
 *  httpClient.post('/백엔드 API 주소', 페이로드)
 *
 *  2. 토큰을 제외 시키고 보내고자 할 때
 *  httpClient.get('/백엔드 API 주소', { excludeToken: true })
 *
 *  3. 헤더 컨텐트 타입을 폼데이터로 하고 싶은 경우 ( Multipart/FormData 업로드 // Content-Type 헤더는 삭제 → 브라우저가 boundary 설정 )
 * const form = new FormData()
 * form.append('file', fileInput.files[0])
 * httpClient.post('/백엔드 API 주소', form)
 *
 * 4. 직접 헤더 지정이 필요할 때
 * httpClient.post(
 *   '/백엔드 API 주소',
 *   페이로드,
 *   { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
 * )
 * */


// 커스텀 Axios 인스턴스 생성
// baseURL 없음, 기본 timeout만 설정
const instance: AxiosInstance = axios.create({
  timeout: 7000,
})

// 요청 인터셉터
instance.interceptors.request.use(
  (config: AxiosRequestConfig & { excludeToken?: boolean }) => {
    const token = getAccessToken()
    const { excludeToken = false } = config

    //  authorization 헤더 자동 부착
    if (token && !excludeToken) {
      config.headers = {
        ...(config.headers || {}),
        Authorization: `Bearer ${token}`,
      }
    }

    // Content-Type 헤더 처리
    // 호출 시 config.headers에 명시된 Content-Type이 있으면 그대로 사용
    const headers = config.headers || {}
    const contentTypeKey = Object.keys(headers).find(
      key => key.toLowerCase() === 'content-type'
    )

    if (!contentTypeKey) {
      // 명시된 Content-Type이 없을 때만 처리
      if (config.data instanceof FormData) {
        // FormData: 브라우저가 boundary를 자동 설정하게 두기 위해 Content-Type 제거
        delete headers['Content-Type']
        delete headers['content-type']
      } else {
        // JSON 데이터: 기본 Content-Type 설정
        headers['Content-Type'] = 'application/json'
      }
      config.headers = headers
    }

    return config
  },
  (error) => Promise.reject(error)
)

// HTTP 요청 래퍼
export const httpClient = {
  get<T = any>(url: string, config?: AxiosRequestConfig): Promise<T> {
    return instance.get<T>(url, config).then((res: AxiosResponse<T>) => res)
  },

  post<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> {
    return instance.post<T>(url, data, config).then((res: AxiosResponse<T>) => res)
  },

  put<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> {
    return instance.put<T>(url, data, config).then((res: AxiosResponse<T>) => res)
  },

  patch<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> {
    return instance.patch<T>(url, data, config).then((res: AxiosResponse<T>) => res)
  },

  delete<T = any>(url: string, config?: AxiosRequestConfig): Promise<T> {
    return instance.delete<T>(url, config).then((res: AxiosResponse<T>) => res)
  },
}
