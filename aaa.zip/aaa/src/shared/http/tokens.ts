// 토큰 관리
import VueCookies from 'vue-cookies'
import GlobalConstants from '@/constants'

export function getAccessToken(): string | null {
  return VueCookies.get(GlobalConstants.ACCESS_TOKEN) || null
}
