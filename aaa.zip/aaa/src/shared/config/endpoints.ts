// src/shared/config/endpoints.ts

import { resolveAgwUrl, agwUrl, agwUrlSub, resolveAgwUrlGenAiServer } from './env';
import _get from 'lodash/get';

// 공용 URL 정의
export const SERVER_URL = window?.opsbotFrontProfile?.serverUrl
  ? `${window.opsbotFrontProfile.serverUrl}/api/`
  : resolveAgwUrl('server', 'https://bb8-server-dev.dev.helpnow.ai/api/') + '/';

export const RAG_SSE_PATH = '/api/rag/agent-code';

export const RAG_ROUTE_PATH = 'api/bb8-tools-router/v1/tools/summary'

// Agent Chat 엔드포인트
export const AGENT_CHAT_RETRIEVE_PATH = '/api/bb8-agent/v1/retrieve';
export const AGENT_CHAT_STREAM_PATH = '/api/bb8-agent/v1/stream';


export const CHATBOT_ASSIST_URL = resolveAgwUrl('assist', 'https://bb8-assist-dev.dev.helpnow.ai')
export const CHATBOT_URL = (() => {
  // resolveAgwUrl 으로 가져오되 기본값에 `/api` 붙여주는 형태
  const raw = resolveAgwUrl(
    'server',
    'https://bb8-server-dev.dev.helpnow.ai/api'
  )
  // 끝에 슬래시 여러 개 제거 & 단일 슬래시 보장
  return raw.replace(/\/+$/, '') + '/'
})()
// https://bb8-genai-indexer-server-sandbox.dev.helpnow.ai/img
export const CHATBOT_INDEXER_ASSIST_URL = resolveAgwUrl('genai-indexer-server', 'https://bb8-genai-indexer-server-dev.dev.helpnow.ai')
export const CHATBOT_CHAT_URL = resolveAgwUrl('chat', 'https://bb8-chat-dev.dev.helpnow.ai')
export const CHATBOT_PROXY_URL = resolveAgwUrl('proxy', 'https://bb8-proxy-dev.dev.helpnow.ai')
export const CHATBOT_LOGGER_URL = resolveAgwUrl('logger', 'https://bb8-logger-dev.dev.helpnow.ai')
export const CHATBOT_FILE_MGR_URL = resolveAgwUrl('filemgr', 'https://bb8-filemgr-dev.dev.helpnow.ai')
export const CHATBOT_PLEX_SERVER_URL = resolveAgwUrl('plex-server', 'https://bb8-plex-server-dev.dev.helpnow.ai/api')
export const RAG_SERVER_URL = resolveAgwUrl('rag', 'https://bb8-rag-dev.dev.helpnow.ai')
export const RAG_ROUTE_URL = resolveAgwUrl('tools-router', 'https://bb8-tools-router-dev.dev.helpnow.ai')
export const AGENT_SERVER_URL = resolveAgwUrl('agent', 'https://bb8-agent-sandbox.dev.helpnow.ai')

export const GENAI_SERVER_URL = (() => {
  if (window?.opsbotFrontProfile?.assistUrl) {
    return window.opsbotFrontProfile.assistUrl
  }
  if (agwUrl) {
    const sub = agwUrlSub ?? ''
    return `${agwUrl}/genai-server${sub}/genai-server`
  }
  return 'https://bb8-api-proxy.dev.helpnow.ai/genai-server-sandbox/genai-server'
})()

// 인증 관련 파라미터
export const SSO_PARAM = {
  realm: process.env.VUE_APP_REALM,
  clientId: process.env.VUE_APP_CLIENT_ID,
}

// API 호출 상태 코드
export const API_STATUS = {
  FAIL: 'fail',
  OK: 'OK',
}

// 사용자 역할 키
export const ROLE = {
  PLATFORM_ADMIN: '관리자(대표계정)',
  ADMIN: '관리자',
  USER: '사용자',
}

// 서비스 상태 변경 메시지
export const CHANGE_STATUS = {
  STOP: '서비스 중지 요청이 처리되었습니다.',
  RESTART: '서비스 재시작이 처리되었습니다.',
  TERMINATE: '회사명’에 대한 서비스 해지 요청이 처리되었습니다.',
}



export function getFullChatbotUrl(apiEndpoint) {
  return `${CHATBOT_URL}${apiEndpoint}`;
}

export function isFailResponse(response) {
  return _get(response, 'data.status') === API_STATUS.FAIL;
}

export function getServerUrl(apiEndpoint) {
  return `${SERVER_URL}${apiEndpoint}`;
}

// sandbox genai indexer (이미지 등 정적 리소스)
export const GENAI_INDEXER_SANDBOX_URL = resolveAgwUrlGenAiServer(
  'https://bb8-filemgr-dev.dev.helpnow.ai'
);


// 예: /img/<fileId> 같은 이미지 경로 만들기
export function getGenaiIndexerSandboxImgUrl(fileId: string) {
  const base = GENAI_INDEXER_SANDBOX_URL.replace(/\/+$/, '');
  const id = String(fileId || '').replace(/^\/+/, '');
  return `${base}${fixUrl(fileId)}`;
}

function fixUrl(url) {
  // knowledgeDocs → knowledge-docsChat
  let replaced = url.replace("knowledgeDocs", "knowledge-docsChat");

  //   knowledge-docsChat 뒤에 /views 붙여줌
  replaced = replaced.replace(/\/views$/, "");
  replaced = replaced.replace(/(knowledge-docs)/, "$1/views");

  return replaced;
}

// 보고서 파일 조회 경로 조립 헬퍼
export const ragReportFilesUrl = (agentCode: string, sessionId: string, queryId) =>
  `${RAG_SERVER_URL}${RAG_SSE_PATH}/${encodeURIComponent(agentCode)}/session-id/${encodeURIComponent(sessionId)}/query-id/${encodeURIComponent(queryId)}/report-files`;

// 에이전트 에디터 SSE 엔드포인트 조립 헬퍼
export const ragEditorSseUrl = (agentCode: string) =>
  `${RAG_SERVER_URL}${RAG_SSE_PATH}/${encodeURIComponent(agentCode)}/agents/editor`;

export const ragRouterUrl = (agentCode: string) =>
  `${RAG_ROUTE_URL}/${RAG_ROUTE_PATH}/${encodeURIComponent(agentCode)}`;