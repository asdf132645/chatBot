// 동적 AGW URL 구성
export let agwUrl = ''
export let agwUrlSub = ''

window.opsbotFrontProfile = {
  agwUrl: process.env.VUE_APP_AGW_URL || "https://bb8-api-proxy.helpnow.ai",
  agwUrlSub: process.env.VUE_APP_AGW_URL_SUB || "",
  realm: process.env.VUE_APP_REALM || "",
}

if(window.opsbotFrontProfile){
  agwUrl = window.opsbotFrontProfile.agwUrl;
  agwUrlSub = window.opsbotFrontProfile.agwUrlSub;
}

if(agwUrlSub){
  agwUrlSub = `-${agwUrlSub}`
}

// 최종 base URL (공통)
export const AGW_BASE_URL = `${agwUrl}${agwUrlSub}`

// 서비스별 최종 URL 생성 함수
export const resolveAgwUrl = (service: string, fallback: string): string => {
  if (window?.opsbotFrontProfile?.[`${service}Url`]) {
    return window.opsbotFrontProfile[`${service}Url`]
  }
  return agwUrl ? `${agwUrl}/${service}${agwUrlSub}` : fallback
}

export const resolveAgwUrlGenAiServer = ( fallback: string): string => {
  return agwUrl ? `${agwUrl}/filemgr${agwUrlSub}` : fallback
}
