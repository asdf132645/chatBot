export default {
    BILLING: {},
    CLIENT: {},
    SETTINGS: {

    },
    PORTAL: {},
    PRODUCT: {},
    SSO: {
    },
    ChATBOT: {
        LIVE_CHAT: {
            LOGGER: 'logger',
            CUSTOM_UI: 'custom-ui',
            CHECK_LOGIN: 'agent/checkLogin',
            // CHATTING: 'user/data',
            CHATTING_BEGIN: 'user/data_begin', // chatbot 대화창 생성
            CHATTING_END: 'user/data_end', // 상담원 연결 없이 chatbot 대화 종료
            CHATTING_TRANSFER: 'user/data_transfer', // 상담원 연결 - live chat 연결
            CHATTING_PROCESSING: 'user/data_processing', // 사용자 대화 시작
            CHATTING_SECURE: 'user/secure', // 사용자 민감정보
            CHATTING_SURVEY: 'user/survey', // 사용자 만족도
            CONNECT_AGENT: 'user/connnect_agent', // 스킬 연결
            WAIT_CNT: 'user/wait_cnt', // 대기자 수, 대기 시간
            AGENT_PROCESSING_CNT: 'user/agent_processing_cnt',
            ROOMS: 'rooms',
            USER: 'liveChat/user',
            USER_AGENT: 'liveChat/sessionAgentId',
            USER_PIN: 'liveChat/sessionPin',
            AGENT: 'liveChat/agent',
            AGENT_GET: 'liveChat/getAgent',
            AGENT_GET_CHAT: 'liveChat/getAgentChat',
            USER_UPDATE: 'liveChat/updateUser',
            AGENT_USER_UPDATE: 'liveChat/agentUpdateUser',
            USER_CREATE: 'liveChat/insertUser',
            USER_SESSION:{
              CREATE: 'liveChat/insertSession'
            },
            LOG_LIST: 'liveChat/logList',
            LC_LOG_LIST: 'liveChat/lcLogList',
            USER_PROFILE: 'liveChat/userProfileList',
            USER_PROFILE_ID: 'liveChat/userProfileId',
            SESSION_HISTORY: 'liveChat/sessionHistory',
            LOG_SKILL: 'liveChat/logSkill',
            SESSION_LIST: 'liveChat/sessionList',
            TALK: 'liveChat/talk',
            CLASS: 'liveChat/class',
            CLASS_ALL: 'liveChat/classAll',
            CLASS_LIST: 'liveChat/classList',
            CLASS_UPLOAD_LIST: 'liveChat/uploadClassList',
            CLASS_LIST_GET: 'liveChat/classList/get',
            CLASS_TYPE_LIST: 'liveChat/classTypeList',
            CLASS_MAIN: 'liveChat/classMain',
            BAN: 'liveChat/ban',
            SURVEY: 'liveChat/survey',
            STYLE: 'liveChat/style',
            TAG: 'liveChat/tag',
            TAG_LIST: 'liveChat/tagList',
            SKILL: 'liveChat/skill',
            SKILL_LIST: 'liveChat/skillList',
            SKILL_SELECT: 'liveChat/skillSelect',
            SECURE_LIST: 'liveChat/secureList',
            SECURE_GET: 'liveChat/secure/get',
            SECURE: 'liveChat/secure',
            DAY_OFF: 'liveChat/dayOff',
            DAY_OFF_LIST: 'liveChat/dayOffList',
            WORK_HOURS: 'liveChat/workHours',
            WORK_HOURS_LIST: 'liveChat/workHoursList',
            WORK_HOURS_TOGGLE: 'liveChat/workHoursToggle',
            ASSIGN_BASIC: 'liveChat/assignBasic'
          },
    }
}