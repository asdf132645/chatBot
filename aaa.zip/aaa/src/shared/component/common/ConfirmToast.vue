<template>
  <!-- body 최상단으로 순간이동 -->
  <teleport to="body">
    <div class="document-wrapper-confirm-toast-overlay">
      <div class="document-wrapper-confirm-toast">
        <div class="document-wrapper-confirm-message">
          {{ message }}
        </div>
        <div class="document-wrapper-confirm-actions">
          <button
            class="document-wrapper-confirm-btn document-wrapper-confirm-btn-danger"
            @click="$emit('resolve', true)"
          >
            {{ confirmText }}
          </button>
          <button
            class="document-wrapper-confirm-btn document-wrapper-confirm-btn-cancel"
            @click="$emit('resolve', false)"
          >
            {{ cancelText }}
          </button>
        </div>
      </div>
    </div>
  </teleport>
</template>

<script setup>
import { defineProps, defineEmits } from 'vue'

defineProps({
  message: { type: String, default: '이 작업을 진행하시겠습니까?' },
  confirmText: { type: String, default: '확인' },
  cancelText: { type: String, default: '취소' }
})

defineEmits(['resolve'])
</script>

<style scoped>
.document-wrapper-confirm-toast-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.35);
  display: flex;
  align-items: flex-start; /* 위쪽 배치 */
  justify-content: center;
  padding-top: 80px; /* 위에서 살짝 내려옴 */
  z-index: 9999;
}

.document-wrapper-confirm-toast {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  padding: 16px 20px;
  min-width: 300px;
  max-width: 420px;
  border-radius: 10px;
  background: #fff;
  border: 1px solid #e5e5e5;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.12);
  animation: slideDown 0.25s ease-out;
}

@keyframes slideDown {
  from {
    transform: translateY(-20px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

.document-wrapper-confirm-message {
  font-size: 15px;
  font-weight: 500;
  text-align: center;
  color: #333;
  line-height: 1.5;
}

.document-wrapper-confirm-actions {
  display: flex;
  gap: 10px;
  justify-content: center;
  margin-top: 6px;
}

.document-wrapper-confirm-btn {
  padding: 6px 14px;
  border-radius: 6px;
  border: none;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.document-wrapper-confirm-btn-danger {
  background: #e5484d;
  color: #fff;
}
.document-wrapper-confirm-btn-danger:hover {
  background: #d33d42;
}

.document-wrapper-confirm-btn-cancel {
  background: #f4f4f4;
  color: #333;
}
.document-wrapper-confirm-btn-cancel:hover {
  background: #e5e5e5;
}
</style>
