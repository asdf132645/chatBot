<template>
  <Teleport to="#toast-message-destination">
    <div class="toast-wrapper">
      <CustomToast
        v-for="toast in toasts"
        :key="toast.id"
        :message="toast.message"
        :type="toast.type"
        :show-close-button="toast.showCloseButton"
        :auto-close="toast.autoClose"
        :duration="toast.duration"
        @close="removeToast(toast.id)"
      />
    </div>
  </Teleport>
</template>

<script setup>
import { useCustomToast } from '@/composables/useCustomToast'
import CustomToast from './CustomToast.vue'
const { toasts, removeToast } = useCustomToast()
</script>
