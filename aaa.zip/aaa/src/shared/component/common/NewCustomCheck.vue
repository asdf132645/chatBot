<template>
  <div class="custom-check" :class="{ disabled: disabled }">
    <input
      type="checkbox"
      :id="id"
      :name="radioName"
      class="custom-input"
      :checked="modelValue"
      @change="onChange"
    />
    <label
      class="custom-check-label"
      :class="{ 'label-none': !label }"
      :for="id"
    >
      {{ label }}
    </label>
  </div>
</template>

<script setup>

import { defineProps, defineEmits } from 'vue'

defineProps({
  modelValue: Boolean,
  id: String,
  label: String,
  radioName: String,
  disabled: Boolean,
})


const emit = defineEmits(['update:modelValue'])

function onChange(event) {
  emit('update:modelValue', event.target.checked)
}
</script>
