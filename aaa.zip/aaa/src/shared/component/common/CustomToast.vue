<template>
  <div v-if="visible" class="custom-toast" :class="toastClass">
    <div class="toast-content">
      <div class="toast-message">{{ message }}</div>
      <button v-if="showCloseButton" @click="close" class="close-button" aria-label="닫기">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, defineProps, defineEmits } from 'vue'

const props = defineProps({
  message: {
    type: String,
    required: true
  },
  type: {
    type: String,
    default: 'info', // success, error, warning, info
    validator: (value) => ['success', 'error', 'warning', 'info'].includes(value)
  },
  showCloseButton: {
    type: Boolean,
    default: true
  },
  autoClose: {
    type: Boolean,
    default: false
  },
  duration: {
    type: Number,
    default: 3000
  }
})

const emit = defineEmits(['close'])

const visible = ref(false)

const toastClass = computed(() => {
  return {
    'toast-success': props.type === 'success',
    'toast-error': props.type === 'error',
    'toast-warning': props.type === 'warning',
    'toast-info': props.type === 'info'
  }
})

const close = () => {
  visible.value = false
  setTimeout(() => {
    emit('close')
  }, 300) // 애니메이션 시간과 맞춤
}

onMounted(() => {
  visible.value = true
  
  if (props.autoClose) {
    setTimeout(() => {
      close()
    }, props.duration)
  }
})
</script>

<style scoped>

</style>
