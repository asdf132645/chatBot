<template>
  <Teleport to="body">
    <transition name="fade">
      <div v-if="visible" :class="['base-toast', type]">
        {{ message }}
      </div>
    </transition>
  </Teleport>
</template>

<script setup>
import { ref, defineExpose } from 'vue'

const visible = ref(false)
const message = ref('')
const type = ref('success')

function show(msg, toastType = 'success') {
  message.value = msg
  type.value = toastType
  visible.value = true
  setTimeout(() => {
    visible.value = false
  }, 3000)
}

defineExpose({ show })
</script>

