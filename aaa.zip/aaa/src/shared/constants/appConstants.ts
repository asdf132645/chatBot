// 공통 상수 정의

export const API_STATUS = {
  FAIL: 'fail',
  OK: 'OK',
} as const

export const ROLE = {
  PLATFORM_ADMIN: '관리자(대표계정)',
  ADMIN: '관리자',
  USER: '사용자',
} as const

export const CHANGE_STATUS = {
  STOP: '서비스 중지 요청이 처리되었습니다.',
  RESTART: '서비스 재시작이 처리되었습니다.',
  TERMINATE: '회사명’에 대한 서비스 해지 요청이 처리되었습니다.',
} as const
