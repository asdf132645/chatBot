const { defineConfig } = require('@vue/cli-service')
const path = require('path')
const webpack = require('webpack')

module.exports = defineConfig({
  css: {
    loaderOptions: {
      scss: {
        additionalData: `
          @use "src/assets/css/scss/_variables.scss" as *;
          @use "src/assets/css/scss/_mixins.scss" as *;
        `
      }
    }
  },
  chainWebpack: config => {
    // ts 설정
    config.module
      .rule('ts')
      .test(/\.ts$/)
      .use('babel-loader')
      .loader('babel-loader')
      .end()

    // vue 설정
    config.module
      .rule('vue')
      .use('vue-loader')
      .tap(options => {
        return options
      })

    // 💡 HTML Webpack Plugin의 title 조건 분기
    config.plugin('html').tap(args => {
      const isPlex = process.env.VUE_APP_REALM === 'plex' || process.env.VUE_APP_REALM === 'nhn'
      args[0].title = isPlex ? 'plex' : '경기도청 BMT'
      return args
    })
  },
  configureWebpack: {
    resolve: {
      extensions: ['.ts', '.js', '.vue', '.json'],
      alias: {
        '@': path.resolve(__dirname, 'src') //  @ → src alias
      },
      fallback: {
        crypto: false
      }
    },
    plugins: [
      new webpack.DefinePlugin({
        __INTLIFY_PROD_DEVTOOLS__: JSON.stringify(false)
      })
    ]
  },
  transpileDependencies: true,
  productionSourceMap: false,
  devServer: {
    port: 8091,
    host: 'local.opsnow.com'
  }
})
